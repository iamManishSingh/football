#!/bin/bash

# Football Ball Detection - Setup Script
# This script sets up the complete development environment

echo "=================================="
echo "Football Ball Detection - Setup"
echo "=================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Node.js
echo "Checking Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    echo -e "${GREEN}✓${NC} Node.js found: $NODE_VERSION"
else
    echo -e "${RED}✗${NC} Node.js not found. Please install Node.js 18+ from https://nodejs.org/"
    exit 1
fi

# Check Python
echo "Checking Python..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo -e "${GREEN}✓${NC} Python found: $PYTHON_VERSION"
else
    echo -e "${RED}✗${NC} Python 3.9+ not found. Please install Python from https://python.org/"
    exit 1
fi

# Check FFmpeg
echo "Checking FFmpeg..."
if command -v ffmpeg &> /dev/null; then
    FFMPEG_VERSION=$(ffmpeg -version | head -n 1)
    echo -e "${GREEN}✓${NC} FFmpeg found"
else
    echo -e "${YELLOW}!${NC} FFmpeg not found. Install with:"
    echo "  macOS:     brew install ffmpeg"
    echo "  Ubuntu:    sudo apt install ffmpeg"
    echo "  Required for video processing module"
fi

echo ""
echo "=================================="
echo "Installing Dependencies"
echo "=================================="
echo ""

# Frontend setup
echo "Setting up Frontend..."
cd frontend
if [ ! -d "node_modules" ]; then
    echo "Installing frontend dependencies..."
    npm install
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} Frontend dependencies installed"
    else
        echo -e "${RED}✗${NC} Frontend installation failed"
        exit 1
    fi
else
    echo -e "${GREEN}✓${NC} Frontend dependencies already installed"
fi
cd ..

# Backend setup
echo ""
echo "Setting up Backend..."
cd backend
if [ ! -d "node_modules" ]; then
    echo "Installing backend dependencies..."
    npm install
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} Backend dependencies installed"
    else
        echo -e "${RED}✗${NC} Backend installation failed"
        exit 1
    fi
else
    echo -e "${GREEN}✓${NC} Backend dependencies already installed"
fi
cd ..

# Python setup
echo ""
echo "Setting up Python Environment..."
cd python_services

if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv venv
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} Virtual environment created"
    else
        echo -e "${RED}✗${NC} Failed to create virtual environment"
        exit 1
    fi
else
    echo -e "${GREEN}✓${NC} Virtual environment already exists"
fi

echo "Activating virtual environment and installing dependencies..."
source venv/bin/activate

if [ -f "requirements.txt" ]; then
    pip install --upgrade pip
    pip install -r requirements.txt
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓${NC} Python dependencies installed"
    else
        echo -e "${RED}✗${NC} Python installation failed"
        exit 1
    fi
else
    echo -e "${RED}✗${NC} requirements.txt not found"
    exit 1
fi

deactivate
cd ..

echo ""
echo "=================================="
echo "Setup Complete!"
echo "=================================="
echo ""
echo "Next Steps:"
echo ""
echo "1. Start Backend Server:"
echo "   ${GREEN}cd backend && npm run dev${NC}"
echo ""
echo "2. Start Frontend (in new terminal):"
echo "   ${GREEN}cd frontend && npm run dev${NC}"
echo ""
echo "3. Access Application:"
echo "   Frontend: ${GREEN}http://localhost:5173${NC}"
echo "   Backend:  ${GREEN}http://localhost:3000${NC}"
echo ""
echo "4. For Training Module, clone RF-DETR:"
echo "   ${YELLOW}cd python_services${NC}"
echo "   ${YELLOW}git clone [rf-detr-repo-url] rf-detr${NC}"
echo "   ${YELLOW}source venv/bin/activate${NC}"
echo "   ${YELLOW}cd rf-detr && pip install -e .${NC}"
echo ""
echo "See README.md for detailed documentation."
echo ""
