# 🚀 Getting Started - Visual Guide

## Step-by-Step Setup

### 1️⃣ Open Terminal and Navigate to Project

```bash
cd /Users/L034900/Library/CloudStorage/OneDrive-EliLillyandCompany/Documents/analytics_manish_learn/CV_Football
```

### 2️⃣ Run Automated Setup

```bash
./setup.sh
```

**What this does:**
```
✓ Checks Node.js installation
✓ Checks Python installation
✓ Checks FFmpeg installation
✓ Installs frontend dependencies (npm install)
✓ Installs backend dependencies (npm install)
✓ Creates Python virtual environment
✓ Installs Python packages
```

### 3️⃣ Start Backend Server (Terminal 1)

```bash
cd backend
npm run dev
```

**You should see:**
```
Server running on port 3000
Environment: development
WebSocket server ready
```

### 4️⃣ Start Frontend Server (Terminal 2 - New Tab)

```bash
cd frontend
npm run dev
```

**You should see:**
```
VITE v5.x.x ready in xxx ms

➜ Local:   http://localhost:5173/
➜ Network: use --host to expose
```

### 5️⃣ Open Your Browser

Navigate to: **http://localhost:5173**

**You should see:**
```
╔══════════════════════════════════════════════════╗
║  ⚽ Football Ball Detection                      ║
║  Dashboard | Video | Annotation | Prepare | Train║
╚══════════════════════════════════════════════════╝

Welcome to the CV Pipeline
Complete end-to-end pipeline for football ball detection using RF-DETR

[Metrics Cards showing: Extracted Frames, Annotated Images, etc.]

Pipeline Workflow:
┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│ 1. Video    │  │ 2. Annotate │  │ 3. Prepare  │  │ 4. Training │
│ Processing  │  │             │  │ Dataset     │  │             │
└─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘
```

---

## 🎯 What You Can Do Now

### Explore the UI
✅ Click "Video Processing" → See video processing page
✅ Click "Annotation" → See annotation page
✅ Click "Data Preparation" → See data prep page
✅ Click "Training" → See training page

### Test Backend
✅ Open: http://localhost:3000/health
✅ Should return: `{"success": true, "message": "Server is running"}`

### Check WebSocket
✅ Open Browser Dev Tools (F12)
✅ Go to Network → WS tab
✅ Should see connected WebSocket

---

## 📁 Your Project Structure

```
CV_Football/
│
├── 📚 Documentation
│   ├── README.md                    ← Main docs
│   ├── QUICKSTART.md                ← This guide
│   ├── PROJECT_STATUS.md            ← Current status
│   ├── DEVELOPMENT_CHECKLIST.md     ← Task list
│   └── PROJECT_SUMMARY.md           ← Complete summary
│
├── 🎨 Frontend (Svelte)
│   ├── src/
│   │   ├── components/shared/       ← UI components
│   │   ├── stores/                  ← State management
│   │   ├── utils/                   ← Helper functions
│   │   ├── routes/                  ← Page components
│   │   └── App.svelte               ← Main app
│   └── package.json
│
├── 🔧 Backend (Node.js)
│   ├── src/
│   │   ├── controllers/             ← API logic
│   │   ├── routes/                  ← API routes
│   │   ├── services/                ← Business logic
│   │   ├── websocket/               ← Real-time comm
│   │   └── server.js                ← Entry point
│   └── package.json
│
├── 🐍 Python Services
│   ├── video_processing/
│   │   └── extract_frames.py        ← Frame extraction
│   ├── dataset/
│   │   └── dataset_splitter.py      ← Dataset split
│   ├── training/
│   │   └── train_rfdetr.py          ← Training
│   └── requirements.txt
│
├── ⚙️ Configuration
│   └── default_config.json          ← Settings
│
└── 💾 Data (gitignored)
    ├── raw_videos/                  ← Input videos
    ├── extracted_frames/            ← Extracted images
    ├── annotations/                 ← COCO JSON
    ├── labeled_images/              ← Labeled data
    ├── datasets/                    ← Train/val/test
    ├── models/                      ← Trained models
    └── logs/                        ← Application logs
```

---

## 🧪 Test the Python Scripts

### Test Frame Extraction

```bash
cd python_services
source venv/bin/activate

# Create a test video or use your own
python video_processing/extract_frames.py \
  --video_path /path/to/your/video.mp4 \
  --output_path ../data/extracted_frames \
  --target_count 100
```

**Output:**
```json
{"status": "processing", "progress": 25.0, "current_frame": 250, ...}
{"status": "processing", "progress": 50.0, "current_frame": 500, ...}
{"status": "completed", "extracted": 100, "output_path": "..."}
```

### Test Dataset Splitter

```bash
python dataset/dataset_splitter.py \
  --annotations /path/to/annotations.json \
  --images_dir /path/to/images \
  --output_dir ../data/datasets \
  --train_ratio 0.7 \
  --val_ratio 0.2 \
  --test_ratio 0.1
```

---

## 🔍 Verify Everything Works

### ✅ Checklist

- [ ] `./setup.sh` runs without errors
- [ ] Backend starts on port 3000
- [ ] Frontend starts on port 5173
- [ ] Dashboard loads in browser
- [ ] All navigation links work
- [ ] http://localhost:3000/health returns success
- [ ] Browser dev tools show WebSocket connected
- [ ] Python virtual environment created
- [ ] Python scripts can run standalone

---

## 🛠️ Common Issues & Solutions

### Port Already in Use

```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Kill process on port 5173
lsof -ti:5173 | xargs kill -9
```

### Python Command Not Found

Update `backend/.env`:
```
PYTHON_PATH=/usr/bin/python3
# Or wherever your Python is: which python3
```

### FFmpeg Not Found

```bash
# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt update && sudo apt install ffmpeg
```

### Dependencies Installation Failed

```bash
# Frontend
cd frontend
rm -rf node_modules package-lock.json
npm install

# Backend
cd backend
rm -rf node_modules package-lock.json
npm install

# Python
cd python_services
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

---

## 📖 Next: Implementation

### Choose Your Path

**Path A: Build Video Processing First** (Recommended)
- Easiest module
- See: `DEVELOPMENT_CHECKLIST.md` → Module 1
- Estimated time: 4-6 hours

**Path B: Build Annotation Interface**
- Core feature
- See: `DEVELOPMENT_CHECKLIST.md` → Module 2
- Estimated time: 8-10 hours

**Path C: Build All Modules**
- Complete implementation
- See: `DEVELOPMENT_CHECKLIST.md` → All Modules
- Estimated time: 25-30 hours

---

## 🎓 Learning Resources

### Svelte
- Official docs: https://svelte.dev/docs
- Tutorial: https://svelte.dev/tutorial

### Socket.IO
- Docs: https://socket.io/docs/
- Client API: https://socket.io/docs/v4/client-api/

### RF-DETR
- Will be cloned during training module implementation
- Research paper and GitHub repo links in README

---

## 💡 Quick Tips

1. **Two Terminals**: Always run backend and frontend in separate terminals
2. **Check Logs**: Backend logs are in `data/logs/combined.log`
3. **Hot Reload**: Both servers support hot reload - changes reflect automatically
4. **WebSocket**: Use browser dev tools to monitor WebSocket messages
5. **Python Env**: Always activate venv before running Python scripts

---

## 🎉 You're Ready!

Your development environment is fully set up. Start implementing modules and building your football ball detection system!

**Happy Coding! ⚽🚀**

---

**Need Help?** Check:
- README.md for detailed docs
- PROJECT_STATUS.md for current state
- DEVELOPMENT_CHECKLIST.md for tasks
- Browser console for frontend errors
- data/logs/ for backend errors
