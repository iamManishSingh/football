# Football Ball Detection - Computer Vision Pipeline

Complete end-to-end computer vision pipeline for football ball detection using RF-DETR (Real-time DEtection TRansformer) model.

## Project Overview

This system provides:
- **Video Processing**: Extract frames from football match videos
- **Annotation Interface**: Label football balls with bounding boxes
- **Data Preparation**: Split datasets into train/val/test sets
- **Model Training**: Train RF-DETR model with real-time monitoring
- **Full-Stack Application**: Svelte frontend + Node.js backend + Python microservices

## Architecture

```
┌─────────────────────────────────────────────┐
│          Svelte Frontend (Port 5173)        │
│  Video Processing | Annotation | Training   │
└────────────────┬────────────────────────────┘
                 │ HTTP/WebSocket
┌────────────────▼────────────────────────────┐
│       Node.js Backend API (Port 3000)       │
│  Express | Socket.IO | File Management      │
└────────────────┬────────────────────────────┘
                 │ Child Process / IPC
┌────────────────▼────────────────────────────┐
│         Python Microservices                │
│  OpenCV | PyTorch | RF-DETR | Training      │
└─────────────────────────────────────────────┘
```

## Tech Stack

- **Frontend**: Svelte 4 + Vite + Chart.js + Socket.IO Client
- **Backend**: Node.js + Express + Socket.IO + FFmpeg
- **Python**: OpenCV + PyTorch + RF-DETR + TensorBoard
- **Data Format**: COCO JSON

## Project Structure

```
CV_Football/
├── frontend/               # Svelte application
├── backend/                # Node.js API server
├── python_services/        # Python microservices
├── data/                   # Data storage (gitignored)
│   ├── raw_videos/
│   ├── extracted_frames/
│   ├── annotations/
│   ├── labeled_images/
│   ├── datasets/
│   ├── models/
│   └── logs/
└── config/                 # Configuration files
```

## Prerequisites

- **Node.js**: v18+ (for backend and frontend)
- **Python**: 3.9+ (for CV operations and ML)
- **FFmpeg**: For video processing (install via homebrew/apt)
- **GPU**: CUDA-capable GPU recommended for training (optional)

## Installation & Setup

### 1. Clone Repository

```bash
cd CV_Football
```

### 2. Frontend Setup

```bash
cd frontend
npm install
```

### 3. Backend Setup

```bash
cd backend
npm install
```

### 4. Python Environment Setup

```bash
cd python_services

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 5. RF-DETR Model Setup (For Training Module)

```bash
# This will be needed for Module 4 - Training
cd python_services
git clone https://github.com/[rf-detr-official-repo] rf-detr
cd rf-detr
pip install -e .
```

### 6. Install FFmpeg (if not already installed)

**macOS:**
```bash
brew install ffmpeg
```

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install ffmpeg
```

**Windows:**
Download from https://ffmpeg.org/download.html

## Running the Application

### Start Backend Server

```bash
cd backend
npm run dev
```

Backend will run on `http://localhost:3000`

### Start Frontend Development Server

```bash
cd frontend
npm run dev
```

Frontend will run on `http://localhost:5173`

### Verify Setup

1. Open browser: `http://localhost:5173`
2. You should see the Football Ball Detection Dashboard
3. Check backend health: `http://localhost:3000/health`

## Module Implementation Status

### ✅ Completed
- [x] Project structure setup
- [x] Frontend scaffolding (Svelte + Vite)
- [x] Backend API server (Node.js + Express)
- [x] WebSocket infrastructure
- [x] Python bridge service
- [x] Basic Python scripts (frame extraction, dataset splitter)
- [x] Shared components and utilities

### 🚧 To Be Implemented
- [ ] **Module 1: Video Processing** - Full UI and backend integration
- [ ] **Module 2: Annotation Interface** - Canvas-based annotation tool
- [ ] **Module 3: Data Preparation** - Complete dataset preparation UI
- [ ] **Module 4: RF-DETR Training** - Full training pipeline with real-time monitoring

## Usage Workflow

### Step 1: Video Processing
1. Navigate to "Video Processing" page
2. Select input video file from your local system
3. Configure extraction parameters (image count, format, quality)
4. Click "Start Extraction"
5. Monitor real-time progress
6. Extracted frames saved to `data/extracted_frames/`

### Step 2: Annotation
1. Navigate to "Annotation" page
2. Load extracted frames
3. Draw bounding boxes around football balls
4. Save annotations in COCO JSON format
5. Annotations saved to `data/annotations/`

### Step 3: Data Preparation
1. Navigate to "Data Preparation" page
2. Configure train/val/test split ratios (e.g., 70/20/10)
3. Click "Prepare Dataset"
4. Dataset organized in RF-DETR compatible format
5. Output saved to `data/datasets/`

### Step 4: Model Training
1. Navigate to "Training" page
2. Configure RF-DETR hyperparameters
3. Start training
4. Monitor real-time metrics:
   - Loss curves
   - mAP progression
   - GPU utilization
   - Training logs
5. Trained models saved to `data/models/`

## Configuration

Default configuration is in `config/default_config.json`. You can modify:
- Video extraction settings
- Annotation format
- Dataset split ratios
- Training hyperparameters (epochs, batch size, learning rate, etc.)

## API Endpoints

### Video Processing
- `POST /api/video/extract` - Start frame extraction
- `GET /api/video/info` - Get video metadata
- `POST /api/video/validate` - Validate video path

### Annotation
- `GET /api/annotations/unlabeled` - Get unlabeled images
- `POST /api/annotations/save` - Save annotation
- `GET /api/annotations/progress` - Get progress stats

### Dataset
- `POST /api/dataset/prepare` - Prepare train/val/test splits
- `GET /api/dataset/statistics` - Get dataset statistics

### Training
- `POST /api/training/start` - Start training
- `POST /api/training/stop` - Stop training
- `GET /api/training/status` - Get training status
- `GET /api/training/checkpoints` - List model checkpoints

## WebSocket Events

### Video Extraction
- `extraction_progress` - Real-time extraction progress
- `extraction_complete` - Extraction completed

### Training
- `training_progress` - Real-time training metrics
- `training_log` - Training logs
- `training_complete` - Training completed

## Development

### Adding New Features
1. Frontend: Add components in `frontend/src/components/`
2. Backend: Add controllers in `backend/src/controllers/`
3. Python: Add scripts in `python_services/`

### Debugging
- Backend logs: `data/logs/combined.log`
- Python output: Via WebSocket or stdout
- Frontend: Browser console

## Testing

Currently configured for manual testing through the UI.

### Manual Testing Checklist
- [ ] Video extraction with sample video
- [ ] Annotation interface with sample images
- [ ] Dataset preparation with sample annotations
- [ ] Training with minimal config (10 epochs, small dataset)

## Deployment

For production deployment:
1. Build frontend: `cd frontend && npm run build`
2. Use PM2 for Node.js process management
3. Set up Nginx as reverse proxy
4. Use environment variables for configuration
5. Consider Docker containers (Dockerfiles are in `docker/` directory)

## Troubleshooting

### Port Already in Use
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Kill process on port 5173
lsof -ti:5173 | xargs kill -9
```

### Python Not Found
```bash
# Update backend/.env
PYTHON_PATH=/path/to/your/python3
```

### FFmpeg Not Found
Install FFmpeg using your package manager (see Installation section)

### GPU Not Detected
Ensure PyTorch is installed with CUDA support:
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
```

## Performance Recommendations

- **GPU**: NVIDIA GPU with 8GB+ VRAM for training
- **RAM**: 16GB+ recommended
- **Storage**: SSD with 50GB+ free space
- **CPU**: Multi-core processor for faster frame extraction

## Contributing

This is a complete pipeline implementation. To extend:
1. Add new extraction modes (fixed FPS, keyframe detection)
2. Enhance annotation UI (multi-class, polygon annotation)
3. Add model export (ONNX, TensorRT)
4. Implement inference/prediction interface

## License

ISC

## Support

For issues and questions:
- Check the logs in `data/logs/`
- Review browser console for frontend errors
- Verify Python environment activation
- Ensure all dependencies are installed

## Acknowledgments

- RF-DETR: Real-time DEtection TRansformer
- COCO Dataset Format
- PyTorch and OpenCV communities

## Next Steps

1. Test the setup by running both servers
2. Implement remaining modules (Video Processing, Annotation, Training)
3. Add sample test data for validation
4. Train first model on your football footage

---

**Status**: Infrastructure complete. Ready for module implementation.

**Last Updated**: 2026-02-03
