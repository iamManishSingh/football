export async function getUnlabeledImages(req, res, next) {
  try {
    res.status(501).json({
      success: false,
      message: 'Annotation API not yet implemented'
    })
  } catch (error) {
    next(error)
  }
}

export async function saveAnnotation(req, res, next) {
  try {
    res.status(501).json({
      success: false,
      message: 'Annotation API not yet implemented'
    })
  } catch (error) {
    next(error)
  }
}

export async function getAnnotationProgress(req, res, next) {
  try {
    res.status(501).json({
      success: false,
      message: 'Annotation API not yet implemented'
    })
  } catch (error) {
    next(error)
  }
}
