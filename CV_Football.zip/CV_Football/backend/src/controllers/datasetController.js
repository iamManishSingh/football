export async function prepareDataset(req, res, next) {
  try {
    res.status(501).json({
      success: false,
      message: 'Dataset preparation not yet implemented'
    })
  } catch (error) {
    next(error)
  }
}

export async function getDatasetStatistics(req, res, next) {
  try {
    res.status(501).json({
      success: false,
      message: 'Dataset API not yet implemented'
    })
  } catch (error) {
    next(error)
  }
}
