import { AppError } from '../utils/errorHandler.js'

export async function extractFrames(req, res, next) {
  try {
    // Will be implemented in Module 1
    res.status(501).json({
      success: false,
      message: 'Video frame extraction not yet implemented'
    })
  } catch (error) {
    next(error)
  }
}

export async function getVideoInfo(req, res, next) {
  try {
    res.status(501).json({
      success: false,
      message: 'Video info retrieval not yet implemented'
    })
  } catch (error) {
    next(error)
  }
}

export async function validateVideoPath(req, res, next) {
  try {
    res.status(501).json({
      success: false,
      message: 'Path validation not yet implemented'
    })
  } catch (error) {
    next(error)
  }
}
