import express from 'express'
import { createServer } from 'http'
import { Server } from 'socket.io'
import cors from 'cors'
import config from './config/config.js'
import logger from './utils/logger.js'
import { errorHandler } from './utils/errorHandler.js'
import { setupSocketHandlers } from './websocket/socketHandler.js'

// Import routes
import videoRoutes from './routes/videoRoutes.js'
import annotationRoutes from './routes/annotationRoutes.js'
import datasetRoutes from './routes/datasetRoutes.js'
import trainingRoutes from './routes/trainingRoutes.js'

const app = express()
const httpServer = createServer(app)
const io = new Server(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
})

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Request logging
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.url}`)
  next()
})

// Health check
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'Server is running',
    timestamp: new Date().toISOString()
  })
})

// API Routes
app.use('/api/video', videoRoutes)
app.use('/api/annotations', annotationRoutes)
app.use('/api/dataset', datasetRoutes)
app.use('/api/training', trainingRoutes)

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Route not found'
  })
})

// Error handler
app.use(errorHandler)

// Setup WebSocket handlers
setupSocketHandlers(io)

// Make io available to routes
app.set('io', io)

// Start server
const PORT = config.port
httpServer.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`)
  logger.info(`Environment: ${config.nodeEnv}`)
  logger.info(`WebSocket server ready`)
})

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully')
  httpServer.close(() => {
    logger.info('Server closed')
    process.exit(0)
  })
})

export { app, io }
