import logger from '../utils/logger.js'

export function setupSocketHandlers(io) {
  io.on('connection', (socket) => {
    logger.info(`Client connected: ${socket.id}`)

    socket.on('disconnect', () => {
      logger.info(`Client disconnected: ${socket.id}`)
    })

    socket.on('ping', () => {
      socket.emit('pong')
    })
  })

  return io
}

export function broadcastProgress(io, event, data) {
  io.emit(event, data)
}

export function emitToSocket(socket, event, data) {
  socket.emit(event, data)
}
