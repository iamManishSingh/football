import express from 'express'
import * as annotationController from '../controllers/annotationController.js'

const router = express.Router()

router.get('/unlabeled', annotationController.getUnlabeledImages)
router.post('/save', annotationController.saveAnnotation)
router.get('/progress', annotationController.getAnnotationProgress)

export default router
