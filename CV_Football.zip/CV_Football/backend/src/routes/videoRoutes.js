import express from 'express'
import * as videoController from '../controllers/videoController.js'

const router = express.Router()

router.post('/extract', videoController.extractFrames)
router.get('/info', videoController.getVideoInfo)
router.post('/validate', videoController.validateVideoPath)

export default router
