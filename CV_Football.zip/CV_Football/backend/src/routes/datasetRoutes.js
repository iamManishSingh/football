import express from 'express'
import * as datasetController from '../controllers/datasetController.js'

const router = express.Router()

router.post('/prepare', datasetController.prepareDataset)
router.get('/statistics', datasetController.getDatasetStatistics)

export default router
