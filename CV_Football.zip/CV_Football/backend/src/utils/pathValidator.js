import path from 'path'
import { access, constants } from 'fs/promises'
import { AppError } from './errorHandler.js'

export async function validatePath(filePath) {
  if (!filePath || typeof filePath !== 'string') {
    throw new AppError('Path is required', 400)
  }

  if (filePath.trim().length === 0) {
    throw new AppError('Path cannot be empty', 400)
  }

  // Security: Prevent directory traversal
  const normalizedPath = path.normalize(filePath)
  if (normalizedPath.includes('..')) {
    throw new AppError('Invalid path: directory traversal not allowed', 400)
  }

  return normalizedPath
}

export async function validateFileExists(filePath) {
  try {
    await access(filePath, constants.F_OK)
    return true
  } catch {
    throw new AppError(`File not found: ${filePath}`, 404)
  }
}

export async function validateVideoPath(filePath) {
  const validExtensions = ['.mp4', '.avi', '.mov', '.mkv']
  const ext = path.extname(filePath).toLowerCase()

  if (!validExtensions.includes(ext)) {
    throw new AppError(
      `Invalid video format. Supported: ${validExtensions.join(', ')}`,
      400
    )
  }

  return true
}
