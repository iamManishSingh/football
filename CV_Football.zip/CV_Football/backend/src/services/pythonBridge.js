import { spawn } from 'child_process'
import path from 'path'
import config from '../config/config.js'
import logger from '../utils/logger.js'

class PythonBridge {
  constructor() {
    this.processes = new Map()
  }

  spawn(scriptPath, args = [], options = {}) {
    const pythonExecutable = config.pythonPath
    const scriptFullPath = path.join(config.paths.pythonServicesDir, scriptPath)

    logger.info(`Spawning Python process: ${scriptFullPath}`)

    const pythonProcess = spawn(pythonExecutable, [scriptFullPath, ...args], {
      stdio: ['pipe', 'pipe', 'pipe'],
      ...options
    })

    const processId = Date.now().toString()
    this.processes.set(processId, pythonProcess)

    pythonProcess.on('error', (error) => {
      logger.error(`Python process error: ${error.message}`)
    })

    pythonProcess.on('close', (code) => {
      logger.info(`Python process exited with code ${code}`)
      this.processes.delete(processId)
    })

    return { process: pythonProcess, processId }
  }

  kill(processId) {
    const process = this.processes.get(processId)
    if (process) {
      process.kill('SIGTERM')
      this.processes.delete(processId)
      logger.info(`Killed Python process: ${processId}`)
      return true
    }
    return false
  }

  killAll() {
    this.processes.forEach((process, id) => {
      process.kill('SIGTERM')
      logger.info(`Killed Python process: ${id}`)
    })
    this.processes.clear()
  }

  parseJsonOutput(data) {
    try {
      return JSON.parse(data.toString())
    } catch (error) {
      logger.warn(`Failed to parse JSON from Python: ${data.toString()}`)
      return null
    }
  }
}

export default new PythonBridge()
