import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

dotenv.config()

export default {
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  pythonPath: process.env.PYTHON_PATH || 'python3',

  paths: {
    dataDir: path.resolve(__dirname, '../../data'),
    configDir: path.resolve(__dirname, '../../config'),
    pythonServicesDir: path.resolve(__dirname, '../../python_services'),
    rawVideos: path.resolve(__dirname, '../../data/raw_videos'),
    extractedFrames: path.resolve(__dirname, '../../data/extracted_frames'),
    annotations: path.resolve(__dirname, '../../data/annotations'),
    labeledImages: path.resolve(__dirname, '../../data/labeled_images'),
    datasets: path.resolve(__dirname, '../../data/datasets'),
    models: path.resolve(__dirname, '../../data/models'),
    logs: path.resolve(__dirname, '../../data/logs')
  },

  logging: {
    level: process.env.LOG_LEVEL || 'info'
  }
}
