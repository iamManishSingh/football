# Quick Start Guide

## Get Started in 3 Steps

### Step 1: Run Setup Script

```bash
./setup.sh
```

This will:
- Check prerequisites (Node.js, Python, FFmpeg)
- Install frontend dependencies
- Install backend dependencies
- Create Python virtual environment
- Install Python packages

### Step 2: Start the Servers

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```

### Step 3: Open the Application

Open your browser and navigate to: **http://localhost:5173**

You should see the Football Ball Detection Dashboard!

## Verify Installation

1. Check backend health: http://localhost:3000/health
2. Should see: `{"success": true, "message": "Server is running"}`

## Current Status

The project infrastructure is complete with:
- ✅ Frontend UI framework
- ✅ Backend API server
- ✅ WebSocket communication
- ✅ Python microservices foundation
- ✅ Basic Python scripts (frame extraction, dataset splitting)

## What's Next?

The 4 main modules are ready to be implemented:

1. **Video Processing** - Extract frames from videos
2. **Annotation Interface** - Label balls with bounding boxes
3. **Data Preparation** - Split into train/val/test
4. **RF-DETR Training** - Train the detection model

Each module has placeholder UI pages that you can enhance with full functionality.

## Testing the Setup

### Test Video Extraction (Python script directly)

```bash
cd python_services
source venv/bin/activate

python video_processing/extract_frames.py \
  --video_path /path/to/your/video.mp4 \
  --output_path ../data/extracted_frames \
  --target_count 100
```

### Test Dataset Splitter (Python script directly)

```bash
cd python_services
source venv/bin/activate

python dataset/dataset_splitter.py \
  --annotations /path/to/annotations.json \
  --images_dir /path/to/images \
  --output_dir ../data/datasets \
  --train_ratio 0.7 \
  --val_ratio 0.2 \
  --test_ratio 0.1
```

## Need Help?

- See [README.md](README.md) for full documentation
- Check logs in `data/logs/combined.log`
- Ensure all dependencies are installed
- Verify Python virtual environment is activated for Python operations

## Manual Setup (If Script Fails)

### Frontend
```bash
cd frontend
npm install
npm run dev
```

### Backend
```bash
cd backend
npm install
npm run dev
```

### Python
```bash
cd python_services
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

---

**Ready to build!** The infrastructure is in place. You can now implement the full features for each module.
