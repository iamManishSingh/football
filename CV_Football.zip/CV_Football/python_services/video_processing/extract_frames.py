"""
Video Processing Utilities
Handles frame extraction from videos
"""

import cv2
import json
import sys
import argparse
from pathlib import Path


def extract_frames_uniform(video_path, output_path, target_count):
    """
    Extract frames uniformly distributed across the video
    """
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    duration = total_frames / fps if fps > 0 else 0

    # Calculate frame interval
    frame_interval = total_frames / target_count if target_count < total_frames else 1

    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    extracted = 0
    frame_indices = [int(i * frame_interval) for i in range(target_count)]

    for idx in frame_indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = cap.read()

        if not ret:
            continue

        # Generate filename
        timestamp = idx / fps if fps > 0 else 0
        filename = f"{video_path.stem}_frame_{idx:06d}_{timestamp:.2f}s.jpg"
        output_file = output_path / filename

        # Save frame
        cv2.imwrite(str(output_file), frame, [cv2.IMWRITE_JPEG_QUALITY, 95])
        extracted += 1

        # Report progress
        progress = {
            "status": "processing",
            "progress": (extracted / target_count) * 100,
            "current_frame": idx,
            "total_frames": total_frames,
            "extracted": extracted,
            "target": target_count
        }
        print(json.dumps(progress), flush=True)

    cap.release()

    # Report completion
    result = {
        "status": "completed",
        "extracted": extracted,
        "output_path": str(output_path),
        "video_info": {
            "total_frames": total_frames,
            "fps": fps,
            "duration": duration
        }
    }
    print(json.dumps(result), flush=True)

    return extracted


def main():
    parser = argparse.ArgumentParser(description='Extract frames from video')
    parser.add_argument('--video_path', required=True, help='Path to video file')
    parser.add_argument('--output_path', required=True, help='Output directory for frames')
    parser.add_argument('--target_count', type=int, default=1000, help='Number of frames to extract')
    parser.add_argument('--mode', default='uniform', help='Extraction mode')

    args = parser.parse_args()

    try:
        video_path = Path(args.video_path)
        if not video_path.exists():
            raise FileNotFoundError(f"Video not found: {video_path}")

        extract_frames_uniform(video_path, args.output_path, args.target_count)

    except Exception as e:
        error = {
            "status": "error",
            "message": str(e)
        }
        print(json.dumps(error), flush=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
