"""
Dataset Splitter
Splits COCO format annotations into train/val/test sets
"""

import json
import random
import shutil
import argparse
from pathlib import Path
from collections import defaultdict


def split_coco_dataset(annotations_file, images_dir, output_dir, train_ratio=0.7, val_ratio=0.2, test_ratio=0.1, shuffle=True):
    """
    Split COCO dataset into train/val/test
    """
    # Load annotations
    with open(annotations_file, 'r') as f:
        coco_data = json.load(f)

    images = coco_data['images']
    annotations = coco_data['annotations']
    categories = coco_data['categories']

    # Validate ratios
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 0.01, "Ratios must sum to 1.0"

    # Shuffle if requested
    if shuffle:
        random.shuffle(images)

    # Calculate split indices
    total = len(images)
    train_end = int(total * train_ratio)
    val_end = train_end + int(total * val_ratio)

    splits = {
        'train': images[:train_end],
        'val': images[train_end:val_end],
        'test': images[val_end:]
    }

    # Create output directories
    output_dir = Path(output_dir)
    for split_name in ['train', 'val', 'test']:
        (output_dir / split_name).mkdir(parents=True, exist_ok=True)
    (output_dir / 'annotations').mkdir(parents=True, exist_ok=True)

    # Group annotations by image_id
    anns_by_image = defaultdict(list)
    for ann in annotations:
        anns_by_image[ann['image_id']].append(ann)

    # Process each split
    results = {}
    for split_name, split_images in splits.items():
        split_annotations = []
        annotation_id = 1

        for img in split_images:
            # Copy image
            src_image = Path(images_dir) / img['file_name']
            dst_image = output_dir / split_name / img['file_name']

            if src_image.exists():
                shutil.copy2(src_image, dst_image)

            # Collect annotations
            for ann in anns_by_image.get(img['id'], []):
                ann_copy = ann.copy()
                ann_copy['id'] = annotation_id
                split_annotations.append(ann_copy)
                annotation_id += 1

        # Create split annotation file
        split_data = {
            'images': split_images,
            'annotations': split_annotations,
            'categories': categories
        }

        ann_file = output_dir / 'annotations' / f'instances_{split_name}.json'
        with open(ann_file, 'w') as f:
            json.dump(split_data, f, indent=2)

        results[split_name] = {
            'image_count': len(split_images),
            'annotation_count': len(split_annotations)
        }

        # Report progress
        progress = {
            "status": "processing",
            "split": split_name,
            "images": len(split_images),
            "annotations": len(split_annotations)
        }
        print(json.dumps(progress), flush=True)

    # Report completion
    result = {
        "status": "completed",
        "output_dir": str(output_dir),
        "splits": results
    }
    print(json.dumps(result), flush=True)

    return results


def main():
    parser = argparse.ArgumentParser(description='Split COCO dataset')
    parser.add_argument('--annotations', required=True, help='COCO annotations JSON file')
    parser.add_argument('--images_dir', required=True, help='Directory containing images')
    parser.add_argument('--output_dir', required=True, help='Output directory')
    parser.add_argument('--train_ratio', type=float, default=0.7)
    parser.add_argument('--val_ratio', type=float, default=0.2)
    parser.add_argument('--test_ratio', type=float, default=0.1)
    parser.add_argument('--shuffle', type=bool, default=True)

    args = parser.parse_args()

    try:
        split_coco_dataset(
            args.annotations,
            args.images_dir,
            args.output_dir,
            args.train_ratio,
            args.val_ratio,
            args.test_ratio,
            args.shuffle
        )
    except Exception as e:
        error = {
            "status": "error",
            "message": str(e)
        }
        print(json.dumps(error), flush=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
