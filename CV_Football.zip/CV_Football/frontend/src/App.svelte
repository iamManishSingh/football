<script>
  import { Router, Link, Route } from 'svelte-routing'
  import Dashboard from './routes/+page.svelte'
  import VideoPage from './routes/video/+page.svelte'
  import AnnotatePage from './routes/annotate/+page.svelte'
  import PreparePage from './routes/prepare/+page.svelte'
  import TrainPage from './routes/train/+page.svelte'

  export let url = ''
</script>

<Router {url}>
  <div class="app">
    <nav class="navbar">
      <h1 class="logo">⚽ Football Ball Detection</h1>
      <div class="nav-links">
        <Link to="/" class="nav-link">Dashboard</Link>
        <Link to="/video" class="nav-link">Video Processing</Link>
        <Link to="/annotate" class="nav-link">Annotation</Link>
        <Link to="/prepare" class="nav-link">Data Preparation</Link>
        <Link to="/train" class="nav-link">Training</Link>
      </div>
    </nav>

    <main class="content">
      <Route path="/" component={Dashboard} />
      <Route path="/video" component={VideoPage} />
      <Route path="/annotate" component={AnnotatePage} />
      <Route path="/prepare" component={PreparePage} />
      <Route path="/train" component={TrainPage} />
    </main>
  </div>
</Router>

<style>
  :global(body) {
    margin: 0;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    background-color: #f5f5f5;
  }

  .app {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }

  .navbar {
    background-color: #2c3e50;
    color: white;
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }

  .logo {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 600;
  }

  .nav-links {
    display: flex;
    gap: 1.5rem;
  }

  :global(.nav-link) {
    color: #ecf0f1;
    text-decoration: none;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    transition: background-color 0.2s;
  }

  :global(.nav-link:hover) {
    background-color: #34495e;
  }

  .content {
    flex: 1;
    padding: 2rem;
    max-width: 1400px;
    width: 100%;
    margin: 0 auto;
  }

  :global(*) {
    box-sizing: border-box;
  }

  :global(button) {
    cursor: pointer;
    font-family: inherit;
  }

  :global(input, select, textarea) {
    font-family: inherit;
  }
</style>
