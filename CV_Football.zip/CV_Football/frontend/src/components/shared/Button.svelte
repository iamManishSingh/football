<script>
  export let type = 'button'
  export let variant = 'primary' // primary, secondary, success, danger
  export let disabled = false
  export let fullWidth = false
</script>

<button
  {type}
  {disabled}
  class="btn btn-{variant}"
  class:full-width={fullWidth}
  on:click
>
  <slot />
</button>

<style>
  .btn {
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 4px;
    font-size: 0.95rem;
    font-weight: 500;
    transition: all 0.2s;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
  }

  .btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  .btn-primary {
    background-color: #3498db;
    color: white;
  }

  .btn-primary:hover:not(:disabled) {
    background-color: #2980b9;
  }

  .btn-secondary {
    background-color: #95a5a6;
    color: white;
  }

  .btn-secondary:hover:not(:disabled) {
    background-color: #7f8c8d;
  }

  .btn-success {
    background-color: #27ae60;
    color: white;
  }

  .btn-success:hover:not(:disabled) {
    background-color: #229954;
  }

  .btn-danger {
    background-color: #e74c3c;
    color: white;
  }

  .btn-danger:hover:not(:disabled) {
    background-color: #c0392b;
  }

  .full-width {
    width: 100%;
  }
</style>
