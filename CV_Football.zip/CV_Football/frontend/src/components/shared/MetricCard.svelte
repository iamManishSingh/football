<script>
  export let title = ''
  export let value = ''
  export let unit = ''
  export let variant = 'default' // default, primary, success, warning, danger
</script>

<div class="metric-card variant-{variant}">
  <div class="metric-title">{title}</div>
  <div class="metric-value">
    {value}
    {#if unit}
      <span class="metric-unit">{unit}</span>
    {/if}
  </div>
</div>

<style>
  .metric-card {
    padding: 1.2rem;
    border-radius: 8px;
    background-color: white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    border-left: 4px solid #95a5a6;
    transition: transform 0.2s;
  }

  .metric-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
  }

  .metric-title {
    font-size: 0.85rem;
    color: #7f8c8d;
    margin-bottom: 0.5rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .metric-value {
    font-size: 1.8rem;
    font-weight: 600;
    color: #2c3e50;
  }

  .metric-unit {
    font-size: 1rem;
    font-weight: 400;
    color: #95a5a6;
  }

  .variant-primary {
    border-left-color: #3498db;
  }

  .variant-success {
    border-left-color: #27ae60;
  }

  .variant-warning {
    border-left-color: #f39c12;
  }

  .variant-danger {
    border-left-color: #e74c3c;
  }
</style>
