<script>
  export let label = ''
  export let type = 'text'
  export let value = ''
  export let placeholder = ''
  export let disabled = false
  export let min = undefined
  export let max = undefined
  export let step = undefined
</script>

<div class="input-group">
  {#if label}
    <label class="input-label">{label}</label>
  {/if}
  <input
    {type}
    {placeholder}
    {disabled}
    {min}
    {max}
    {step}
    bind:value
    class="input-field"
    on:input
    on:change
    on:blur
  />
</div>

<style>
  .input-group {
    display: flex;
    flex-direction: column;
    gap: 0.4rem;
  }

  .input-label {
    font-size: 0.9rem;
    font-weight: 500;
    color: #2c3e50;
  }

  .input-field {
    padding: 0.6rem 0.8rem;
    border: 1px solid #bdc3c7;
    border-radius: 4px;
    font-size: 0.95rem;
    transition: border-color 0.2s;
  }

  .input-field:focus {
    outline: none;
    border-color: #3498db;
  }

  .input-field:disabled {
    background-color: #ecf0f1;
    cursor: not-allowed;
  }
</style>
