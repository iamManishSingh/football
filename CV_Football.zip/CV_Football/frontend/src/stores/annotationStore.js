import { writable } from 'svelte/store'

export const images = writable([])
export const currentImageIndex = writable(0)
export const currentImage = writable(null)
export const annotations = writable({})
export const currentBoundingBoxes = writable([])
export const annotationProgress = writable({
  total: 0,
  labeled: 0,
  remaining: 0,
  skipped: 0
})

export function addBoundingBox(box) {
  currentBoundingBoxes.update(boxes => [...boxes, box])
}

export function removeBoundingBox(index) {
  currentBoundingBoxes.update(boxes => boxes.filter((_, i) => i !== index))
}

export function clearBoundingBoxes() {
  currentBoundingBoxes.set([])
}

export function nextImage() {
  currentImageIndex.update(i => i + 1)
}

export function previousImage() {
  currentImageIndex.update(i => Math.max(0, i - 1))
}

export function jumpToImage(index) {
  currentImageIndex.set(index)
}
