import { writable, derived } from 'svelte/store'

export const trainingConfig = writable({
  // Basic settings
  datasetPath: '',
  epochs: 100,
  batchSize: 4,
  imageSize: 640,
  device: 'cuda',
  numWorkers: 4,
  pretrainedWeights: 'coco_pretrained',

  // RF-DETR architecture
  backbone: 'resnet50',
  numQueries: 300,
  hiddenDim: 256,
  numEncoderLayers: 6,
  numDecoderLayers: 6,
  numHeads: 8,
  dropout: 0.1,
  focalAlpha: 0.25,

  // Optimizer
  optimizer: 'AdamW',
  learningRate: 0.0001,
  weightDecay: 0.0001,
  lrScheduler: 'StepLR',
  lrDropEpochs: [50, 80],
  warmupEpochs: 5,

  // Loss
  clsLossCoef: 2.0,
  bboxLossCoef: 5.0,
  giouLossCoef: 2.0,

  // Augmentation
  augmentationEnabled: true,
  randomCrop: 0.5,
  randomFlip: 0.5,
  randomResize: [480, 800],

  // Training options
  mixedPrecision: true,
  gradientClip: 0.1,
  earlyStoppingPatience: 20,
  evalInterval: 5,
  modelOutputPath: './data/models',
  checkpointFrequency: 5,
  saveBestOnly: true,
  logInterval: 50,
  tensorboardLogs: true
})

export const trainingStatus = writable({
  isTraining: false,
  status: 'idle', // idle, training, paused, completed, error
  message: ''
})

export const trainingMetrics = writable({
  epoch: 0,
  totalEpochs: 0,
  batch: 0,
  totalBatches: 0,
  loss: 0,
  clsLoss: 0,
  bboxLoss: 0,
  giouLoss: 0,
  learningRate: 0,
  valMetrics: {
    mAP_50: 0,
    mAP_75: 0,
    mAP: 0
  },
  etaMinutes: 0
})

export const trainingLogs = writable([])

export const trainingHistory = writable({
  lossHistory: [],
  valLossHistory: [],
  mAPHistory: [],
  lrHistory: []
})

export function addLog(log) {
  trainingLogs.update(logs => [...logs, {
    ...log,
    timestamp: new Date().toISOString()
  }])
}

export function clearLogs() {
  trainingLogs.set([])
}

export const trainingProgress = derived(
  trainingMetrics,
  $metrics => {
    if ($metrics.totalEpochs === 0) return 0
    return ($metrics.epoch / $metrics.totalEpochs) * 100
  }
)
