import { writable } from 'svelte/store'

export const videoConfig = writable({
  videoInputPath: '',
  outputImagePath: '',
  targetImageCount: 1000,
  extractionMode: 'uniform_sampling',
  imageFormat: 'jpg',
  imageQuality: 95
})

export const extractionProgress = writable({
  status: 'idle', // idle, processing, completed, error
  progress: 0,
  currentFrame: 0,
  totalFrames: 0,
  etaSeconds: 0,
  message: ''
})

export const videoInfo = writable({
  duration: 0,
  fps: 0,
  resolution: '',
  totalFrames: 0
})

export function resetProgress() {
  extractionProgress.set({
    status: 'idle',
    progress: 0,
    currentFrame: 0,
    totalFrames: 0,
    etaSeconds: 0,
    message: ''
  })
}
