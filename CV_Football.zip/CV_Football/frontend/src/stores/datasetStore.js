import { writable } from 'svelte/store'

export const datasetConfig = writable({
  labeledDataPath: '',
  outputDatasetPath: '',
  trainRatio: 70,
  valRatio: 20,
  testRatio: 10,
  shuffleData: true
})

export const datasetStats = writable({
  totalImages: 0,
  totalAnnotations: 0,
  trainCount: 0,
  valCount: 0,
  testCount: 0
})

export const datasetStatus = writable({
  status: 'idle', // idle, processing, completed, error
  message: ''
})
