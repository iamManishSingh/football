export function drawRect(ctx, x, y, width, height, color = '#27ae60', lineWidth = 2) {
  ctx.strokeStyle = color
  ctx.lineWidth = lineWidth
  ctx.strokeRect(x, y, width, height)
}

export function clearCanvas(ctx, canvas) {
  ctx.clearRect(0, 0, canvas.width, canvas.height)
}

export function drawImage(ctx, img, canvas) {
  const scale = Math.min(canvas.width / img.width, canvas.height / img.height)
  const x = (canvas.width - img.width * scale) / 2
  const y = (canvas.height - img.height * scale) / 2

  ctx.clearRect(0, 0, canvas.width, canvas.height)
  ctx.drawImage(img, x, y, img.width * scale, img.height * scale)

  return { scale, offsetX: x, offsetY: y }
}

export function getMousePos(canvas, evt) {
  const rect = canvas.getBoundingClientRect()
  return {
    x: evt.clientX - rect.left,
    y: evt.clientY - rect.top
  }
}

export function drawBoundingBoxes(ctx, boxes, color = '#3498db') {
  boxes.forEach(box => {
    drawRect(ctx, box.x, box.y, box.width, box.height, color)

    // Draw label if exists
    if (box.label) {
      ctx.fillStyle = color
      ctx.fillRect(box.x, box.y - 20, 80, 20)
      ctx.fillStyle = 'white'
      ctx.font = '12px Arial'
      ctx.fillText(box.label, box.x + 5, box.y - 6)
    }
  })
}

export function isPointInBox(point, box) {
  return (
    point.x >= box.x &&
    point.x <= box.x + box.width &&
    point.y >= box.y &&
    point.y <= box.y + box.height
  )
}

export function normalizeBox(box) {
  return {
    x: Math.min(box.x, box.x + box.width),
    y: Math.min(box.y, box.y + box.height),
    width: Math.abs(box.width),
    height: Math.abs(box.height)
  }
}
