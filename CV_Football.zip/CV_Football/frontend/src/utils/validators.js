export function validatePath(path) {
  if (!path || typeof path !== 'string') {
    return { valid: false, error: 'Path is required' }
  }

  if (path.trim().length === 0) {
    return { valid: false, error: 'Path cannot be empty' }
  }

  return { valid: true }
}

export function validateVideoPath(path) {
  const pathValidation = validatePath(path)
  if (!pathValidation.valid) return pathValidation

  const validExtensions = ['.mp4', '.avi', '.mov', '.mkv']
  const hasValidExtension = validExtensions.some(ext => path.toLowerCase().endsWith(ext))

  if (!hasValidExtension) {
    return {
      valid: false,
      error: `Invalid video format. Supported: ${validExtensions.join(', ')}`
    }
  }

  return { valid: true }
}

export function validateImageCount(count) {
  const num = parseInt(count)
  if (isNaN(num) || num < 1) {
    return { valid: false, error: 'Image count must be a positive number' }
  }
  if (num > 10000) {
    return { valid: false, error: 'Image count cannot exceed 10,000' }
  }
  return { valid: true }
}

export function validateSplitRatios(train, val, test) {
  const sum = train + val + test
  if (Math.abs(sum - 100) > 0.01) {
    return { valid: false, error: 'Split ratios must sum to 100%' }
  }
  if (train < 50 || train > 90) {
    return { valid: false, error: 'Train ratio should be between 50-90%' }
  }
  return { valid: true }
}

export function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i]
}

export function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  return `${h > 0 ? h + 'h ' : ''}${m}m ${s}s`
}

export function formatTimestamp(date) {
  return new Date(date).toLocaleString()
}
