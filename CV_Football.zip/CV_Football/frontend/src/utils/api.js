import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Video Processing API
export const videoAPI = {
  extractFrames: (config) => api.post('/video/extract', config),
  getVideoInfo: (videoPath) => api.get('/video/info', { params: { path: videoPath } }),
  validatePath: (path) => api.post('/video/validate', { path })
}

// Annotation API
export const annotationAPI = {
  getUnlabeledImages: () => api.get('/annotations/unlabeled'),
  saveAnnotation: (data) => api.post('/annotations/save', data),
  getAnnotation: (imageId) => api.get(`/annotations/${imageId}`),
  moveProcessed: (imageId) => api.put('/annotations/move-processed', { imageId }),
  getProgress: () => api.get('/annotations/progress')
}

// Dataset API
export const datasetAPI = {
  prepareDataset: (config) => api.post('/dataset/prepare', config),
  validateData: () => api.get('/dataset/validate'),
  getStatistics: () => api.get('/dataset/statistics')
}

// Training API
export const trainingAPI = {
  startTraining: (config) => api.post('/training/start', config),
  stopTraining: () => api.post('/training/stop'),
  getStatus: () => api.get('/training/status'),
  getCheckpoints: () => api.get('/training/checkpoints'),
  saveConfig: (config) => api.post('/config/save', config),
  getPresets: () => api.get('/config/presets')
}

// Config API
export const configAPI = {
  getDefaultConfig: () => api.get('/config/default'),
  updateConfig: (config) => api.put('/config/update', config)
}

export default api
