import { io } from 'socket.io-client'
import { writable } from 'svelte/store'

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:3000'

let socket = null
export const connected = writable(false)

export function initSocket() {
  if (socket) return socket

  socket = io(SOCKET_URL, {
    transports: ['websocket'],
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 1000
  })

  socket.on('connect', () => {
    console.log('WebSocket connected')
    connected.set(true)
  })

  socket.on('disconnect', () => {
    console.log('WebSocket disconnected')
    connected.set(false)
  })

  socket.on('error', (error) => {
    console.error('WebSocket error:', error)
  })

  return socket
}

export function getSocket() {
  if (!socket) {
    return initSocket()
  }
  return socket
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect()
    socket = null
    connected.set(false)
  }
}

// Video extraction events
export function onExtractionProgress(callback) {
  const s = getSocket()
  s.on('extraction_progress', callback)
  return () => s.off('extraction_progress', callback)
}

export function onExtractionComplete(callback) {
  const s = getSocket()
  s.on('extraction_complete', callback)
  return () => s.off('extraction_complete', callback)
}

// Training events
export function onTrainingProgress(callback) {
  const s = getSocket()
  s.on('training_progress', callback)
  return () => s.off('training_progress', callback)
}

export function onTrainingComplete(callback) {
  const s = getSocket()
  s.on('training_complete', callback)
  return () => s.off('training_complete', callback)
}

export function onTrainingLog(callback) {
  const s = getSocket()
  s.on('training_log', callback)
  return () => s.off('training_log', callback)
}

export default { initSocket, getSocket, disconnectSocket }
