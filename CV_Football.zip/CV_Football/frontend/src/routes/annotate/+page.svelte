<script>
</script>

<div class="page">
  <h1>Annotation Interface</h1>
  <p>Label football balls with bounding boxes using canvas-based annotation tool.</p>

  <div class="placeholder">
    <p>This module will be implemented with:</p>
    <ul>
      <li>Canvas-based annotation interface</li>
      <li>Bounding box drawing</li>
      <li>Image navigation</li>
      <li>Zoom and pan controls</li>
      <li>COCO JSON export</li>
    </ul>
  </div>
</div>

<style>
  .page {
    max-width: 1400px;
  }
  .placeholder {
    background: white;
    padding: 2rem;
    border-radius: 8px;
    margin-top: 2rem;
  }
</style>
