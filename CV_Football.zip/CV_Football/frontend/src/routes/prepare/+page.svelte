<script>
</script>

<div class="page">
  <h1>Data Preparation</h1>
  <p>Split labeled dataset into train/validation/test sets for model training.</p>

  <div class="placeholder">
    <p>This module will be implemented with:</p>
    <ul>
      <li>Split ratio configuration</li>
      <li>Dataset validation</li>
      <li>Statistics display</li>
      <li>RF-DETR compatible output</li>
    </ul>
  </div>
</div>

<style>
  .page {
    max-width: 1000px;
  }
  .placeholder {
    background: white;
    padding: 2rem;
    border-radius: 8px;
    margin-top: 2rem;
  }
</style>
