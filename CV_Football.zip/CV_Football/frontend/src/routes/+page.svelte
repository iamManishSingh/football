<script>
  import { Link } from 'svelte-routing'
  import MetricCard from '../components/shared/MetricCard.svelte'
  import Button from '../components/shared/Button.svelte'

  let stats = {
    extractedFrames: 0,
    annotatedImages: 0,
    trainedModels: 0,
    lastTraining: 'Never'
  }
</script>

<div class="dashboard">
  <h1 class="page-title">Football Ball Detection Dashboard</h1>

  <div class="welcome-section">
    <h2>Welcome to the CV Pipeline</h2>
    <p>Complete end-to-end pipeline for football ball detection using RF-DETR model.</p>
  </div>

  <div class="metrics-grid">
    <MetricCard
      title="Extracted Frames"
      value={stats.extractedFrames}
      variant="primary"
    />
    <MetricCard
      title="Annotated Images"
      value={stats.annotatedImages}
      variant="success"
    />
    <MetricCard
      title="Trained Models"
      value={stats.trainedModels}
      variant="warning"
    />
    <MetricCard
      title="Last Training"
      value={stats.lastTraining}
      variant="default"
    />
  </div>

  <div class="workflow-section">
    <h2>Pipeline Workflow</h2>
    <div class="workflow-steps">
      <Link to="/video" class="workflow-card">
        <div class="step-number">1</div>
        <h3>Video Processing</h3>
        <p>Extract frames from football match videos</p>
        <Button variant="primary">Start</Button>
      </Link>

      <Link to="/annotate" class="workflow-card">
        <div class="step-number">2</div>
        <h3>Annotation</h3>
        <p>Label football balls with bounding boxes</p>
        <Button variant="primary">Annotate</Button>
      </Link>

      <Link to="/prepare" class="workflow-card">
        <div class="step-number">3</div>
        <h3>Data Preparation</h3>
        <p>Split dataset into train/val/test sets</p>
        <Button variant="primary">Prepare</Button>
      </Link>

      <Link to="/train" class="workflow-card">
        <div class="step-number">4</div>
        <h3>Model Training</h3>
        <p>Train RF-DETR model for ball detection</p>
        <Button variant="success">Train</Button>
      </Link>
    </div>
  </div>

  <div class="info-section">
    <h3>System Information</h3>
    <ul>
      <li><strong>Model:</strong> RF-DETR (Real-time DEtection TRansformer)</li>
      <li><strong>Backend:</strong> Node.js + Python Microservices</li>
      <li><strong>Framework:</strong> PyTorch</li>
      <li><strong>Annotation Format:</strong> COCO JSON</li>
    </ul>
  </div>
</div>

<style>
  .dashboard {
    max-width: 1200px;
    margin: 0 auto;
  }

  .page-title {
    font-size: 2rem;
    color: #2c3e50;
    margin-bottom: 1rem;
  }

  .welcome-section {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 2rem;
    border-radius: 8px;
    margin-bottom: 2rem;
  }

  .welcome-section h2 {
    margin: 0 0 0.5rem 0;
    font-size: 1.5rem;
  }

  .welcome-section p {
    margin: 0;
    font-size: 1.1rem;
    opacity: 0.9;
  }

  .metrics-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 3rem;
  }

  .workflow-section {
    margin-bottom: 3rem;
  }

  .workflow-section h2 {
    font-size: 1.5rem;
    color: #2c3e50;
    margin-bottom: 1.5rem;
  }

  .workflow-steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
  }

  .workflow-card {
    background-color: white;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    text-decoration: none;
    color: inherit;
    transition: transform 0.2s, box-shadow 0.2s;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
  }

  .workflow-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  }

  .step-number {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background-color: #3498db;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    font-weight: 600;
    margin-bottom: 1rem;
  }

  .workflow-card h3 {
    margin: 0 0 0.5rem 0;
    font-size: 1.2rem;
    color: #2c3e50;
  }

  .workflow-card p {
    margin: 0 0 1.5rem 0;
    color: #7f8c8d;
    flex: 1;
  }

  .info-section {
    background-color: white;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }

  .info-section h3 {
    margin: 0 0 1rem 0;
    color: #2c3e50;
  }

  .info-section ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  .info-section li {
    padding: 0.5rem 0;
    color: #34495e;
  }
</style>
