<script>
  import Button from '../../components/shared/Button.svelte'
  import Input from '../../components/shared/Input.svelte'
</script>

<div class="page">
  <h1>Video Processing</h1>
  <p>Extract frames from football match videos for annotation.</p>

  <div class="placeholder">
    <p>This module will be implemented with:</p>
    <ul>
      <li>Video file selection</li>
      <li>Frame extraction configuration</li>
      <li>Real-time progress monitoring</li>
      <li>Extraction results display</li>
    </ul>
  </div>
</div>

<style>
  .page {
    max-width: 1000px;
  }
  .placeholder {
    background: white;
    padding: 2rem;
    border-radius: 8px;
    margin-top: 2rem;
  }
</style>
