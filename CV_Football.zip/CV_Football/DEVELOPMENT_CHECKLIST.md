# Development Checklist

## Module 1: Video Processing

### Backend Implementation
- [ ] Implement `extractFrames()` in videoController.js
  - [ ] Validate video path
  - [ ] Get video metadata using ffprobe
  - [ ] Spawn Python frame extraction process
  - [ ] Pipe stdout to WebSocket
  - [ ] Handle errors
- [ ] Implement `getVideoInfo()`
  - [ ] Extract duration, fps, resolution
  - [ ] Calculate frame count
- [ ] Implement `validateVideoPath()`
  - [ ] Check file exists
  - [ ] Validate extension
  - [ ] Return video metadata

### Frontend Implementation
- [ ] VideoProcessor.svelte
  - [ ] File path input with validation
  - [ ] Video info display (duration, fps, resolution)
  - [ ] Configuration panel (target count, format, quality)
  - [ ] Start/Cancel buttons
- [ ] ProgressMonitor.svelte
  - [ ] Progress bar
  - [ ] Current frame / Total frames
  - [ ] ETA calculation
  - [ ] Status messages
- [ ] ConfigPanel.svelte
  - [ ] Target image count slider (100-5000)
  - [ ] Image format dropdown
  - [ ] Quality slider
- [ ] WebSocket integration
  - [ ] Listen to extraction_progress events
  - [ ] Update UI in real-time
  - [ ] Handle completion and errors

### Testing
- [ ] Test with sample video
- [ ] Verify frames extracted correctly
- [ ] Check progress updates
- [ ] Test error handling (invalid path, corrupted video)

---

## Module 2: Annotation Interface

### Backend Implementation
- [ ] Implement annotationService.js
  - [ ] loadUnlabeledImages() - scan directory
  - [ ] saveAnnotation() - append to COCO JSON
  - [ ] moveProcessedImage() - organize files
  - [ ] getProgress() - calculate stats
- [ ] Implement annotationController.js
  - [ ] GET /unlabeled - return image list
  - [ ] POST /save - save annotation
  - [ ] GET /progress - return stats
- [ ] COCO JSON utilities
  - [ ] Create new COCO file if not exists
  - [ ] Add image to COCO
  - [ ] Add annotation to COCO
  - [ ] Update IDs properly

### Frontend Implementation
- [ ] AnnotationCanvas.svelte
  - [ ] Canvas setup with proper sizing
  - [ ] Image loading and display
  - [ ] Mouse event handlers:
    - [ ] mousedown - start box
    - [ ] mousemove - draw preview
    - [ ] mouseup - finalize box
  - [ ] Draw existing boxes
  - [ ] Zoom controls (+/- buttons)
  - [ ] Pan functionality (drag canvas)
- [ ] ImageNavigator.svelte
  - [ ] Previous button
  - [ ] Next button
  - [ ] Image counter (X of Y)
  - [ ] Jump to image input
  - [ ] Skip image button
- [ ] AnnotationControls.svelte
  - [ ] Draw box tool
  - [ ] Delete box button
  - [ ] Reset button
  - [ ] Coordinates display
  - [ ] Save & Next button
  - [ ] Auto-save toggle
- [ ] BoundingBox.svelte
  - [ ] Visual representation
  - [ ] Edit handles
  - [ ] Delete button per box
- [ ] LocalStorage integration
  - [ ] Save current progress
  - [ ] Resume on reload

### Testing
- [ ] Load sample images
- [ ] Draw bounding boxes
- [ ] Save and verify COCO JSON
- [ ] Navigate between images
- [ ] Test zoom and pan
- [ ] Verify resume functionality

---

## Module 3: Data Preparation

### Backend Implementation
- [ ] Implement datasetController.js
  - [ ] prepareDataset() - call Python splitter
  - [ ] validateData() - check COCO JSON integrity
  - [ ] getStatistics() - analyze dataset
- [ ] Implement fileService.js helpers
  - [ ] Copy/move files
  - [ ] Create directories
  - [ ] Validate paths

### Python Enhancement
- [ ] Enhance dataset_splitter.py
  - [ ] Add validation checks
  - [ ] Generate statistics
  - [ ] Progress reporting
  - [ ] Error handling

### Frontend Implementation
- [ ] DataPreparation.svelte
  - [ ] Labeled data path selector
  - [ ] Output path selector
  - [ ] Split configuration sliders
  - [ ] Real-time ratio sum validation
  - [ ] Shuffle toggle
  - [ ] Validate & Prepare buttons
- [ ] SplitConfig.svelte
  - [ ] Train ratio slider (50-80%)
  - [ ] Val ratio slider (10-30%)
  - [ ] Test ratio slider (10-30%)
  - [ ] Auto-adjust to sum 100%
  - [ ] Visual split preview
- [ ] Statistics display
  - [ ] Total images per split
  - [ ] Annotations per split
  - [ ] Image distribution chart

### Testing
- [ ] Prepare dataset with sample annotations
- [ ] Verify train/val/test split
- [ ] Check COCO JSON files
- [ ] Validate image copying
- [ ] Test different split ratios

---

## Module 4: RF-DETR Training

### Prerequisites
- [ ] Clone RF-DETR repository
- [ ] Install RF-DETR package
- [ ] Download pretrained weights

### Python Implementation
- [ ] train_rfdetr.py
  - [ ] Load RF-DETR model
  - [ ] Setup dataloaders (COCO format)
  - [ ] Configure optimizer (AdamW)
  - [ ] Setup loss functions
  - [ ] Training loop with metrics
  - [ ] Validation loop
  - [ ] Checkpoint saving
  - [ ] TensorBoard logging
  - [ ] Progress reporting via JSON stdout
- [ ] trainer.py
  - [ ] Training class with all logic
  - [ ] EarlyStopping implementation
  - [ ] LR scheduling
  - [ ] Mixed precision training
- [ ] models/rfdetr_model.py
  - [ ] Wrapper for RF-DETR
  - [ ] Custom modifications if needed

### Backend Implementation
- [ ] Implement trainingManager.js
  - [ ] startTraining() - spawn Python
  - [ ] monitorTraining() - parse stdout
  - [ ] stopTraining() - kill process
  - [ ] listCheckpoints() - scan models dir
- [ ] Implement trainingController.js
  - [ ] POST /start - validate config, start training
  - [ ] POST /stop - gracefully stop
  - [ ] GET /status - return current status
  - [ ] GET /checkpoints - list saved models
- [ ] WebSocket broadcasting
  - [ ] training_progress events
  - [ ] training_log events
  - [ ] training_complete event

### Frontend Implementation
- [ ] TrainingDashboard.svelte (Main)
  - [ ] Layout with tabs
  - [ ] Training control section
  - [ ] Real-time metrics display
  - [ ] Charts section
  - [ ] Logs console
- [ ] ConfigTabs.svelte
  - [ ] Basic Settings Tab
    - [ ] Epochs input
    - [ ] Batch size select
    - [ ] Image size input
    - [ ] Device select
  - [ ] Architecture Tab
    - [ ] Backbone select
    - [ ] Num queries slider
    - [ ] Hidden dim input
    - [ ] Layers configuration
    - [ ] Dropout slider
  - [ ] Optimizer Tab
    - [ ] Learning rate input
    - [ ] Weight decay input
    - [ ] LR scheduler select
    - [ ] Warmup epochs
  - [ ] Loss Tab
    - [ ] Loss coefficient sliders
    - [ ] Preset buttons
  - [ ] Augmentation Tab
    - [ ] Master toggle
    - [ ] Individual augmentation toggles
    - [ ] Parameter sliders
    - [ ] Preview (optional)
- [ ] MetricsGrid.svelte
  - [ ] Epoch counter
  - [ ] Loss display
  - [ ] mAP display
  - [ ] Learning rate display
- [ ] Charts.svelte
  - [ ] Loss curve chart (train vs val)
  - [ ] mAP progression chart
  - [ ] LR schedule chart
  - [ ] Using Chart.js
- [ ] LogsConsole.svelte
  - [ ] Log display with colors
  - [ ] Filter by level (info/warning/error)
  - [ ] Export logs button
  - [ ] Auto-scroll toggle
- [ ] Training control buttons
  - [ ] Start Training
  - [ ] Stop Training
  - [ ] Pause/Resume (optional)
- [ ] Results section (post-training)
  - [ ] Final metrics summary
  - [ ] Best checkpoint info
  - [ ] Download model button
  - [ ] Sample predictions gallery

### Testing
- [ ] Test with minimal config (10 epochs, small dataset)
- [ ] Verify real-time metrics update
- [ ] Check checkpoint saving
- [ ] Test stop functionality
- [ ] Validate TensorBoard logs
- [ ] Train actual model on football data

---

## Integration Testing

### End-to-End Workflow
1. [ ] Extract frames from test video
2. [ ] Annotate 50+ images
3. [ ] Prepare dataset (70/20/10 split)
4. [ ] Train model for 20 epochs
5. [ ] Verify model checkpoint saved
6. [ ] Check all logs generated

### Performance Testing
- [ ] Test with large video (1hr+)
- [ ] Test with 1000+ images for annotation
- [ ] Test training with large dataset
- [ ] Monitor memory usage
- [ ] Monitor GPU utilization

### Error Handling
- [ ] Test invalid video path
- [ ] Test corrupted video file
- [ ] Test invalid COCO JSON
- [ ] Test training interruption
- [ ] Test out of memory scenario

---

## Polish & Enhancement

### UI/UX Improvements
- [ ] Add loading spinners
- [ ] Add success/error toasts
- [ ] Improve form validation feedback
- [ ] Add keyboard shortcuts
- [ ] Responsive design for mobile
- [ ] Dark mode support (optional)

### Features
- [ ] Add undo/redo for annotations
- [ ] Batch operations
- [ ] Export annotations to other formats
- [ ] Model comparison tool
- [ ] Inference interface
- [ ] Result visualization

### Performance
- [ ] Optimize image loading
- [ ] Lazy load image lists
- [ ] Compress logs before sending
- [ ] Debounce WebSocket messages
- [ ] Implement caching

### Documentation
- [ ] API documentation
- [ ] Component documentation
- [ ] Training guide
- [ ] Troubleshooting guide
- [ ] Video tutorials (optional)

---

## Deployment Checklist

- [ ] Build frontend for production
- [ ] Setup PM2 for Node.js
- [ ] Configure Nginx reverse proxy
- [ ] Setup SSL certificate
- [ ] Configure environment variables
- [ ] Setup log rotation
- [ ] Create backup strategy
- [ ] Write deployment documentation
- [ ] Create Docker images (optional)
- [ ] Setup CI/CD pipeline (optional)

---

**Track your progress by checking off items as you complete them!**
