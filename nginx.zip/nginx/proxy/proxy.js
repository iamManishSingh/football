const http = require("http");
const httpProxy = require("http-proxy");

// ---- Configuration ----
const PROXY_PORT = 8080;
const BACKEND_URL = "http://localhost:3000";
const FRONTEND_URL = "http://localhost:3001";

// Basic Auth credentials (username: admin, password: password123)
const VALID_USER = "admin";
const VALID_PASS = "password123";

// ---- Create Proxy ----
const proxy = httpProxy.createProxyServer({});

proxy.on("error", (err, req, res) => {
  console.error(`Proxy error: ${err.message}`);
  res.writeHead(502, { "Content-Type": "text/plain" });
  res.end("Bad Gateway — is the backend/frontend running?");
});

// ---- Basic Auth Check ----
function checkAuth(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Basic ")) {
    return false;
  }
  const base64 = authHeader.split(" ")[1];
  const decoded = Buffer.from(base64, "base64").toString("utf-8");
  const [user, pass] = decoded.split(":");
  return user === VALID_USER && pass === VALID_PASS;
}

function sendAuthRequired(res) {
  res.writeHead(401, {
    "WWW-Authenticate": 'Basic realm="Restricted Access"',
    "Content-Type": "text/plain",
  });
  res.end("401 Unauthorized — Please enter valid credentials.");
}

// ---- Reverse Proxy Server ----
const server = http.createServer((req, res) => {
  // Step 1: Check Basic Auth
  if (!checkAuth(req)) {
    return sendAuthRequired(res);
  }

  // Step 2: Route requests
  if (req.url.startsWith("/api")) {
    // /api/* → Backend (Express on port 3000)
    proxy.web(req, res, { target: BACKEND_URL });
  } else {
    // Everything else → Frontend (http-server on port 3001)
    proxy.web(req, res, { target: FRONTEND_URL });
  }
});

server.listen(PROXY_PORT, () => {
  console.log(`\n🔒 Reverse Proxy with Basic Auth running at http://localhost:${PROXY_PORT}`);
  console.log(`   ├── /       → Frontend (${FRONTEND_URL})`);
  console.log(`   └── /api/*  → Backend  (${BACKEND_URL})`);
  console.log(`\n   Username: ${VALID_USER}`);
  console.log(`   Password: ${VALID_PASS}\n`);
});
