# Fullstack Node App with Reverse Proxy & Basic Auth

## Architecture

```
Browser → http://localhost:8080 (Proxy + Basic Auth)
              │
              ├── /       → Frontend (port 3001)
              └── /api/   → Backend  (port 3000)
```

All three components are **pure Node.js** — no Docker or Nginx needed.

## Credentials

| Username | Password      |
| -------- | ------------- |
| admin    | password123   |

## How to Run (3 Terminals)

### Terminal 1 — Backend
```bash
cd backend
npm run dev
```

### Terminal 2 — Frontend
```bash
cd frontend
npm run dev
```

### Terminal 3 — Reverse Proxy with Basic Auth
```bash
cd proxy
npm run dev
```

Then open **http://localhost:8080** → you'll get a Basic Auth prompt → enter `admin` / `password123`.
