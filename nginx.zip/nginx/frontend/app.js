// Use relative URL when accessed via Nginx proxy (port 8080),
// fallback to direct backend URL for standalone dev (port 3001)
const API_URL = window.location.port === "8080" ? "/api" : "http://localhost:3000/api";

// ---- DOM Elements ----
const healthStatus = document.getElementById("health-status");
const usersBody = document.getElementById("users-body");
const noUsers = document.getElementById("no-users");
const addUserForm = document.getElementById("add-user-form");

// ---- Check API Health ----
async function checkHealth() {
  try {
    const res = await fetch(`${API_URL}/health`);
    const data = await res.json();
    healthStatus.textContent = `✅ API Online — ${data.timestamp}`;
    healthStatus.className = "health-badge online";
  } catch {
    healthStatus.textContent = "❌ API Offline";
    healthStatus.className = "health-badge offline";
  }
}

// ---- Load Users ----
async function loadUsers() {
  try {
    const res = await fetch(`${API_URL}/users`);
    const users = await res.json();

    if (users.length === 0) {
      usersBody.innerHTML = "";
      noUsers.classList.remove("hidden");
      return;
    }

    noUsers.classList.add("hidden");
    usersBody.innerHTML = users
      .map(
        (user) => `
      <tr>
        <td>${user.id}</td>
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td><span class="role-badge role-${user.role}">${user.role}</span></td>
        <td><button class="btn btn-danger" onclick="deleteUser(${user.id})">Delete</button></td>
      </tr>
    `
      )
      .join("");
  } catch (err) {
    usersBody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:#e74c3c;">Failed to load users. Is the backend running?</td></tr>`;
  }
}

// ---- Add User ----
addUserForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const role = document.getElementById("role").value;

  if (!name || !email) return;

  try {
    await fetch(`${API_URL}/users`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, role }),
    });
    addUserForm.reset();
    loadUsers();
  } catch (err) {
    alert("Failed to add user. Is the backend running?");
  }
});

// ---- Delete User ----
async function deleteUser(id) {
  if (!confirm("Are you sure you want to delete this user?")) return;

  try {
    await fetch(`${API_URL}/users/${id}`, { method: "DELETE" });
    loadUsers();
  } catch (err) {
    alert("Failed to delete user.");
  }
}

// ---- Init ----
checkHealth();
loadUsers();

// Refresh health every 30 seconds
setInterval(checkHealth, 30000);
