# Advanced Tracking Mode - Usage Guide

## 🎯 What's New?

Your pipeline now has **two modes**:

1. **Basic Mode** (default) - Simple RF-DETR detection
2. **Advanced Tracking Mode** (new) - With filters to solve:
   - ✅ False positives (shoes detected as balls)
   - ✅ Aerial ball tracking (ball in the air)
   - ✅ Background crowd interference

---

## 🚀 Quick Start

### Basic Mode (Original - No Tracking)
```bash
python main.py --source video.mp4
```

### Advanced Tracking Mode (NEW!)
```bash
python main.py --source video.mp4 --use-tracking
```

**That's it!** Just add `--use-tracking` flag.

---

## 🎮 How to Use

### Example 1: Fix False Positives (Shoes as Balls)

```bash
# Problem: Shoes detected as balls
python main.py --source video.mp4

# Solution: Use tracking mode with higher confidence
python main.py --source video.mp4 --use-tracking --tracking-confidence 0.6
```

**What it does:**
- Filters by size (shoes are too big)
- Filters by aspect ratio (shoes are elongated, balls are round)
- Higher confidence threshold

### Example 2: Track Aerial Ball

```bash
# Problem: Ball lost when in the air
python main.py --source video.mp4

# Solution: Use tracking with aerial prediction
python main.py --source video.mp4 --use-tracking --tracking-max-predict-frames 60
```

**What it does:**
- Kalman filter predicts ball trajectory
- Keeps tracking for 60 frames without detection
- Shows predicted position with yellow circle
- Re-acquires ball when it lands

### Example 3: Exclude Crowd/Background

```bash
# Problem: Crowd objects detected as balls
python main.py --source video.mp4

# Solution: Use tracking with ROI masking
python main.py --source video.mp4 --use-tracking --tracking-exclude-top 0.15 --tracking-exclude-bottom 0.10
```

**What it does:**
- Excludes top 15% (crowd, sky)
- Excludes bottom 10% (broadcast bar)
- Only detects in playing area

---

## 📋 Command Comparison

### Without Tracking (Basic)
```bash
python main.py --source video.mp4 --confidence 0.3
```
**Output:**
- Green boxes on ALL detections above 0.3 confidence
- May show false positives (shoes, crowd objects)
- Loses ball during aerial play

### With Tracking (Advanced)
```bash
python main.py --source video.mp4 --use-tracking
```
**Output:**
- **Green boxes** on DETECTED & TRACKED balls
- **Yellow circles** on PREDICTED positions (aerial)
- **Velocity arrows** showing ball direction
- **State info** at bottom (TRACKING/PREDICTING/LOST)
- **Filtered false positives** (shoes, crowd)
- **Continuous tracking** through aerial play

---

## 🎛️ All Tracking Options

```bash
python main.py --source video.mp4 \
  --use-tracking \                              # Enable tracking mode
  --tracking-confidence 0.5 \                   # Confidence threshold (↑ = fewer false positives)
  --tracking-search-confidence 0.25 \           # Lower threshold near predicted position
  --tracking-max-predict-frames 45 \            # Max frames to predict (aerial grace period)
  --tracking-exclude-top 0.10 \                 # Exclude top 10% of frame
  --tracking-exclude-bottom 0.05 \              # Exclude bottom 5% of frame
  --tracking-debug                              # Show filter decisions
```

---

## 📊 Visual Differences

### Basic Mode Output:
```
Frame: [Video with green boxes]
FPS: 25.3
Detections: 5  ← May include false positives
```

### Tracking Mode Output:
```
Frame: [Video with green boxes + yellow predicted circles + arrows]
FPS: 24.1
State: TRACKING | Lost: 0  ← Tracking state
Tracked: 142 | Predicted: 23  ← Statistics

Final Stats:
  Detected frames: 142
  Predicted frames: 23  ← Aerial ball frames
  Lost frames: 30
  Detection rate: 72.8%
  Tracking rate: 84.6%
```

---

## 🔧 Fine-Tuning Tips

### Problem: Too Many False Positives

```bash
# Solution 1: Raise confidence
python main.py --source video.mp4 --use-tracking --tracking-confidence 0.7

# Solution 2: Stricter ROI (exclude more background)
python main.py --source video.mp4 --use-tracking --tracking-exclude-top 0.20

# Solution 3: Enable debug to see what's being filtered
python main.py --source video.mp4 --use-tracking --tracking-debug
```

### Problem: Ball Lost Too Quickly

```bash
# Solution: Increase prediction grace period
python main.py --source video.mp4 --use-tracking --tracking-max-predict-frames 60
```

### Problem: Ball Not Detected

```bash
# Solution: Lower confidence thresholds
python main.py --source video.mp4 --use-tracking \
  --tracking-confidence 0.3 \
  --tracking-search-confidence 0.15
```

---

## 🎨 Visual Legend

| Visual Element | Meaning | Color |
|----------------|---------|-------|
| **Green box** | Ball detected & tracked | Green |
| **Yellow circle** | Predicted position (aerial) | Yellow |
| **Blue arrow** | Velocity vector | Blue/Orange |
| **State: TRACKING** | Ball being tracked | - |
| **State: PREDICTING** | Ball in air (predicted) | - |
| **State: TENTATIVE** | Confirming new track | - |
| **State: NO_TRACK** | No ball found | - |

---

## 📈 Statistics Explained

After processing, you'll see:

```
Tracking Statistics:
  Detected frames: 850       ← Frames with actual ball detection
  Predicted frames: 120      ← Frames where ball was predicted (aerial)
  Lost frames: 30            ← Frames where ball was lost
  Avg confidence: 0.687      ← Average confidence of detections
  Detection rate: 85.0%      ← % frames with detection
  Tracking rate: 97.0%       ← % frames with detection OR prediction
```

**Tracking rate > Detection rate** means the Kalman filter is successfully maintaining the track during gaps!

---

## 🆚 Mode Comparison Table

| Feature | Basic Mode | Tracking Mode |
|---------|------------|---------------|
| **False positives** | ❌ Common (shoes, crowd) | ✅ Filtered (size, aspect, ROI) |
| **Aerial tracking** | ❌ Lost when airborne | ✅ Predicted with Kalman filter |
| **Temporal consistency** | ❌ Frame-by-frame only | ✅ Multi-frame tracking |
| **ROI masking** | ❌ No | ✅ Yes (exclude crowd/scoreboard) |
| **Velocity info** | ❌ No | ✅ Yes (arrows + speed) |
| **Prediction** | ❌ No | ✅ Yes (physics-based) |
| **State machine** | ❌ No | ✅ Yes (TRACKING/PREDICTING/LOST) |
| **Performance** | Fast (~30 FPS) | Slightly slower (~25 FPS) |
| **Best for** | Quick testing | Production, sports analysis |

---

## 🎯 Recommended Settings by Use Case

### Soccer/Football
```bash
python main.py --source soccer.mp4 --use-tracking \
  --tracking-confidence 0.5 \
  --tracking-max-predict-frames 50 \
  --tracking-exclude-top 0.12 \
  --tracking-exclude-bottom 0.08
```

### Basketball
```bash
python main.py --source basketball.mp4 --use-tracking \
  --tracking-confidence 0.6 \
  --tracking-max-predict-frames 30 \
  --tracking-exclude-top 0.10
```

### Tennis
```bash
python main.py --source tennis.mp4 --use-tracking \
  --tracking-confidence 0.4 \
  --tracking-max-predict-frames 25 \
  --tracking-exclude-top 0.05 \
  --tracking-exclude-bottom 0.05
```

---

## 🐛 Debugging

Enable debug mode to see filter decisions:

```bash
python main.py --source video.mp4 --use-tracking --tracking-debug
```

Output:
```
Frame 45 | State: TRACKING | Raw: 8
  Raw detections: 8
  After confidence: 3
  After size: 2
  After aspect ratio: 2
  After ROI: 1
  After max jump: 1
  → Ball at (856, 432) conf=0.67
```

This shows you exactly what's being filtered and why!

---

## 💡 Pro Tips

1. **Start with defaults** - The default tracking settings work well for most videos
2. **Tune incrementally** - Adjust one parameter at a time
3. **Use debug mode** - See what's being filtered
4. **Save output** - Compare basic vs tracking mode side-by-side
5. **Watch state transitions** - TRACKING → PREDICTING → TRACKING means aerial ball handling is working!

---

## 🚀 Quick Commands

```bash
# Quick test (basic mode)
python main.py --source video.mp4

# Production (tracking mode)
python main.py --source video.mp4 --use-tracking --save-output tracked.mp4

# Debug false positives
python main.py --source video.mp4 --use-tracking --tracking-debug

# Maximum aerial tracking
python main.py --source video.mp4 --use-tracking --tracking-max-predict-frames 90

# Strict mode (minimal false positives)
python main.py --source video.mp4 --use-tracking --tracking-confidence 0.8
```

---

**That's it!** Just add `--use-tracking` to enable the advanced pipeline. 🎾⚽🏀
