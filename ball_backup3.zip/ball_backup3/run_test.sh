#!/bin/bash

# Ball Detection Pipeline - Quick Test Script
# This script helps you quickly test different configurations

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║     Ball Detection Pipeline - Quick Test                      ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Function to test webcam
test_webcam() {
    echo "Testing webcam detection..."
    echo "Press 'q' to quit and move to next test"
    echo ""
    python main.py --source webcam --confidence 0.3
}

# Function to test with sample (if exists)
test_video() {
    if [ -f "$1" ]; then
        echo "Testing with video file: $1"
        echo "Press 'q' to quit and move to next test"
        echo ""
        python main.py --source "$1" --confidence 0.3
    else
        echo "Video file not found: $1"
        echo "Skipping video test..."
    fi
}

# Main menu
echo "Choose test mode:"
echo "1) Test webcam (default)"
echo "2) Test with your video file"
echo "3) Run setup verification"
echo "4) Show help"
echo ""
read -p "Enter choice [1-4]: " choice

case $choice in
    1)
        test_webcam
        ;;
    2)
        read -p "Enter video file path: " video_path
        test_video "$video_path"
        ;;
    3)
        python test_setup.py
        ;;
    4)
        python main.py --help
        ;;
    *)
        echo "Invalid choice. Running default (webcam)..."
        test_webcam
        ;;
esac

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║     Test complete! See README.md for more options             ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
