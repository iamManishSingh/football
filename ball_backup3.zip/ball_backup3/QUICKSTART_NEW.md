# Quick Start Guide - Updated

Get up and running with ball detection in 4 steps!

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

This will install:
- `rfdetr` - RF-DETR model
- `opencv-python` - Video processing
- `supervision` - Visualization utilities
- `torch` & `torchvision` - Deep learning
- Other required packages

**Note**: This may take 5-10 minutes depending on your system.

---

## Step 2: Download Models (Recommended)

Pre-download the RF-DETR models to the local `models/` folder:

```bash
python download_models.py
```

### Interactive Menu:
```
============================================================
RF-DETR Model Downloader
============================================================
Models will be saved to: /path/to/ball/models
============================================================

Available models to download:
  1. rfdetr-base    (~150 MB)
  2. rfdetr-large   (~300 MB)
  3. Download all
  0. Exit

Select option [0-3]:
```

**Select option 3 to download all models** (recommended) or choose specific models.

### What Gets Downloaded:
- **rfdetr-base**: ~150 MB - Faster, good accuracy
- **rfdetr-large**: ~300 MB - Slower, better accuracy

Models are saved to: `models/rfdetr_base.pth` and `models/rfdetr_large.pth`

**Why download first?**
- ✓ Faster startup on subsequent runs
- ✓ Works offline after download
- ✓ Clear visibility of model files
- ✓ No surprises during first run

---

## Step 3: Test Your Setup

```bash
python test_setup.py
```

This verifies:
- ✓ All dependencies are installed
- ✓ GPU/CPU device detection
- ✓ Webcam availability
- ✓ Downloaded models

---

## Step 4: Run Detection

### Option A: Webcam (Live)

```bash
python main.py
```

### Option B: Video File

```bash
python main.py --source your_video.mp4
```

Press `q` to quit!

---

## What Happens When You Run?

1. ✓ Model loads from `models/` folder (instant if pre-downloaded)
2. ✓ Video source opens (webcam or file)
3. ✓ Each frame is processed in real-time
4. ✓ Live window shows:
   - Green bounding boxes around detected balls
   - Labels with confidence scores
   - FPS counter
   - Detection count

---

## Commands Summary

```bash
# 1. Install
pip install -r requirements.txt

# 2. Download models (do this once)
python download_models.py

# 3. Test setup
python test_setup.py

# 4. Run on video
python main.py --source video.mp4
```

---

## Alternative: Skip Pre-Download

If you skip Step 2, models will auto-download on first run:

```bash
# This works but downloads during first run
python main.py --source video.mp4
```

The first run will download models automatically (~2-5 minutes), but it's better to use `download_models.py` for control.

---

## Common Options

```bash
# Higher confidence (fewer false positives)
python main.py --source video.mp4 --confidence 0.6

# Better accuracy (slower)
python main.py --source video.mp4 --model large

# Save output
python main.py --source video.mp4 --save-output output.mp4

# Faster on CPU
python main.py --resolution 320
```

---

## Managing Models

### List Downloaded Models
```bash
python download_models.py --list
```

Output:
```
============================================================
Downloaded Models
============================================================
✓ rfdetr_base.pth     (145.2 MB)
✓ rfdetr_large.pth    (287.6 MB)
============================================================
```

### Verify Models
```bash
python download_models.py --verify
```

### Re-download Models
```bash
# Run the interactive script again
python download_models.py
```

---

## Troubleshooting

**Download fails?**
- Check internet connection
- Try again - downloads can be interrupted
- Models are downloaded from HuggingFace

**Models not found during inference?**
```bash
# Check if models exist
ls -lh models/

# Re-download
python download_models.py
```

**Want to use online download instead?**
- Simply skip Step 2
- Models will download automatically on first `main.py` run
- Will be cached to `models/` folder automatically

---

**That's it! You're ready to detect balls in real-time!** 🎾⚽🏀

**Next**: See [USAGE.md](USAGE.md) for advanced examples
