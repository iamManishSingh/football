# Quick Start Guide

Get up and running with ball detection in 3 steps!

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

This will install:
- `rfdetr` - RF-DETR model
- `opencv-python` - Video processing
- `supervision` - Visualization utilities
- `torch` & `torchvision` - Deep learning
- Other required packages

## Step 2: Test Your Setup

```bash
python test_setup.py
```

This verifies:
- ✓ All dependencies are installed
- ✓ GPU/CPU device detection
- ✓ Webcam availability

## Step 3: Run Detection

### Option A: Webcam (Live)

```bash
python main.py
```

### Option B: Video File

```bash
python main.py --source your_video.mp4
```

Press `q` to quit!

## What Happens on First Run?

The model weights (~150MB) will auto-download from HuggingFace. This takes 2-5 minutes depending on your connection. Subsequent runs are instant!

## Next Steps

- See [USAGE.md](USAGE.md) for detailed examples
- See [README.md](README.md) for full documentation

## Common Options

```bash
# Higher confidence (fewer false positives)
python main.py --source video.mp4 --confidence 0.6

# Better accuracy (slower)
python main.py --source video.mp4 --model large

# Save output
python main.py --source video.mp4 --save-output output.mp4

# Faster on CPU
python main.py --resolution 320
```

## Troubleshooting

**No webcam?**
```bash
python main.py --source 1  # Try device 1
```

**Slow on CPU?**
```bash
python main.py --resolution 320  # Lower resolution
```

**Too many false detections?**
```bash
python main.py --confidence 0.7  # Higher threshold
```

---

**That's it! You're ready to detect balls in real-time!** 🎾⚽🏀
