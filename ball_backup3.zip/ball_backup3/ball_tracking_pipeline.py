"""
⚽ Football Ball Detection Post-Processing Pipeline (Python Port)

A single-file module that filters, tracks, and smooths ball detections
from any object detection model (RF-DETR, YOLO, etc.)

USAGE:
─────────────────────────────────────────────────────────────────
from ball_tracking_pipeline import BallTrackingPipeline

pipeline = BallTrackingPipeline(
    frame_width=1920,
    frame_height=1080,
    confidence_threshold=0.5,
    # ... other config overrides
)

# For each frame, pass your model's raw detections:
result = pipeline.process_frame(frame_index, raw_detections)
# raw_detections = [{"x": ..., "y": ..., "width": ..., "height": ..., "confidence": ...}, ...]
# result = {"x": ..., "y": ..., "w": ..., "h": ..., "confidence": ..., "state": ..., "is_predicted": ...} or None

# After processing all frames (optional): fill gaps with interpolation
smoothed_trajectory = pipeline.get_smoothed_trajectory()
─────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import csv
import io
import math
from copy import deepcopy
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

# Import the single source of truth for tracker defaults.
# Users can still override individual keys via BallTrackingPipeline(**overrides).
from config import TRACKER_CONFIG


# ============================================================================
# SECTION 1: CONFIGURATION
# ============================================================================

# All defaults now live in config.py → TRACKER_CONFIG.
# This alias keeps the rest of the file unchanged.
DEFAULT_CONFIG: Dict[str, Any] = TRACKER_CONFIG


# ============================================================================
# SECTION 2: KALMAN FILTER
# ============================================================================

class KalmanFilter:
    """
    6-state Kalman Filter: [x, y, vx, vy, ax, ay]

    Models position, velocity, and acceleration.
    Acceleration state allows tracking parabolic (aerial) trajectories
    where gravity affects the vertical component.

    When detection is lost, predict() continues the trajectory using
    last known velocity + acceleration — this is what keeps the track
    alive during aerial play.

    Direction-change handling:
    - When the innovation (difference between predicted and measured position)
      is large, the velocity and acceleration states are reset so the tracker
      snaps to the new direction instead of drifting in the old one.
    - Acceleration states decay each frame so stale momentum doesn't persist.
    """

    def __init__(
        self,
        process_noise: float = 8.0,
        measurement_noise: float = 2.0,
        gravity: float = 0.5,
        direction_change_threshold: float = 60.0,
        acceleration_decay: float = 0.6,
    ):
        self.state_size = 6   # [x, y, vx, vy, ax, ay]
        self.meas_size = 2    # [x, y]
        self.gravity = gravity
        self.direction_change_threshold = direction_change_threshold
        self.acceleration_decay = acceleration_decay

        # State vector
        self.state = [0.0] * 6

        # State covariance (6×6) — high initial uncertainty
        self.P = self._eye(6, 1000.0)

        # Transition matrix (constant-acceleration model, dt = 1 frame)
        # x'  = x + vx + 0.5*ax
        # y'  = y + vy + 0.5*ay
        # vx' = vx + ax
        # vy' = vy + ay
        # ax' = ax
        # ay' = ay
        self.F = [
            [1, 0, 1, 0, 0.5, 0  ],
            [0, 1, 0, 1, 0,   0.5],
            [0, 0, 1, 0, 1,   0  ],
            [0, 0, 0, 1, 0,   1  ],
            [0, 0, 0, 0, 1,   0  ],
            [0, 0, 0, 0, 0,   1  ],
        ]

        # Measurement matrix: we observe [x, y]
        self.H = [
            [1, 0, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0],
        ]

        # Process noise covariance (6×6)
        self.Q = self._eye(6, process_noise)
        # Less noise on acceleration states (they change slowly)
        self.Q[4][4] = process_noise * 0.1
        self.Q[5][5] = process_noise * 0.1

        # Measurement noise covariance (2×2)
        self.R = self._eye(2, measurement_noise)

        self.initialized = False

    # ── Public API ──────────────────────────────────────────────

    def initialize(self, x: float, y: float) -> None:
        """Initialize with first detection."""
        self.state = [x, y, 0.0, 0.0, 0.0, self.gravity]
        self.P = self._eye(6, 100.0)
        self.initialized = True

    def predict(self) -> Tuple[float, float]:
        """
        Predict next state (one frame forward).
        Call once per frame BEFORE update().
        Returns predicted (x, y).
        """
        if not self.initialized:
            return (0.0, 0.0)

        # Decay acceleration so stale momentum doesn't persist
        # (keeps gravity component via re-initialization, decays learned ax)
        self.state[4] *= self.acceleration_decay   # ax
        self.state[5] = (self.state[5] - self.gravity) * self.acceleration_decay + self.gravity  # ay: decay only non-gravity part

        # Also decay velocity each prediction step.
        # This prevents the bounding box from drifting endlessly when the ball
        # stops or changes direction.  A real ball decelerates due to friction.
        # During TRACKING (update() is called right after), the measurement
        # will correct the velocity anyway, so this only matters during
        # PREDICTING when no detection is available.
        velocity_decay = 0.85  # lose 15% speed per frame → stops in ~10 frames
        self.state[2] *= velocity_decay   # vx
        self.state[3] = (self.state[3] - self.gravity) * velocity_decay + self.gravity  # vy: decay only non-gravity part

        # state = F · state
        new_state = [0.0] * 6
        for i in range(6):
            s = 0.0
            for j in range(6):
                s += self.F[i][j] * self.state[j]
            new_state[i] = s
        self.state = new_state

        # P = F · P · Fᵀ + Q
        FP = self._mul66(self.F, self.P)
        FPFt = self._mul_transpose66(FP, self.F)
        self.P = self._add_mat(FPFt, self.Q)

        return (self.state[0], self.state[1])

    def update(self, x: float, y: float) -> Tuple[float, float]:
        """
        Update state with a measurement (x, y).
        Call after predict() when a detection is available.
        Returns corrected (x, y).

        Direction-change handling:
          If the innovation is very large (ball suddenly changed direction,
          e.g. during a pass), reset velocity and acceleration to prevent
          the tracker from drifting in the old direction.
        """
        if not self.initialized:
            self.initialize(x, y)
            return (x, y)

        z = [x, y]

        # Innovation: y = z − H · state
        innovation = [
            z[0] - self.state[0],
            z[1] - self.state[1],
        ]

        # ── Direction-change detection ──
        # If the measurement is far from the prediction, the ball changed
        # direction sharply.  Reset velocity/acceleration so the Kalman
        # doesn't keep pulling in the old direction.
        innov_magnitude = math.sqrt(innovation[0] ** 2 + innovation[1] ** 2)
        if innov_magnitude > self.direction_change_threshold:
            # Snap velocity to the direction of the innovation
            self.state[2] = innovation[0]   # vx = jump in x
            self.state[3] = innovation[1]   # vy = jump in y
            # Reset acceleration (keep gravity on ay)
            self.state[4] = 0.0
            self.state[5] = self.gravity
            # Increase uncertainty so Kalman trusts the measurement
            for r in range(6):
                self.P[r][r] = max(self.P[r][r], 500.0)

        # S = H · P · Hᵀ + R  (2×2)
        HP = self._mul26(self.H, self.P)
        S = self._add_mat2(self._mul2x_transpose(HP, self.H), self.R)

        # K = P · Hᵀ · S⁻¹  (6×2)
        PHt = self._mul_transpose62(self.P, self.H)
        S_inv = self._inv2x2(S)
        K = self._mul62x22(PHt, S_inv)

        # state = state + K · innovation
        for i in range(6):
            self.state[i] += K[i][0] * innovation[0] + K[i][1] * innovation[1]

        # P = (I − K · H) · P
        KH = self._mul66_from62x26(K, self.H)
        I_KH = self._subtract_from_identity6(KH)
        self.P = self._mul66(I_KH, self.P)

        return (self.state[0], self.state[1])

    def get_velocity(self) -> Tuple[float, float]:
        """Current velocity (vx, vy)."""
        return (self.state[2], self.state[3])

    def get_speed(self) -> float:
        """Current speed (magnitude of velocity)."""
        return math.sqrt(self.state[2] ** 2 + self.state[3] ** 2)

    def get_acceleration(self) -> Tuple[float, float]:
        """Current acceleration (ax, ay)."""
        return (self.state[4], self.state[5])

    # ── Matrix helpers (small fixed-size, no numpy needed) ─────

    @staticmethod
    def _eye(n: int, scale: float = 1.0) -> List[List[float]]:
        m = [[0.0] * n for _ in range(n)]
        for i in range(n):
            m[i][i] = scale
        return m

    @staticmethod
    def _mul66(A, B):
        C = [[0.0] * 6 for _ in range(6)]
        for i in range(6):
            for j in range(6):
                s = 0.0
                for k in range(6):
                    s += A[i][k] * B[k][j]
                C[i][j] = s
        return C

    @staticmethod
    def _mul_transpose66(A, B):
        """A (6×6) · Bᵀ (6×6) → C (6×6)."""
        C = [[0.0] * 6 for _ in range(6)]
        for i in range(6):
            for j in range(6):
                s = 0.0
                for k in range(6):
                    s += A[i][k] * B[j][k]
                C[i][j] = s
        return C

    @staticmethod
    def _add_mat(A, B):
        rows = len(A)
        cols = len(A[0])
        return [[A[i][j] + B[i][j] for j in range(cols)] for i in range(rows)]

    @staticmethod
    def _add_mat2(A, B):
        return [
            [A[0][0] + B[0][0], A[0][1] + B[0][1]],
            [A[1][0] + B[1][0], A[1][1] + B[1][1]],
        ]

    @staticmethod
    def _mul26(H, P):
        """H (2×6) · P (6×6) → (2×6)."""
        C = [[0.0] * 6 for _ in range(2)]
        for i in range(2):
            for j in range(6):
                s = 0.0
                for k in range(6):
                    s += H[i][k] * P[k][j]
                C[i][j] = s
        return C

    @staticmethod
    def _mul2x_transpose(A, B):
        """A (2×6) · Bᵀ (6×2) → (2×2)."""
        C = [[0.0, 0.0], [0.0, 0.0]]
        for i in range(2):
            for j in range(2):
                s = 0.0
                for k in range(6):
                    s += A[i][k] * B[j][k]
                C[i][j] = s
        return C

    @staticmethod
    def _mul_transpose62(P, H):
        """P (6×6) · Hᵀ (6×2) → (6×2)."""
        C = [[0.0, 0.0] for _ in range(6)]
        for i in range(6):
            for k in range(6):
                C[i][0] += P[i][k] * H[0][k]
                C[i][1] += P[i][k] * H[1][k]
        return C

    @staticmethod
    def _mul62x22(A, B):
        """A (6×2) · B (2×2) → (6×2)."""
        C = [[0.0, 0.0] for _ in range(6)]
        for i in range(6):
            C[i][0] = A[i][0] * B[0][0] + A[i][1] * B[1][0]
            C[i][1] = A[i][0] * B[0][1] + A[i][1] * B[1][1]
        return C

    @staticmethod
    def _mul66_from62x26(A, B):
        """A (6×2) · B (2×6) → (6×6)."""
        C = [[0.0] * 6 for _ in range(6)]
        for i in range(6):
            for j in range(6):
                for k in range(2):
                    C[i][j] += A[i][k] * B[k][j]
        return C

    @staticmethod
    def _subtract_from_identity6(A):
        C = [[0.0] * 6 for _ in range(6)]
        for i in range(6):
            for j in range(6):
                C[i][j] = (1.0 if i == j else 0.0) - A[i][j]
        return C

    @staticmethod
    def _inv2x2(M):
        det = M[0][0] * M[1][1] - M[0][1] * M[1][0]
        if abs(det) < 1e-10:
            return [[1e6, 0.0], [0.0, 1e6]]
        inv_det = 1.0 / det
        return [
            [ M[1][1] * inv_det, -M[0][1] * inv_det],
            [-M[1][0] * inv_det,  M[0][0] * inv_det],
        ]


# ============================================================================
# SECTION 3: DETECTION FILTERS
# ============================================================================

class DetectionFilters:
    """
    All filtering logic to reject false positives.
    Each filter takes a list of detections and returns a filtered list.
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.frame_area = config["frame_width"] * config["frame_height"]
        self.frame_diagonal = math.sqrt(config["frame_width"] ** 2 + config["frame_height"] ** 2)
        self.min_area = self.frame_area * config["min_ball_area_ratio"]
        self.max_area = self.frame_area * config["max_ball_area_ratio"]
        self.max_jump = config["max_jump_distance"] or (config["max_jump_distance_ratio"] * self.frame_diagonal)

        # Pre-compute ROI bounds
        self.roi_top = config["frame_height"] * config["exclude_top_ratio"]
        self.roi_bottom = config["frame_height"] * (1 - config["exclude_bottom_ratio"])
        self.roi_left = config["frame_width"] * config["exclude_left_ratio"]
        self.roi_right = config["frame_width"] * (1 - config["exclude_right_ratio"])

    def filter_by_confidence(
        self,
        detections: List[Dict],
        search_zone: Optional[Dict] = None,
    ) -> List[Dict]:
        """
        Two-tier confidence filter.

        Addresses: False positives (shoes, distant objects)
        AND: Re-acquisition after aerial play (lower threshold near predicted zone)
        """
        result = []
        for d in detections:
            if search_zone is not None:
                dist = _distance(d["cx"], d["cy"], search_zone["x"], search_zone["y"])
                if dist <= search_zone["radius"]:
                    if d["confidence"] >= self.config["search_zone_confidence_threshold"]:
                        result.append(d)
                    continue
            # Outside search zone (or no zone): strict threshold
            if d["confidence"] >= self.config["confidence_threshold"]:
                result.append(d)
        return result

    def filter_by_size(self, detections: List[Dict]) -> List[Dict]:
        """
        Size filter — reject detections that are too large or too small.

        Addresses: Shoes, body parts (too large), noise (too small).
        A football has a fairly consistent size at any given camera distance.
        """
        result = []
        for d in detections:
            area = d["width"] * d["height"]
            if area < self.min_area or area > self.max_area:
                if self.config["debug"]:
                    print(f"  [SIZE REJECT] area={area:.0f}, bounds=[{self.min_area:.0f}, {self.max_area:.0f}]")
                continue
            result.append(d)
        return result

    def filter_by_aspect_ratio(self, detections: List[Dict]) -> List[Dict]:
        """
        Aspect ratio filter — reject elongated bounding boxes.

        Addresses: Shoes produce wide/tall boxes. Ball should be ~square.
        """
        result = []
        for d in detections:
            ratio = d["width"] / max(d["height"], 1)
            if ratio < self.config["min_aspect_ratio"] or ratio > self.config["max_aspect_ratio"]:
                if self.config["debug"]:
                    print(f"  [ASPECT REJECT] ratio={ratio:.2f}, bounds=[{self.config['min_aspect_ratio']}, {self.config['max_aspect_ratio']}]")
                continue
            result.append(d)
        return result

    def filter_by_roi(self, detections: List[Dict]) -> List[Dict]:
        """
        ROI filter — reject detections outside the playing area.

        Addresses: Detections in crowd, scoreboard, broadcast graphics, sky.
        """
        if not self.config["use_roi"]:
            return detections

        result = []
        for d in detections:
            cx, cy = d["cx"], d["cy"]

            # Custom polygon first
            if self.config["custom_roi_polygon"] is not None:
                if not _point_in_polygon(cx, cy, self.config["custom_roi_polygon"]):
                    if self.config["debug"]:
                        print(f"  [ROI POLYGON REJECT] ({cx:.0f}, {cy:.0f})")
                    continue
                result.append(d)
                continue

            # Rectangular ROI
            if cy < self.roi_top or cy > self.roi_bottom or cx < self.roi_left or cx > self.roi_right:
                if self.config["debug"]:
                    print(
                        f"  [ROI REJECT] ({cx:.0f}, {cy:.0f}) outside "
                        f"[{self.roi_left:.0f},{self.roi_top:.0f},{self.roi_right:.0f},{self.roi_bottom:.0f}]"
                    )
                continue
            result.append(d)
        return result

    def filter_by_max_jump(
        self,
        detections: List[Dict],
        last_position: Optional[Dict] = None,
    ) -> List[Dict]:
        """
        Maximum jump filter — reject detections too far from last known position.

        Addresses: A real ball can't teleport. If a detection appears far from the
        tracked position, it's almost certainly a false positive.
        """
        if last_position is None:
            return detections

        result = []
        for d in detections:
            dist = _distance(d["cx"], d["cy"], last_position["x"], last_position["y"])
            if dist > self.max_jump:
                if self.config["debug"]:
                    print(f"  [JUMP REJECT] dist={dist:.0f}, max={self.max_jump:.0f}")
                continue
            result.append(d)
        return result

    def apply_all(
        self,
        detections: List[Dict],
        search_zone: Optional[Dict] = None,
        last_position: Optional[Dict] = None,
    ) -> List[Dict]:
        """
        Apply ALL filters in sequence.
        Order matters: cheapest filters first, most restrictive last.
        """
        d = detections
        debug = self.config["debug"]

        if debug and d:
            print(f"\n  Raw detections: {len(d)}")

        d = self.filter_by_confidence(d, search_zone)
        if debug:
            print(f"  After confidence: {len(d)}")

        d = self.filter_by_size(d)
        if debug:
            print(f"  After size: {len(d)}")

        d = self.filter_by_aspect_ratio(d)
        if debug:
            print(f"  After aspect ratio: {len(d)}")

        d = self.filter_by_roi(d)
        if debug:
            print(f"  After ROI: {len(d)}")

        d = self.filter_by_max_jump(d, last_position)
        if debug:
            print(f"  After max jump: {len(d)}")

        return d


# ============================================================================
# SECTION 4: TRACK MANAGER (State Machine)
# ============================================================================

class TrackManager:
    """
    Manages the ball track lifecycle with states:

        NO_TRACK → TENTATIVE → VALIDATING → TRACKING → PREDICTING → LOST → NO_TRACK
                                     ↑           ↑            │
                                     │           └────────────┘  (re-acquired)
                                     │
                                     └── rejected if static (shoe/logo/marking)

    Strategy: "Detect aggressively, validate over time."
    - TENTATIVE: require N detections in M frames to start a candidate track
    - VALIDATING: require the candidate to actually MOVE before promoting
    - TRACKING: ball is being actively tracked; continuously check for static stall
    - PREDICTING: ball lost, use Kalman to predict landing zone

    Addresses:
    - Aerial ball: PREDICTING state keeps the track alive using Kalman prediction
    - Static FPs: VALIDATING + continuous static check kills shoes/logos/markings
    - Re-acquisition: Search zone around predicted position with lower confidence threshold
    - Fast movement: Velocity-aware search radius expands when ball is moving fast
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.kalman = KalmanFilter(
            process_noise=config["kalman_process_noise"],
            measurement_noise=config["kalman_measurement_noise"],
            gravity=config["gravity_pixels_per_frame2"],
            direction_change_threshold=config.get("kalman_direction_change_threshold", 60.0),
            acceleration_decay=config.get("kalman_acceleration_decay", 0.6),
        )
        self.filters = DetectionFilters(config)

        # State
        self.state: str = "NO_TRACK"  # NO_TRACK | TENTATIVE | VALIDATING | TRACKING | PREDICTING
        self.frames_lost: int = 0
        self.last_detected_position: Optional[Dict] = None
        self.last_position: Optional[Dict] = None
        self.frame_history: List[Dict] = []

        # Track confirmation buffer
        self.candidate_buffer: List[Dict] = []
        self.candidate_frame_start: int = -1

        # Position history for static-object rejection (sliding window)
        # Each entry: {"x": float, "y": float, "frame": int}
        self.position_history: List[Dict] = []

        # Validation state tracking
        self.validation_frame_start: int = -1
        self.validation_positions: List[Dict] = []

        # Aerial recovery state
        self._aerial_recovery_active: bool = False
        self._velocity_at_loss: Tuple[float, float] = (0.0, 0.0)

    def process_frame(self, frame_index: int, raw_detections: List[Dict]) -> Optional[Dict]:
        """
        Process one frame of detections.

        Args:
            frame_index: Current frame number.
            raw_detections: Raw model detections for this frame.
                Each detection dict:
                    x, y        — top-left corner of bounding box (pixels)
                    width, height — bbox dimensions (pixels)
                    confidence  — model confidence (0–1)
                    class_id    — (optional) integer class id

        Returns:
            Tracked ball dict or None:
                x, y            — ball center (pixels)
                w, h            — bbox size (0 if predicted)
                confidence      — 0 if predicted
                state           — "TRACKING" | "PREDICTING" | "TENTATIVE"
                is_predicted    — True = Kalman prediction only
                velocity        — {"vx": ..., "vy": ...}
                speed           — velocity magnitude
        """
        detections = self._normalize_detections(raw_detections)

        if self.config["debug"]:
            print(f"\nFrame {frame_index} | State: {self.state} | Raw: {len(detections)}")

        search_zone = self._get_search_zone()

        filtered = self.filters.apply_all(
            detections,
            search_zone=search_zone,
            last_position=self.last_detected_position,
        )

        result: Optional[Dict] = None

        if self.state == "NO_TRACK":
            result = self._handle_no_track(frame_index, filtered)
        elif self.state == "TENTATIVE":
            result = self._handle_tentative(frame_index, filtered)
        elif self.state == "VALIDATING":
            result = self._handle_validating(frame_index, filtered)
        elif self.state == "TRACKING":
            result = self._handle_tracking(frame_index, filtered)
        elif self.state == "PREDICTING":
            result = self._handle_predicting(frame_index, filtered)

        # Record history
        self.frame_history.append({
            "frame": frame_index,
            "ball": deepcopy(result) if result else None,
            "state": self.state,
            "raw_count": len(raw_detections),
            "filtered_count": len(filtered),
        })

        return result

    # ── State Handlers ──────────────────────────────────────────

    def _handle_no_track(self, frame_index: int, filtered: List[Dict]) -> Optional[Dict]:
        if not filtered:
            return None

        best = self._pick_best(filtered)

        if self.config["min_detections_to_confirm"] <= 1:
            self.kalman.initialize(best["cx"], best["cy"])
            self.last_detected_position = {"x": best["cx"], "y": best["cy"]}
            self.last_position = {"x": best["cx"], "y": best["cy"]}

            # If static rejection is enabled, require motion validation first
            if self.config.get("enable_static_rejection", True):
                self.state = "VALIDATING"
                self.validation_frame_start = frame_index
                self.validation_positions = [{"x": best["cx"], "y": best["cy"], "frame": frame_index}]
                if self.config["debug"]:
                    print(f"  → VALIDATING (single-detect confirm, need motion proof)")
                return self._make_result(best["cx"], best["cy"], best["width"], best["height"], best["confidence"], False)
            else:
                self.state = "TRACKING"
                return self._make_result(best["cx"], best["cy"], best["width"], best["height"], best["confidence"], False)

        # Tentative: require multiple detections to confirm
        self.candidate_buffer = [{"frame": frame_index, "detection": best}]
        self.candidate_frame_start = frame_index
        self.state = "TENTATIVE"
        return None

    def _handle_tentative(self, frame_index: int, filtered: List[Dict]) -> Optional[Dict]:
        if frame_index - self.candidate_frame_start > self.config["confirm_window_frames"]:
            self.state = "NO_TRACK"
            self.candidate_buffer = []
            return None

        if filtered:
            best = self._pick_best(filtered)
            self.candidate_buffer.append({"frame": frame_index, "detection": best})

            if len(self.candidate_buffer) >= self.config["min_detections_to_confirm"]:
                self.kalman.initialize(best["cx"], best["cy"])
                self.last_detected_position = {"x": best["cx"], "y": best["cy"]}
                self.last_position = {"x": best["cx"], "y": best["cy"]}
                self.frames_lost = 0

                # If static rejection is enabled, go through VALIDATING first
                if self.config.get("enable_static_rejection", True):
                    self.state = "VALIDATING"
                    self.validation_frame_start = frame_index
                    self.validation_positions = []
                    # Seed validation with positions from the candidate buffer
                    for entry in self.candidate_buffer:
                        d = entry["detection"]
                        self.validation_positions.append({
                            "x": d["cx"], "y": d["cy"], "frame": entry["frame"]
                        })
                    if self.config["debug"]:
                        print(f"  → VALIDATING (need motion proof over {self.config['validation_min_frames']} frames)")
                    return self._make_result(best["cx"], best["cy"], best["width"], best["height"], best["confidence"], False)
                else:
                    # Skip validation, go straight to TRACKING
                    self.state = "TRACKING"
                    return self._make_result(best["cx"], best["cy"], best["width"], best["height"], best["confidence"], False)

        return None

    def _handle_validating(self, frame_index: int, filtered: List[Dict]) -> Optional[Dict]:
        """
        VALIDATING state: the track has been tentatively confirmed (N detections in M
        frames), but we need to prove it's actually MOVING before we promote it to
        full TRACKING.  If it sits still (shoe / logo / pitch marking), kill it.

        Emits result so the user sees the candidate, but marks state="VALIDATING".
        """
        pred_x, pred_y = self.kalman.predict()

        if filtered:
            best = self._closest_to(filtered, pred_x, pred_y)
            corr_x, corr_y = self.kalman.update(best["cx"], best["cy"])

            self.validation_positions.append({
                "x": best["cx"], "y": best["cy"], "frame": frame_index
            })
            self.last_detected_position = {"x": corr_x, "y": corr_y}
            self.last_position = {"x": corr_x, "y": corr_y}

            # Check if we have enough frames to decide
            frames_in_validation = frame_index - self.validation_frame_start + 1
            if frames_in_validation >= self.config["validation_min_frames"]:
                moving_count = self._count_moving_frames(self.validation_positions)

                if moving_count >= self.config["validation_min_moving_frames"]:
                    # It's moving — promote to TRACKING
                    self.state = "TRACKING"
                    self.position_history = list(self.validation_positions)  # carry over
                    self.validation_positions = []
                    if self.config["debug"]:
                        print(f"  → TRACKING (validated: {moving_count} moving frames)")
                    return self._make_result(corr_x, corr_y, best["width"], best["height"], best["confidence"], False)
                else:
                    # Static object — kill the track
                    if self.config["debug"]:
                        print(f"  → STATIC REJECTED (only {moving_count} moving frames, need {self.config['validation_min_moving_frames']})")
                    self._reset_track()
                    return None

            # Still collecting evidence — output the candidate position
            return self._make_result(corr_x, corr_y, best["width"], best["height"], best["confidence"], False)
        else:
            # Lost detection during validation — kill the candidate
            if self.config["debug"]:
                print("  → VALIDATION FAILED (lost detection)")
            self._reset_track()
            return None

    def _handle_tracking(self, frame_index: int, filtered: List[Dict]) -> Optional[Dict]:
        pred_x, pred_y = self.kalman.predict()

        if filtered:
            best = self._closest_to(filtered, pred_x, pred_y)
            det_dist = math.sqrt((best["cx"] - pred_x) ** 2 + (best["cy"] - pred_y) ** 2)

            if det_dist > self.config.get("kalman_direction_change_threshold", 60.0):
                # Ball changed direction sharply (e.g. kick, bounce, stop).
                # Re-initialize Kalman at the detection position so the tracker
                # doesn't keep pulling in the old direction.
                self.kalman.initialize(best["cx"], best["cy"])
                out_x, out_y = best["cx"], best["cy"]
            else:
                corr_x, corr_y = self.kalman.update(best["cx"], best["cy"])
                out_x, out_y = corr_x, corr_y

            self.last_detected_position = {"x": out_x, "y": out_y}
            self.last_position = {"x": out_x, "y": out_y}
            self.frames_lost = 0

            # ── Continuous static-object check ──
            # Even a confirmed track can become stale (e.g. ball stops and camera
            # pans — the track latches onto a static marking/logo). Record position
            # and check for staleness over the sliding window.
            if self.config.get("enable_static_rejection", True):
                self.position_history.append({
                    "x": out_x, "y": out_y, "frame": frame_index
                })
                # Trim to window size
                window = self.config["static_check_frames"]
                if len(self.position_history) > window:
                    self.position_history = self.position_history[-window:]

                # Only check once we have a full window
                if len(self.position_history) >= window:
                    if self._is_static(self.position_history):
                        if self.config["debug"]:
                            print(f"  → STATIC KILL (tracked object hasn't moved for {window} frames)")
                        self._reset_track()
                        return None

            return self._make_result(out_x, out_y, best["width"], best["height"], best["confidence"], False)

        # No detection → PREDICTING
        self.state = "PREDICTING"
        self.frames_lost = 1
        self.last_position = {"x": pred_x, "y": pred_y}

        # Capture velocity at the moment we lose the ball.
        # If the ball was moving fast (goal shot), activate aerial recovery.
        vx, vy = self.kalman.get_velocity()
        self._velocity_at_loss = (vx, vy)
        speed_at_loss = self.kalman.get_speed()
        min_speed = self.config.get("aerial_recovery_min_speed", 15.0)
        if speed_at_loss >= min_speed:
            self._aerial_recovery_active = True
            if self.config["debug"]:
                print(f"  → PREDICTING (lost detection, AERIAL RECOVERY activated, speed={speed_at_loss:.1f})")
        else:
            self._aerial_recovery_active = False
            if self.config["debug"]:
                print("  → PREDICTING (lost detection)")

        return self._make_result(pred_x, pred_y, 0, 0, 0.0, True)

    def _handle_predicting(self, frame_index: int, filtered: List[Dict]) -> Optional[Dict]:
        pred_x, pred_y = self.kalman.predict()
        self.frames_lost += 1

        # Determine effective max prediction frames
        base_max = self.config["max_frames_to_predict"]
        if self._aerial_recovery_active:
            max_predict = base_max + self.config.get("aerial_recovery_max_frames", 20)
        else:
            max_predict = base_max

        if filtered:
            search_radius = self._get_search_radius()

            if self._aerial_recovery_active:
                # ── AERIAL RECOVERY: expanded search ──────────────
                scale = self.config.get("aerial_recovery_search_scale", 2.5)
                vert_bias = self.config.get("aerial_recovery_vertical_bias", 1.5)
                aerial_radius = search_radius * scale
                aerial_min_conf = self.config.get("aerial_recovery_min_confidence", 0.15)

                if self.config["debug"]:
                    print(f"  [AERIAL-SEARCH] radius={aerial_radius:.0f}, "
                          f"min_conf={aerial_min_conf:.2f}, pred=({pred_x:.0f},{pred_y:.0f})")

                # Search near PREDICTED position with vertical bias
                # (ball trajectory during a shot is more vertical)
                nearby_pred = []
                for d in filtered:
                    dx = d["cx"] - pred_x
                    dy = d["cy"] - pred_y
                    # Vertical bias: compress vertical distance so the search
                    # ellipse is taller than wide
                    dist = math.sqrt(dx ** 2 + (dy / vert_bias) ** 2)
                    if dist <= aerial_radius and d["confidence"] >= aerial_min_conf:
                        nearby_pred.append(d)

                # ALSO search near LAST DETECTED position
                nearby_last = []
                if self.last_detected_position is not None:
                    lx = self.last_detected_position["x"]
                    ly = self.last_detected_position["y"]
                    last_radius = max(aerial_radius, self.config["min_search_radius"] * 2.0)
                    for d in filtered:
                        dx = d["cx"] - lx
                        dy = d["cy"] - ly
                        dist = math.sqrt(dx ** 2 + (dy / vert_bias) ** 2)
                        if dist <= last_radius and d["confidence"] >= aerial_min_conf:
                            nearby_last.append(d)

                candidates = nearby_pred or nearby_last
            else:
                # ── STANDARD dual search (existing logic) ─────────
                # Search near the PREDICTED position
                nearby_pred = [
                    d for d in filtered
                    if math.sqrt((d["cx"] - pred_x) ** 2 + (d["cy"] - pred_y) ** 2) <= search_radius
                ]

                # ALSO search near the LAST DETECTED position
                nearby_last = []
                if self.last_detected_position is not None:
                    lx = self.last_detected_position["x"]
                    ly = self.last_detected_position["y"]
                    last_radius = max(search_radius, self.config["min_search_radius"] * 1.5)
                    nearby_last = [
                        d for d in filtered
                        if math.sqrt((d["cx"] - lx) ** 2 + (d["cy"] - ly) ** 2) <= last_radius
                    ]

                candidates = nearby_pred or nearby_last

            if candidates:
                best = self._pick_best(candidates)

                # SNAP: Re-initialize Kalman at the detection position.
                self.kalman.initialize(best["cx"], best["cy"])

                self.state = "TRACKING"
                self.frames_lost = 0
                self._aerial_recovery_active = False
                self.last_detected_position = {"x": best["cx"], "y": best["cy"]}
                self.last_position = {"x": best["cx"], "y": best["cy"]}
                self.position_history = []  # fresh start for static check

                if self.config["debug"]:
                    tag = " (aerial re-acquired)" if self._aerial_recovery_active else ""
                    print(f"  → RE-ACQUIRED at ({best['cx']:.0f},{best['cy']:.0f}){tag}")

                return self._make_result(best["cx"], best["cy"], best["width"], best["height"], best["confidence"], False)

        # Check grace period
        if self.frames_lost > max_predict:
            if self.config["debug"]:
                print(f"  → LOST (exceeded {max_predict} frames)")
            self._reset_track()
            return None

        # Still predicting
        self.last_position = {"x": pred_x, "y": pred_y}
        return self._make_result(pred_x, pred_y, 0, 0, 0.0, True)

    # ── Helpers ─────────────────────────────────────────────────

    @staticmethod
    def _normalize_detections(raw: List[Dict]) -> List[Dict]:
        return [
            {
                "x": d["x"],
                "y": d["y"],
                "width": d["width"],
                "height": d["height"],
                "confidence": d["confidence"],
                "cx": d["x"] + d["width"] / 2,
                "cy": d["y"] + d["height"] / 2,
                "class_id": d.get("class_id"),
            }
            for d in raw
        ]

    @staticmethod
    def _pick_best(detections: List[Dict]) -> Dict:
        return max(detections, key=lambda d: d["confidence"])

    @staticmethod
    def _closest_to(detections: List[Dict], px: float, py: float) -> Dict:
        return min(detections, key=lambda d: (d["cx"] - px) ** 2 + (d["cy"] - py) ** 2)

    def _get_search_zone(self) -> Optional[Dict]:
        if not self.kalman.initialized or self.state == "NO_TRACK":
            return None
        pos = self.last_position
        if pos is None:
            return None
        return {"x": pos["x"], "y": pos["y"], "radius": self._get_search_radius()}

    # ── Static-object rejection helpers ─────────────────────────

    def _count_moving_frames(self, positions: List[Dict]) -> int:
        """
        Count how many consecutive-frame pairs show displacement above the
        per-frame threshold.  Used during VALIDATING to decide if the object
        is moving.
        """
        threshold = self.config["static_per_frame_threshold_px"]
        moving = 0
        for i in range(1, len(positions)):
            dx = positions[i]["x"] - positions[i - 1]["x"]
            dy = positions[i]["y"] - positions[i - 1]["y"]
            dist = math.sqrt(dx * dx + dy * dy)
            if dist >= threshold:
                moving += 1
        return moving

    def _is_static(self, positions: List[Dict]) -> bool:
        """
        Determine if a sequence of positions represents a static object.

        Two criteria must BOTH hold:
        1. Total displacement (first → last) < static_min_displacement_px
        2. Fraction of stationary frame-pairs ≥ static_max_stationary_ratio

        Returns True if the object is static (should be killed).
        """
        if len(positions) < 2:
            return False

        # Criterion 1: total displacement over the full window
        total_dx = positions[-1]["x"] - positions[0]["x"]
        total_dy = positions[-1]["y"] - positions[0]["y"]
        total_disp = math.sqrt(total_dx * total_dx + total_dy * total_dy)

        if total_disp >= self.config["static_min_displacement_px"]:
            return False  # clearly moving

        # Criterion 2: per-frame stationarity ratio
        threshold = self.config["static_per_frame_threshold_px"]
        stationary = 0
        for i in range(1, len(positions)):
            dx = positions[i]["x"] - positions[i - 1]["x"]
            dy = positions[i]["y"] - positions[i - 1]["y"]
            if math.sqrt(dx * dx + dy * dy) < threshold:
                stationary += 1

        ratio = stationary / (len(positions) - 1)
        return ratio >= self.config["static_max_stationary_ratio"]

    def _reset_track(self):
        """
        Full track reset — return to NO_TRACK and clear all buffers.
        Used when a track is killed (static rejection, validation failure, etc.)
        """
        self.state = "NO_TRACK"
        self.kalman = KalmanFilter(
            process_noise=self.config["kalman_process_noise"],
            measurement_noise=self.config["kalman_measurement_noise"],
            gravity=self.config["gravity_pixels_per_frame2"],
            direction_change_threshold=self.config.get("kalman_direction_change_threshold", 60.0),
            acceleration_decay=self.config.get("kalman_acceleration_decay", 0.6),
        )
        self.last_detected_position = None
        self.last_position = None
        self.frames_lost = 0
        self.candidate_buffer = []
        self.candidate_frame_start = -1
        self.position_history = []
        self.validation_positions = []
        self.validation_frame_start = -1
        self._aerial_recovery_active = False
        self._velocity_at_loss = (0.0, 0.0)

    def _get_search_radius(self) -> float:
        speed = self.kalman.get_speed()
        radius = speed * self.config["search_radius_multiplier"]
        return max(self.config["min_search_radius"], min(radius, self.config["max_search_radius"]))

    def _make_result(
        self, x: float, y: float, w: float, h: float, confidence: float, is_predicted: bool,
    ) -> Dict:
        vx, vy = self.kalman.get_velocity()
        return {
            "x": round(x, 2),
            "y": round(y, 2),
            "w": round(w),
            "h": round(h),
            "confidence": round(confidence, 3),
            "state": self.state,
            "is_predicted": is_predicted,
            "velocity": {"vx": round(vx, 2), "vy": round(vy, 2)},
            "speed": round(self.kalman.get_speed(), 2),
        }


# ============================================================================
# SECTION 5: TRAJECTORY INTERPOLATION & SMOOTHING
# ============================================================================

class TrajectoryProcessor:
    """
    Post-processing: fill gaps and smooth the trajectory.

    Addresses:
    - Missing detections during fast movement → interpolate positions
    - Jittery detections → smooth with moving average
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    def interpolate_gaps(self, history: List[Dict]) -> List[Dict]:
        """
        Fill gaps in the trajectory where ball position is None.

        Returns same list with gaps filled (ball["is_interpolated"] = True).
        """
        result = [
            {"frame": h["frame"], "ball": deepcopy(h["ball"]) if h["ball"] else None, "state": h.get("state", "")}
            for h in history
        ]

        gap_start = -1

        for i in range(len(result)):
            if result[i]["ball"] is None:
                if gap_start == -1:
                    gap_start = i
            else:
                if gap_start != -1:
                    gap_end = i
                    gap_length = gap_end - gap_start

                    if gap_length <= self.config["max_gap_to_interpolate"] and gap_start > 0:
                        before = result[gap_start - 1]["ball"]
                        after = result[gap_end]["ball"]
                        if before and after:
                            self._fill_gap(result, gap_start, gap_end, before, after)

                    gap_start = -1

        return result

    def smooth(self, history: List[Dict]) -> List[Dict]:
        """Smooth detected (non-interpolated) positions to reduce jitter."""
        if not self.config["enable_smoothing"]:
            return history

        win = self.config["smoothing_window_size"]
        half_win = win // 2
        result = [
            {"frame": h["frame"], "ball": deepcopy(h["ball"]) if h["ball"] else None, "state": h.get("state", "")}
            for h in history
        ]

        for i in range(half_win, len(result) - half_win):
            b = result[i]["ball"]
            if not b or b.get("is_predicted") or b.get("is_interpolated"):
                continue

            sum_x, sum_y, count = 0.0, 0.0, 0
            for j in range(i - half_win, i + half_win + 1):
                bj = result[j]["ball"]
                if bj and not bj.get("is_predicted"):
                    sum_x += bj["x"]
                    sum_y += bj["y"]
                    count += 1

            if count >= 2:
                result[i]["ball"]["x"] = round(sum_x / count, 2)
                result[i]["ball"]["y"] = round(sum_y / count, 2)
                result[i]["ball"]["is_smoothed"] = True

        return result

    # ── Interpolation Methods ──────────────────────────────────

    def _fill_gap(self, result, gap_start, gap_end, before, after):
        gap_length = gap_end - gap_start
        if self.config["interpolation_method"] == "cubic" and gap_length > 2:
            self._cubic_interpolate(result, gap_start, gap_end, before, after)
        else:
            self._linear_interpolate(result, gap_start, gap_end, before, after)

    @staticmethod
    def _linear_interpolate(result, gap_start, gap_end, before, after):
        total = gap_end - gap_start + 1
        for i in range(gap_start, gap_end):
            t = (i - gap_start + 1) / total
            result[i]["ball"] = {
                "x": round(before["x"] + (after["x"] - before["x"]) * t, 2),
                "y": round(before["y"] + (after["y"] - before["y"]) * t, 2),
                "w": 0, "h": 0, "confidence": 0.0,
                "state": "INTERPOLATED",
                "is_predicted": False,
                "is_interpolated": True,
                "velocity": {"vx": 0.0, "vy": 0.0},
                "speed": 0.0,
            }

    @staticmethod
    def _cubic_interpolate(result, gap_start, gap_end, before, after):
        """Hermite (Catmull-Rom style) interpolation using endpoint velocities."""
        v0x = before.get("velocity", {}).get("vx", 0.0)
        v0y = before.get("velocity", {}).get("vy", 0.0)
        v1x = after.get("velocity", {}).get("vx", 0.0)
        v1y = after.get("velocity", {}).get("vy", 0.0)

        total = gap_end - gap_start + 1

        for i in range(gap_start, gap_end):
            t = (i - gap_start + 1) / total

            h00 = 2 * t**3 - 3 * t**2 + 1
            h10 = t**3 - 2 * t**2 + t
            h01 = -2 * t**3 + 3 * t**2
            h11 = t**3 - t**2

            x = h00 * before["x"] + h10 * v0x * total + h01 * after["x"] + h11 * v1x * total
            y = h00 * before["y"] + h10 * v0y * total + h01 * after["y"] + h11 * v1y * total

            result[i]["ball"] = {
                "x": round(x, 2), "y": round(y, 2),
                "w": 0, "h": 0, "confidence": 0.0,
                "state": "INTERPOLATED",
                "is_predicted": False,
                "is_interpolated": True,
                "velocity": {"vx": 0.0, "vy": 0.0},
                "speed": 0.0,
            }


# ============================================================================
# SECTION 6: MAIN PIPELINE (Public API)
# ============================================================================

class BallTrackingPipeline:
    """
    Main entry point. Create one instance, feed it detections frame by frame.

    Example::

        pipeline = BallTrackingPipeline(frame_width=1920, frame_height=1080)

        for frame_index, frame in enumerate(frames):
            raw_detections = your_model.detect(frame)
            result = pipeline.process_frame(frame_index, raw_detections)

            if result:
                print(f"Ball at ({result['x']}, {result['y']}) — {result['state']}")

        # After all frames — fill gaps:
        trajectory = pipeline.get_smoothed_trajectory()
    """

    def __init__(self, **user_config):
        self.config: Dict[str, Any] = {**DEFAULT_CONFIG, **user_config}
        self.track_manager = TrackManager(self.config)
        self.trajectory_processor = TrajectoryProcessor(self.config)
        self.frame_count = 0

        # Stats
        self._stats = {
            "total_frames": 0,
            "detected": 0,
            "predicted": 0,
            "interpolated": 0,
            "lost": 0,
            "_confidence_sum": 0.0,
            "_confidence_count": 0,
        }

    def process_frame(self, frame_index: int, raw_detections: List[Dict]) -> Optional[Dict]:
        """
        Process one frame of raw detections from your model.
        Call this for every frame in sequence.

        Args:
            frame_index: Frame number (0, 1, 2, …)
            raw_detections: List of dicts, each with keys:
                x, y, width, height, confidence  (and optionally class_id)

        Returns:
            Dict with tracked ball position, or None.
        """
        result = self.track_manager.process_frame(frame_index, raw_detections)

        self._stats["total_frames"] += 1
        if result:
            if result["is_predicted"]:
                self._stats["predicted"] += 1
            else:
                self._stats["detected"] += 1
                self._stats["_confidence_sum"] += result["confidence"]
                self._stats["_confidence_count"] += 1
        else:
            self._stats["lost"] += 1

        self.frame_count = frame_index + 1
        return result

    def get_history(self) -> List[Dict]:
        """Get the full frame history (for post-processing or export)."""
        return self.track_manager.frame_history

    def get_smoothed_trajectory(self) -> List[Dict]:
        """
        Post-process: interpolate gaps and smooth trajectory.
        Call after processing all frames.
        """
        history = self.track_manager.frame_history
        history = self.trajectory_processor.interpolate_gaps(history)
        history = self.trajectory_processor.smooth(history)

        self._stats["interpolated"] = sum(
            1 for h in history if h["ball"] and h["ball"].get("is_interpolated")
        )
        return history

    def get_stats(self) -> Dict[str, Any]:
        """Get processing statistics."""
        total = self._stats["total_frames"]
        cc = self._stats["_confidence_count"]
        return {
            "total_frames": total,
            "detected": self._stats["detected"],
            "predicted": self._stats["predicted"],
            "interpolated": self._stats["interpolated"],
            "lost": self._stats["lost"],
            "avg_confidence": round(self._stats["_confidence_sum"] / cc, 3) if cc > 0 else 0.0,
            "detection_rate": round(self._stats["detected"] / total, 3) if total > 0 else 0.0,
            "tracking_rate": round((self._stats["detected"] + self._stats["predicted"]) / total, 3) if total > 0 else 0.0,
        }

    def to_csv(self, fps: int = 30) -> str:
        """Export trajectory as CSV string."""
        history = self.get_smoothed_trajectory()
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow([
            "frame", "timestamp_ms", "x", "y", "confidence", "state",
            "is_predicted", "is_interpolated", "vx", "vy", "speed",
        ])

        for h in history:
            b = h["ball"]
            ts = round((h["frame"] / fps) * 1000)
            if b:
                writer.writerow([
                    h["frame"], ts, b["x"], b["y"], b["confidence"], b["state"],
                    b["is_predicted"], b.get("is_interpolated", False),
                    b["velocity"]["vx"], b["velocity"]["vy"], b["speed"],
                ])
            else:
                writer.writerow([h["frame"], ts, "", "", "", "NO_TRACK", False, False, "", "", ""])

        return buf.getvalue()

    def reset(self) -> None:
        """Reset pipeline state (for a new video)."""
        self.track_manager = TrackManager(self.config)
        self.frame_count = 0
        self._stats = {
            "total_frames": 0, "detected": 0, "predicted": 0, "interpolated": 0, "lost": 0,
            "_confidence_sum": 0.0, "_confidence_count": 0,
        }

    def update_config(self, **partial) -> None:
        """
        Update config mid-stream (e.g., user adjusts sliders).
        Note: Only filter thresholds take effect immediately.
        Kalman parameters require a reset().
        """
        self.config.update(partial)
        self.track_manager.filters = DetectionFilters(self.config)

    def get_current_state(self) -> Dict:
        """Get current tracking state (for UI display)."""
        tm = self.track_manager
        return {
            "state": tm.state,
            "position": tm.last_position,
            "frames_lost": tm.frames_lost,
            "search_radius": tm._get_search_radius() if tm.state != "NO_TRACK" else 0,
            "velocity": list(tm.kalman.get_velocity()) if tm.kalman.initialized else [0.0, 0.0],
        }


# ============================================================================
# SECTION 7: MODULE-LEVEL HELPERS
# ============================================================================

def _distance(x1: float, y1: float, x2: float, y2: float) -> float:
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)


def _point_in_polygon(x: float, y: float, polygon: List[Tuple[float, float]]) -> bool:
    """Ray-casting point-in-polygon test."""
    inside = False
    n = len(polygon)
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if (yi > y) != (yj > y) and x < ((xj - xi) * (y - yi)) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


# ============================================================================
# QUICK SELF-TEST
# ============================================================================

if __name__ == "__main__":
    print("=== Ball Tracking Pipeline — Self-Test ===\n")

    pipeline = BallTrackingPipeline(
        frame_width=1920,
        frame_height=1080,
        confidence_threshold=0.4,
        min_detections_to_confirm=1,
        debug=True,
    )

    # Simulate a ball moving diagonally with a gap (aerial)
    fake_frames = [
        # Frame 0–4: ball detected moving right-down
        [{"x": 100, "y": 200, "width": 20, "height": 20, "confidence": 0.85}],
        [{"x": 130, "y": 220, "width": 20, "height": 20, "confidence": 0.80}],
        [{"x": 160, "y": 240, "width": 20, "height": 20, "confidence": 0.82}],
        [{"x": 190, "y": 260, "width": 20, "height": 20, "confidence": 0.78}],
        [{"x": 220, "y": 280, "width": 20, "height": 20, "confidence": 0.81}],
        # Frame 5–9: ball goes aerial — no detection (Kalman should predict)
        [],
        [],
        [],
        [],
        [],
        # Frame 10–12: ball lands, re-acquired
        [{"x": 370, "y": 380, "width": 20, "height": 20, "confidence": 0.75}],
        [{"x": 400, "y": 400, "width": 20, "height": 20, "confidence": 0.79}],
        [{"x": 430, "y": 420, "width": 20, "height": 20, "confidence": 0.83}],
    ]

    print("Processing frames...")
    for i, dets in enumerate(fake_frames):
        result = pipeline.process_frame(i, dets)
        if result:
            pred_tag = " [PREDICTED]" if result["is_predicted"] else ""
            print(f"  Frame {i:2d}: ({result['x']:7.1f}, {result['y']:7.1f})  "
                  f"conf={result['confidence']:.3f}  state={result['state']}{pred_tag}")
        else:
            print(f"  Frame {i:2d}: NO BALL")

    print("\n--- Stats ---")
    stats = pipeline.get_stats()
    for k, v in stats.items():
        print(f"  {k}: {v}")

    # Smoothed trajectory
    traj = pipeline.get_smoothed_trajectory()
    interp_count = sum(1 for h in traj if h["ball"] and h["ball"].get("is_interpolated"))
    print(f"\nInterpolated frames: {interp_count}")

    print("\n=== Self-Test Complete ===")
