"""
Visualization utilities for drawing bounding boxes, labels, and FPS
"""

import cv2
import numpy as np
import supervision as sv
from typing import List, Optional
import time


class Visualizer:
    """Handles all visualization tasks - bounding boxes, labels, FPS counter"""

    def __init__(
        self,
        box_color: tuple = (0, 255, 0),  # Green
        text_color: tuple = (255, 255, 255),  # White
        text_scale: float = 0.6,
        text_thickness: int = 2,
        box_thickness: int = 2
    ):
        """
        Initialize the visualizer

        Args:
            box_color: RGB color for bounding boxes
            text_color: RGB color for text
            text_scale: Font scale for text
            text_thickness: Thickness of text
            box_thickness: Thickness of bounding boxes
        """
        self.box_color = box_color
        self.text_color = text_color
        self.text_scale = text_scale
        self.text_thickness = text_thickness
        self.box_thickness = box_thickness

        # Initialize supervision annotators
        self.box_annotator = sv.BoxAnnotator(
            thickness=box_thickness,
            color=sv.Color.from_rgb_tuple(box_color)
        )

        self.label_annotator = sv.LabelAnnotator(
            text_scale=text_scale,
            text_thickness=text_thickness,
            text_color=sv.Color.from_rgb_tuple(text_color)
        )

        # FPS tracking
        self.fps_history = []
        self.max_fps_history = 30

    def annotate_frame(
        self,
        frame: np.ndarray,
        detections: sv.Detections,
        labels: List[str]
    ) -> np.ndarray:
        """
        Draw bounding boxes and labels on frame

        Args:
            frame: Input frame
            detections: Detection results
            labels: Label strings for each detection

        Returns:
            Annotated frame
        """
        annotated_frame = frame.copy()

        # Draw boxes
        if len(detections) > 0:
            annotated_frame = self.box_annotator.annotate(
                scene=annotated_frame,
                detections=detections
            )

            # Draw labels
            annotated_frame = self.label_annotator.annotate(
                scene=annotated_frame,
                detections=detections,
                labels=labels
            )

        return annotated_frame

    def draw_fps(self, frame: np.ndarray, fps: float) -> np.ndarray:
        """
        Draw FPS counter on frame

        Args:
            frame: Input frame
            fps: Current FPS value

        Returns:
            Frame with FPS overlay
        """
        # Update FPS history for smoothing
        self.fps_history.append(fps)
        if len(self.fps_history) > self.max_fps_history:
            self.fps_history.pop(0)

        # Calculate average FPS
        avg_fps = np.mean(self.fps_history)

        # Create FPS text
        fps_text = f"FPS: {avg_fps:.1f}"

        # Get text size for background rectangle
        (text_width, text_height), baseline = cv2.getTextSize(
            fps_text,
            cv2.FONT_HERSHEY_SIMPLEX,
            self.text_scale,
            self.text_thickness
        )

        # Draw semi-transparent background
        padding = 5
        cv2.rectangle(
            frame,
            (padding, padding),
            (padding + text_width + padding, padding + text_height + baseline + padding),
            (0, 0, 0),
            -1
        )

        # Draw FPS text
        cv2.putText(
            frame,
            fps_text,
            (padding + padding, padding + text_height + padding),
            cv2.FONT_HERSHEY_SIMPLEX,
            self.text_scale,
            self.text_color,
            self.text_thickness,
            cv2.LINE_AA
        )

        return frame

    def draw_info_panel(
        self,
        frame: np.ndarray,
        info_dict: dict,
        position: str = "top-right"
    ) -> np.ndarray:
        """
        Draw information panel on frame

        Args:
            frame: Input frame
            info_dict: Dictionary of info to display
            position: Panel position ('top-right', 'top-left', 'bottom-left', 'bottom-right')

        Returns:
            Frame with info panel
        """
        if not info_dict:
            return frame

        # Format info text
        info_lines = [f"{key}: {value}" for key, value in info_dict.items()]

        # Calculate panel size
        max_width = 0
        total_height = 0
        line_heights = []

        for line in info_lines:
            (w, h), baseline = cv2.getTextSize(
                line,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.4,
                1
            )
            max_width = max(max_width, w)
            line_heights.append(h + baseline)
            total_height += h + baseline + 3

        padding = 10
        panel_width = max_width + 2 * padding
        panel_height = total_height + 2 * padding

        # Calculate position
        h, w = frame.shape[:2]
        if position == "top-right":
            x = w - panel_width - 10
            y = 10
        elif position == "top-left":
            x = 10
            y = 10
        elif position == "bottom-left":
            x = 10
            y = h - panel_height - 10
        else:  # bottom-right
            x = w - panel_width - 10
            y = h - panel_height - 10

        # Draw semi-transparent background
        overlay = frame.copy()
        cv2.rectangle(
            overlay,
            (x, y),
            (x + panel_width, y + panel_height),
            (0, 0, 0),
            -1
        )
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

        # Draw text lines
        current_y = y + padding
        for line, line_height in zip(info_lines, line_heights):
            cv2.putText(
                frame,
                line,
                (x + padding, current_y + line_height - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.4,
                (255, 255, 255),
                1,
                cv2.LINE_AA
            )
            current_y += line_height + 3

        return frame

    def draw_detection_count(
        self,
        frame: np.ndarray,
        count: int
    ) -> np.ndarray:
        """
        Draw detection count on frame

        Args:
            frame: Input frame
            count: Number of detections

        Returns:
            Frame with detection count
        """
        text = f"Detections: {count}"

        # Position below FPS counter
        position = (10, 50)

        cv2.putText(
            frame,
            text,
            position,
            cv2.FONT_HERSHEY_SIMPLEX,
            self.text_scale,
            self.text_color,
            self.text_thickness,
            cv2.LINE_AA
        )

        return frame


class FPSCounter:
    """Simple FPS counter utility"""

    def __init__(self):
        self.start_time = time.time()
        self.frame_count = 0
        self.fps = 0.0

    def update(self) -> float:
        """Update FPS counter and return current FPS"""
        self.frame_count += 1
        elapsed_time = time.time() - self.start_time

        if elapsed_time > 0:
            self.fps = self.frame_count / elapsed_time

        return self.fps

    def reset(self):
        """Reset the counter"""
        self.start_time = time.time()
        self.frame_count = 0
        self.fps = 0.0
