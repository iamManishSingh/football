# Usage Guide - Ball Detection Pipeline

This guide provides practical examples and use cases for the ball detection pipeline.

## Table of Contents
1. [Quick Start](#quick-start)
2. [Common Use Cases](#common-use-cases)
3. [Command Reference](#command-reference)
4. [Tips and Best Practices](#tips-and-best-practices)
5. [Troubleshooting](#troubleshooting)

## Quick Start

### First Time Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Test your setup
python test_setup.py

# 3. Run on webcam (model will auto-download on first run)
python main.py
```

The first run will download the model weights (~150MB), which may take a few minutes.

### Basic Usage

```bash
# Webcam
python main.py

# Video file
python main.py --source video.mp4

# Quit anytime by pressing 'q'
```

## Common Use Cases

### 1. Live Webcam Detection

**Goal**: Detect balls in real-time using your webcam

```bash
# Basic webcam
python main.py

# Webcam with higher confidence (fewer false positives)
python main.py --confidence 0.5

# Webcam with large model (better accuracy, slower)
python main.py --model large
```

**Expected Output**:
- Live video window showing detections
- Green bounding boxes around detected balls
- FPS counter in top-left corner
- Detection count below FPS

### 2. Video File Analysis

**Goal**: Process a video file and see detections in real-time

```bash
# Basic video processing
python main.py --source game_footage.mp4

# High-confidence detections only
python main.py --source game_footage.mp4 --confidence 0.7

# Save annotated output
python main.py --source input.mp4 --save-output output.mp4
```

**Use Cases**:
- Sports game analysis
- Training footage review
- Ball tracking in recorded games

### 3. Sports Game Analysis

**Goal**: Analyze sports footage with optimal settings

```bash
# Soccer/Football
python main.py --source soccer.mp4 --confidence 0.4 --model large --save-output soccer_analyzed.mp4

# Basketball
python main.py --source basketball.mp4 --confidence 0.5 --save-output basketball_analyzed.mp4

# Tennis
python main.py --source tennis.mp4 --confidence 0.6 --model large
```

**Tips**:
- Use `--confidence 0.4-0.6` for sports footage
- Use `--model large` for better accuracy on small balls
- Save output for later review with `--save-output`

### 4. Multiple Camera Devices

**Goal**: Use a specific camera when you have multiple webcams

```bash
# Try different camera indices
python main.py --source 0  # Default camera
python main.py --source 1  # Second camera
python main.py --source 2  # Third camera
```

**How to find your camera**:
```bash
# Test each camera
for i in 0 1 2; do
    echo "Testing camera $i..."
    python main.py --source $i &
    sleep 3
    pkill -f "python main.py"
done
```

### 5. High-Performance Setup (GPU)

**Goal**: Maximize FPS on GPU-enabled systems

```bash
# Force CUDA (NVIDIA GPU)
python main.py --device cuda --model base --resolution 640

# Force MPS (Apple Silicon)
python main.py --device mps --model base --resolution 640

# Check your device
python test_setup.py
```

**Expected FPS**:
- NVIDIA RTX 4090: 60-80 FPS (base model)
- Apple M1 Max: 25-35 FPS (base model)

### 6. Low-Resource Setup (CPU)

**Goal**: Run on CPU with acceptable performance

```bash
# CPU with lower resolution
python main.py --device cpu --resolution 320 --model base

# CPU with minimal processing
python main.py --device cpu --resolution 320 --confidence 0.5
```

**Expected FPS**:
- Intel i7 CPU: 5-8 FPS (base model, 320 resolution)

### 7. Headless/Server Mode

**Goal**: Run without display window (for servers or remote processing)

```bash
# Process and save without display
python main.py --source input.mp4 --no-display --save-output output.mp4

# Batch processing
for video in *.mp4; do
    python main.py --source "$video" --no-display --save-output "processed_$video"
done
```

### 8. All Object Detection (Not Just Balls)

**Goal**: Detect all COCO objects, not just balls

```bash
# Show all detections
python main.py --all-classes

# All classes with high confidence
python main.py --all-classes --confidence 0.6

# Useful for debugging or general object detection
python main.py --source video.mp4 --all-classes --save-output all_objects.mp4
```

### 9. Production/Demo Setup

**Goal**: Best settings for demos or production use

```bash
# High quality, saved output
python main.py \
    --source camera_feed.mp4 \
    --model large \
    --confidence 0.5 \
    --resolution 640 \
    --save-output demo_output.mp4 \
    --device cuda
```

## Command Reference

### Source Options

| Source | Command | Description |
|--------|---------|-------------|
| Default webcam | `--source webcam` or `--source 0` | Built-in camera |
| External webcam | `--source 1` | Second camera device |
| Video file | `--source video.mp4` | Local video file |
| RTSP stream | `--source rtsp://url` | Network camera stream |

### Model Options

| Model | Speed | Accuracy | Use Case |
|-------|-------|----------|----------|
| `base` | Fast | Good | Real-time applications |
| `large` | Slower | Better | High-accuracy needed |

### Confidence Levels

| Confidence | Use Case |
|------------|----------|
| `0.1-0.3` | Maximum sensitivity (more false positives) |
| `0.3-0.5` | Balanced (default) |
| `0.5-0.7` | High confidence (fewer false positives) |
| `0.7-1.0` | Very strict (may miss detections) |

### Resolution Settings

| Resolution | Speed | Use Case |
|------------|-------|----------|
| `320` | Fastest | CPU or low-end hardware |
| `640` | Balanced | Default, good for most cases |
| `1280` | Slowest | High accuracy, powerful GPU |

## Tips and Best Practices

### Getting Best Performance

1. **Use GPU**: Ensure CUDA or MPS is available
   ```bash
   python test_setup.py  # Check your setup
   ```

2. **Optimize Resolution**: Match resolution to your hardware
   ```bash
   # CPU: use 320
   python main.py --resolution 320

   # GPU: use 640 or higher
   python main.py --resolution 640
   ```

3. **Choose Right Model**: Base model for speed, large for accuracy
   ```bash
   # Fast
   python main.py --model base

   # Accurate
   python main.py --model large
   ```

### Getting Best Accuracy

1. **Use Large Model**:
   ```bash
   python main.py --model large
   ```

2. **Adjust Confidence**:
   ```bash
   # More detections (may include false positives)
   python main.py --confidence 0.3

   # Fewer but more certain detections
   python main.py --confidence 0.6
   ```

3. **Good Lighting**: Ensure video has good lighting and contrast

4. **Appropriate Resolution**: Higher resolution for smaller balls

### Recording Output

```bash
# Save with same name + "_annotated"
python main.py --source video.mp4 --save-output video_annotated.mp4

# Save to different directory
python main.py --source video.mp4 --save-output /path/to/output.mp4
```

## Troubleshooting

### Problem: Low FPS

**Solutions**:
1. Lower resolution: `--resolution 320`
2. Use base model: `--model base`
3. Check GPU is being used: `python test_setup.py`
4. Close other applications

### Problem: No Detections

**Solutions**:
1. Lower confidence: `--confidence 0.2`
2. Check video quality (lighting, focus)
3. Try all classes: `--all-classes`
4. Verify ball is visible in frame

### Problem: Too Many False Positives

**Solutions**:
1. Raise confidence: `--confidence 0.6`
2. Use large model: `--model large`
3. Ensure good lighting in video

### Problem: Webcam Not Working

**Solutions**:
1. Check permissions (System Preferences > Privacy > Camera)
2. Try different device index: `--source 1`
3. Test with: `python test_setup.py`
4. Check if another app is using the camera

### Problem: Out of Memory

**Solutions**:
1. Lower resolution: `--resolution 320`
2. Use base model: `--model base`
3. Close other GPU applications
4. Use CPU: `--device cpu`

## Advanced Examples

### Batch Processing

Process multiple videos:

```bash
#!/bin/bash
for video in videos/*.mp4; do
    output="processed/$(basename "$video")"
    python main.py \
        --source "$video" \
        --no-display \
        --save-output "$output" \
        --confidence 0.5
done
```

### Custom Processing Script

```python
#!/usr/bin/env python3
from detector import BallDetector
from visualizer import Visualizer
import cv2

# Initialize
detector = BallDetector(model_size="base", confidence_threshold=0.4)
visualizer = Visualizer()

# Process video
cap = cv2.VideoCapture("input.mp4")
while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Detect
    detections, labels = detector.predict(frame)

    # Annotate
    annotated = visualizer.annotate_frame(frame, detections, labels)

    # Display
    cv2.imshow("Ball Detection", annotated)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
```

## Getting Help

1. Run setup test: `python test_setup.py`
2. Check README: [README.md](README.md)
3. Check your installation: `pip list | grep -E "rfdetr|torch|opencv"`

## Examples Summary

| Goal | Command |
|------|---------|
| Quick test | `python main.py` |
| Video file | `python main.py --source video.mp4` |
| Save output | `python main.py --source video.mp4 --save-output out.mp4` |
| High accuracy | `python main.py --model large --confidence 0.6` |
| Fast processing | `python main.py --model base --resolution 320` |
| All objects | `python main.py --all-classes` |
| Headless mode | `python main.py --no-display --save-output out.mp4` |

---

For more information, see [README.md](README.md)
