# SIMPLE STEP-BY-STEP GUIDE

## How to Run Ball Detection on Your Video

Follow these exact steps:

---

## Step 1: Install Dependencies

```bash
cd /Users/L034900/Library/CloudStorage/OneDrive-EliLillyandCompany/Documents/analytics_manish_learn/ball

pip install -r requirements.txt
```

Wait for installation (~5-10 minutes).

---

## Step 2: Download Models (Optional but Recommended)

```bash
python download_models.py
```

When the menu appears, type **3** and press Enter to download all models.

**What this does:**
- Downloads RF-DETR base model (~130 MB)
- Downloads RF-DETR large model (~130 MB)
- Models are cached by RF-DETR library automatically
- Makes first run faster

**Note:** If you skip this step, models will download automatically when you first run the detection.

---

## Step 3: Run on Your Video

```bash
python main.py --source YOUR_VIDEO.mp4
```

Replace `YOUR_VIDEO.mp4` with your actual video file.

**That's it!**

### What you'll see:
- A window opens with your video
- Green boxes around detected balls
- FPS counter in top-left
- Press **`q`** to quit

---

## Common Commands

```bash
# Basic run
python main.py --source video.mp4

# Higher confidence (fewer false detections)
python main.py --source video.mp4 --confidence 0.6

# Better accuracy (slower)
python main.py --source video.mp4 --model large

# Save output video
python main.py --source video.mp4 --save-output output.mp4
```

---

## Troubleshooting

### "No module named 'rfdetr'"
```bash
pip install rfdetr
```

### "Video file not found"
- Use full path: `--source /full/path/to/video.mp4`
- Or copy video to the ball folder

### Slow performance
```bash
python main.py --source video.mp4 --resolution 320
```

### No detections
```bash
python main.py --source video.mp4 --confidence 0.2
```

---

## Complete Example

```bash
# 1. Install
pip install -r requirements.txt

# 2. Download models (optional)
python download_models.py
# Type: 3

# 3. Run
python main.py --source my_game.mp4

# 4. Save output
python main.py --source my_game.mp4 --save-output detected.mp4
```

---

## What Happens?

**First Run:**
- If you didn't pre-download, RF-DETR downloads the model (~2 min)
- Model is cached for future runs

**Subsequent Runs:**
- Model loads instantly from cache
- Video plays with live ball detection
- Press `q` to quit

---

**That's all you need!** 🎾⚽🏀

The models are automatically cached by the RF-DETR library, so you don't need to worry about managing them manually.
