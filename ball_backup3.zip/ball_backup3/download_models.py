#!/usr/bin/env python3
"""
RF-DETR Model Downloader - Simplified Version
Downloads RF-DETR models (they are auto-cached by the RF-DETR library)
"""

import os
import sys
from pathlib import Path


def check_dependencies():
    """Check if required packages are installed"""
    try:
        import torch
        import rfdetr
        return True
    except ImportError as e:
        print(f"Error: Missing dependency - {e}")
        print("Please run: pip install -r requirements.txt")
        return False


def download_model(model_name: str, model_class):
    """Download a specific RF-DETR model"""
    print(f"\n{'='*60}")
    print(f"Downloading {model_name} model...")
    print(f"{'='*60}")

    try:
        # Initialize model (this triggers download and caching by RF-DETR)
        print("Initializing model (this will download weights)...")
        print("RF-DETR will cache the model automatically...")
        model = model_class()

        print(f"✓ Successfully initialized {model_name} model!")
        print(f"  Model is cached by RF-DETR library")

        # Try to find cache location
        try:
            cache_dir = Path.home() / ".cache" / "torch" / "hub" / "checkpoints"
            if cache_dir.exists():
                model_files = list(cache_dir.glob("*rf-detr*.pth"))
                if model_files:
                    print(f"  Cache location: {cache_dir}")
                    for f in model_files:
                        size_mb = f.stat().st_size / (1024*1024)
                        print(f"    - {f.name} ({size_mb:.1f} MB)")
        except:
            pass

        return True

    except Exception as e:
        print(f"✗ Error downloading {model_name} model: {e}")
        import traceback
        traceback.print_exc()
        return False


def download_all_models():
    """Download all RF-DETR models"""
    print("\n" + "="*60)
    print("RF-DETR Model Downloader")
    print("="*60)
    print("Note: Models are cached automatically by RF-DETR library")
    print("      Usually in: ~/.cache/torch/hub/checkpoints/")
    print("="*60)

    # Import RF-DETR models
    try:
        from rfdetr import RFDETRBase, RFDETRLarge
    except ImportError as e:
        print(f"\nError: Cannot import rfdetr - {e}")
        print("Please run: pip install rfdetr")
        return False

    models = {
        "base": RFDETRBase,
        "large": RFDETRLarge,
    }

    print(f"\nAvailable models to download:")
    for i, (name, _) in enumerate(models.items(), 1):
        print(f"  {i}. rfdetr-{name}")
    print(f"  {len(models)+1}. Download all")
    print(f"  0. Exit")

    choice = input(f"\nSelect option [0-{len(models)+1}]: ").strip()

    if choice == "0":
        print("Exiting...")
        return True

    if choice == str(len(models)+1):
        # Download all models
        print("\nDownloading all models...")
        success_count = 0
        for name, model_class in models.items():
            if download_model(name, model_class):
                success_count += 1

        print("\n" + "="*60)
        print(f"Download Summary: {success_count}/{len(models)} models downloaded")
        print("="*60)
        return success_count == len(models)

    else:
        # Download specific model
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                name = list(models.keys())[idx]
                model_class = models[name]
                success = download_model(name, model_class)

                print("\n" + "="*60)
                if success:
                    print("✓ Download complete!")
                else:
                    print("✗ Download failed")
                print("="*60)
                return success
            else:
                print("Invalid choice")
                return False
        except ValueError:
            print("Invalid input")
            return False


def list_cached_models():
    """List cached RF-DETR models"""
    print("\n" + "="*60)
    print("Cached RF-DETR Models")
    print("="*60)

    cache_locations = [
        Path.home() / ".cache" / "torch" / "hub" / "checkpoints",
        Path.home() / ".cache" / "huggingface" / "hub",
    ]

    found_models = []
    for cache_dir in cache_locations:
        if cache_dir.exists():
            model_files = list(cache_dir.glob("*rf-detr*.pth")) + list(cache_dir.glob("*rfdetr*.pth"))
            for model_file in model_files:
                size_mb = model_file.stat().st_size / (1024*1024)
                found_models.append((model_file, size_mb))
                print(f"✓ {model_file.name}")
                print(f"  Location: {model_file.parent}")
                print(f"  Size: {size_mb:.1f} MB")
                print()

    if not found_models:
        print("No RF-DETR models found in cache")
        print("Run: python download_models.py to download models")
    else:
        print(f"Total: {len(found_models)} model(s) cached")

    print("="*60)


def verify_models():
    """Verify that models can be loaded"""
    print("\n" + "="*60)
    print("Verifying RF-DETR Models")
    print("="*60)

    try:
        from rfdetr import RFDETRBase, RFDETRLarge

        models = {
            "base": RFDETRBase,
            "large": RFDETRLarge,
        }

        for name, model_class in models.items():
            try:
                print(f"\nTesting rfdetr-{name}...")
                model = model_class()
                print(f"✓ {name} model loads successfully")
            except Exception as e:
                print(f"✗ {name} model failed: {e}")
                return False

        print("\n" + "="*60)
        print("✓ All models verified successfully")
        print("="*60)
        return True

    except Exception as e:
        print(f"✗ Error during verification: {e}")
        return False


def main():
    """Main entry point"""
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)

    # Check command line arguments
    if len(sys.argv) > 1:
        if sys.argv[1] == "--list":
            list_cached_models()
            return
        elif sys.argv[1] == "--verify":
            verify_models()
            return
        elif sys.argv[1] == "--help" or sys.argv[1] == "-h":
            print("RF-DETR Model Downloader")
            print("\nUsage:")
            print("  python download_models.py          # Interactive download")
            print("  python download_models.py --list    # List cached models")
            print("  python download_models.py --verify  # Verify models work")
            print("  python download_models.py --help    # Show this help")
            return

    # Interactive download
    try:
        success = download_all_models()

        if success:
            print("\n" + "="*60)
            print("Next steps:")
            print("  1. Run: python test_setup.py")
            print("  2. Run: python main.py --source video.mp4")
            print("\nModels are cached and ready to use!")
            print("="*60)

    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        sys.exit(1)


if __name__ == "__main__":
    main()
