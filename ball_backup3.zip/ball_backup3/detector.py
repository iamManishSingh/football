"""
RF-DETR Model Wrapper for Ball Detection
Handles model loading, inference, and detection filtering.

Enhanced with post-detection filters to address:
  1) Ball not detected in air / against crowd background
  2) False positives from shoes and body parts
  3) Off-pitch white objects misidentified as ball

Filter stack applied AFTER model inference:
  - Aspect ratio filter   → rejects elongated shoe-shaped boxes
  - Size-range filter     → rejects too-large / too-small detections
  - Circularity filter    → rejects non-round blob shapes
  - Pitch ROI filter      → rejects detections outside playing area
  - Green-field proximity → rejects objects not near the green pitch
  - Edge-region filter    → rejects objects hugging frame borders
  - Best-candidate pick   → keeps only the single highest-scoring detection
"""

import cv2
import math
import torch
import numpy as np
from typing import Optional, List, Tuple, Dict
from pathlib import Path
import supervision as sv

from config import DETECTOR_CONFIG


class BallDetector:
    """Wrapper class for RF-DETR model with ball-specific filtering"""

    # COCO class IDs for ball-related objects
    # Note: RF-DETR uses class ID 37 for sports ball
    BALL_CLASSES = {
        37: "sports ball",    # Main ball class
        32: "sports ball",    # Alternative ID (some COCO versions)
    }

    # ── Default filter configuration ────────────────────────────
    # All defaults live in config.py (single source of truth).
    # Users can still override individual keys via the filter_config
    # dict passed to __init__().
    DEFAULT_FILTER_CONFIG = DETECTOR_CONFIG

    def __init__(
        self,
        model_size: str = "base",
        confidence_threshold: float = 0.3,
        device: Optional[str] = None,
        filter_ball_only: bool = True,
        filter_config: Optional[Dict] = None,
        advanced_filters: bool = True,
    ):
        """
        Initialize the ball detector

        Args:
            model_size: Model size - 'base' or 'large'
            confidence_threshold: Minimum confidence for detections
            device: Device to run on ('cuda', 'mps', 'cpu', or None for auto)
            filter_ball_only: If True, only return ball-related detections
            filter_config: Optional dict to override default filter settings
            advanced_filters: If True, apply full post-detection filter pipeline.
                              If False, return raw model output (class filter + confidence only).
        """
        self.model_size = model_size
        self.confidence_threshold = confidence_threshold
        self.filter_ball_only = filter_ball_only
        self.advanced_filters = advanced_filters
        self.device = self._setup_device(device)

        # Merge user overrides into default filter config
        self.fcfg = {**self.DEFAULT_FILTER_CONFIG}
        if filter_config:
            self.fcfg.update(filter_config)

        print(f"Loading RF-DETR-{model_size} model...")
        print(f"Running on: {self.device}")

        self.model = self._load_model()

        print(f"Model loaded successfully!")

        if self.advanced_filters:
            print(f"Mode: ADVANCED FILTERS (Yes)")
            print(f"Post-detection filters enabled:")
            print(f"  Aspect ratio : [{self.fcfg['min_aspect_ratio']}, {self.fcfg['max_aspect_ratio']}]")
            print(f"  Size range   : [{self.fcfg['min_ball_area_ratio']}, {self.fcfg['max_ball_area_ratio']}]")
            print(f"  Circularity  : {self.fcfg['enable_circularity_filter']}  (min={self.fcfg['min_circularity']})")
            print(f"  ROI masking  : {self.fcfg['enable_roi_filter']}")
            print(f"  Green-field  : {self.fcfg['enable_green_field_filter']}")
            print(f"  Edge filter  : {self.fcfg['enable_edge_filter']}")
            print(f"  White-dot    : {self.fcfg['enable_white_dot_filter']}  (max_area={self.fcfg['white_dot_max_area']})")
            print(f"  Context-adapt: {self.fcfg['enable_context_filter']}  (aerial_conf≥{self.fcfg['aerial_min_confidence']})")
            print(f"  Low-conf retry: {self.fcfg['enable_low_conf_retry']} (th={self.fcfg['low_conf_threshold']})")
        else:
            print(f"Mode: RAW MODEL (No advanced filters)")
            print(f"  Only class-ID + confidence filtering applied.")

    # ================================================================
    # Device & model loading
    # ================================================================

    def _setup_device(self, device: Optional[str]) -> str:
        """Auto-detect or set device"""
        if device and device != "auto":
            return device

        if torch.cuda.is_available():
            device_name = torch.cuda.get_device_name(0)
            print(f"CUDA available: {device_name}")
            return "cuda"
        elif torch.backends.mps.is_available():
            print("MPS (Apple Silicon) available")
            return "mps"
        else:
            print("No GPU available, using CPU")
            return "cpu"

    def _load_model(self):
        """Load RF-DETR model based on size"""
        try:
            if self.model_size == "base":
                from rfdetr import RFDETRBase
                model = RFDETRBase()
            elif self.model_size == "large":
                from rfdetr import RFDETRLarge
                model = RFDETRLarge()
            else:
                raise ValueError(f"Unknown model size: {self.model_size}. Use 'base' or 'large'")

            if hasattr(model, 'model') and hasattr(model.model, 'to'):
                model.model.to(self.device)
                model.model.eval()

            return model

        except ImportError as e:
            raise ImportError(
                "RF-DETR not installed. Run: pip install rfdetr\n"
                f"Original error: {e}"
            )
        except Exception as e:
            raise RuntimeError(f"Failed to load model: {e}")

    # ================================================================
    # Main prediction entry point
    # ================================================================

    def predict(self, frame: np.ndarray, tracking_active: bool = False) -> Tuple[sv.Detections, List[str]]:
        """
        Run inference on a single frame.

        When advanced_filters=True  → full post-detection filter pipeline.
        When advanced_filters=False → raw model output (class + confidence only).

        Args:
            frame: Input frame (numpy array in BGR format)
            tracking_active: If True, the temporal tracker is actively tracking
                or predicting the ball. Circularity filter is disabled because
                the ball near feet / in motion blur often fails circularity but
                the tracker will validate it temporally.

        Returns:
            detections: supervision.Detections object (filtered)
            labels: List of label strings for each detection
        """
        try:
            # --- Primary detection pass ---
            detections = self.model.predict(
                frame,
                threshold=self.confidence_threshold
            )

            # Filter for ball-related classes
            if self.filter_ball_only and len(detections) > 0:
                ball_mask = np.isin(detections.class_id, list(self.BALL_CLASSES.keys()))
                detections = detections[ball_mask]

            # ── RAW MODEL mode: skip all advanced filters ──
            if not self.advanced_filters:
                labels = self._generate_labels(detections)
                return detections, labels

            # ── ADVANCED FILTERS mode ──
            # Apply post-detection filters
            if len(detections) > 0:
                detections = self._apply_post_filters(
                    detections, frame, skip_circularity=tracking_active
                )

            # --- Low-confidence retry pass (aerial ball recovery) ---
            # If no ball survived the primary pass, try a lower threshold.
            # This helps detect the ball when it's in the air against a
            # cluttered background where the model is less confident.
            if (
                len(detections) == 0
                and self.fcfg["enable_low_conf_retry"]
                and self.fcfg["low_conf_threshold"] < self.confidence_threshold
            ):
                retry_dets = self.model.predict(
                    frame,
                    threshold=self.fcfg["low_conf_threshold"]
                )
                if self.filter_ball_only and len(retry_dets) > 0:
                    ball_mask = np.isin(retry_dets.class_id, list(self.BALL_CLASSES.keys()))
                    retry_dets = retry_dets[ball_mask]
                if len(retry_dets) > 0:
                    # Apply normal filters on low-conf detections (not strict —
                    # the temporal tracker will catch any FPs that slip through)
                    detections = self._apply_post_filters(
                        retry_dets, frame, strict=False,
                        skip_circularity=tracking_active
                    )
                    if self.fcfg["debug_filters"]:
                        print(f"  [LOW-CONF RETRY] recovered {len(detections)} detection(s)")

            # Generate labels
            labels = self._generate_labels(detections)
            return detections, labels

        except Exception as e:
            print(f"Prediction error: {e}")
            return sv.Detections.empty(), []

    # ================================================================
    # Post-detection filter pipeline
    # ================================================================

    def _apply_post_filters(
        self,
        detections: sv.Detections,
        frame: np.ndarray,
        strict: bool = False,
        skip_circularity: bool = False,
    ) -> sv.Detections:
        """
        Apply all post-detection filters to remove false positives.

        Args:
            detections: Raw (ball-class) detections from the model
            frame: The original BGR frame (needed for color analysis)
            strict: If True, use tighter thresholds (for low-conf retry)
            skip_circularity: If True, skip the circularity filter entirely
                (used when the tracker is actively tracking — temporal
                validation handles FP rejection instead)

        Returns:
            Filtered detections
        """
        h, w = frame.shape[:2]
        frame_area = h * w
        keep_mask = np.ones(len(detections), dtype=bool)

        debug = self.fcfg["debug_filters"]

        # Pre-compute grayscale and HSV once (shared by multiple filters)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        for i in range(len(detections)):
            x1, y1, x2, y2 = detections.xyxy[i]
            bw = x2 - x1
            bh = y2 - y1
            cx = (x1 + x2) / 2
            cy = (y1 + y2) / 2
            area = bw * bh
            conf = detections.confidence[i]

            # ------ 1. Aspect ratio filter (shoes are elongated) ------
            aspect = bw / max(bh, 1)
            min_ar = self.fcfg["min_aspect_ratio"] + (0.1 if strict else 0)
            max_ar = self.fcfg["max_aspect_ratio"] - (0.1 if strict else 0)
            if aspect < min_ar or aspect > max_ar:
                keep_mask[i] = False
                if debug:
                    print(f"  [ASPECT REJECT] det {i}: ratio={aspect:.2f}")
                continue

            # ------ 2. Size filter (too big = body part, too small = noise) ------
            min_area = frame_area * self.fcfg["min_ball_area_ratio"]
            max_area = frame_area * self.fcfg["max_ball_area_ratio"]
            if strict:
                max_area *= 0.7   # tighter for low-conf retry
            if area < min_area or area > max_area:
                keep_mask[i] = False
                if debug:
                    print(f"  [SIZE REJECT] det {i}: area={area:.0f} bounds=[{min_area:.0f},{max_area:.0f}]")
                continue

            # ------ 3. ROI filter (off-pitch regions) ------
            if self.fcfg["enable_roi_filter"]:
                top_limit = h * self.fcfg["exclude_top_ratio"]
                bottom_limit = h * (1 - self.fcfg["exclude_bottom_ratio"])
                left_limit = w * self.fcfg["exclude_left_ratio"]
                right_limit = w * (1 - self.fcfg["exclude_right_ratio"])
                if cy < top_limit or cy > bottom_limit or cx < left_limit or cx > right_limit:
                    keep_mask[i] = False
                    if debug:
                        print(f"  [ROI REJECT] det {i}: center=({cx:.0f},{cy:.0f})")
                    continue

            # ------ 4. Edge-region filter ------
            if self.fcfg["enable_edge_filter"]:
                margin = self.fcfg["edge_margin_pixels"]
                if x1 < margin or y1 < margin or x2 > (w - margin) or y2 > (h - margin):
                    keep_mask[i] = False
                    if debug:
                        print(f"  [EDGE REJECT] det {i}: box too close to frame border")
                    continue

            # ------ 5. White-dot / noise rejection ------
            # Tiny, bright, uniform, isolated blobs on plain surfaces
            # (pitch markings, corner spots, sensor noise).
            if self.fcfg["enable_white_dot_filter"]:
                if self._is_white_dot_noise(gray, x1, y1, x2, y2, area):
                    keep_mask[i] = False
                    if debug:
                        print(f"  [WHITE-DOT REJECT] det {i}: isolated bright dot (area={area:.0f})")
                    continue

            # ------ 6. Context-adaptive detection (pitch vs aerial) ------
            # Classify whether the detection is on the green pitch or in
            # an aerial zone (crowd / sky / goal-net).  Apply different
            # confidence thresholds and skip green-field filter for aerial.
            det_context = "pitch"  # default
            if self.fcfg["enable_context_filter"]:
                det_context = self._classify_context(hsv, x1, y1, x2, y2, w, h)

                # Context-dependent confidence threshold
                if det_context == "aerial":
                    min_conf = self.fcfg["aerial_min_confidence"]
                else:
                    min_conf = self.fcfg["pitch_min_confidence"]

                if conf < min_conf:
                    keep_mask[i] = False
                    if debug:
                        print(f"  [CONF-CTX REJECT] det {i}: conf={conf:.2f} < {min_conf:.2f} ({det_context})")
                    continue

                # For aerial detections, verify contrast with background
                if det_context == "aerial":
                    if not self._has_sufficient_contrast(gray, x1, y1, x2, y2):
                        keep_mask[i] = False
                        if debug:
                            print(f"  [CONTRAST REJECT] det {i}: low contrast in aerial zone")
                        continue

            # ------ 7. Circularity filter (ball should be round-ish) ------
            # Skip when tracker is actively tracking — temporal validation
            # handles FP rejection, and circularity is unreliable for small /
            # motion-blurred / near-feet bounding boxes.
            if self.fcfg["enable_circularity_filter"] and not skip_circularity:
                # High-confidence detections bypass circularity check
                # (motion blur during fast passes makes the ball look non-round
                #  but if the model is confident, it's likely the real ball)
                bypass_thresh = self.fcfg.get("circularity_high_conf_bypass", 0.45)
                if conf < bypass_thresh:
                    circ = self._compute_circularity(frame, int(x1), int(y1), int(x2), int(y2))
                    min_circ = self.fcfg["min_circularity"]
                    if circ < min_circ:
                        keep_mask[i] = False
                        if debug:
                            print(f"  [CIRCULARITY REJECT] det {i}: circ={circ:.2f}, conf={conf:.2f}")
                        continue

            # ------ 8. Green-field proximity (off-pitch white objects) ------
            # SKIP for aerial detections — the ball is above the grass,
            # so requiring green nearby would kill valid aerial balls.
            if self.fcfg["enable_green_field_filter"] and det_context != "aerial":
                green_ok = self._check_green_proximity(frame, cx, cy, bw, bh)
                if not green_ok:
                    keep_mask[i] = False
                    if debug:
                        print(f"  [GREEN FIELD REJECT] det {i}: insufficient grass context")
                    continue

        detections = detections[keep_mask]

        # ------ 9. Single-ball selection (highest confidence) ------
        if self.fcfg["pick_single_ball"] and len(detections) > 1:
            best_idx = np.argmax(detections.confidence)
            detections = detections[best_idx : best_idx + 1]
            if debug:
                print(f"  [SINGLE PICK] kept detection with conf={detections.confidence[0]:.3f}")

        return detections

    # ================================================================
    # White-dot / noise rejection
    # ================================================================

    def _is_white_dot_noise(
        self,
        gray: np.ndarray,
        x1: float, y1: float, x2: float, y2: float,
        area: float,
    ) -> bool:
        """
        Reject tiny, bright, uniform, isolated blobs that are pitch markings
        or sensor noise rather than a real ball.

        A real ball (even small) has:
          - some internal texture / intensity variation
          - surrounding context with edges (players, shadows, etc.)
          - not perfectly uniform brightness

        Returns True if the detection looks like noise (should be rejected).
        """
        cfg = self.fcfg
        if area > cfg["white_dot_max_area"]:
            return False  # too large to be a dot

        h_img, w_img = gray.shape[:2]
        ix1, iy1 = max(0, int(x1)), max(0, int(y1))
        ix2, iy2 = min(w_img, int(x2)), min(h_img, int(y2))

        patch = gray[iy1:iy2, ix1:ix2]
        if patch.size == 0:
            return False

        mean_brightness = float(np.mean(patch))
        std_brightness = float(np.std(patch))

        # Check 1: Is it very bright and uniform?
        if mean_brightness < cfg["white_dot_brightness_min"]:
            return False  # not particularly bright — probably not a dot artifact

        if std_brightness > cfg["white_dot_uniformity_max"]:
            return False  # has internal texture — probably a real object

        # Check 2: Is the surrounding area lacking texture (isolated on plain surface)?
        r = cfg["white_dot_isolation_radius"]
        sx1 = max(0, int(x1) - r)
        sy1 = max(0, int(y1) - r)
        sx2 = min(w_img, int(x2) + r)
        sy2 = min(h_img, int(y2) + r)

        surround = gray[sy1:sy2, sx1:sx2]
        if surround.size == 0:
            return False

        edges = cv2.Canny(surround, 50, 150)
        edge_density = np.count_nonzero(edges) / max(edges.size, 1)

        if edge_density < cfg["white_dot_edge_density_min"]:
            # Isolated bright uniform blob on a plain surface → noise
            if self.fcfg["debug_filters"]:
                print(f"    white-dot detail: brightness={mean_brightness:.0f}, "
                      f"std={std_brightness:.1f}, edge_density={edge_density:.4f}")
            return True

        return False

    # ================================================================
    # Context classification: pitch vs aerial
    # ================================================================

    def _classify_context(
        self,
        hsv: np.ndarray,
        x1: float, y1: float, x2: float, y2: float,
        img_w: int, img_h: int,
    ) -> str:
        """
        Classify the detection zone as 'pitch' or 'aerial'.

        Checks the green-pixel ratio in a padded region surrounding the
        detection.  If the surroundings are predominantly green → on-pitch.
        Otherwise → aerial (crowd, sky, goal-net, etc.).

        Returns:
            "pitch" or "aerial"
        """
        cfg = self.fcfg
        pad = cfg.get("context_pad_px", 60)

        rx1 = max(0, int(x1) - pad)
        ry1 = max(0, int(y1) - pad)
        rx2 = min(img_w, int(x2) + pad)
        ry2 = min(img_h, int(y2) + pad)

        region_hsv = hsv[ry1:ry2, rx1:rx2]
        if region_hsv.size == 0:
            return "pitch"

        # Count green pixels using the existing green HSV range
        lower = np.array(cfg["green_hsv_lower"], dtype=np.uint8)
        upper = np.array(cfg["green_hsv_upper"], dtype=np.uint8)
        green_mask = cv2.inRange(region_hsv, lower, upper)

        green_ratio = np.count_nonzero(green_mask) / max(green_mask.size, 1)

        if green_ratio >= cfg["pitch_green_ratio_threshold"]:
            return "pitch"
        else:
            if self.fcfg["debug_filters"]:
                print(f"    context: green_ratio={green_ratio:.3f} < {cfg['pitch_green_ratio_threshold']} → AERIAL")
            return "aerial"

    # ================================================================
    # Aerial contrast check
    # ================================================================

    def _has_sufficient_contrast(
        self,
        gray: np.ndarray,
        x1: float, y1: float, x2: float, y2: float,
    ) -> bool:
        """
        For aerial detections (crowd/sky background), verify that the
        detected blob contrasts sufficiently with its immediate surroundings.

        This prevents false positives from crowd faces, ad-board textures, etc.
        while allowing a real ball (white/colored on darker crowd) through.

        Returns True if contrast is sufficient (detection is plausible).
        """
        h_img, w_img = gray.shape[:2]
        ix1, iy1 = max(0, int(x1)), max(0, int(y1))
        ix2, iy2 = min(w_img, int(x2)), min(h_img, int(y2))

        patch = gray[iy1:iy2, ix1:ix2]
        if patch.size == 0:
            return True  # can't check, let it through

        # Get surrounding annulus
        pad = 15
        sx1 = max(0, ix1 - pad)
        sy1 = max(0, iy1 - pad)
        sx2 = min(w_img, ix2 + pad)
        sy2 = min(h_img, iy2 + pad)

        surround = gray[sy1:sy2, sx1:sx2].copy()

        # Create boolean mask for the annulus (exclude the inner detection area)
        inner_y1 = iy1 - sy1
        inner_x1 = ix1 - sx1
        inner_y2 = inner_y1 + (iy2 - iy1)
        inner_x2 = inner_x1 + (ix2 - ix1)

        mask = np.ones(surround.shape, dtype=bool)
        mask[inner_y1:inner_y2, inner_x1:inner_x2] = False

        if np.count_nonzero(mask) == 0:
            return True

        annulus_mean = float(np.mean(surround[mask]))
        patch_mean = float(np.mean(patch))

        contrast = abs(patch_mean - annulus_mean)
        min_contrast = self.fcfg["aerial_min_contrast"]

        if self.fcfg["debug_filters"] and contrast < min_contrast * 2:
            print(f"    contrast check: patch={patch_mean:.0f}, surround={annulus_mean:.0f}, "
                  f"diff={contrast:.1f}, threshold={min_contrast:.1f}")

        return contrast >= min_contrast

    # ================================================================
    # Individual filter implementations
    # ================================================================

    def _compute_circularity(
        self, frame: np.ndarray, x1: int, y1: int, x2: int, y2: int
    ) -> float:
        """
        Compute the circularity of the object inside the bounding box.

        Circularity = 4π × Area / Perimeter²
        A perfect circle → 1.0,  a line → ~0.

        A football should score > 0.4.  Shoes/cleats typically < 0.3.

        For small or motion-blurred bounding boxes where contour detection
        is unreliable, falls back to aspect-ratio-based circularity estimate
        so that roughly-square boxes still pass.
        """
        h, w = frame.shape[:2]
        # Clamp to frame
        x1, y1 = max(x1, 0), max(y1, 0)
        x2, y2 = min(x2, w), min(y2, h)
        bw, bh = x2 - x1, y2 - y1

        # For very small bounding boxes, contour detection is unreliable.
        # Fall back to aspect-ratio-based estimate: a square box gets ~1.0,
        # an elongated box gets a lower score.
        if bw < 10 or bh < 10:
            ratio = min(bw, bh) / max(bw, bh) if max(bw, bh) > 0 else 0
            return ratio  # square = 1.0, elongated = low

        roi = frame[y1:y2, x1:x2]
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

        # Try multiple thresholding strategies for robustness
        circularity_values = []

        # Strategy 1: Otsu thresholding
        blurred = cv2.GaussianBlur(gray, (3, 3), 0)  # smaller kernel for small objects
        _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        c1 = self._circularity_from_mask(thresh)
        if c1 > 0:
            circularity_values.append(c1)

        # Strategy 2: Inverted Otsu
        c2 = self._circularity_from_mask(255 - thresh)
        if c2 > 0:
            circularity_values.append(c2)

        # Strategy 3: Adaptive thresholding (better for varying illumination)
        if bw >= 15 and bh >= 15:
            block_size = max(3, (min(bw, bh) // 2) | 1)  # ensure odd
            adaptive = cv2.adaptiveThreshold(
                blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, block_size, 2
            )
            c3 = self._circularity_from_mask(adaptive)
            if c3 > 0:
                circularity_values.append(c3)

        # Strategy 4: Aspect-ratio fallback (always available)
        ratio = min(bw, bh) / max(bw, bh)
        circularity_values.append(ratio * 0.85)  # slightly penalised

        # Return the BEST circularity found across all strategies.
        # This is generous on purpose: "detect aggressively, validate over time"
        return min(max(circularity_values), 1.0)

    @staticmethod
    def _circularity_from_mask(mask: np.ndarray) -> float:
        """Compute circularity from the largest contour in a binary mask."""
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return 0.0
        largest = max(contours, key=cv2.contourArea)
        area = cv2.contourArea(largest)
        perimeter = cv2.arcLength(largest, True)
        if perimeter < 1e-5 or area < 3:
            return 0.0
        circ = (4 * math.pi * area) / (perimeter * perimeter)
        return min(circ, 1.0)

    def _check_green_proximity(
        self, frame: np.ndarray, cx: float, cy: float, bw: float, bh: float
    ) -> bool:
        """
        Check whether the region around the detection has enough green
        (grass) pixels.  If the ball is on the pitch, there should be
        significant green in its neighbourhood.  If it's in the stands /
        outside the pitch, there won't be.

        Returns True if enough green is found (detection is likely on pitch).
        """
        h, w = frame.shape[:2]
        r = self.fcfg["green_context_radius"]
        half_w = max(bw * r, 30)
        half_h = max(bh * r, 30)

        # Context window around the detection
        rx1 = int(max(cx - half_w, 0))
        ry1 = int(max(cy - half_h, 0))
        rx2 = int(min(cx + half_w, w))
        ry2 = int(min(cy + half_h, h))

        if rx2 - rx1 < 10 or ry2 - ry1 < 10:
            return True  # too small to judge — allow

        context = frame[ry1:ry2, rx1:rx2]
        hsv = cv2.cvtColor(context, cv2.COLOR_BGR2HSV)

        lower = np.array(self.fcfg["green_hsv_lower"], dtype=np.uint8)
        upper = np.array(self.fcfg["green_hsv_upper"], dtype=np.uint8)
        green_mask = cv2.inRange(hsv, lower, upper)

        green_ratio = np.count_nonzero(green_mask) / green_mask.size
        return green_ratio >= self.fcfg["min_green_ratio"]

    # ================================================================
    # Label generation
    # ================================================================

    def _generate_labels(self, detections: sv.Detections) -> List[str]:
        """Generate label strings for detections"""
        labels = []
        if len(detections) == 0:
            return labels

        for class_id, confidence in zip(detections.class_id, detections.confidence):
            class_name = self.BALL_CLASSES.get(class_id, f"class_{class_id}")
            label = f"{class_name} {confidence:.2f}"
            labels.append(label)

        return labels

    # ================================================================
    # Info
    # ================================================================

    def get_model_info(self) -> dict:
        """Return model information"""
        return {
            "model_size": self.model_size,
            "device": self.device,
            "confidence_threshold": self.confidence_threshold,
            "filter_ball_only": self.filter_ball_only,
            "advanced_filters": self.advanced_filters,
            "filters": {k: v for k, v in self.fcfg.items() if not k.startswith("debug")},
        }
