# Ball Detection - Visual Output Explained

## What You'll See When Running Detection

When you run `python main.py --source video.mp4`, you'll see a **live video window** with the following visual elements:

---

## 📦 Visual Elements

### 1. **Bounding Boxes** (Green Rectangles)
- **Color**: Bright green `(0, 255, 0)`
- **Thickness**: 2 pixels
- **Purpose**: Rectangular box around each detected ball
- **Position**: Automatically fits around the ball

```
┌─────────────────────────────────────────────┐
│                                             │
│         Your Video Frame                    │
│                                             │
│              ┌─────┐                       │
│              │ ⚽  │  ← Green box           │
│              └─────┘                       │
│    "sports ball 0.87"  ← Label             │
│                                             │
└─────────────────────────────────────────────┘
```

### 2. **Labels** (Text Above Boxes)
- **Color**: White `(255, 255, 255)`
- **Position**: Directly above the bounding box
- **Format**: `"class_name confidence"`
- **Examples**:
  - `"sports ball 0.87"` (87% confidence)
  - `"sports ball 0.92"` (92% confidence)
  - `"frisbee 0.65"` (65% confidence)

### 3. **FPS Counter** (Top-Left Corner)
- **Position**: Top-left corner with dark background
- **Format**: `"FPS: 25.3"`
- **Updates**: Real-time, smoothed over 30 frames
- **Background**: Semi-transparent black for readability

### 4. **Detection Count** (Below FPS)
- **Position**: Below FPS counter
- **Format**: `"Detections: 2"`
- **Updates**: Shows number of balls detected in current frame

---

## 🎨 Complete Visual Layout

```
┌─────────────────────────────────────────────────────────────┐
│ ┌──────────┐                                                │
│ │FPS: 25.3 │  ← FPS counter (top-left)                     │
│ └──────────┘                                                │
│ Detections: 2  ← Detection count                            │
│                                                             │
│                                                             │
│                    Your Video Playing                       │
│                                                             │
│              ┌──────────┐                                  │
│              │    ⚽    │  ← Green bounding box            │
│              └──────────┘                                  │
│         "sports ball 0.87"  ← White label                  │
│                                                             │
│                           ┌──────────┐                     │
│                           │    ⚽    │                     │
│                           └──────────┘                     │
│                      "sports ball 0.92"                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Detection Details

### Bounding Box Specifications:
- **Shape**: Rectangle (4 corners)
- **Color**: Green RGB(0, 255, 0)
- **Line thickness**: 2 pixels
- **Fit**: Automatically sized to ball dimensions
- **Updates**: Every frame (real-time)

### Label Specifications:
- **Position**: Above the box, left-aligned
- **Font**: OpenCV default (Hershey Simplex)
- **Size**: 0.6 scale
- **Thickness**: 2 pixels
- **Color**: White (high contrast)
- **Background**: None (overlays on video)

### Example Labels You'll See:
```
sports ball 0.95    ← Very confident detection
sports ball 0.87    ← Good detection
sports ball 0.45    ← Lower confidence
sports ball 0.32    ← Near threshold (default 0.3)
```

---

## 🎬 Real-Time Behavior

### When a Ball is Detected:
1. ✅ Green bounding box appears around it
2. ✅ Label shows above the box with class + confidence
3. ✅ Box follows the ball as it moves
4. ✅ Multiple balls → Multiple boxes

### When No Ball is Detected:
- No boxes or labels appear
- "Detections: 0" shown
- Video continues playing normally

### Dynamic Updates:
- **Every frame** is analyzed independently
- Boxes appear/disappear as balls enter/leave frame
- Confidence scores update based on ball visibility
- FPS counter shows processing speed

---

## 🎨 Customization Options

You can customize the appearance by editing `visualizer.py`:

```python
# Default colors (in RGB)
box_color = (0, 255, 0)      # Green boxes
text_color = (255, 255, 255)  # White text

# Change to other colors:
box_color = (255, 0, 0)      # Red boxes
box_color = (0, 0, 255)      # Blue boxes
box_color = (255, 255, 0)    # Yellow boxes
```

Or modify in the code:
```python
visualizer = Visualizer(
    box_color=(255, 0, 0),     # Red boxes
    text_color=(0, 255, 255),  # Cyan text
    box_thickness=3            # Thicker boxes
)
```

---

## 📊 Visual Examples by Confidence Level

### High Confidence (0.8 - 1.0):
```
┌──────────┐
│    ⚽    │  ← Thick, solid green box
└──────────┘
"sports ball 0.92"  ← High score
```
**Meaning**: Very clear ball detection, model is very confident

### Medium Confidence (0.5 - 0.8):
```
┌──────────┐
│    ⚽    │  ← Same green box
└──────────┘
"sports ball 0.67"  ← Medium score
```
**Meaning**: Ball detected, reasonably confident

### Low Confidence (0.3 - 0.5):
```
┌──────────┐
│    ⚽    │  ← Same green box
└──────────┘
"sports ball 0.35"  ← Lower score
```
**Meaning**: Possible ball, near threshold (might be false positive)

---

## 🎥 Example Scenarios

### Soccer Game:
```
Frame shows:
- 1 soccer ball in center: "sports ball 0.89"
- Green box tracking the ball as players kick it
- FPS: 28.5
- Detections: 1
```

### Basketball Game:
```
Frame shows:
- Basketball in player's hands: "sports ball 0.92"
- Box follows ball during dribbling/passing
- Multiple players visible but only ball highlighted
- FPS: 26.3
- Detections: 1
```

### Tennis Match:
```
Frame shows:
- Tennis ball mid-air: "sports ball 0.67"
- Tennis racket: "tennis racket 0.81" (if --all-classes used)
- Small box for small fast-moving ball
- FPS: 24.1
- Detections: 1 or 2
```

---

## 💡 Tips for Best Visualization

### For Better Detection Visibility:
1. **Good lighting** in video → Higher confidence scores
2. **Clear ball visibility** → Bigger, clearer boxes
3. **Slower motion** → More stable boxes
4. **Higher resolution** video → More accurate boxes

### Adjust Confidence Threshold:
```bash
# See more detections (more boxes, some false positives)
python main.py --source video.mp4 --confidence 0.2

# See only confident detections (fewer boxes, more accurate)
python main.py --source video.mp4 --confidence 0.7
```

### Performance vs Visual Quality:
- **Higher FPS** (30+) → Smooth, responsive boxes
- **Lower FPS** (10-15) → Choppy, delayed boxes
- Use `--resolution 640` for good balance

---

## 🖼️ What It Looks Like in Practice

Imagine watching your soccer video and seeing:
1. ✅ Video plays normally
2. ✅ **Bright green rectangle** automatically appears around the soccer ball
3. ✅ **White text "sports ball 0.87"** floats above the box
4. ✅ As the ball moves, the **box tracks it smoothly**
5. ✅ **"FPS: 25.3"** in top-left shows performance
6. ✅ **"Detections: 1"** confirms one ball found
7. ✅ When ball goes out of frame → box disappears
8. ✅ When ball returns → box reappears

It's like having a **smart highlighter** that automatically finds and marks balls in your video in real-time!

---

## 🎮 Interactive Controls

While watching:
- **`q` key** → Quit and close window
- **Window** → Can be moved/resized
- **Video** → Plays at original speed with detections overlaid

---

## Summary

**Yes, it's bounding boxes!** Specifically:
- ✅ **Green rectangular boxes** around detected balls
- ✅ **White text labels** with class name and confidence
- ✅ **FPS counter** showing performance
- ✅ **Detection count** showing number of balls
- ✅ **Real-time** updates as video plays
- ✅ **Live visualization** in OpenCV window

Just run `python main.py --source video.mp4` and you'll see it in action! 🎾⚽🏀
