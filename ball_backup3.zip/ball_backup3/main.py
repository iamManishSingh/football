#!/usr/bin/env python3
"""
Real-time Ball Detection Pipeline using RF-DETR
Main entry point with CLI interface and live inference loop.

Integrates:
  - BallDetector   : RF-DETR inference + per-frame post-detection filters
  - BallTrackingPipeline : temporal tracking, Kalman prediction, gap interpolation
"""

import argparse
import cv2
import sys
import time
import numpy as np
from pathlib import Path
from typing import Optional

from detector import BallDetector
from visualizer import Visualizer, FPSCounter
from ball_tracking_pipeline import BallTrackingPipeline
from config import TRACKER_CONFIG
import supervision as sv


class BallDetectionPipeline:
    """Main pipeline for real-time ball detection"""

    def __init__(self, args):
        """Initialize the pipeline with CLI arguments"""
        self.args = args
        self.detector = None
        self.visualizer = None
        self.fps_counter = None
        self.video_writer = None
        self.tracker = None       # BallTrackingPipeline for temporal filtering

        # Initialize components
        self._setup()

    def _setup(self):
        """Setup all pipeline components"""
        print("=" * 60)
        print("Ball Detection Pipeline - RF-DETR")
        print("=" * 60)

        # Determine mode: raw model vs advanced filters
        use_advanced = self.args.advanced_filters
        mode_label = "ADVANCED FILTERS" if use_advanced else "RAW MODEL"
        print(f">>> Detection mode: {mode_label} <<<")

        # Build filter config from CLI flags
        filter_config = {}
        if self.args.debug_filters:
            filter_config["debug_filters"] = True
        if self.args.no_green_filter:
            filter_config["enable_green_field_filter"] = False
        if self.args.no_circularity_filter:
            filter_config["enable_circularity_filter"] = False
        if self.args.no_roi_filter:
            filter_config["enable_roi_filter"] = False
        if self.args.low_conf_threshold is not None:
            filter_config["low_conf_threshold"] = self.args.low_conf_threshold

        # Initialize detector (RF-DETR + per-frame filters)
        self.detector = BallDetector(
            model_size=self.args.model,
            confidence_threshold=self.args.confidence,
            device=self.args.device,
            filter_ball_only=not self.args.all_classes,
            filter_config=filter_config,
            advanced_filters=use_advanced,
        )

        # Initialize visualizer
        self.visualizer = Visualizer()

        # Initialize FPS counter
        self.fps_counter = FPSCounter()

        # Tracking pipeline will be initialised after we know frame size
        # (disabled automatically when running in raw-model mode)
        self.tracker = None

        print("=" * 60)
        print("Setup complete! Starting inference...")
        print("Press 'q' to quit")
        print("=" * 60)

    def _get_video_source(self):
        """Get video capture source"""
        source = self.args.source

        # Handle webcam
        if source.lower() == "webcam":
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                raise RuntimeError("Error: Cannot open webcam. Check device index or permissions.")
            print(f"Video source: Webcam (device 0)")
            return cap

        # Handle video file
        if Path(source).exists():
            cap = cv2.VideoCapture(source)
            if not cap.isOpened():
                raise RuntimeError(f"Error: Cannot open video file: {source}")
            print(f"Video source: {source}")
            # Get video info
            fps = cap.get(cv2.CAP_PROP_FPS)
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            print(f"Video info: {width}x{height} @ {fps:.2f} FPS, {frame_count} frames")
            return cap

        # Try as RTSP URL or device index
        try:
            device_index = int(source)
            cap = cv2.VideoCapture(device_index)
            if not cap.isOpened():
                raise RuntimeError(f"Error: Cannot open camera device {device_index}")
            print(f"Video source: Camera device {device_index}")
            return cap
        except ValueError:
            # Assume it's an RTSP URL or other video source
            cap = cv2.VideoCapture(source)
            if not cap.isOpened():
                raise RuntimeError(f"Error: Cannot open video source: {source}")
            print(f"Video source: {source}")
            return cap

    def _setup_video_writer(self, frame_width: int, frame_height: int, fps: float):
        """Setup video writer for saving output"""
        if not self.args.save_output:
            return None

        output_path = self.args.save_output
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')

        writer = cv2.VideoWriter(
            output_path,
            fourcc,
            fps if fps > 0 else 30.0,
            (frame_width, frame_height)
        )

        if writer.isOpened():
            print(f"Saving output to: {output_path}")
            return writer
        else:
            print(f"Warning: Could not open video writer for {output_path}")
            return None

    def _resize_for_inference(self, frame: np.ndarray) -> tuple:
        """
        Resize frame for inference while maintaining aspect ratio

        Returns:
            resized_frame, scale_factor
        """
        target_size = self.args.resolution
        h, w = frame.shape[:2]

        # Calculate scale to fit within target size
        scale = min(target_size / w, target_size / h)

        if scale < 1.0:
            new_w = int(w * scale)
            new_h = int(h * scale)
            resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            return resized, scale
        else:
            return frame, 1.0

    def _scale_detections(self, detections, scale: float):
        """Scale detection boxes back to original resolution"""
        if scale != 1.0 and len(detections) > 0:
            detections.xyxy = detections.xyxy / scale
        return detections

    def run(self):
        """Main inference loop"""
        try:
            # Get video source
            cap = self._get_video_source()

            # Get video properties
            frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            video_fps = cap.get(cv2.CAP_PROP_FPS)

            # Initialise tracking pipeline now that we know the frame size
            # Tracking is only used in advanced-filters mode
            if self.args.advanced_filters and self.args.enable_tracking:
                # All filter defaults come from config.py → TRACKER_CONFIG.
                # Only override the runtime-specific values here.
                self.tracker = BallTrackingPipeline(
                    frame_width=frame_width,
                    frame_height=frame_height,
                    confidence_threshold=self.args.confidence,
                    debug=self.args.debug_filters,
                )
                cfg = self.tracker.config  # resolved config for display
                print(f"Temporal tracking ENABLED  (frame {frame_width}x{frame_height})")
                print(f"  Static-object rejection: ON (check every {cfg['static_check_frames']} frames, "
                      f"min displacement {cfg['static_min_displacement_px']}px)")
                print(f"  Aerial recovery: ON (speed>{cfg['aerial_recovery_min_speed']} px/frame, "
                      f"extra {cfg['aerial_recovery_max_frames']} predict frames)")
            else:
                self.tracker = None
                print("Temporal tracking DISABLED (per-frame mode)")

            # Setup video writer if needed
            if self.args.save_output:
                self.video_writer = self._setup_video_writer(
                    frame_width, frame_height, video_fps
                )

            # Main loop
            frame_number = 0
            total_detections = 0

            while True:
                # Read frame
                ret, frame = cap.read()

                if not ret:
                    print("\nEnd of video or cannot read frame")
                    break

                frame_number += 1

                # Resize for inference
                inference_frame, scale = self._resize_for_inference(frame)

                # ── Stage 1: per-frame detection + spatial filters ──
                # When the tracker is actively tracking/predicting, tell the
                # detector to skip the circularity filter (it's unreliable for
                # small/blurry/near-feet balls and we rely on temporal
                # validation instead).
                tracker_state = (
                    self.tracker.track_manager.state
                    if self.tracker is not None
                    else "NO_TRACK"
                )
                tracking_active = tracker_state in ("TRACKING", "PREDICTING", "VALIDATING")
                detections, labels = self.detector.predict(
                    inference_frame, tracking_active=tracking_active
                )

                # Scale detections back to original size
                detections = self._scale_detections(detections, scale)

                # ── Stage 2: temporal tracking (optional) ──
                tracked_result = None
                if self.tracker is not None and len(detections) >= 0:
                    # Convert sv.Detections → list-of-dict for the tracker
                    raw_dets = self._detections_to_dicts(detections)
                    tracked_result = self.tracker.process_frame(frame_number - 1, raw_dets)

                    if tracked_result is not None:
                        # Build a single-element sv.Detections from the tracker output
                        detections, labels = self._tracked_to_detections(
                            tracked_result, frame_width, frame_height
                        )
                    else:
                        detections = sv.Detections.empty()
                        labels = []

                # Update detection count
                total_detections += len(detections)

                # Annotate frame
                try:
                    annotated_frame = self.visualizer.annotate_frame(
                        frame, detections, labels
                    )
                except cv2.error:
                    # Fallback if annotation fails (e.g. coordinate issues)
                    annotated_frame = frame.copy()

                # Draw tracking state info when tracker is active
                if self.tracker is not None:
                    state_info = self.tracker.get_current_state()
                    info_dict = {
                        "State": state_info["state"],
                        "Speed": f"{state_info.get('velocity', [0,0])[0]:.0f},{state_info.get('velocity', [0,0])[1]:.0f}",
                    }
                    if tracked_result and tracked_result.get("is_predicted"):
                        info_dict["Mode"] = "PREDICTED"
                    if (hasattr(self.tracker.track_manager, '_aerial_recovery_active')
                            and self.tracker.track_manager._aerial_recovery_active):
                        info_dict["Mode"] = "AERIAL RECOVERY"
                    annotated_frame = self.visualizer.draw_info_panel(
                        annotated_frame, info_dict, position="top-right"
                    )

                # Draw FPS
                current_fps = self.fps_counter.update()
                annotated_frame = self.visualizer.draw_fps(annotated_frame, current_fps)

                # Draw detection count
                annotated_frame = self.visualizer.draw_detection_count(
                    annotated_frame, len(detections)
                )

                # Display frame (if not in no-display mode)
                if not self.args.no_display:
                    cv2.imshow('Ball Detection - RF-DETR (Press q to quit)', annotated_frame)

                # Save frame if needed
                if self.video_writer is not None:
                    self.video_writer.write(annotated_frame)

                # Check for quit key
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    print("\nQuitting...")
                    break

                # Print progress for video files
                if self.args.source != "webcam" and frame_number % 30 == 0:
                    print(f"Processed {frame_number} frames | "
                          f"FPS: {current_fps:.1f} | "
                          f"Detections: {len(detections)}", end='\r')

            # Print summary
            print("\n" + "=" * 60)
            print(f"Processing complete!")
            print(f"Total frames: {frame_number}")
            print(f"Total detections: {total_detections}")
            print(f"Average FPS: {self.fps_counter.fps:.2f}")
            if self.tracker is not None:
                stats = self.tracker.get_stats()
                print(f"Tracking stats:")
                print(f"  Detection rate : {stats['detection_rate']*100:.1f}%")
                print(f"  Tracking rate  : {stats['tracking_rate']*100:.1f}%")
                print(f"  Predicted frames: {stats['predicted']}")
                print(f"  Lost frames     : {stats['lost']}")
                print(f"  Avg confidence  : {stats['avg_confidence']:.3f}")
            print("=" * 60)

        except KeyboardInterrupt:
            print("\n\nInterrupted by user")

        except Exception as e:
            print(f"\nError during processing: {e}")
            import traceback
            traceback.print_exc()

        finally:
            # Cleanup
            self._cleanup(cap)

    # ── Conversion helpers for tracker integration ────────────

    @staticmethod
    def _detections_to_dicts(detections: sv.Detections):
        """Convert sv.Detections → list of dicts expected by BallTrackingPipeline."""
        result = []
        if len(detections) == 0:
            return result
        for i in range(len(detections)):
            x1, y1, x2, y2 = detections.xyxy[i]
            result.append({
                "x": float(x1),
                "y": float(y1),
                "width": float(x2 - x1),
                "height": float(y2 - y1),
                "confidence": float(detections.confidence[i]),
                "class_id": int(detections.class_id[i]) if detections.class_id is not None else 37,
            })
        return result

    @staticmethod
    def _tracked_to_detections(tracked: dict, frame_w: int, frame_h: int):
        """Convert a tracked-ball dict back into sv.Detections + labels."""
        cx, cy = tracked["x"], tracked["y"]
        w = tracked.get("w", 20) or 20   # fallback if 0 (predicted frames)
        h = tracked.get("h", 20) or 20
        # Ensure minimum visible box size for annotation
        w = max(w, 16)
        h = max(h, 16)
        x1 = max(0.0, cx - w / 2)
        y1 = max(0.0, cy - h / 2)
        x2 = min(float(frame_w), cx + w / 2)
        y2 = min(float(frame_h), cy + h / 2)
        conf = tracked.get("confidence", 0.0)
        state = tracked.get("state", "")

        det = sv.Detections(
            xyxy=np.array([[int(round(x1)), int(round(y1)), int(round(x2)), int(round(y2))]], dtype=np.float64),
            confidence=np.array([max(conf, 0.01)], dtype=np.float64),
            class_id=np.array([37], dtype=int),
        )

        if tracked.get("is_predicted"):
            label = f"ball (pred) {state}"
        elif state == "VALIDATING":
            label = f"ball (validating) {conf:.2f}"
        else:
            label = f"sports ball {conf:.2f}"

        return det, [label]

    def _cleanup(self, cap):
        """Release resources"""
        print("\nCleaning up...")

        if cap is not None:
            cap.release()

        if self.video_writer is not None:
            self.video_writer.release()

        cv2.destroyAllWindows()


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="Real-time Ball Detection using RF-DETR",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    parser.add_argument(
        "--source",
        type=str,
        default="webcam",
        help="Video source: 'webcam', video file path, RTSP URL, or camera device index"
    )

    parser.add_argument(
        "--model",
        type=str,
        default="base",
        choices=["base", "large"],
        help="RF-DETR model size"
    )

    parser.add_argument(
        "--confidence",
        type=float,
        default=0.3,
        help="Minimum confidence threshold for detections"
    )

    parser.add_argument(
        "--all-classes",
        action="store_true",
        help="Show all COCO class detections (not just balls)"
    )

    parser.add_argument(
        "--resolution",
        type=int,
        default=640,
        help="Inference resolution (model input size)"
    )

    parser.add_argument(
        "--no-display",
        action="store_true",
        help="Run without GUI window (headless mode)"
    )

    parser.add_argument(
        "--save-output",
        type=str,
        default=None,
        help="Path to save annotated video output"
    )

    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=["auto", "cuda", "mps", "cpu"],
        help="Device to run inference on"
    )

    # ── Master toggle: raw model vs advanced filters ───────────
    parser.add_argument(
        "--advanced-filters",
        action="store_true",
        default=True,
        help="Yes — run with advanced post-detection filters + temporal tracking (default)"
    )

    parser.add_argument(
        "--raw-model",
        action="store_false",
        dest="advanced_filters",
        help="No — run with raw model output only (class + confidence filtering, no advanced filters or tracking)"
    )

    # ── Tracking & filter arguments ──────────────────────────
    parser.add_argument(
        "--enable-tracking",
        action="store_true",
        default=True,
        help="Enable temporal tracking via BallTrackingPipeline (Kalman + search zones)"
    )

    parser.add_argument(
        "--no-tracking",
        action="store_false",
        dest="enable_tracking",
        help="Disable temporal tracking (per-frame detection only)"
    )

    parser.add_argument(
        "--debug-filters",
        action="store_true",
        default=False,
        help="Print per-frame filter decisions to console (verbose)"
    )

    parser.add_argument(
        "--no-green-filter",
        action="store_true",
        default=False,
        help="Disable the green-field proximity filter (useful for indoor / non-grass pitches)"
    )

    parser.add_argument(
        "--no-circularity-filter",
        action="store_true",
        default=False,
        help="Disable the circularity / shape filter"
    )

    parser.add_argument(
        "--no-roi-filter",
        action="store_true",
        default=False,
        help="Disable the pitch ROI boundary filter"
    )

    parser.add_argument(
        "--low-conf-threshold",
        type=float,
        default=None,
        help="Override low-confidence retry threshold (default 0.15). "
             "Used when no ball is found at normal threshold to recover aerial balls."
    )

    return parser.parse_args()


def main():
    """Main entry point"""
    # Parse arguments
    args = parse_args()

    # Validate arguments
    if args.source != "webcam" and not args.source.startswith("rtsp://"):
        source_path = Path(args.source)
        if not source_path.exists() and not args.source.isdigit():
            print(f"Error: Video file not found: {args.source}")
            sys.exit(1)

    # Create and run pipeline
    try:
        pipeline = BallDetectionPipeline(args)
        pipeline.run()

    except Exception as e:
        print(f"\nFatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
