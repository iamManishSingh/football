#!/usr/bin/env python3
"""
Quick test script to verify the installation and setup
Run this to check if all dependencies are installed correctly
"""

import sys


def check_imports():
    """Check if all required packages are installed"""
    print("Checking dependencies...")
    print("=" * 60)

    packages = {
        "cv2": "opencv-python",
        "torch": "torch",
        "torchvision": "torchvision",
        "supervision": "supervision",
        "numpy": "numpy",
        "PIL": "Pillow"
    }

    missing = []
    for module, package in packages.items():
        try:
            __import__(module)
            print(f"✓ {package:20s} - installed")
        except ImportError:
            print(f"✗ {package:20s} - MISSING")
            missing.append(package)

    print("=" * 60)

    if missing:
        print(f"\nMissing packages: {', '.join(missing)}")
        print("Install with: pip install -r requirements.txt")
        return False
    else:
        print("\n✓ All dependencies installed!")
        return True


def check_rfdetr():
    """Check if RF-DETR is installed"""
    print("\nChecking RF-DETR...")
    print("=" * 60)

    try:
        import rfdetr
        print("✓ rfdetr - installed")
        print("=" * 60)
        return True
    except ImportError:
        print("✗ rfdetr - MISSING")
        print("=" * 60)
        print("\nInstall with: pip install rfdetr")
        return False


def check_cuda():
    """Check CUDA availability"""
    print("\nChecking compute devices...")
    print("=" * 60)

    try:
        import torch

        if torch.cuda.is_available():
            print(f"✓ CUDA available")
            print(f"  Device: {torch.cuda.get_device_name(0)}")
            print(f"  Count: {torch.cuda.device_count()}")
        elif torch.backends.mps.is_available():
            print(f"✓ MPS (Apple Silicon) available")
        else:
            print(f"⚠ No GPU available - will use CPU (slower)")

        print("=" * 60)
        return True

    except Exception as e:
        print(f"✗ Error checking devices: {e}")
        print("=" * 60)
        return False


def check_webcam():
    """Check if webcam is accessible"""
    print("\nChecking webcam...")
    print("=" * 60)

    try:
        import cv2
        cap = cv2.VideoCapture(0)

        if cap.isOpened():
            print("✓ Webcam accessible (device 0)")
            ret, frame = cap.read()
            if ret:
                h, w = frame.shape[:2]
                print(f"  Resolution: {w}x{h}")
            cap.release()
        else:
            print("⚠ Webcam not accessible")
            print("  You can still use video files with --source <file>")

        print("=" * 60)
        return True

    except Exception as e:
        print(f"✗ Error checking webcam: {e}")
        print("=" * 60)
        return False


def main():
    """Run all checks"""
    print("\n" + "=" * 60)
    print("Ball Detection Pipeline - Setup Verification")
    print("=" * 60)

    checks = [
        check_imports(),
        check_rfdetr(),
        check_cuda(),
        check_webcam()
    ]

    print("\n" + "=" * 60)
    if all(checks[:2]):  # Only require core dependencies
        print("✓ Setup complete! You can now run:")
        print("  python main.py --source webcam")
        print("  python main.py --source video.mp4")
    else:
        print("✗ Setup incomplete. Please install missing dependencies.")
        sys.exit(1)
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
