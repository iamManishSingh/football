# STEP-BY-STEP GUIDE: Running Ball Detection on Your Video

This guide provides **exact commands** to run ball detection on your video file.

---

## Overview

The process is now:
1. Install dependencies → 2. Download models → 3. Test → 4. Run on video

Total time: ~15-20 minutes (mostly downloads)

---

## STEP 1: Install Dependencies

Open Terminal and run:

```bash
# Navigate to project directory
cd /Users/L034900/Library/CloudStorage/OneDrive-EliLillyandCompany/Documents/analytics_manish_learn/ball

# Install all required packages
pip install -r requirements.txt
```

**Wait for installation to complete** (~5-10 minutes).

You should see messages like:
```
Successfully installed opencv-python-4.8.1 torch-2.0.1 supervision-0.19.0 ...
```

---

## STEP 2: Download RF-DETR Models

This is the **new recommended step** - download models first!

```bash
python download_models.py
```

### Interactive Menu Will Appear:

```
============================================================
RF-DETR Model Downloader
============================================================
Models will be saved to: /path/to/ball/models
============================================================

Available models to download:
  1. rfdetr-base
  2. rfdetr-large
  3. Download all
  0. Exit

Select option [0-3]:
```

**Type `3` and press Enter** to download all models.

### What Happens:
- Downloads `rfdetr-base` model (~150 MB) → saved as `models/rfdetr_base.pth`
- Downloads `rfdetr-large` model (~300 MB) → saved as `models/rfdetr_large.pth`
- Takes ~5-10 minutes depending on internet speed

You'll see:
```
============================================================
Downloading base model...
============================================================
Initializing model (this will download weights)...
Saving model to: /path/to/models/rfdetr_base.pth
✓ Successfully downloaded: /path/to/models/rfdetr_base.pth
  Size: 145.2 MB

============================================================
Downloading large model...
============================================================
...
✓ Successfully downloaded: /path/to/models/rfdetr_large.pth
  Size: 287.6 MB

============================================================
Download Summary: 2/2 models downloaded
============================================================
```

---

## STEP 3: Verify Setup

Test that everything is installed correctly:

```bash
python test_setup.py
```

Expected output:
```
============================================================
Ball Detection Pipeline - Setup Verification
============================================================
Checking dependencies...
============================================================
✓ opencv-python      - installed
✓ torch              - installed
✓ torchvision        - installed
✓ supervision        - installed
✓ numpy              - installed
✓ Pillow             - installed
============================================================

✓ All dependencies installed!

Checking RF-DETR...
============================================================
✓ rfdetr - installed
============================================================

Checking compute devices...
============================================================
✓ MPS (Apple Silicon) available
============================================================

Checking webcam...
============================================================
✓ Webcam accessible (device 0)
  Resolution: 1280x720
============================================================

============================================================
✓ Setup complete! You can now run:
  python main.py --source webcam
  python main.py --source video.mp4
============================================================
```

---

## STEP 4: Run Ball Detection on Your Video

Now you're ready to detect balls in your video!

### Basic Command:

```bash
python main.py --source YOUR_VIDEO.mp4
```

**Replace `YOUR_VIDEO.mp4` with your actual video filename.**

### Examples:

```bash
# If video is in the same folder
python main.py --source game_footage.mp4

# If video is elsewhere, use full path
python main.py --source /Users/L034900/Downloads/soccer_game.mp4

# Higher confidence (fewer false positives)
python main.py --source game.mp4 --confidence 0.6

# Use large model (better accuracy)
python main.py --source game.mp4 --model large

# Save output video
python main.py --source game.mp4 --save-output detected_output.mp4
```

### What You'll See:

1. **Model loads** (instant, from `models/` folder):
```
============================================================
Ball Detection Pipeline - RF-DETR
============================================================
Loading RF-DETR-base model...
Running on: mps
Loading model from local cache: models/rfdetr_base.pth
✓ Loaded from local cache
Model loaded successfully!
============================================================
Setup complete! Starting inference...
Press 'q' to quit
============================================================
Video source: game.mp4
Video info: 1920x1080 @ 30.00 FPS, 1500 frames
```

2. **Live window opens** showing:
   - Your video playing
   - Green boxes around detected balls
   - Labels: "sports ball 0.87"
   - FPS counter: "FPS: 25.3"
   - Detection count: "Detections: 2"

3. **Progress in terminal**:
```
Processed 30 frames | FPS: 25.1 | Detections: 1
Processed 60 frames | FPS: 26.3 | Detections: 2
Processed 90 frames | FPS: 25.8 | Detections: 1
...
```

4. **Press `q` to quit** anytime

5. **Summary at end**:
```
============================================================
Processing complete!
Total frames: 1500
Total detections: 342
Average FPS: 25.7
============================================================
```

---

## Complete Example Session

Here's what a complete run looks like:

```bash
# Step 1: Navigate to directory
cd /Users/L034900/Library/CloudStorage/OneDrive-EliLillyandCompany/Documents/analytics_manish_learn/ball

# Step 2: Install (first time only)
pip install -r requirements.txt

# Step 3: Download models (first time only)
python download_models.py
# Select option 3 (Download all)

# Step 4: Test setup (optional)
python test_setup.py

# Step 5: Run on your video
python main.py --source my_video.mp4

# Step 6: Save output (optional)
python main.py --source my_video.mp4 --save-output output.mp4
```

---

## Command Options Reference

| Goal | Command |
|------|---------|
| Basic detection | `python main.py --source video.mp4` |
| Higher confidence | `python main.py --source video.mp4 --confidence 0.6` |
| Better accuracy | `python main.py --source video.mp4 --model large` |
| Save output | `python main.py --source video.mp4 --save-output out.mp4` |
| Faster (CPU) | `python main.py --source video.mp4 --resolution 320` |
| All objects | `python main.py --source video.mp4 --all-classes` |

---

## Managing Models

### Check what's downloaded:
```bash
python download_models.py --list
```

### Verify models work:
```bash
python download_models.py --verify
```

### Models location:
```bash
ls -lh models/
```

Output:
```
rfdetr_base.pth   (145 MB)
rfdetr_large.pth  (287 MB)
```

---

## Troubleshooting

### "No module named 'rfdetr'"
```bash
pip install rfdetr
```

### "Video file not found"
- Check filename spelling
- Use full path: `--source /full/path/to/video.mp4`
- Or copy video to project folder

### Models not loading
```bash
# Re-download models
python download_models.py
```

### Slow performance
```bash
# Use lower resolution
python main.py --source video.mp4 --resolution 320
```

### No detections
```bash
# Lower confidence threshold
python main.py --source video.mp4 --confidence 0.2

# Or try all classes
python main.py --source video.mp4 --all-classes
```

---

## Summary - Quick Commands

```bash
# First time setup (do once)
pip install -r requirements.txt
python download_models.py  # Select option 3

# Every time you want to detect
python main.py --source your_video.mp4

# With output saved
python main.py --source your_video.mp4 --save-output output.mp4
```

---

## What Changed?

**OLD way** (without download_models.py):
- Models download automatically during first run
- Long wait with no progress indication
- Not sure where models are stored

**NEW way** (with download_models.py):
- ✓ Download models first with clear progress
- ✓ Models stored in `models/` folder
- ✓ Instant loading on subsequent runs
- ✓ Works offline after download
- ✓ Easy to manage and verify models

---

**You're all set!** Run your first detection:

```bash
python main.py --source your_video.mp4
```

🎾⚽🏀 Happy ball detecting!
