"""
⚽ Ball Detection Pipeline — Unified Configuration
====================================================

ALL filter parameters live here in ONE place.

Two sections:
  1. DETECTOR_CONFIG  — per-frame spatial / visual filters (used by detector.py)
  2. TRACKER_CONFIG   — temporal tracking filters + Kalman (used by ball_tracking_pipeline.py)

To tune a parameter, change it here and both modules pick it up automatically.

NOTE: configs/default.yaml mirrors this file for documentation purposes
      but is NOT loaded at runtime.  This file IS the runtime source of truth.
"""

from typing import Any, Dict


# ============================================================================
# SECTION 1 — DETECTOR (per-frame spatial / visual filters)
# ============================================================================
# Applied inside detector.py after each RF-DETR inference call.
# Strategy: "detect aggressively, validate over time"
# These spatial filters are intentionally relaxed so we catch the ball
# even with some false positives.  Static FPs (shoes, logos, markings)
# are killed later by temporal static-object rejection in the tracker.

DETECTOR_CONFIG: Dict[str, Any] = {
    # --- Aspect ratio (rejects shoes / elongated objects) ---
    "min_aspect_ratio": 0.40,       # relaxed: motion blur can stretch bbox
    "max_aspect_ratio": 2.5,        # relaxed: allow wider range

    # --- Size range (fraction of frame area) ---
    "min_ball_area_ratio": 0.00001,  # ~20 px² at 1080p (catch small distant balls)
    "max_ball_area_ratio": 0.008,    # ~16 000 px² at 1080p (allow close-up)

    # --- Circularity (0=line, 1=perfect circle) ---
    "enable_circularity_filter": True,
    "min_circularity": 0.18,        # very relaxed: fast moving ball is not round at all
    "circularity_high_conf_bypass": 0.45,  # lower bypass threshold → more balls get through

    # --- Pitch ROI masking (fraction of frame to exclude) ---
    "enable_roi_filter": True,
    "exclude_top_ratio": 0.04,      # reduced: ball can go high
    "exclude_bottom_ratio": 0.03,   # reduced: allow near-bottom detections
    "exclude_left_ratio": 0.01,
    "exclude_right_ratio": 0.01,

    # --- Green-field proximity ---
    # Checks whether the area around the detection has enough
    # green (grass) pixels. Helps reject off-pitch white objects.
    "enable_green_field_filter": True,
    "green_hsv_lower": (30, 25, 25),    # slightly wider HSV range
    "green_hsv_upper": (90, 255, 255),  # slightly wider HSV range
    "green_context_radius": 3.0,        # bigger context window for better sampling
    "min_green_ratio": 0.05,            # relaxed to 5%: ball near lines/markings has less green

    # --- Edge-region filter ---
    # Rejects detections very close to frame borders (score overlays, etc.)
    "enable_edge_filter": True,
    "edge_margin_pixels": 10,           # reduced margin

    # --- Single-ball selection ---
    # When multiple detections survive filters, keep only the best one
    "pick_single_ball": True,

    # --- Lower threshold for second pass (aerial ball recovery) ---
    # If no ball found at normal threshold, retry with a lower one
    "enable_low_conf_retry": True,
    "low_conf_threshold": 0.12,         # even lower retry threshold

    # --- White-dot / noise rejection ---
    # Rejects tiny, bright, uniform blobs on plain surfaces (pitch
    # markings, sensor noise, corner spots).  A real ball — even when
    # small — has internal texture and surrounding context (players,
    # shadows).
    "enable_white_dot_filter": True,
    "white_dot_max_area": 320,           # blobs below this area (px²) are suspect
    "white_dot_brightness_min": 170,     # mean grayscale brightness threshold
    "white_dot_uniformity_max": 35,      # max std-dev of intensities (low = uniform blob)
    "white_dot_isolation_radius": 50,    # px — context radius for edge-density check
    "white_dot_edge_density_min": 0.04,  # surrounding edge density below this → isolated dot

    # --- Context-adaptive detection (pitch vs aerial) ---
    # Classifies each detection's surroundings as "pitch" (green grass)
    # or "aerial" (crowd, sky, goal-net).  Applies different rules to
    # each zone so aerial balls aren't killed by green-field filter and
    # crowd FPs are caught by contrast check.
    "enable_context_filter": True,
    "context_pad_px": 60,                # px padding around bbox for context sampling
    "pitch_green_ratio_threshold": 0.18, # green-pixel ratio ≥ this → "on pitch"
    "aerial_min_confidence": 0.15,       # relaxed conf for aerial-zone detections
    "pitch_min_confidence": 0.30,        # normal conf for on-pitch detections
    "aerial_max_size_px": 60,            # ball looks smaller when far / high
    "aerial_min_contrast": 11.0,         # min brightness diff between blob & surroundings

    # --- Debug logging ---
    "debug_filters": False,
}


# ============================================================================
# SECTION 2 — TRACKER (temporal tracking, Kalman, state machine)
# ============================================================================
# Applied inside ball_tracking_pipeline.py across frames.
# This module is model-agnostic — it only receives plain dicts, no images.

TRACKER_CONFIG: Dict[str, Any] = {
    # ── Frame Dimensions (MUST be set at runtime) ──
    "frame_width": 1920,
    "frame_height": 1080,

    # ── Confidence Filtering ──
    # Problem: False positives (shoes, round objects)
    # Fix: Raise this to reject low-confidence detections globally
    "confidence_threshold": 0.6,              # Global threshold (start here, increase if too many FPs)
    "search_zone_confidence_threshold": 0.3,  # Lower threshold inside predicted search zone (for aerial re-acquisition)

    # ── Size Filtering ──
    # Problem: Shoes/body parts detected as ball (too large), noise (too small)
    # Fix: Ball has predictable size range relative to frame
    "min_ball_area_ratio": 0.00005,           # Min bbox area as fraction of frame area (~60px² at 1080p)
    "max_ball_area_ratio": 0.002,             # Max bbox area as fraction of frame area (~8000px² at 1080p)

    # ── Aspect Ratio Filtering ──
    # Problem: Shoes produce elongated bounding boxes, ball should be ~square
    # Fix: Reject anything that isn't roughly square
    "min_aspect_ratio": 0.6,                  # width/height minimum (ball ≈ 0.8–1.2)
    "max_aspect_ratio": 1.6,                  # width/height maximum

    # ── Pitch ROI Masking ──
    # Problem: Detections outside the pitch (crowd, scoreboard, sideline objects)
    # Fix: Exclude regions where the ball cannot be
    "use_roi": True,
    "exclude_top_ratio": 0.15,                # Exclude top 15% of frame (crowd, sky, banners)
    "exclude_bottom_ratio": 0.07,             # Exclude bottom 7% (broadcast bar, score overlay)
    "exclude_left_ratio": 0.0,                # Exclude left edge
    "exclude_right_ratio": 0.0,               # Exclude right edge
    # Custom polygon ROI (optional — overrides rectangle if set)
    # List of (x, y) tuples defining the pitch boundary in pixel coordinates
    # Example: [(100, 200), (1800, 200), (1900, 900), (50, 900)]
    "custom_roi_polygon": None,

    # ── Temporal Consistency ──
    # Problem: Ball doesn't teleport — sudden jumps are false positives
    # Fix: Reject detections too far from last known position
    "max_jump_distance": 500,                 # Max pixels between consecutive frames (increased for fast passes)
    "max_jump_distance_ratio": 0.20,          # Alternative: max jump as fraction of frame diagonal

    # ── Kalman Filter (Tracking & Prediction) ──
    # Problem: Ball lost during aerial play; bounding box drifts during direction changes
    # Fix: Physics-based prediction maintains track during gaps;
    #       direction-change detection re-initialises Kalman on kicks/bounces;
    #       velocity decay stops drift within a few frames;
    #       dual search (predicted + last-detected) re-acquires stationary ball
    "kalman_process_noise": 10.0,             # Higher = more responsive to direction changes
    "kalman_measurement_noise": 1.0,          # Lower = trust detections more (snaps to ball faster)
    "gravity_pixels_per_frame2": 0.5,         # Gravity in px/frame² (tune for camera angle)
    "kalman_direction_change_threshold": 50.0,  # Innovation threshold (px) to trigger full Kalman re-init
    "kalman_acceleration_decay": 0.5,         # Decay factor for acceleration (0=instant decay, 1=no decay)

    # ── Track Management ──
    # Problem: Track killed too soon during aerial play; ball not re-acquired after landing
    # Fix: Keep predicting for N frames, velocity decay stops drift;
    #       dual search (predicted + last-detected position) enables re-acquisition
    "max_frames_to_predict": 18,              # Short window — velocity decay stops drift within this
    "search_radius_multiplier": 5.0,          # Search radius = speed × this multiplier (widened for passes)
    "min_search_radius": 100,                 # Minimum search zone radius (pixels) — wider for re-acquisition
    "max_search_radius": 500,                 # Maximum search zone radius (pixels)
    "min_detections_to_confirm": 2,           # Need N detections in M frames to confirm a new track
    "confirm_window_frames": 5,               # Window of M frames for track confirmation

    # ── Interpolation (Post-Processing) ──
    # Problem: Missing detections during fast movement create gaps in trajectory
    # Fix: Fill gaps with interpolated positions after processing
    "interpolation_method": "linear",         # "linear" or "cubic"
    "max_gap_to_interpolate": 20,             # Don't interpolate gaps longer than this

    # ── Smoothing ──
    # Problem: Even detected positions jitter frame-to-frame
    # Fix: Apply smoothing to reduce noise
    "enable_smoothing": True,
    "smoothing_window_size": 5,               # Moving average window (odd number)

    # ── Static-Object Rejection (Temporal Validation) ──
    # Strategy: "Detect aggressively, validate over time."
    # Problem: Static objects (shoes, logos, pitch markings) get detected as ball
    #          and persist for many frames without moving. A real ball is almost
    #          always in motion during active play.
    # Fix:     After a track is tentatively confirmed, require it to demonstrate
    #          movement over a short window before promoting it to full TRACKING.
    #          Also, continuously check established tracks — if the tracked object
    #          hasn't moved for several frames, kill it as a false positive.
    "enable_static_rejection": True,          # Master switch for static-object rejection
    "static_check_frames": 12,                 # How many recent frames to examine for movement
    "static_min_displacement_px": 20.0,       # Min total displacement (px) over the window to be "moving"
    "static_max_stationary_ratio": 0.75,      # If ≥75% of frames show <threshold movement → static
    "static_per_frame_threshold_px": 4.0,     # Per-frame displacement below this counts as "stationary"
    "validation_min_frames": 8,               # How many frames in VALIDATING state before deciding
    "validation_min_moving_frames": 4,        # Of those, how many must show movement to confirm

    # ── Aerial Recovery ──
    # When the ball is moving fast (e.g. a goal shot) and tracking is lost,
    # expand the search zone, relax confidence, and extend the prediction
    # window so we can re-acquire the ball against a crowd/sky background.
    "aerial_recovery_min_speed": 12.0,        # px/frame speed at loss to trigger aerial mode
    "aerial_recovery_max_frames": 30,         # extra prediction frames during aerial recovery
    "aerial_recovery_search_scale": 3.1,      # multiply search radius during aerial recovery
    "aerial_recovery_vertical_bias": 1.5,     # expand search more vertically (ball goes up)
    "aerial_recovery_min_confidence": 0.12,   # accept lower confidence during recovery

    # ── Debug ──
    "debug": False,                           # Log filter decisions to console
}
