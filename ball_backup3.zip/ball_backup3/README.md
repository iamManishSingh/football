# Ball Detection Pipeline - RF-DETR

Real-time ball detection using RF-DETR (Real-time Fine-grained Detection Transformer) model. This pipeline performs **live inference** on video streams, displaying detections as they happen — not as a post-processing step.

## Features

- **Real-time inference** on webcam or video files
- **RF-DETR model** with automatic weight download
- **Live visualization** with bounding boxes, labels, and FPS counter
- **Multiple model sizes** (base, large)
- **GPU acceleration** (CUDA, MPS for Apple Silicon)
- **Configurable confidence threshold**
- **Video output recording**
- **Ball-specific filtering** or all COCO classes

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run on Webcam (Default)

```bash
python main.py
```

### 3. Run on Video File

```bash
python main.py --source path/to/video.mp4
```

Press `q` to quit the live window.

## Installation

### Requirements

- Python 3.8 or higher
- CUDA-capable GPU (optional, but recommended for real-time performance)
- Webcam (for live camera detection)

### Install from requirements.txt

```bash
# Clone or download this repository
cd ball-detection

# Install dependencies
pip install -r requirements.txt
```

### Model Weights

Model weights are **automatically downloaded** on first run:
- `rfdetr-base`: ~150MB
- `rfdetr-large`: ~300MB

Weights are cached locally via PyTorch Hub, so subsequent runs are faster.

## Usage

### Basic Examples

```bash
# Webcam with default settings
python main.py

# Video file with base model
python main.py --source video.mp4

# Webcam with large model and higher confidence threshold
python main.py --source webcam --model large --confidence 0.5

# Video file with all COCO classes (not just balls)
python main.py --source video.mp4 --all-classes

# Save annotated output video
python main.py --source video.mp4 --save-output output.mp4

# Run on specific camera device
python main.py --source 1

# Headless mode (no display window)
python main.py --source video.mp4 --no-display --save-output output.mp4
```

### CLI Arguments

| Argument | Default | Description |
|----------|---------|-------------|
| `--source` | `webcam` | Video source: `webcam`, file path, RTSP URL, or camera index |
| `--model` | `base` | Model size: `base` or `large` |
| `--confidence` | `0.3` | Minimum confidence threshold (0.0-1.0) |
| `--all-classes` | `False` | Show all COCO detections (not just balls) |
| `--resolution` | `640` | Inference resolution (model input size) |
| `--no-display` | `False` | Run without GUI window (headless mode) |
| `--save-output` | `None` | Path to save annotated video (e.g., `output.mp4`) |
| `--device` | `auto` | Device: `auto`, `cuda`, `mps`, or `cpu` |

### Detected Classes

By default, the pipeline filters for ball-related objects:
- **Sports ball** (COCO class 32)
- **Frisbee** (COCO class 33)
- **Tennis racket** (COCO class 38)

Use `--all-classes` to detect all 80 COCO classes.

## Project Structure

```
ball-detection/
├── main.py                 # Entry point - CLI + live inference loop
├── detector.py             # RF-DETR model wrapper
├── visualizer.py           # Drawing utilities (boxes, labels, FPS)
├── requirements.txt        # Dependencies
├── README.md               # This file
└── configs/
    └── default.yaml        # Default configuration
```

## How It Works

The pipeline follows a real-time processing flow:

```
[Video Source] → [Read Frame] → [RF-DETR Inference] → [Draw Annotations] → [Display Frame] → Loop
```

1. **Video Capture**: Reads frames from webcam or video file using OpenCV
2. **Inference**: Each frame is passed to RF-DETR model for object detection
3. **Filtering**: Detections are filtered by confidence threshold and class (if enabled)
4. **Visualization**: Bounding boxes, labels, and FPS counter are drawn on the frame
5. **Display**: Annotated frame is shown in real-time OpenCV window
6. **Output**: Optionally saves the annotated video to file

## Performance

### Expected FPS (approximate)

| Hardware | Model | Resolution | FPS |
|----------|-------|------------|-----|
| NVIDIA RTX 4090 | base | 640x640 | 60-80 |
| NVIDIA RTX 4090 | large | 640x640 | 40-50 |
| Apple M1 Max (MPS) | base | 640x640 | 25-35 |
| Apple M1 Max (MPS) | large | 640x640 | 15-20 |
| CPU (Intel i7) | base | 640x640 | 5-8 |

### Optimization Tips

- Use `--resolution 320` for faster inference (lower accuracy)
- Use `--model base` instead of `large` for better FPS
- Ensure GPU drivers are up to date
- Close other GPU-intensive applications

## Supported Platforms

- **Linux**: CUDA-enabled GPUs (NVIDIA)
- **macOS**: MPS acceleration (Apple Silicon M1/M2/M3)
- **Windows**: CUDA-enabled GPUs (NVIDIA)
- **All platforms**: CPU fallback (slower performance)

## Device Auto-Detection

The pipeline automatically detects the best available device:

1. **CUDA** (NVIDIA GPU) - highest priority
2. **MPS** (Apple Silicon) - for macOS
3. **CPU** - fallback if no GPU available

You can override with `--device cuda`, `--device mps`, or `--device cpu`.

## Troubleshooting

### Webcam not opening

```
Error: Cannot open webcam. Check device index or permissions.
```

**Solution**:
- Check camera permissions in system settings
- Try a different device index: `--source 1` or `--source 2`
- Test webcam with: `python -c "import cv2; cap = cv2.VideoCapture(0); print(cap.isOpened())"`

### Video file not found

```
Error: Video file not found: video.mp4
```

**Solution**:
- Verify the file path is correct
- Use absolute path: `--source /full/path/to/video.mp4`

### CUDA out of memory

**Solution**:
- Reduce inference resolution: `--resolution 320`
- Use smaller model: `--model base`
- Close other GPU applications
- The pipeline will auto-fallback to CPU with a warning

### RF-DETR not installed

```
ImportError: No module named 'rfdetr'
```

**Solution**:
```bash
pip install rfdetr
```

### Low FPS on CPU

**Solution**:
- This is expected on CPU. Consider:
  - Using a GPU-enabled system
  - Reducing resolution: `--resolution 320`
  - Using smaller model: `--model base`

## Examples

### Example 1: Basic Webcam Detection

```bash
python main.py
```

Output:
```
============================================================
Ball Detection Pipeline - RF-DETR
============================================================
Loading RF-DETR-base model...
Running on: cuda
Model loaded successfully!
============================================================
Setup complete! Starting inference...
Press 'q' to quit
============================================================
Video source: Webcam (device 0)
```

### Example 2: High-Confidence Video Processing

```bash
python main.py --source game.mp4 --confidence 0.7 --save-output annotated_game.mp4
```

### Example 3: Large Model on Apple Silicon

```bash
python main.py --model large --device mps
```

## Advanced Usage

### Custom Configuration

Edit [configs/default.yaml](configs/default.yaml) to change default settings:

```yaml
model:
  size: "base"
  confidence_threshold: 0.3

visualization:
  box_color: [0, 255, 0]  # Green
  text_color: [255, 255, 255]  # White
```

### Programmatic Usage

You can also use the components programmatically:

```python
from detector import BallDetector
from visualizer import Visualizer

# Initialize detector
detector = BallDetector(model_size="base", confidence_threshold=0.3)

# Run inference on a frame
detections, labels = detector.predict(frame)

# Visualize
visualizer = Visualizer()
annotated_frame = visualizer.annotate_frame(frame, detections, labels)
```

## Model Information

### RF-DETR (Real-time Fine-grained Detection Transformer)

- **Paper**: [RF-DETR on arXiv](https://arxiv.org/abs/2404.03853)
- **GitHub**: [roboflow/rf-detr](https://github.com/roboflow/rf-detr)
- **Training Data**: COCO dataset (80 classes)
- **Architecture**: Transformer-based object detector optimized for real-time inference

### Model Sizes

| Model | Parameters | Speed | Accuracy |
|-------|-----------|-------|----------|
| base | ~30M | Faster | Good |
| large | ~60M | Slower | Better |

## Citation

If you use RF-DETR in your research, please cite:

```bibtex
@article{rfdetr2024,
  title={RF-DETR: Real-time Fine-grained Detection Transformer},
  author={Roboflow},
  journal={arXiv preprint},
  year={2024}
}
```

## License

This project is provided as-is for educational and research purposes.

## Contributing

Contributions are welcome! Please open an issue or pull request.

## Acknowledgments

- RF-DETR model by [Roboflow](https://github.com/roboflow)
- [Supervision](https://github.com/roboflow/supervision) library for visualization utilities
- OpenCV for video processing

## Support

For issues, questions, or feature requests, please open an issue on GitHub.

---

**Note**: This pipeline is designed for real-time inference. Each frame is processed individually as it's captured, not in batch or post-processing mode.
