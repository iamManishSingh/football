"""
Training Dataset & Data Loader
================================
Two data sources supported:

1. Metrica Sports Open Data (recommended for starting)
   - Tracking data at 25fps with player positions
   - Synchronized event labels (pass, shot, etc.)
   - Free: https://github.com/metrica-sports/sample-data

2. StatsBomb Open Data
   - Event data with x,y coordinates
   - No tracking data, but can be used for event classification training
   - Free: https://github.com/statsbomb/open-data

3. Your Own Video Pipeline (later stage)
   - Extract game states from your detection pipeline
   - Self-label or semi-automatically label events
"""

import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from loguru import logger


class MetricaTrackingDataset(Dataset):
    """
    Loads Metrica Sports sample tracking data for training.

    Data format:
    - Tracking data: CSV with columns [Frame, Time, Player1_x, Player1_y, ..., Ball_x, Ball_y]
    - Events data: JSON/CSV with [Frame, Type, From, To, Start_x, Start_y, End_x, End_y]

    Each sample is a sequence of `seq_length` frames ending at an event,
    with the event type as the label.
    """

    def __init__(
        self,
        tracking_csv: str,
        events_csv: str,
        seq_length: int = 30,
        max_players: int = 22,
        player_feat_dim: int = 12,
        pitch_length: float = 105.0,
        pitch_width: float = 68.0,
    ):
        self.seq_length = seq_length
        self.max_players = max_players
        self.player_feat_dim = player_feat_dim
        self.pitch_length = pitch_length
        self.pitch_width = pitch_width

        # Load data
        logger.info(f"Loading tracking data from {tracking_csv}")
        self.tracking_df = pd.read_csv(tracking_csv)

        logger.info(f"Loading events from {events_csv}")
        self.events_df = pd.read_csv(events_csv)

        # Map event types to class indices
        self.event_to_idx = {
            "PASS": 0,
            "SHOT": 1,
            "CARRY": 2,       # = dribble
            "CROSS": 3,
            "CLEARANCE": 4,
            "THROUGH_BALL": 5,
        }

        # Filter events to only those we can classify
        self.events_df = self.events_df[
            self.events_df["Type"].isin(self.event_to_idx.keys())
        ].reset_index(drop=True)

        # Parse tracking data into per-frame arrays
        self._parse_tracking()

        logger.info(
            f"Dataset: {len(self.events_df)} events, "
            f"{len(self.frames)} frames"
        )

    def _parse_tracking(self):
        """
        Parse the Metrica CSV into structured frame data.

        Metrica format (normalized 0-1 coordinates):
        Frame, Time[s], Home_1_x, Home_1_y, Home_2_x, Home_2_y, ...,
        Away_1_x, Away_1_y, ..., Ball_x, Ball_y

        We convert to pitch meters by multiplying by pitch dimensions.
        """
        self.frames = {}

        for _, row in self.tracking_df.iterrows():
            frame_id = int(row.get("Frame", row.name))

            # Extract player positions
            players = []
            player_teams = []

            # Home team players (team_id = 0)
            for i in range(1, 15):  # Up to 14 home players
                x_col = f"Home_{i}_x"
                y_col = f"Home_{i}_y"
                if x_col in row and y_col in row:
                    x, y = row[x_col], row[y_col]
                    if not (np.isnan(x) or np.isnan(y)):
                        players.append(np.array([
                            x * self.pitch_length,
                            y * self.pitch_width,
                        ]))
                        player_teams.append(0)

            # Away team players (team_id = 1)
            for i in range(1, 15):
                x_col = f"Away_{i}_x"
                y_col = f"Away_{i}_y"
                if x_col in row and y_col in row:
                    x, y = row[x_col], row[y_col]
                    if not (np.isnan(x) or np.isnan(y)):
                        players.append(np.array([
                            x * self.pitch_length,
                            y * self.pitch_width,
                        ]))
                        player_teams.append(1)

            # Ball position
            ball_x = row.get("Ball_x", row.get("ball_x", 0.5))
            ball_y = row.get("Ball_y", row.get("ball_y", 0.5))
            if np.isnan(ball_x):
                ball_x = 0.5
            if np.isnan(ball_y):
                ball_y = 0.5

            ball_pos = np.array([
                ball_x * self.pitch_length,
                ball_y * self.pitch_width,
            ])

            self.frames[frame_id] = {
                "players": players,
                "teams": player_teams,
                "ball": ball_pos,
            }

    def __len__(self) -> int:
        return len(self.events_df)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """
        Get a training sample: sequence of frames ending at an event.

        Returns:
            Dict with:
                player_features: (seq_len, max_players, player_feat_dim)
                ball_features: (seq_len, 6)
                player_mask: (seq_len, max_players)
                action_label: int (event class)
                destination_label: (105, 68) heatmap with Gaussian at event end position
                xg_label: float (1 if goal, 0 otherwise — only meaningful for shots)
        """
        event = self.events_df.iloc[idx]
        event_frame = int(event["Start Frame"])
        event_type = self.event_to_idx[event["Type"]]

        # Build sequence ending at event frame
        start_frame = event_frame - self.seq_length + 1

        player_features = np.zeros(
            (self.seq_length, self.max_players, self.player_feat_dim),
            dtype=np.float32
        )
        ball_features = np.zeros((self.seq_length, 6), dtype=np.float32)
        player_mask = np.zeros((self.seq_length, self.max_players), dtype=np.float32)

        prev_positions = {}  # player_idx -> previous position for velocity

        for t in range(self.seq_length):
            frame_id = start_frame + t
            if frame_id not in self.frames:
                continue

            frame_data = self.frames[frame_id]
            ball_pos = frame_data["ball"]

            for p_idx, (pos, team) in enumerate(
                zip(frame_data["players"], frame_data["teams"])
            ):
                if p_idx >= self.max_players:
                    break

                player_mask[t, p_idx] = 1.0

                # Velocity (from previous frame)
                vel = np.array([0.0, 0.0])
                if p_idx in prev_positions:
                    vel = (pos - prev_positions[p_idx]) * 25.0  # 25fps → m/s
                prev_positions[p_idx] = pos.copy()

                # Distance to ball
                dist_ball = np.linalg.norm(pos - ball_pos)

                # Distance and angle to goal
                goal = np.array([105.0, 34.0]) if team == 0 else np.array([0.0, 34.0])
                dist_goal = np.linalg.norm(pos - goal)
                angle_goal = np.degrees(np.arctan2(
                    abs(pos[1] - goal[1]),
                    abs(pos[0] - goal[0])
                ))

                # Is ball carrier
                is_carrier = 1.0 if dist_ball < 2.0 else 0.0

                # Nearest opponent
                nearest_opp = 50.0
                for q_idx, (q_pos, q_team) in enumerate(
                    zip(frame_data["players"], frame_data["teams"])
                ):
                    if q_team != team:
                        d = np.linalg.norm(pos - q_pos)
                        nearest_opp = min(nearest_opp, d)

                player_features[t, p_idx] = np.array([
                    pos[0] / 105.0,     # normalized x
                    pos[1] / 68.0,      # normalized y
                    vel[0] / 10.0,      # normalized vx
                    vel[1] / 10.0,      # normalized vy
                    0.0,                # ax (would need 3 frames)
                    0.0,                # ay
                    dist_ball / 125.0,
                    dist_goal / 125.0,
                    angle_goal / 180.0,
                    nearest_opp / 50.0,
                    is_carrier,
                    float(team),
                ])

            # Ball features
            ball_vel = np.array([0.0, 0.0])
            ball_features[t] = np.array([
                ball_pos[0] / 105.0,
                ball_pos[1] / 68.0,
                ball_vel[0] / 30.0,
                ball_vel[1] / 30.0,
                0.0,  # speed
                0.0,  # possession team (simplified)
            ])

        # --- Labels ---
        # Action label
        action_label = event_type

        # Destination heatmap (Gaussian around end position of the event)
        dest_heatmap = np.zeros((105, 68), dtype=np.float32)
        if "End X" in event and "End Y" in event:
            end_x = float(event["End X"]) * 105.0
            end_y = float(event["End Y"]) * 68.0
            dest_heatmap = self._create_gaussian_heatmap(end_x, end_y, sigma=3.0)

        # xG label (1 if the event is a shot that resulted in a goal)
        xg_label = 0.0
        if event_type == 1:  # SHOT
            # Check if shot resulted in goal (adapt to your event data format)
            if "Subtype" in event:
                xg_label = 1.0 if "GOAL" in str(event["Subtype"]).upper() else 0.0

        return {
            "player_features": torch.tensor(player_features),
            "ball_features": torch.tensor(ball_features),
            "player_mask": torch.tensor(player_mask),
            "action_label": torch.tensor(action_label, dtype=torch.long),
            "destination_label": torch.tensor(dest_heatmap),
            "xg_label": torch.tensor(xg_label, dtype=torch.float32),
        }

    def _create_gaussian_heatmap(
        self,
        cx: float,
        cy: float,
        sigma: float = 3.0,
        grid_x: int = 105,
        grid_y: int = 68,
    ) -> np.ndarray:
        """
        Create a 2D Gaussian heatmap centered at (cx, cy).
        This represents the probability distribution of where the ball will go.
        """
        x = np.arange(grid_x)
        y = np.arange(grid_y)
        xx, yy = np.meshgrid(x, y, indexing="ij")

        heatmap = np.exp(-((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * sigma ** 2))
        heatmap /= heatmap.sum() + 1e-8  # Normalize to probability distribution
        return heatmap.astype(np.float32)


def create_dataloaders(
    tracking_csv: str,
    events_csv: str,
    config: dict,
    val_split: float = 0.15,
    num_workers: int = 4,
) -> Tuple[DataLoader, DataLoader]:
    """
    Create train and validation data loaders.
    """
    dataset = MetricaTrackingDataset(
        tracking_csv=tracking_csv,
        events_csv=events_csv,
        seq_length=config["features"]["sequence_length"],
        max_players=config["features"]["max_players"],
        player_feat_dim=config["features"]["player_feature_dim"],
    )

    # Split into train/val
    total = len(dataset)
    val_size = int(total * val_split)
    train_size = total - val_size

    train_dataset, val_dataset = torch.utils.data.random_split(
        dataset, [train_size, val_size]
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=config["training"]["batch_size"],
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=config["training"]["batch_size"],
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )

    logger.info(f"Created loaders: {train_size} train, {val_size} val samples")
    return train_loader, val_loader
