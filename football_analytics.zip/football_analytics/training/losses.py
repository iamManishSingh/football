"""
Custom Loss Functions for Multi-Task Football Prediction
=========================================================

We have 4 prediction heads, each with a different loss:
1. Action Classification → CrossEntropyLoss
2. Destination Heatmap → KL Divergence (comparing two probability distributions)
3. xG → Binary Cross Entropy
4. Pressing → MSE or BCE

Multi-task loss = weighted sum of all individual losses.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict


class ActionLoss(nn.Module):
    """
    Cross-entropy loss for action classification.
    Handles class imbalance with optional class weights.
    """

    def __init__(self, num_classes: int = 6, class_weights: torch.Tensor = None):
        super().__init__()
        # Passes dominate events (~70%), so we upweight rare classes
        if class_weights is None:
            class_weights = torch.tensor([
                0.3,   # pass (very common)
                2.0,   # shot (rare)
                0.5,   # dribble
                1.5,   # cross
                1.0,   # clearance
                2.5,   # through_ball (very rare)
            ])
        self.loss_fn = nn.CrossEntropyLoss(weight=class_weights)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Args:
            logits: (batch, num_classes) — raw logits from action head
            targets: (batch,) — class indices
        """
        return self.loss_fn(logits, targets)


class DestinationLoss(nn.Module):
    """
    KL Divergence loss for destination heatmap prediction.

    Both prediction and target are probability distributions over the pitch grid.
    KL(target || prediction) measures how well the prediction matches the target.
    """

    def __init__(self):
        super().__init__()

    def forward(
        self,
        prediction: torch.Tensor,
        target: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            prediction: (batch, 105, 68) — predicted probability heatmap
            target: (batch, 105, 68) — target Gaussian heatmap

        Returns:
            Scalar loss
        """
        # Flatten to (batch, 105*68)
        pred_flat = prediction.view(prediction.size(0), -1)
        target_flat = target.view(target.size(0), -1)

        # Add small epsilon to avoid log(0)
        pred_flat = pred_flat + 1e-8
        target_flat = target_flat + 1e-8

        # Normalize to ensure valid distributions
        pred_flat = pred_flat / pred_flat.sum(dim=-1, keepdim=True)
        target_flat = target_flat / target_flat.sum(dim=-1, keepdim=True)

        # KL Divergence
        loss = F.kl_div(
            pred_flat.log(),
            target_flat,
            reduction="batchmean",
            log_target=False,
        )

        return loss


class XGLoss(nn.Module):
    """Binary cross entropy for xG prediction."""

    def __init__(self):
        super().__init__()
        self.loss_fn = nn.BCELoss()

    def forward(self, prediction: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        Args:
            prediction: (batch, 1) — predicted goal probability
            target: (batch,) — 0 or 1
        """
        return self.loss_fn(prediction.squeeze(-1), target.float())


class PressingLoss(nn.Module):
    """MSE loss for pressing intensity."""

    def __init__(self):
        super().__init__()
        self.loss_fn = nn.MSELoss()

    def forward(self, prediction: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return self.loss_fn(prediction.squeeze(-1), target.float())


class MultiTaskLoss(nn.Module):
    """
    Combined multi-task loss with learnable or fixed weights.

    Total loss = w1 * action_loss + w2 * destination_loss + w3 * xg_loss + w4 * pressing_loss

    Option: Use uncertainty-based weighting (Kendall et al., 2018)
    where the model learns the optimal weight for each task.
    """

    def __init__(self, config: dict, learnable_weights: bool = False):
        super().__init__()

        weights = config["training"]["loss_weights"]

        self.action_loss = ActionLoss()
        self.destination_loss = DestinationLoss()
        self.xg_loss = XGLoss()
        self.pressing_loss = PressingLoss()

        if learnable_weights:
            # Learnable log-variance parameters (uncertainty weighting)
            self.log_vars = nn.Parameter(torch.zeros(4))
        else:
            self.register_buffer("weights", torch.tensor([
                weights["action"],
                weights["destination"],
                weights["xg"],
                weights["pressing"],
            ]))
            self.log_vars = None

    def forward(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Dict[str, torch.Tensor]:
        """
        Compute all losses.

        Args:
            predictions: Model output dict
            targets: Dict with action_label, destination_label, xg_label

        Returns:
            Dict with total_loss and individual losses
        """
        l_action = self.action_loss(predictions["action_logits"], targets["action_label"])
        l_dest = self.destination_loss(predictions["destination"], targets["destination_label"])
        l_xg = self.xg_loss(predictions["xg"], targets["xg_label"])

        # Pressing label can be derived from features if not explicitly labeled
        l_pressing = torch.tensor(0.0, device=l_action.device)

        if self.log_vars is not None:
            # Uncertainty-based weighting
            precision = torch.exp(-self.log_vars)
            total = (
                precision[0] * l_action + self.log_vars[0]
                + precision[1] * l_dest + self.log_vars[1]
                + precision[2] * l_xg + self.log_vars[2]
                + precision[3] * l_pressing + self.log_vars[3]
            )
        else:
            total = (
                self.weights[0] * l_action
                + self.weights[1] * l_dest
                + self.weights[2] * l_xg
                + self.weights[3] * l_pressing
            )

        return {
            "total_loss": total,
            "action_loss": l_action.detach(),
            "destination_loss": l_dest.detach(),
            "xg_loss": l_xg.detach(),
            "pressing_loss": l_pressing.detach(),
        }
