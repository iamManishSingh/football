"""
Training Script
================
Train the FootballPredictionModel on Metrica tracking data.

Usage:
    python -m training.train \
        --tracking_csv data/metrica/tracking_home.csv \
        --events_csv data/metrica/events.csv \
        --config configs/config.yaml

Training Strategy:
    1. Start with Action Classification head only (simplest task)
    2. Add Destination Heatmap (harder, needs good spatial understanding)
    3. Add xG head (needs shot situations specifically)
    4. Add Pressing head (can be derived from features directly)
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR, LinearLR, SequentialLR
import numpy as np
import yaml
import argparse
from pathlib import Path
from tqdm import tqdm
from loguru import logger
from typing import Dict

from models.prediction_model import FootballPredictionModel
from training.dataset import create_dataloaders
from training.losses import MultiTaskLoss


class Trainer:
    """Full training pipeline."""

    def __init__(self, config: dict, device: str = "cuda:0"):
        self.config = config
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")

        train_config = config["training"]

        # Model
        self.model = FootballPredictionModel(config).to(self.device)
        total_params = sum(p.numel() for p in self.model.parameters())
        logger.info(f"Model parameters: {total_params:,}")

        # Loss
        self.criterion = MultiTaskLoss(config, learnable_weights=True).to(self.device)

        # Optimizer (include loss parameters if learnable)
        all_params = list(self.model.parameters()) + list(self.criterion.parameters())
        self.optimizer = optim.AdamW(
            all_params,
            lr=train_config["learning_rate"],
            weight_decay=train_config["weight_decay"],
        )

        # LR Scheduler: warmup + cosine decay
        warmup_epochs = train_config["warmup_epochs"]
        total_epochs = train_config["epochs"]
        warmup_scheduler = LinearLR(
            self.optimizer, start_factor=0.1, total_iters=warmup_epochs
        )
        cosine_scheduler = CosineAnnealingLR(
            self.optimizer, T_max=total_epochs - warmup_epochs
        )
        self.scheduler = SequentialLR(
            self.optimizer,
            schedulers=[warmup_scheduler, cosine_scheduler],
            milestones=[warmup_epochs],
        )

        self.epochs = total_epochs
        self.best_val_loss = float("inf")
        self.save_dir = Path("checkpoints")
        self.save_dir.mkdir(exist_ok=True)

    def train(self, train_loader, val_loader):
        """Main training loop."""
        logger.info(f"Starting training for {self.epochs} epochs on {self.device}")

        for epoch in range(1, self.epochs + 1):
            # --- Train ---
            train_metrics = self._train_epoch(train_loader, epoch)

            # --- Validate ---
            val_metrics = self._validate(val_loader, epoch)

            # --- LR Step ---
            self.scheduler.step()
            current_lr = self.optimizer.param_groups[0]["lr"]

            # --- Log ---
            logger.info(
                f"Epoch {epoch}/{self.epochs} | "
                f"Train Loss: {train_metrics['total_loss']:.4f} | "
                f"Val Loss: {val_metrics['total_loss']:.4f} | "
                f"Action Acc: {val_metrics.get('action_accuracy', 0):.2%} | "
                f"LR: {current_lr:.6f}"
            )

            # --- Checkpoint ---
            if val_metrics["total_loss"] < self.best_val_loss:
                self.best_val_loss = val_metrics["total_loss"]
                self._save_checkpoint(epoch, val_metrics)
                logger.info(f"  ★ New best model saved (val_loss={self.best_val_loss:.4f})")

    def _train_epoch(self, loader, epoch: int) -> Dict[str, float]:
        """Single training epoch."""
        self.model.train()
        total_losses = {"total_loss": 0, "action_loss": 0, "destination_loss": 0, "xg_loss": 0}
        num_batches = 0

        pbar = tqdm(loader, desc=f"Epoch {epoch} [TRAIN]", leave=False)
        for batch in pbar:
            # Move to device
            player_feat = batch["player_features"].to(self.device)
            ball_feat = batch["ball_features"].to(self.device)
            player_mask = batch["player_mask"].to(self.device)

            targets = {
                "action_label": batch["action_label"].to(self.device),
                "destination_label": batch["destination_label"].to(self.device),
                "xg_label": batch["xg_label"].to(self.device),
            }

            # Forward pass
            predictions = self.model(player_feat, ball_feat, player_mask)

            # Compute loss
            losses = self.criterion(predictions, targets)

            # Backward pass
            self.optimizer.zero_grad()
            losses["total_loss"].backward()

            # Gradient clipping (important for transformers)
            nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

            self.optimizer.step()

            # Accumulate
            for k in total_losses:
                if k in losses:
                    total_losses[k] += losses[k].item()
            num_batches += 1

            pbar.set_postfix(loss=f"{losses['total_loss'].item():.4f}")

        # Average
        return {k: v / max(num_batches, 1) for k, v in total_losses.items()}

    @torch.no_grad()
    def _validate(self, loader, epoch: int) -> Dict[str, float]:
        """Validation pass."""
        self.model.eval()
        total_losses = {"total_loss": 0, "action_loss": 0, "destination_loss": 0, "xg_loss": 0}
        correct_actions = 0
        total_actions = 0
        num_batches = 0

        for batch in tqdm(loader, desc=f"Epoch {epoch} [VAL]", leave=False):
            player_feat = batch["player_features"].to(self.device)
            ball_feat = batch["ball_features"].to(self.device)
            player_mask = batch["player_mask"].to(self.device)

            targets = {
                "action_label": batch["action_label"].to(self.device),
                "destination_label": batch["destination_label"].to(self.device),
                "xg_label": batch["xg_label"].to(self.device),
            }

            predictions = self.model(player_feat, ball_feat, player_mask)
            losses = self.criterion(predictions, targets)

            for k in total_losses:
                if k in losses:
                    total_losses[k] += losses[k].item()

            # Action accuracy
            pred_actions = predictions["action_probs"].argmax(dim=-1)
            correct_actions += (pred_actions == targets["action_label"]).sum().item()
            total_actions += len(targets["action_label"])

            num_batches += 1

        metrics = {k: v / max(num_batches, 1) for k, v in total_losses.items()}
        metrics["action_accuracy"] = correct_actions / max(total_actions, 1)
        return metrics

    def _save_checkpoint(self, epoch: int, metrics: Dict):
        """Save model checkpoint."""
        ckpt = {
            "epoch": epoch,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "metrics": metrics,
            "config": self.config,
        }
        path = self.save_dir / "best_model.pth"
        torch.save(ckpt, path)

        # Also save model weights separately (for inference)
        torch.save(
            self.model.state_dict(),
            self.save_dir / "prediction_model.pth",
        )


def main():
    parser = argparse.ArgumentParser(description="Train Football Prediction Model")
    parser.add_argument("--tracking_csv", required=True, help="Path to tracking CSV")
    parser.add_argument("--events_csv", required=True, help="Path to events CSV")
    parser.add_argument("--config", default="configs/config.yaml", help="Config file")
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()

    # Load config
    with open(args.config) as f:
        config = yaml.safe_load(f)

    # Create data loaders
    train_loader, val_loader = create_dataloaders(
        tracking_csv=args.tracking_csv,
        events_csv=args.events_csv,
        config=config,
    )

    # Train
    trainer = Trainer(config, device=args.device)
    trainer.train(train_loader, val_loader)


if __name__ == "__main__":
    main()
