"""
STEP 6: Prediction Model
==========================
Graph Attention Network + Temporal Transformer with multiple prediction heads.

Architecture:
    1. Player Encoder: MLP to project raw features into hidden space
    2. Spatial Attention (per frame): Multi-head attention across all 22 players
       → captures who is interacting with whom
    3. Frame Pooling: Aggregate player embeddings into a single frame embedding
    4. Temporal Transformer: Model how the game state evolves over N frames
    5. Prediction Heads:
       a) Action Classification → what the ball carrier will do next
       b) Destination Heatmap → where the ball will go on the pitch
       c) xG (Expected Goals) → probability of a goal if a shot is taken
       d) Pressing Score → defensive intensity level

Input:
    player_features: (batch, seq_len, 22, 12)
    ball_features:   (batch, seq_len, 6)
    player_mask:     (batch, seq_len, 22)

Output:
    action_probs:    (batch, 6)         — probability per action class
    destination:     (batch, 105, 68)   — heatmap over pitch
    xg:              (batch, 1)         — goal probability
    pressing:        (batch, 1)         — pressing intensity
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, Tuple


class PlayerEncoder(nn.Module):
    """
    Encodes raw per-player features into a hidden representation.
    Simple MLP with residual connection.
    """

    def __init__(self, input_dim: int = 12, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (batch * seq_len, num_players, input_dim)
        Returns:
            (batch * seq_len, num_players, hidden_dim)
        """
        return self.net(x)


class BallEncoder(nn.Module):
    """Encodes ball features."""

    def __init__(self, input_dim: int = 6, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class SpatialAttention(nn.Module):
    """
    Multi-head attention across players within a single frame.

    This learns which players are interacting with each other:
    - Ball carrier attending to open teammates (for pass prediction)
    - Defenders attending to nearby attackers (for pressing)
    - All players relative to the ball

    Uses a key_padding_mask to handle variable numbers of visible players.
    """

    def __init__(self, hidden_dim: int = 128, num_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.attention = nn.MultiheadAttention(
            embed_dim=hidden_dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True,
        )
        self.norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Args:
            x: (batch * seq_len, num_players, hidden_dim)
            mask: (batch * seq_len, num_players) — True where player is MISSING

        Returns:
            (batch * seq_len, num_players, hidden_dim)
        """
        # Self-attention with residual
        attn_out, _ = self.attention(x, x, x, key_padding_mask=mask)
        x = self.norm(x + self.dropout(attn_out))
        return x


class TemporalTransformer(nn.Module):
    """
    Transformer encoder over the time dimension.
    Each "token" is a frame embedding (aggregated from all players + ball).
    """

    def __init__(
        self,
        hidden_dim: int = 128,
        num_heads: int = 4,
        num_layers: int = 3,
        dropout: float = 0.1,
    ):
        super().__init__()
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=num_heads,
            dim_feedforward=hidden_dim * 4,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        # Learnable positional encoding for temporal positions
        self.pos_encoding = nn.Parameter(torch.randn(1, 100, hidden_dim) * 0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (batch, seq_len, hidden_dim)

        Returns:
            (batch, seq_len, hidden_dim)
        """
        seq_len = x.size(1)
        x = x + self.pos_encoding[:, :seq_len, :]
        return self.transformer(x)


class ActionHead(nn.Module):
    """Predicts the next action: pass, shot, dribble, cross, clearance, through_ball."""

    def __init__(self, hidden_dim: int = 128, num_classes: int = 6):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim // 2, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Returns: (batch, num_classes) — log-probabilities."""
        return self.head(x)


class DestinationHead(nn.Module):
    """
    Predicts WHERE the ball will go next as a probability heatmap over the pitch.
    Output is a (pitch_grid_x, pitch_grid_y) grid — each cell is 1m x 1m.
    """

    def __init__(self, hidden_dim: int = 128, grid_x: int = 105, grid_y: int = 68):
        super().__init__()
        self.grid_x = grid_x
        self.grid_y = grid_y

        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.GELU(),
            nn.Linear(hidden_dim * 2, grid_x * grid_y),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Returns: (batch, grid_x, grid_y) — probability heatmap."""
        logits = self.head(x)
        # Reshape to 2D grid and apply softmax to get a proper probability distribution
        logits = logits.view(-1, self.grid_x, self.grid_y)
        # Softmax over the entire grid (flatten then reshape)
        probs = F.softmax(logits.view(-1, self.grid_x * self.grid_y), dim=-1)
        return probs.view(-1, self.grid_x, self.grid_y)


class XGHead(nn.Module):
    """Predicts expected goals probability (0-1)."""

    def __init__(self, hidden_dim: int = 128):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Returns: (batch, 1) — goal probability."""
        return torch.sigmoid(self.head(x))


class PressingHead(nn.Module):
    """Predicts team pressing intensity (0=low block, 1=high press)."""

    def __init__(self, hidden_dim: int = 128):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 4),
            nn.GELU(),
            nn.Linear(hidden_dim // 4, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Returns: (batch, 1) — pressing intensity."""
        return torch.sigmoid(self.head(x))


# ============================================================
# MAIN MODEL
# ============================================================

class FootballPredictionModel(nn.Module):
    """
    Complete prediction model combining all components.

    Pipeline per forward pass:
        1. Encode each player → hidden representation
        2. Encode ball → hidden representation
        3. Spatial attention across players (per frame)
        4. Pool players + ball into frame embedding
        5. Temporal transformer across frames
        6. Take last frame's embedding → prediction heads
    """

    def __init__(self, config: dict):
        super().__init__()

        model_config = config["model"]
        feat_config = config["features"]

        hidden_dim = model_config["hidden_dim"]
        num_heads = model_config["num_attention_heads"]
        num_layers = model_config["num_transformer_layers"]
        dropout = model_config["dropout"]
        num_actions = model_config["num_action_classes"]
        grid_x = model_config["pitch_grid_x"]
        grid_y = model_config["pitch_grid_y"]

        player_feat_dim = feat_config["player_feature_dim"]
        ball_feat_dim = feat_config["ball_feature_dim"]

        # Encoders
        self.player_encoder = PlayerEncoder(player_feat_dim, hidden_dim)
        self.ball_encoder = BallEncoder(ball_feat_dim, hidden_dim)

        # Spatial attention (player interactions within a frame)
        self.spatial_attention = SpatialAttention(hidden_dim, num_heads, dropout)

        # Frame-level fusion (combine player embeddings + ball)
        self.frame_fusion = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),  # players + ball
            nn.GELU(),
            nn.LayerNorm(hidden_dim),
        )

        # Temporal model
        self.temporal = TemporalTransformer(hidden_dim, num_heads, num_layers, dropout)

        # Prediction heads
        self.action_head = ActionHead(hidden_dim, num_actions)
        self.destination_head = DestinationHead(hidden_dim, grid_x, grid_y)
        self.xg_head = XGHead(hidden_dim)
        self.pressing_head = PressingHead(hidden_dim)

    def forward(
        self,
        player_features: torch.Tensor,
        ball_features: torch.Tensor,
        player_mask: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """
        Full forward pass.

        Args:
            player_features: (B, T, N, F_player) — B=batch, T=seq_len, N=max_players
            ball_features:   (B, T, F_ball)
            player_mask:     (B, T, N) — 1 where player exists, 0 where padding

        Returns:
            Dict with keys: action_probs, destination, xg, pressing
        """
        B, T, N, F_p = player_features.shape

        # --- 1. Encode Players ---
        # Reshape for batch processing: (B*T, N, F_p)
        players = player_features.view(B * T, N, F_p)
        players_encoded = self.player_encoder(players)  # (B*T, N, hidden)

        # --- 2. Spatial Attention ---
        # Create padding mask: True where player is ABSENT
        attn_mask = (player_mask.view(B * T, N) == 0)  # (B*T, N)
        players_attended = self.spatial_attention(players_encoded, mask=attn_mask)  # (B*T, N, hidden)

        # --- 3. Pool Players → frame embedding ---
        # Masked mean pooling (only average over valid players)
        mask_expanded = player_mask.view(B * T, N, 1)  # (B*T, N, 1)
        player_sum = (players_attended * mask_expanded).sum(dim=1)  # (B*T, hidden)
        player_count = mask_expanded.sum(dim=1).clamp(min=1)       # (B*T, 1)
        player_pooled = player_sum / player_count                  # (B*T, hidden)

        # --- 4. Encode Ball ---
        ball = ball_features.view(B * T, -1)
        ball_encoded = self.ball_encoder(ball)  # (B*T, hidden)

        # --- 5. Fuse players + ball into frame embedding ---
        frame_embedding = self.frame_fusion(
            torch.cat([player_pooled, ball_encoded], dim=-1)
        )  # (B*T, hidden)

        # Reshape back to sequence: (B, T, hidden)
        frame_embedding = frame_embedding.view(B, T, -1)

        # --- 6. Temporal Transformer ---
        temporal_out = self.temporal(frame_embedding)  # (B, T, hidden)

        # Take the LAST frame's embedding for prediction
        last_frame = temporal_out[:, -1, :]  # (B, hidden)

        # --- 7. Prediction Heads ---
        action_logits = self.action_head(last_frame)            # (B, num_actions)
        action_probs = F.softmax(action_logits, dim=-1)

        destination = self.destination_head(last_frame)          # (B, 105, 68)
        xg = self.xg_head(last_frame)                           # (B, 1)
        pressing = self.pressing_head(last_frame)                # (B, 1)

        return {
            "action_logits": action_logits,
            "action_probs": action_probs,
            "destination": destination,
            "xg": xg,
            "pressing": pressing,
        }


# ============================================================
# INFERENCE WRAPPER
# ============================================================

class PredictionEngine:
    """
    Wraps the model for easy inference from numpy arrays.
    """

    def __init__(self, config: dict, device: str = "cuda:0"):
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.model = FootballPredictionModel(config).to(self.device)
        self.model.eval()

        # Load checkpoint if exists
        ckpt_path = config["model"].get("checkpoint_path")
        if ckpt_path:
            try:
                state_dict = torch.load(ckpt_path, map_location=self.device)
                self.model.load_state_dict(state_dict)
                print(f"Loaded checkpoint from {ckpt_path}")
            except FileNotFoundError:
                print(f"No checkpoint found at {ckpt_path}, using random weights")

    @torch.no_grad()
    def predict(self, sequence: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """
        Run prediction on a single sequence.

        Args:
            sequence: Dict from SequenceBuilder.get_sequence()
                - player_features: (seq_len, max_players, 12)
                - ball_features: (seq_len, 6)
                - player_mask: (seq_len, max_players)

        Returns:
            Dict with numpy arrays:
                - action_probs: (6,) probability per action
                - destination: (105, 68) heatmap
                - xg: float
                - pressing: float
        """
        # Add batch dimension
        player_feat = torch.tensor(sequence["player_features"]).unsqueeze(0).to(self.device)
        ball_feat = torch.tensor(sequence["ball_features"]).unsqueeze(0).to(self.device)
        player_mask = torch.tensor(sequence["player_mask"]).unsqueeze(0).to(self.device)

        outputs = self.model(player_feat, ball_feat, player_mask)

        return {
            "action_probs": outputs["action_probs"][0].cpu().numpy(),
            "destination": outputs["destination"][0].cpu().numpy(),
            "xg": float(outputs["xg"][0].cpu().numpy()),
            "pressing": float(outputs["pressing"][0].cpu().numpy()),
        }
