"""
============================================================
  EXTRACT GAME STATES FROM YOUR FOOTBALL VIDEO
  (Simple Step-by-Step Version)
============================================================

Think of it like a FACTORY ASSEMBLY LINE:

  Video Frame
      │
      ▼
  ┌─────────┐    "Where are the players and ball?"
  │ DETECT   │──► Bounding boxes for each player + ball
  └────┬─────┘
       ▼
  ┌─────────┐    "Which player is which across frames?"
  │ TRACK    │──► Same player gets same ID (Player #5 stays #5)
  └────┬─────┘
       ▼
  ┌─────────┐    "Where on the REAL pitch are they?"
  │ MAP      │──► Pixel (400,300) → Pitch (52m, 34m)
  └────┬─────┘
       ▼
  ┌─────────┐    "Which team does each player belong to?"
  │ TEAMS    │──► Player #5 = Team A (red jersey)
  └────┬─────┘
       ▼
  ┌─────────┐    "What's the full game situation right now?"
  │ FEATURES │──► [positions, speeds, distances, who has ball...]
  └────┬─────┘
       ▼
  📦 GAME STATE  ← This is what the prediction model eats!

============================================================
BEFORE RUNNING: Replace the model loading with YOUR models.
Look for 🔧 markers below.
============================================================

Usage:
    python simple_extract.py --video match.mp4 --output game_states.npz
"""

import cv2
import numpy as np
from collections import defaultdict
from pathlib import Path
from tqdm import tqdm
import json
import argparse


# ============================================================
# 🔧 STEP 1: LOAD YOUR MODELS
# ============================================================
# Replace these with YOUR actual model imports

def load_player_ball_detector():
    """
    🔧 Load YOUR RF-DETR model here.

    Example with rfdetr package:
        from rfdetr import RFDETRBase
        model = RFDETRBase()
        model.load("weights/rfdetr_football.pt")
        return model

    Example with Hugging Face:
        from transformers import RTDetrForObjectDetection
        model = RTDetrForObjectDetection.from_pretrained("your_model")
        return model
    """
    # UNCOMMENT AND MODIFY for your model:
    # from rfdetr import RFDETRBase
    # model = RFDETRBase()
    # model.load("weights/rfdetr_football.pt")
    # return model

    print("⚠️  Using DUMMY detector. Replace with your RF-DETR model!")
    return None


def load_pitch_detector():
    """
    🔧 Load YOUR YOLO pitch detection model here.

    Example:
        from ultralytics import YOLO
        model = YOLO("weights/yolo_pitch.pt")
        return model
    """
    # UNCOMMENT AND MODIFY for your model:
    # from ultralytics import YOLO
    # model = YOLO("weights/yolo_pitch.pt")
    # return model

    print("⚠️  Using DUMMY pitch detector. Replace with your YOLO model!")
    return None


# ============================================================
# STEP 1: DETECT — Find players, ball, and pitch in each frame
# ============================================================

def detect_players_and_ball(model, frame):
    """
    Run RF-DETR on one frame.

    Returns a list of detections, each is a dict:
    {
        "bbox": [x1, y1, x2, y2],      ← bounding box corners
        "class": "player" or "ball",     ← what was detected
        "confidence": 0.92               ← how sure the model is
    }
    """

    # ====================================================
    # 🔧 REPLACE THIS BLOCK WITH YOUR RF-DETR INFERENCE
    # ====================================================
    #
    # --- Option A: rfdetr package ---
    # results = model.predict(frame, threshold=0.5)
    # detections = []
    # for i in range(len(results.xyxy)):
    #     cls_id = int(results.class_id[i])
    #     detections.append({
    #         "bbox": results.xyxy[i].tolist(),    # [x1, y1, x2, y2]
    #         "class": "player" if cls_id == 0 else "ball" if cls_id == 1 else "other",
    #         "confidence": float(results.confidence[i]),
    #     })
    # return detections
    #
    # --- Option B: Using supervision library ---
    # import supervision as sv
    # results = model(frame)
    # detections = sv.Detections.from_...(results)
    # ... convert to our dict format
    #
    # ====================================================

    # DUMMY: returns empty (replace with above)
    return []


def detect_pitch_keypoints(model, frame):
    """
    Run YOLO pitch model on one frame.

    Returns a list of keypoints, each is a dict:
    {
        "name": "top_left_corner",   ← which pitch marking
        "x": 150.5,                  ← pixel x
        "y": 200.3,                  ← pixel y
        "confidence": 0.85
    }
    """

    # ====================================================
    # 🔧 REPLACE THIS BLOCK WITH YOUR YOLO PITCH INFERENCE
    # ====================================================
    #
    # --- If your YOLO detects keypoints as bounding boxes ---
    # results = model(frame, conf=0.3)
    # keypoints = []
    # KEYPOINT_NAMES = ["top_left_corner", "top_right_corner", ...]  # match your model
    # for box in results[0].boxes:
    #     cls_id = int(box.cls)
    #     cx = float((box.xyxy[0][0] + box.xyxy[0][2]) / 2)  # center x
    #     cy = float((box.xyxy[0][1] + box.xyxy[0][3]) / 2)  # center y
    #     keypoints.append({
    #         "name": KEYPOINT_NAMES[cls_id],
    #         "x": cx,
    #         "y": cy,
    #         "confidence": float(box.conf),
    #     })
    # return keypoints
    #
    # --- If your YOLO is a keypoint/pose model ---
    # results = model(frame, conf=0.3)
    # kps = results[0].keypoints.xy[0]  # shape (N, 2)
    # confs = results[0].keypoints.conf[0]  # shape (N,)
    # keypoints = []
    # for i, name in enumerate(KEYPOINT_NAMES):
    #     if confs[i] > 0.3:
    #         keypoints.append({"name": name, "x": float(kps[i][0]),
    #                           "y": float(kps[i][1]), "confidence": float(confs[i])})
    # return keypoints
    #
    # ====================================================

    # DUMMY: returns empty
    return []


# ============================================================
# STEP 2: TRACK — Give each player a consistent ID across frames
# ============================================================

def setup_tracker():
    """
    Set up ByteTrack tracker using the supervision library.
    This makes sure Player #5 in frame 1 is still Player #5 in frame 100.
    """
    import supervision as sv

    tracker = sv.ByteTrack(
        track_activation_threshold=0.25,
        lost_track_buffer=30,
        minimum_matching_threshold=0.8,
        minimum_consecutive_frames=3,
    )
    return tracker


def track_detections(tracker, detections):
    """
    Take this frame's detections and update the tracker.

    Input:  List of {"bbox": [x1,y1,x2,y2], "class": "player", "confidence": 0.9}
    Output: List of {"bbox": ..., "class": ..., "track_id": 5}  ← now has persistent ID!
    """
    import supervision as sv

    players = [d for d in detections if d["class"] == "player"]
    balls = [d for d in detections if d["class"] == "ball"]

    tracked_result = []

    if players:
        xyxy = np.array([p["bbox"] for p in players])
        confidence = np.array([p["confidence"] for p in players])

        sv_dets = sv.Detections(
            xyxy=xyxy,
            confidence=confidence,
            class_id=np.zeros(len(players), dtype=int),
        )

        tracked = tracker.update_with_detections(sv_dets)

        for i in range(len(tracked)):
            tracked_result.append({
                "bbox": tracked.xyxy[i].tolist(),
                "class": "player",
                "confidence": float(tracked.confidence[i]),
                "track_id": int(tracked.tracker_id[i]),
            })

    if balls:
        best_ball = max(balls, key=lambda b: b["confidence"])
        best_ball["track_id"] = -1
        tracked_result.append(best_ball)

    return tracked_result


# ============================================================
# STEP 3: MAP — Convert pixel positions to real pitch coordinates
# ============================================================

# 🔧 These are the REAL positions on a football pitch (in meters).
#    You MUST update these to match whatever keypoints YOUR YOLO model detects.
REAL_PITCH_POINTS = {
    "top_left_corner":     [0.0, 0.0],
    "top_right_corner":    [105.0, 0.0],
    "bottom_left_corner":  [0.0, 68.0],
    "bottom_right_corner": [105.0, 68.0],
    "center_circle_top":   [52.5, 24.85],
    "center_circle_bottom":[52.5, 43.15],
    "left_penalty_top":    [16.5, 13.84],
    "left_penalty_bottom": [16.5, 54.16],
    "right_penalty_top":   [88.5, 13.84],
    "right_penalty_bottom":[88.5, 54.16],
}


def compute_homography(pitch_keypoints):
    """
    Compute the "magic matrix" that converts pixel coords → pitch coords.

    Think of it like this:
        You know a certain pixel in the image = the corner flag of the pitch
        (which is at 0m, 0m in real life). If you know 4+ such correspondences,
        you can figure out where ANY pixel on the pitch is in real meters.

    Returns:
        H: 3x3 matrix, or None if not enough keypoints
    """
    pixel_points = []
    real_points = []

    for kp in pitch_keypoints:
        if kp["name"] in REAL_PITCH_POINTS:
            pixel_points.append([kp["x"], kp["y"]])
            real_points.append(REAL_PITCH_POINTS[kp["name"]])

    if len(pixel_points) < 4:
        return None  # Need at least 4 points!

    pixel_points = np.float32(pixel_points)
    real_points = np.float32(real_points)

    H, _ = cv2.findHomography(pixel_points, real_points, cv2.RANSAC, 5.0)
    return H


def pixel_to_pitch(pixel_x, pixel_y, H):
    """
    Convert a single pixel coordinate to pitch meters.

    Example:
        pixel (400, 300) → pitch (52.5m, 34.0m) = center of the pitch!
    """
    if H is None:
        return None, None

    pt = np.float32([[[pixel_x, pixel_y]]])
    transformed = cv2.perspectiveTransform(pt, H)
    pitch_x = float(np.clip(transformed[0][0][0], 0, 105))
    pitch_y = float(np.clip(transformed[0][0][1], 0, 68))
    return pitch_x, pitch_y


def get_foot_position(bbox):
    """
    Get the bottom-center of a bounding box = where the player's FEET are.
    This is much more accurate for pitch mapping than the center of the box.
    """
    x1, y1, x2, y2 = bbox
    foot_x = (x1 + x2) / 2   # Horizontal center
    foot_y = y2               # Bottom edge = feet
    return foot_x, foot_y


# ============================================================
# STEP 4: TEAMS — Figure out which team each player is on
# ============================================================

def classify_teams(frame, tracked_objects):
    """
    Separate players into 2 teams based on jersey color.

    How it works:
    1. For each player, crop the TORSO region (skip head and legs)
    2. Get the average color of the torso
    3. Use KMeans (k=2) to split all players into 2 color groups
    """
    from sklearn.cluster import KMeans

    players = [t for t in tracked_objects if t["class"] == "player"]
    if len(players) < 2:
        return {}

    colors = []
    valid_track_ids = []

    for player in players:
        x1, y1, x2, y2 = [int(c) for c in player["bbox"]]
        h, w = frame.shape[:2]
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(w, x2), min(h, y2)

        if x2 <= x1 or y2 <= y1:
            continue

        bbox_h = y2 - y1
        torso_y1 = y1 + int(bbox_h * 0.2)   # Skip head
        torso_y2 = y2 - int(bbox_h * 0.3)   # Skip legs

        if torso_y2 <= torso_y1:
            continue

        torso = frame[torso_y1:torso_y2, x1:x2]
        if torso.size == 0:
            continue

        torso_hsv = cv2.cvtColor(torso, cv2.COLOR_BGR2HSV)
        avg_color = torso_hsv.mean(axis=(0, 1))

        colors.append(avg_color)
        valid_track_ids.append(player["track_id"])

    if len(colors) < 2:
        return {}

    kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
    labels = kmeans.fit_predict(np.array(colors))

    return {tid: int(label) for tid, label in zip(valid_track_ids, labels)}


# ============================================================
# STEP 5: FEATURES — Build the game state from all the above
# ============================================================

def build_game_state(tracked_objects, team_map, H, prev_positions, dt):
    """
    Build the complete GAME STATE for one frame.

    This is what the prediction model needs.

    Returns:
        dict with player_features (22, 12), ball_features (6,), player_mask (22,)
    """
    if H is None:
        return None

    players = [t for t in tracked_objects if t["class"] == "player"]
    balls = [t for t in tracked_objects if t["class"] == "ball"]

    # --- Ball position ---
    ball_x, ball_y = 52.5, 34.0  # Default: center
    if balls:
        bx, by = get_foot_position(balls[0]["bbox"])
        result = pixel_to_pitch(bx, by, H)
        if result[0] is not None:
            ball_x, ball_y = result

    # --- Process each player ---
    player_data = []

    for player in players:
        track_id = player["track_id"]
        team_id = team_map.get(track_id, 0)

        foot_x, foot_y = get_foot_position(player["bbox"])
        pitch_x, pitch_y = pixel_to_pitch(foot_x, foot_y, H)

        if pitch_x is None:
            continue

        # Velocity
        vx, vy = 0.0, 0.0
        if track_id in prev_positions:
            old_x, old_y = prev_positions[track_id]
            vx = (pitch_x - old_x) / dt
            vy = (pitch_y - old_y) / dt

        dist_to_ball = np.sqrt((pitch_x - ball_x)**2 + (pitch_y - ball_y)**2)

        goal_x = 105.0 if team_id == 0 else 0.0
        goal_y = 34.0
        dist_to_goal = np.sqrt((pitch_x - goal_x)**2 + (pitch_y - goal_y)**2)
        angle = np.degrees(np.arctan2(abs(pitch_y - goal_y), abs(pitch_x - goal_x)))

        is_ball_carrier = 1.0 if dist_to_ball < 3.0 else 0.0

        prev_positions[track_id] = (pitch_x, pitch_y)

        player_data.append({
            "track_id": track_id, "team_id": team_id,
            "pitch_x": pitch_x, "pitch_y": pitch_y,
            "vx": vx, "vy": vy,
            "dist_to_ball": dist_to_ball, "dist_to_goal": dist_to_goal,
            "angle_to_goal": angle, "is_ball_carrier": is_ball_carrier,
        })

    # --- Nearest opponent ---
    for i, p in enumerate(player_data):
        nearest = 100.0
        for q in player_data:
            if q["team_id"] != p["team_id"]:
                d = np.sqrt((p["pitch_x"] - q["pitch_x"])**2 + (p["pitch_y"] - q["pitch_y"])**2)
                nearest = min(nearest, d)
        player_data[i]["nearest_opp"] = nearest

    # --- Build tensor ---
    MAX_PLAYERS = 22
    feature_tensor = np.zeros((MAX_PLAYERS, 12), dtype=np.float32)
    player_mask = np.zeros(MAX_PLAYERS, dtype=np.float32)

    for i, p in enumerate(player_data[:MAX_PLAYERS]):
        player_mask[i] = 1.0
        feature_tensor[i] = [
            p["pitch_x"] / 105.0,   p["pitch_y"] / 68.0,
            p["vx"] / 10.0,         p["vy"] / 10.0,
            0.0,                     0.0,
            p["dist_to_ball"] / 125.0, p["dist_to_goal"] / 125.0,
            p["angle_to_goal"] / 180.0, p["nearest_opp"] / 50.0,
            p["is_ball_carrier"],    float(p["team_id"]),
        ]

    ball_features = np.array([
        ball_x / 105.0, ball_y / 68.0,
        0.0, 0.0, 0.0, 0.0,
    ], dtype=np.float32)

    return {
        "player_features": feature_tensor,
        "ball_features": ball_features,
        "player_mask": player_mask,
        "ball_position": (ball_x, ball_y),
        "player_data": player_data,
    }


# ============================================================
# 🚀 MAIN: Run everything on your video
# ============================================================

def extract_game_states(video_path, output_path="game_states.npz"):
    print("=" * 60)
    print("  FOOTBALL GAME STATE EXTRACTION")
    print("=" * 60)

    print("\n📦 Loading models...")
    player_ball_model = load_player_ball_detector()
    pitch_model = load_pitch_detector()

    print("🔗 Setting up tracker...")
    tracker = setup_tracker()

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    dt = 1.0 / fps

    print(f"🎥 Video: {video_path}")
    print(f"   FPS: {fps}, Total frames: {total_frames}")

    all_states = []
    prev_positions = {}
    team_map = {}
    last_H = None

    print(f"\n🏃 Processing {total_frames} frames...\n")

    for frame_id in tqdm(range(total_frames), desc="Extracting"):
        ret, frame = cap.read()
        if not ret:
            break

        # STEP 1: Detect
        detections = detect_players_and_ball(player_ball_model, frame)
        keypoints = detect_pitch_keypoints(pitch_model, frame)

        # STEP 2: Track
        tracked = track_detections(tracker, detections)

        # STEP 3: Homography
        H = compute_homography(keypoints)
        if H is not None:
            last_H = H
        else:
            H = last_H

        # STEP 4: Teams (every 30 frames)
        if frame_id % 30 == 0 and len(tracked) > 2:
            team_map = classify_teams(frame, tracked)

        # STEP 5: Game State
        state = build_game_state(tracked, team_map, H, prev_positions, dt)
        if state is not None:
            all_states.append({
                "frame_id": frame_id,
                "player_features": state["player_features"],
                "ball_features": state["ball_features"],
                "player_mask": state["player_mask"],
            })

    cap.release()

    # Save
    print(f"\n💾 Saving {len(all_states)} game states...")

    player_features = np.stack([s["player_features"] for s in all_states])
    ball_features = np.stack([s["ball_features"] for s in all_states])
    player_masks = np.stack([s["player_mask"] for s in all_states])
    frame_ids = np.array([s["frame_id"] for s in all_states])

    np.savez_compressed(output_path,
        player_features=player_features,
        ball_features=ball_features,
        player_masks=player_masks,
        frame_ids=frame_ids,
        fps=np.array([fps]),
    )

    print(f"\n✅ DONE! Saved to {output_path}")
    print(f"   Shapes: players={player_features.shape}, ball={ball_features.shape}")


# ============================================================
# INSPECT SAVED DATA
# ============================================================

def inspect_game_states(npz_path):
    data = np.load(npz_path)
    print(f"\n📊 Inspecting {npz_path}:")
    print(f"   Frames: {len(data['frame_ids'])}")
    print(f"   Player features: {data['player_features'].shape}")
    print(f"   Ball features:   {data['ball_features'].shape}")

    idx = len(data['frame_ids']) // 2
    pf = data['player_features'][idx]
    bf = data['ball_features'][idx]
    mask = data['player_masks'][idx]

    print(f"\n   Sample frame {data['frame_ids'][idx]}:")
    print(f"     Visible players: {int(mask.sum())}")
    print(f"     Ball: ({bf[0]*105:.1f}m, {bf[1]*68:.1f}m)")
    if mask[0]:
        print(f"     Player 0: ({pf[0,0]*105:.1f}m, {pf[0,1]*68:.1f}m), "
              f"team={int(pf[0,11])}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--output", default="game_states.npz")
    parser.add_argument("--inspect", action="store_true")
    args = parser.parse_args()

    if args.inspect:
        inspect_game_states(args.output)
    else:
        extract_game_states(args.video, args.output)
        inspect_game_states(args.output)
