# Football Analytics - Prediction Pipeline

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        VIDEO INPUT                              │
│                    (frame by frame)                              │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  STEP 1: DETECTION LAYER                                        │
│  ┌──────────────────┐    ┌──────────────────────┐               │
│  │  RF-DETR          │    │  YOLO (fine-tuned)    │              │
│  │  → Players        │    │  → Pitch keypoints    │              │
│  │  → Ball           │    │                       │              │
│  └──────────────────┘    └──────────────────────┘               │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  STEP 2: TRACKING (ByteTrack)                                   │
│  → Assign persistent IDs to each player across frames           │
│  → Track ball trajectory                                        │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  STEP 3: HOMOGRAPHY (Pitch Keypoints → Bird's Eye View)         │
│  → Map pixel coordinates to real pitch coordinates (0-105m)     │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  STEP 4: TEAM CLASSIFICATION (KMeans on jersey color)           │
│  → Assign each player to Team A or Team B                       │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  STEP 5: FEATURE ENGINEERING                                    │
│  → Build GameState per frame (positions, velocities, context)   │
│  → Create sliding windows of N frames                           │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  STEP 6: PREDICTION MODEL (GNN + Transformer)                   │
│  → Action Classification (pass/shot/dribble/cross)              │
│  → Destination Heatmap (where ball goes next)                   │
│  → xG (expected goal probability)                               │
│  → Pressing Intensity                                           │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│  STEP 7: VISUALIZATION                                          │
│  → Overlay predictions on video                                 │
│  → Heatmaps, action labels, pressing arrows                     │
└──────────────────────────────────────────────────────────────────┘
```

## Project Structure

```
football_analytics/
├── configs/
│   └── config.yaml              # All hyperparameters
├── pipeline/
│   ├── step1_detection.py       # RF-DETR + YOLO inference
│   ├── step2_tracking.py        # ByteTrack integration
│   ├── step3_homography.py      # Pitch mapping
│   ├── step4_team_classify.py   # Jersey color clustering
│   ├── step5_features.py        # Game state extraction
│   └── step6_prediction.py      # Model inference
├── models/
│   └── prediction_model.py      # GNN + Transformer architecture
├── training/
│   ├── dataset.py               # Data loading
│   ├── train.py                 # Training loop
│   └── losses.py                # Custom losses
├── utils/
│   ├── geometry.py              # Homography, distance calcs
│   └── constants.py             # Pitch dimensions etc.
├── visualization/
│   └── overlay.py               # Draw predictions on frames
├── run_pipeline.py              # Main entry point
└── requirements.txt
```

## Quick Start

```bash
pip install -r requirements.txt
python run_pipeline.py --video input.mp4 --output output.mp4
```
