"""
Constants used throughout the football analytics pipeline.
"""

# ============================================================
# Pitch Dimensions (FIFA Standard, in meters)
# ============================================================
PITCH_LENGTH = 105.0
PITCH_WIDTH = 68.0
PENALTY_AREA_LENGTH = 16.5
PENALTY_AREA_WIDTH = 40.32
GOAL_AREA_LENGTH = 5.5
GOAL_AREA_WIDTH = 18.32
CENTER_CIRCLE_RADIUS = 9.15
PENALTY_SPOT_DISTANCE = 11.0
GOAL_WIDTH = 7.32
GOAL_HEIGHT = 2.44

# Goal positions (center of each goal)
LEFT_GOAL_CENTER = (0.0, PITCH_WIDTH / 2)      # (0, 34)
RIGHT_GOAL_CENTER = (PITCH_LENGTH, PITCH_WIDTH / 2)  # (105, 34)

# ============================================================
# Action Classes
# ============================================================
ACTION_CLASSES = {
    0: "pass",
    1: "shot",
    2: "dribble",
    3: "cross",
    4: "clearance",
    5: "through_ball",
}
ACTION_TO_IDX = {v: k for k, v in ACTION_CLASSES.items()}
NUM_ACTIONS = len(ACTION_CLASSES)

# ============================================================
# Detection Classes (match your RF-DETR model)
# ============================================================
DETECTION_CLASSES = {
    0: "player",
    1: "ball",
    2: "referee",
    3: "goalkeeper",
}

# ============================================================
# Pitch Zones (for contextual features)
# ============================================================
# Divide pitch into 6 zones
ZONES = {
    "defensive_third_left":  (0, 0, 35, 68),
    "middle_third":          (35, 0, 70, 68),
    "attacking_third_right": (70, 0, 105, 68),
}

# ============================================================
# Feature Dimensions
# ============================================================
# Per player: x, y, vx, vy, ax, ay, dist_ball, dist_goal, angle_goal,
#             nearest_opp_dist, is_ball_carrier, team_id
PLAYER_FEATURE_DIM = 12

# Ball: x, y, vx, vy, possession_team, speed
BALL_FEATURE_DIM = 6

# ============================================================
# Pressing Thresholds
# ============================================================
PRESSING_DISTANCE_THRESHOLD = 5.0   # meters — if defender within 5m of ball carrier
HIGH_PRESS_LINE = 70.0              # If defensive line > 70m from own goal = high press
LOW_BLOCK_LINE = 35.0               # If defensive line < 35m = low block
