"""
Geometry utilities: homography computation, coordinate transforms,
distance and angle calculations.
"""

import numpy as np
import cv2
from typing import Tuple, List, Optional


def compute_homography(
    src_points: np.ndarray,
    dst_points: np.ndarray,
) -> Optional[np.ndarray]:
    """
    Compute homography matrix from source (pixel) to destination (pitch) points.

    Args:
        src_points: (N, 2) array of pixel coordinates from pitch keypoint detection
        dst_points: (N, 2) array of real-world pitch coordinates in meters

    Returns:
        3x3 homography matrix, or None if computation fails

    Example:
        # Pixel coordinates from your YOLO pitch detector
        src = np.array([[100, 200], [1800, 200], [100, 900], [1800, 900]])
        # Real-world coordinates (meters)
        dst = np.array([[0, 0], [105, 0], [0, 68], [105, 68]])
        H = compute_homography(src, dst)
    """
    if len(src_points) < 4:
        print(f"WARNING: Need at least 4 points for homography, got {len(src_points)}")
        return None

    src_points = np.float32(src_points)
    dst_points = np.float32(dst_points)

    # Use RANSAC for robustness against outlier keypoints
    H, mask = cv2.findHomography(src_points, dst_points, cv2.RANSAC, 5.0)

    if H is None:
        print("WARNING: Homography computation failed")
        return None

    # Validate: check that the homography is not degenerate
    det = np.linalg.det(H)
    if abs(det) < 1e-6:
        print("WARNING: Degenerate homography matrix (det ≈ 0)")
        return None

    return H


def pixel_to_pitch(
    pixel_coords: np.ndarray,
    homography: np.ndarray,
) -> np.ndarray:
    """
    Transform pixel coordinates to pitch coordinates using homography.

    Args:
        pixel_coords: (N, 2) array of pixel (x, y) coordinates
        homography: 3x3 homography matrix

    Returns:
        (N, 2) array of pitch coordinates in meters
    """
    if len(pixel_coords) == 0:
        return np.array([]).reshape(0, 2)

    pixel_coords = np.float32(pixel_coords)

    # Convert to homogeneous coordinates: (N, 2) -> (N, 1, 2)
    pts = pixel_coords.reshape(-1, 1, 2)

    # Apply homography
    transformed = cv2.perspectiveTransform(pts, homography)

    return transformed.reshape(-1, 2)


def pitch_to_pixel(
    pitch_coords: np.ndarray,
    homography: np.ndarray,
) -> np.ndarray:
    """
    Transform pitch coordinates back to pixel coordinates (inverse homography).

    Args:
        pitch_coords: (N, 2) array of pitch coordinates in meters
        homography: 3x3 homography matrix (pixel → pitch)

    Returns:
        (N, 2) array of pixel coordinates
    """
    H_inv = np.linalg.inv(homography)
    return pixel_to_pitch(pitch_coords, H_inv)


def get_foot_point(bbox: np.ndarray) -> np.ndarray:
    """
    Get the bottom-center of a bounding box (approximate foot position).
    This is a better point to project than the center of the bbox.

    Args:
        bbox: (x1, y1, x2, y2) bounding box

    Returns:
        (x, y) foot point coordinates
    """
    x1, y1, x2, y2 = bbox
    return np.array([(x1 + x2) / 2, y2])


def euclidean_distance(p1: np.ndarray, p2: np.ndarray) -> float:
    """Euclidean distance between two 2D points."""
    return float(np.linalg.norm(np.array(p1) - np.array(p2)))


def angle_to_goal(
    player_pos: np.ndarray,
    goal_center: Tuple[float, float] = (105.0, 34.0),
) -> float:
    """
    Compute angle (in degrees) from player position to goal center.

    Args:
        player_pos: (x, y) on pitch in meters
        goal_center: (x, y) of goal center

    Returns:
        Angle in degrees [0, 180]
    """
    dx = goal_center[0] - player_pos[0]
    dy = goal_center[1] - player_pos[1]
    return float(np.degrees(np.arctan2(abs(dy), abs(dx))))


def compute_velocity(
    positions: np.ndarray,
    dt: float = 1.0 / 30.0,
) -> np.ndarray:
    """
    Compute velocity from position sequence using finite differences.

    Args:
        positions: (T, 2) array of (x, y) positions over T frames
        dt: time between frames (1/fps)

    Returns:
        (T, 2) array of (vx, vy) velocities. First frame velocity = 0.
    """
    if len(positions) < 2:
        return np.zeros_like(positions)

    velocities = np.zeros_like(positions)
    velocities[1:] = (positions[1:] - positions[:-1]) / dt

    # Smooth with simple moving average to reduce noise
    if len(velocities) >= 3:
        kernel = np.ones(3) / 3
        for dim in range(2):
            velocities[:, dim] = np.convolve(velocities[:, dim], kernel, mode='same')

    return velocities


def compute_acceleration(
    velocities: np.ndarray,
    dt: float = 1.0 / 30.0,
) -> np.ndarray:
    """
    Compute acceleration from velocity sequence.

    Args:
        velocities: (T, 2) array of (vx, vy)
        dt: time between frames

    Returns:
        (T, 2) array of (ax, ay)
    """
    if len(velocities) < 2:
        return np.zeros_like(velocities)

    acc = np.zeros_like(velocities)
    acc[1:] = (velocities[1:] - velocities[:-1]) / dt
    return acc


def compute_speed(velocities: np.ndarray) -> np.ndarray:
    """Compute speed (scalar) from velocity vectors."""
    return np.linalg.norm(velocities, axis=-1)


def find_nearest_opponent(
    player_pos: np.ndarray,
    opponent_positions: np.ndarray,
) -> Tuple[float, int]:
    """
    Find the nearest opponent to a player.

    Args:
        player_pos: (2,) position of the player
        opponent_positions: (N, 2) positions of all opponents

    Returns:
        (distance, index) of nearest opponent
    """
    if len(opponent_positions) == 0:
        return 100.0, -1  # No opponents visible

    distances = np.linalg.norm(opponent_positions - player_pos, axis=1)
    nearest_idx = int(np.argmin(distances))
    return float(distances[nearest_idx]), nearest_idx


def point_in_zone(
    pos: np.ndarray,
    zone: Tuple[float, float, float, float],
) -> bool:
    """Check if a point is inside a rectangular zone (x1, y1, x2, y2)."""
    x, y = pos
    x1, y1, x2, y2 = zone
    return x1 <= x <= x2 and y1 <= y <= y2


def compute_convex_hull_area(positions: np.ndarray) -> float:
    """
    Compute the area of the convex hull of a set of positions.
    Useful for measuring team compactness.
    """
    if len(positions) < 3:
        return 0.0
    from scipy.spatial import ConvexHull
    try:
        hull = ConvexHull(positions)
        return float(hull.volume)  # In 2D, 'volume' = area
    except Exception:
        return 0.0
