"""
Main Pipeline Runner
======================
Processes a football video through the complete pipeline:
    Step 1: Detection (RF-DETR + YOLO)
    Step 2: Tracking (ByteTrack)
    Step 3: Homography (pixel → pitch coordinates)
    Step 4: Team Classification (jersey color)
    Step 5: Feature Engineering (game state tensors)
    Step 6: Prediction (GNN + Transformer model)
    Step 7: Visualization (overlay on video)

Usage:
    python run_pipeline.py --video input.mp4 --output output.mp4 --config configs/config.yaml
"""

import cv2
import yaml
import argparse
import numpy as np
from pathlib import Path
from tqdm import tqdm
from loguru import logger

# Pipeline steps
from pipeline.step1_detection import DetectionPipeline
from pipeline.step2_tracking import MultiObjectTracker
from pipeline.step3_homography import HomographyEstimator
from pipeline.step4_team_classify import TeamClassifier
from pipeline.step5_features import FeatureExtractor, SequenceBuilder
from models.prediction_model import PredictionEngine
from visualization.overlay import PredictionVisualizer


class FootballAnalyticsPipeline:
    """
    Complete end-to-end pipeline for football video analytics.
    """

    def __init__(self, config_path: str):
        # Load config
        with open(config_path) as f:
            self.config = yaml.safe_load(f)

        logger.info("=" * 60)
        logger.info("Initializing Football Analytics Pipeline")
        logger.info("=" * 60)

        # Initialize all pipeline components
        self.detector = DetectionPipeline(self.config)
        self.tracker = MultiObjectTracker(self.config)
        self.homography = HomographyEstimator(self.config)
        self.team_classifier = TeamClassifier(self.config)
        self.feature_extractor = FeatureExtractor(self.config)
        self.sequence_builder = SequenceBuilder(self.config)
        self.prediction_engine = PredictionEngine(self.config)
        self.visualizer = PredictionVisualizer(self.config)

        logger.info("All components initialized ✓")

    def process_video(self, video_path: str, output_path: str):
        """
        Process a complete video file.

        Args:
            video_path: Path to input video
            output_path: Path to output annotated video
        """
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise ValueError(f"Cannot open video: {video_path}")

        # Video properties
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        logger.info(f"Video: {video_path}")
        logger.info(f"  Resolution: {width}x{height} @ {fps}fps")
        logger.info(f"  Total frames: {total_frames}")

        # Output writer
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        # Process frame by frame
        pbar = tqdm(total=total_frames, desc="Processing")
        frame_id = 0

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            # Process single frame
            annotated_frame = self.process_frame(frame, frame_id)

            # Write output
            writer.write(annotated_frame)

            frame_id += 1
            pbar.update(1)

        pbar.close()
        cap.release()
        writer.release()

        logger.info(f"Output saved to: {output_path}")

    def process_frame(self, frame: np.ndarray, frame_id: int) -> np.ndarray:
        """
        Process a single frame through the complete pipeline.

        This is the CORE METHOD that chains all steps together.

        Args:
            frame: BGR image (H, W, 3)
            frame_id: Frame index

        Returns:
            Annotated frame with prediction overlays
        """
        # ============================================================
        # STEP 1: Detection
        # ============================================================
        detection_result = self.detector.process_frame(frame, frame_id)

        # ============================================================
        # STEP 2: Tracking
        # ============================================================
        tracking_result = self.tracker.update(detection_result)

        # ============================================================
        # STEP 3: Homography (pixel → pitch coordinates)
        # ============================================================
        tracking_result = self.homography.transform_tracking_result(
            tracking_result, detection_result.pitch_keypoints
        )

        # ============================================================
        # STEP 4: Team Classification
        # ============================================================
        tracking_result = self.team_classifier.classify(frame, tracking_result)

        # ============================================================
        # STEP 5: Feature Engineering
        # ============================================================
        game_state = self.feature_extractor.update(tracking_result)

        if game_state is None:
            # Not enough frames buffered yet
            return frame

        self.sequence_builder.add_state(game_state)

        # ============================================================
        # STEP 6: Prediction
        # ============================================================
        predictions = None
        if self.sequence_builder.is_ready():
            sequence = self.sequence_builder.get_sequence()
            if sequence is not None:
                predictions = self.prediction_engine.predict(sequence)

        # ============================================================
        # STEP 7: Visualization
        # ============================================================
        if predictions is not None:
            # Get ball pixel position for label placement
            ball_pixel_pos = None
            if tracking_result.ball:
                ball_pixel_pos = tuple(tracking_result.ball.bbox.center.astype(int))

            frame = self.visualizer.draw(
                frame=frame,
                predictions=predictions,
                ball_pixel_pos=ball_pixel_pos,
                homography=self.homography.current_homography,
            )

        return frame


def main():
    parser = argparse.ArgumentParser(
        description="Football Analytics Pipeline - Live Prediction System"
    )
    parser.add_argument(
        "--video", required=True, help="Path to input football video"
    )
    parser.add_argument(
        "--output", default="output.mp4", help="Path to output annotated video"
    )
    parser.add_argument(
        "--config", default="configs/config.yaml", help="Path to config file"
    )
    args = parser.parse_args()

    # Run pipeline
    pipeline = FootballAnalyticsPipeline(args.config)
    pipeline.process_video(args.video, args.output)


if __name__ == "__main__":
    main()
