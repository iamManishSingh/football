"""
Download Training Data
========================
Downloads Metrica Sports sample tracking data for model training.

Metrica provides:
- Player tracking data at 25fps (x, y positions for all 22 players + ball)
- Synchronized event data (passes, shots, carries, etc.)

This is the BEST free dataset for training your prediction model.

Usage:
    python data/download_metrica.py
"""

import os
import urllib.request
from pathlib import Path
from loguru import logger

# Metrica Sports sample data URLs (hosted on GitHub)
METRICA_BASE = "https://raw.githubusercontent.com/metrica-sports/sample-data/master/data"

DATASETS = {
    "Sample_Game_1": {
        "tracking_home": f"{METRICA_BASE}/Sample_Game_1/Sample_Game_1_RawTrackingData_Home_Team.csv",
        "tracking_away": f"{METRICA_BASE}/Sample_Game_1/Sample_Game_1_RawTrackingData_Away_Team.csv",
        "events": f"{METRICA_BASE}/Sample_Game_1/Sample_Game_1_RawEventsData.csv",
    },
    "Sample_Game_2": {
        "tracking_home": f"{METRICA_BASE}/Sample_Game_2/Sample_Game_2_RawTrackingData_Home_Team.csv",
        "tracking_away": f"{METRICA_BASE}/Sample_Game_2/Sample_Game_2_RawTrackingData_Away_Team.csv",
        "events": f"{METRICA_BASE}/Sample_Game_2/Sample_Game_2_RawEventsData.csv",
    },
}


def download_file(url: str, dest: str):
    """Download a file with progress."""
    if os.path.exists(dest):
        logger.info(f"  Already exists: {dest}")
        return

    logger.info(f"  Downloading: {os.path.basename(dest)}")
    urllib.request.urlretrieve(url, dest)
    size_mb = os.path.getsize(dest) / (1024 * 1024)
    logger.info(f"  Done ({size_mb:.1f} MB)")


def main():
    data_dir = Path("data/metrica")
    data_dir.mkdir(parents=True, exist_ok=True)

    for game_name, urls in DATASETS.items():
        logger.info(f"\nDownloading {game_name}...")
        game_dir = data_dir / game_name
        game_dir.mkdir(exist_ok=True)

        for file_type, url in urls.items():
            filename = url.split("/")[-1]
            dest = game_dir / filename
            download_file(url, str(dest))

    logger.info("\n" + "=" * 50)
    logger.info("Download complete!")
    logger.info("=" * 50)
    logger.info("\nData saved to: data/metrica/")
    logger.info("\nNext step: Train the model with:")
    logger.info("  python -m training.train \\")
    logger.info("    --tracking_csv data/metrica/Sample_Game_1/Sample_Game_1_RawTrackingData_Home_Team.csv \\")
    logger.info("    --events_csv data/metrica/Sample_Game_1/Sample_Game_1_RawEventsData.csv")


if __name__ == "__main__":
    main()
