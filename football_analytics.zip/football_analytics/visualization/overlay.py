"""
STEP 7: Visualization Overlay
================================
Draws prediction results on video frames:
- Action probability bar next to ball carrier
- Destination heatmap on a mini-pitch
- xG meter near goal area
- Pressing arrows for defensive players
"""

import numpy as np
import cv2
from typing import Dict, Optional, Tuple
from utils.constants import ACTION_CLASSES, PITCH_LENGTH, PITCH_WIDTH


class PredictionVisualizer:
    """
    Overlays model predictions onto video frames.
    """

    def __init__(self, config: dict):
        vis_config = config["visualization"]
        self.show_heatmap = vis_config["show_heatmap"]
        self.show_actions = vis_config["show_action_labels"]
        self.show_pressing = vis_config["show_pressing_arrows"]
        self.show_xg = vis_config["show_xg_meter"]
        self.heatmap_alpha = vis_config["heatmap_alpha"]

        # Mini pitch for heatmap overlay (positioned in top-right corner)
        self.mini_pitch_w = 315  # 3 pixels per meter
        self.mini_pitch_h = 204

    def draw(
        self,
        frame: np.ndarray,
        predictions: Dict[str, np.ndarray],
        ball_pixel_pos: Optional[Tuple[int, int]] = None,
        homography: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """
        Draw all prediction overlays on the frame.

        Args:
            frame: BGR frame (H, W, 3)
            predictions: Dict from PredictionEngine.predict()
            ball_pixel_pos: Ball position in pixel coordinates
            homography: For projecting pitch heatmap back to frame

        Returns:
            Annotated frame
        """
        frame = frame.copy()

        # 1. Action probability label near ball carrier
        if self.show_actions and ball_pixel_pos is not None:
            frame = self._draw_action_probs(frame, predictions["action_probs"], ball_pixel_pos)

        # 2. Destination heatmap on mini-pitch
        if self.show_heatmap:
            frame = self._draw_destination_heatmap(frame, predictions["destination"])

        # 3. xG meter
        if self.show_xg:
            frame = self._draw_xg_meter(frame, predictions["xg"])

        # 4. Pressing indicator
        if self.show_pressing:
            frame = self._draw_pressing_indicator(frame, predictions["pressing"])

        return frame

    def _draw_action_probs(
        self,
        frame: np.ndarray,
        action_probs: np.ndarray,
        ball_pos: Tuple[int, int],
    ) -> np.ndarray:
        """
        Draw action probability bars next to the ball carrier.

        Shows something like:
            Pass    ████████░░ 72%
            Shot    ██░░░░░░░░ 18%
            Dribble █░░░░░░░░░  8%
        """
        h, w = frame.shape[:2]
        bx, by = int(ball_pos[0]), int(ball_pos[1])

        # Position the label box
        box_x = min(bx + 40, w - 200)
        box_y = max(by - 80, 10)

        # Background
        overlay = frame.copy()
        cv2.rectangle(overlay, (box_x - 5, box_y - 5),
                      (box_x + 195, box_y + len(ACTION_CLASSES) * 22 + 5),
                      (0, 0, 0), -1)
        frame = cv2.addWeighted(overlay, 0.7, frame, 0.3, 0)

        # Sort by probability
        sorted_indices = np.argsort(action_probs)[::-1]

        colors = [
            (46, 204, 113),   # green  - pass
            (231, 76, 60),    # red    - shot
            (52, 152, 219),   # blue   - dribble
            (241, 196, 15),   # yellow - cross
            (149, 165, 166),  # gray   - clearance
            (155, 89, 182),   # purple - through ball
        ]

        for i, idx in enumerate(sorted_indices[:4]):  # Show top 4
            name = ACTION_CLASSES[idx]
            prob = action_probs[idx]
            color = colors[idx % len(colors)]

            y = box_y + i * 22

            # Label
            cv2.putText(frame, f"{name[:8]:8s}", (box_x, y + 14),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

            # Bar
            bar_start = box_x + 80
            bar_width = int(prob * 80)
            cv2.rectangle(frame, (bar_start, y + 2), (bar_start + bar_width, y + 16),
                          color, -1)

            # Percentage
            cv2.putText(frame, f"{prob:.0%}", (bar_start + 85, y + 14),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

        return frame

    def _draw_destination_heatmap(
        self,
        frame: np.ndarray,
        heatmap: np.ndarray,
    ) -> np.ndarray:
        """
        Draw a mini-pitch with the destination probability heatmap in the top-right corner.
        """
        h, w = frame.shape[:2]

        # Resize heatmap to mini-pitch dimensions
        heatmap_vis = cv2.resize(heatmap, (self.mini_pitch_w, self.mini_pitch_h))

        # Normalize to 0-255
        heatmap_vis = (heatmap_vis / (heatmap_vis.max() + 1e-8) * 255).astype(np.uint8)

        # Apply colormap
        heatmap_colored = cv2.applyColorMap(heatmap_vis, cv2.COLORMAP_HOT)

        # Draw pitch lines on the heatmap
        heatmap_colored = self._draw_pitch_lines(heatmap_colored)

        # Position in top-right corner
        margin = 10
        y_start = margin
        y_end = margin + self.mini_pitch_h
        x_start = w - self.mini_pitch_w - margin
        x_end = w - margin

        # Blend with frame
        if y_end <= h and x_end <= w:
            roi = frame[y_start:y_end, x_start:x_end]
            blended = cv2.addWeighted(roi, 1 - self.heatmap_alpha, heatmap_colored, self.heatmap_alpha, 0)
            frame[y_start:y_end, x_start:x_end] = blended

            # Border
            cv2.rectangle(frame, (x_start - 1, y_start - 1), (x_end, y_end),
                          (255, 255, 255), 1)

            # Label
            cv2.putText(frame, "Predicted Destination", (x_start, y_start - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)

        return frame

    def _draw_pitch_lines(self, img: np.ndarray) -> np.ndarray:
        """Draw simplified pitch lines on the mini-pitch."""
        h, w = img.shape[:2]
        color = (255, 255, 255)
        thickness = 1

        # Outer boundary
        cv2.rectangle(img, (0, 0), (w - 1, h - 1), color, thickness)

        # Center line
        cv2.line(img, (w // 2, 0), (w // 2, h), color, thickness)

        # Center circle (approximate)
        cv2.circle(img, (w // 2, h // 2), int(9.15 / 105 * w), color, thickness)

        # Penalty areas
        pa_w = int(16.5 / 105 * w)
        pa_h = int(40.32 / 68 * h)
        pa_y = (h - pa_h) // 2

        cv2.rectangle(img, (0, pa_y), (pa_w, pa_y + pa_h), color, thickness)
        cv2.rectangle(img, (w - pa_w, pa_y), (w, pa_y + pa_h), color, thickness)

        return img

    def _draw_xg_meter(self, frame: np.ndarray, xg: float) -> np.ndarray:
        """
        Draw an xG meter bar in the bottom-left corner.
        """
        h, w = frame.shape[:2]

        # Position
        meter_x = 20
        meter_y = h - 50
        meter_w = 200
        meter_h = 25

        # Background
        cv2.rectangle(frame, (meter_x - 2, meter_y - 20),
                      (meter_x + meter_w + 2, meter_y + meter_h + 2),
                      (0, 0, 0), -1)

        # Label
        cv2.putText(frame, f"xG: {xg:.2f}", (meter_x, meter_y - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        # Background bar
        cv2.rectangle(frame, (meter_x, meter_y),
                      (meter_x + meter_w, meter_y + meter_h),
                      (50, 50, 50), -1)

        # Filled bar
        fill_w = int(xg * meter_w)
        # Color gradient: green (low xG) → red (high xG)
        r = int(min(xg * 2, 1.0) * 255)
        g = int((1 - min(xg * 2, 1.0)) * 255)
        cv2.rectangle(frame, (meter_x, meter_y),
                      (meter_x + fill_w, meter_y + meter_h),
                      (0, g, r), -1)

        return frame

    def _draw_pressing_indicator(self, frame: np.ndarray, pressing: float) -> np.ndarray:
        """
        Draw a pressing intensity indicator.
        """
        h, w = frame.shape[:2]

        # Position bottom-left, above xG meter
        x = 20
        y = h - 90

        label = "HIGH PRESS" if pressing > 0.6 else "MID BLOCK" if pressing > 0.3 else "LOW BLOCK"
        color = (0, 0, 255) if pressing > 0.6 else (0, 165, 255) if pressing > 0.3 else (0, 255, 0)

        cv2.putText(frame, f"Press: {label} ({pressing:.0%})", (x, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        return frame
