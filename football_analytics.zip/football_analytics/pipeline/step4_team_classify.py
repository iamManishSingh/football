"""
STEP 4: Team Classification
=============================
Assigns each player to Team A (0) or Team B (1) based on jersey color.
Uses KMeans clustering on the torso region of each player's bounding box.

Input:  TrackingResult + original frame
Output: TrackingResult with team_id filled in
"""

import numpy as np
import cv2
from sklearn.cluster import KMeans
from typing import List, Optional, Tuple
from loguru import logger

from pipeline.step2_tracking import TrackingResult, TrackedObject


class TeamClassifier:
    """
    Classifies players into two teams based on jersey color.

    Approach:
    1. Crop the torso region of each player bbox (skip head & legs)
    2. Extract dominant color from the torso crop
    3. Run KMeans (k=2) on the dominant colors of all players
    4. Assign cluster labels as team IDs

    This runs periodically (e.g., every 30 frames) and assignments
    are propagated via track IDs to intermediate frames.
    """

    def __init__(self, config: dict):
        team_config = config["team_classification"]
        self.n_clusters = team_config["n_clusters"]
        self.color_space = team_config["color_space"]
        self.crop_top_ratio = team_config["crop_top_ratio"]
        self.crop_bottom_ratio = team_config["crop_bottom_ratio"]

        self.kmeans: Optional[KMeans] = None
        self.track_to_team: dict = {}  # track_id -> team_id (cache)
        self.reclassify_interval = 30  # Re-run KMeans every N frames
        self.frame_counter = 0

        logger.info(f"TeamClassifier initialized (color_space={self.color_space})")

    def classify(
        self,
        frame: np.ndarray,
        tracking_result: TrackingResult,
    ) -> TrackingResult:
        """
        Assign team IDs to all tracked players.

        Args:
            frame: Original BGR frame
            tracking_result: From Step 3

        Returns:
            TrackingResult with team_id filled in
        """
        self.frame_counter += 1

        all_players = tracking_result.players + tracking_result.goalkeepers

        if len(all_players) < 2:
            return tracking_result

        # --- Periodically re-run KMeans clustering ---
        if self.frame_counter % self.reclassify_interval == 1 or self.kmeans is None:
            self._fit_kmeans(frame, all_players)

        # --- Assign team IDs using fitted model or cache ---
        for player in all_players:
            # Check cache first
            if player.track_id in self.track_to_team:
                player.team_id = self.track_to_team[player.track_id]
            else:
                # Extract color and predict
                color_feat = self._extract_color_feature(frame, player)
                if color_feat is not None and self.kmeans is not None:
                    team_id = int(self.kmeans.predict(color_feat.reshape(1, -1))[0])
                    player.team_id = team_id
                    self.track_to_team[player.track_id] = team_id

        return tracking_result

    def _fit_kmeans(self, frame: np.ndarray, players: List[TrackedObject]):
        """
        Run KMeans on color features of all visible players.
        """
        color_features = []
        valid_players = []

        for player in players:
            feat = self._extract_color_feature(frame, player)
            if feat is not None:
                color_features.append(feat)
                valid_players.append(player)

        if len(color_features) < self.n_clusters:
            return

        X = np.array(color_features)

        self.kmeans = KMeans(
            n_clusters=self.n_clusters,
            random_state=42,
            n_init=10,
        )
        labels = self.kmeans.fit_predict(X)

        # Update cache
        for player, label in zip(valid_players, labels):
            self.track_to_team[player.track_id] = int(label)
            player.team_id = int(label)

        logger.debug(
            f"KMeans fitted: {sum(labels == 0)} in team 0, {sum(labels == 1)} in team 1"
        )

    def _extract_color_feature(
        self,
        frame: np.ndarray,
        player: TrackedObject,
    ) -> Optional[np.ndarray]:
        """
        Extract dominant color feature from the torso region of a player bbox.

        Strategy:
        - Crop the middle portion of the bbox (skip head and legs)
        - Convert to the target color space
        - Use the mean color as the feature vector
        """
        bbox = player.bbox
        x1, y1, x2, y2 = int(bbox.x1), int(bbox.y1), int(bbox.x2), int(bbox.y2)

        # Clamp to frame boundaries
        h, w = frame.shape[:2]
        x1 = max(0, x1)
        y1 = max(0, y1)
        x2 = min(w, x2)
        y2 = min(h, y2)

        if x2 <= x1 or y2 <= y1:
            return None

        # Crop the torso region (skip head and legs)
        bbox_height = y2 - y1
        top_offset = int(bbox_height * self.crop_top_ratio)
        bottom_offset = int(bbox_height * self.crop_bottom_ratio)

        torso_y1 = y1 + top_offset
        torso_y2 = y2 - bottom_offset

        if torso_y2 <= torso_y1:
            return None

        crop = frame[torso_y1:torso_y2, x1:x2]

        if crop.size == 0:
            return None

        # Convert color space
        if self.color_space == "hsv":
            crop = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
        elif self.color_space == "lab":
            crop = cv2.cvtColor(crop, cv2.COLOR_BGR2LAB)
        # else: keep BGR

        # Use mean color as feature
        mean_color = crop.mean(axis=(0, 1))
        return mean_color
