"""
STEP 5: Feature Engineering
==============================
Converts raw tracking data into structured tensors for the prediction model.

This is THE MOST CRITICAL STEP. The quality of your predictions depends
entirely on how well you represent the game state.

Input:  Sequence of TrackingResults (N frames)
Output: GameState tensor ready for the prediction model

Feature dimensions per player (12):
    [x, y, vx, vy, ax, ay, dist_to_ball, dist_to_goal, angle_to_goal,
     nearest_opponent_dist, is_ball_carrier, team_id]

Feature dimensions for ball (6):
    [x, y, vx, vy, speed, possession_team]
"""

import numpy as np
from dataclasses import dataclass
from typing import List, Optional, Dict, Tuple
from collections import deque
from loguru import logger

from pipeline.step2_tracking import TrackingResult, TrackedObject, TrackHistory
from utils.geometry import (
    euclidean_distance,
    angle_to_goal,
    compute_velocity,
    compute_acceleration,
    compute_speed,
    find_nearest_opponent,
    compute_convex_hull_area,
)
from utils.constants import (
    PITCH_LENGTH, PITCH_WIDTH,
    LEFT_GOAL_CENTER, RIGHT_GOAL_CENTER,
    PRESSING_DISTANCE_THRESHOLD,
    PLAYER_FEATURE_DIM, BALL_FEATURE_DIM,
)


@dataclass
class GameState:
    """
    Complete game state for a single frame, ready for model input.
    """
    frame_id: int

    # Player features: shape (max_players, PLAYER_FEATURE_DIM)
    player_features: np.ndarray

    # Ball features: shape (BALL_FEATURE_DIM,)
    ball_features: np.ndarray

    # Mask for valid players (some slots may be empty): shape (max_players,)
    player_mask: np.ndarray

    # Context features
    ball_carrier_id: Optional[int] = None
    possession_team: Optional[int] = None
    pressing_intensity: float = 0.0
    team_a_compactness: float = 0.0
    team_b_compactness: float = 0.0
    pitch_zone: str = "middle"  # defensive / middle / attacking


class FeatureExtractor:
    """
    Extracts structured game state features from tracking data.

    This maintains a rolling window of frames and computes:
    - Per-player features (position, velocity, acceleration, relational)
    - Ball features
    - Team-level tactical features
    """

    def __init__(self, config: dict):
        feat_config = config["features"]
        self.seq_length = feat_config["sequence_length"]
        self.stride = feat_config["stride"]
        self.max_players = feat_config["max_players"]
        self.normalize = feat_config["normalize_positions"]

        self.fps = config["video"]["fps"]
        self.dt = 1.0 / self.fps

        # Rolling window of tracking results
        self.frame_buffer: deque = deque(maxlen=self.seq_length + 10)

        # Track history for velocity computation
        self.track_history = TrackHistory(max_history=self.seq_length + 10)

        # Attacking direction: which goal is each team attacking?
        # Convention: team 0 attacks right goal (105, 34), team 1 attacks left (0, 34)
        # You may need to detect this automatically or set it per half
        self.team_attack_direction = {0: RIGHT_GOAL_CENTER, 1: LEFT_GOAL_CENTER}

        logger.info(
            f"FeatureExtractor: seq_len={self.seq_length}, "
            f"max_players={self.max_players}, fps={self.fps}"
        )

    def update(self, tracking_result: TrackingResult) -> Optional[GameState]:
        """
        Add a new frame to the buffer and extract features.

        Args:
            tracking_result: Fully processed tracking result (with pitch positions & team IDs)

        Returns:
            GameState if enough frames buffered, else None
        """
        self.frame_buffer.append(tracking_result)
        self.track_history.update(tracking_result)

        if len(self.frame_buffer) < 3:  # Need at least 3 frames for velocity
            return None

        return self._extract_current_state(tracking_result)

    def _extract_current_state(self, current: TrackingResult) -> GameState:
        """
        Build the game state for the current frame.
        """
        player_features = np.zeros((self.max_players, PLAYER_FEATURE_DIM), dtype=np.float32)
        player_mask = np.zeros(self.max_players, dtype=np.float32)
        ball_features = np.zeros(BALL_FEATURE_DIM, dtype=np.float32)

        all_players = current.all_field_players

        # --- Ball position ---
        ball_pos = np.array([PITCH_LENGTH / 2, PITCH_WIDTH / 2])  # Default: center
        if current.ball and current.ball.pitch_position is not None:
            ball_pos = current.ball.pitch_position

        # --- Separate teams ---
        team_a_positions = []
        team_b_positions = []

        for player in all_players:
            if player.pitch_position is not None:
                if player.team_id == 0:
                    team_a_positions.append(player.pitch_position)
                elif player.team_id == 1:
                    team_b_positions.append(player.pitch_position)

        team_a_positions = np.array(team_a_positions) if team_a_positions else np.empty((0, 2))
        team_b_positions = np.array(team_b_positions) if team_b_positions else np.empty((0, 2))

        # --- Determine ball carrier (closest player to ball) ---
        ball_carrier_id = None
        min_dist_to_ball = float('inf')

        for player in all_players:
            if player.pitch_position is not None:
                d = euclidean_distance(player.pitch_position, ball_pos)
                if d < min_dist_to_ball:
                    min_dist_to_ball = d
                    ball_carrier_id = player.track_id

        # --- Fill player features ---
        for i, player in enumerate(all_players[:self.max_players]):
            if player.pitch_position is None:
                continue

            pos = player.pitch_position
            player_mask[i] = 1.0

            # Determine which goal this player is attacking
            team_id = player.team_id if player.team_id is not None else 0
            target_goal = self.team_attack_direction.get(team_id, RIGHT_GOAL_CENTER)

            # Opponents for this player
            if team_id == 0:
                opponent_positions = team_b_positions
            else:
                opponent_positions = team_a_positions

            # Compute velocity from track history
            positions_hist = self.track_history.get_positions(player.track_id, n_frames=5)
            if len(positions_hist) >= 2:
                velocities = compute_velocity(positions_hist, self.dt)
                vel = velocities[-1]
                accelerations = compute_acceleration(velocities, self.dt)
                acc = accelerations[-1]
            else:
                vel = np.array([0.0, 0.0])
                acc = np.array([0.0, 0.0])

            # Nearest opponent distance
            opp_dist, _ = find_nearest_opponent(pos, opponent_positions)

            # Is this player the ball carrier?
            is_carrier = 1.0 if player.track_id == ball_carrier_id else 0.0

            # --- Assemble feature vector ---
            feat = np.array([
                pos[0],                                    # 0: x position (meters)
                pos[1],                                    # 1: y position (meters)
                vel[0],                                    # 2: vx (m/s)
                vel[1],                                    # 3: vy (m/s)
                acc[0],                                    # 4: ax (m/s²)
                acc[1],                                    # 5: ay (m/s²)
                euclidean_distance(pos, ball_pos),          # 6: distance to ball
                euclidean_distance(pos, target_goal),       # 7: distance to goal
                angle_to_goal(pos, target_goal),            # 8: angle to goal (degrees)
                opp_dist,                                   # 9: nearest opponent distance
                is_carrier,                                 # 10: is ball carrier
                float(team_id),                             # 11: team ID
            ], dtype=np.float32)

            player_features[i] = feat

        # --- Ball features ---
        ball_positions_hist = self.track_history.get_positions("ball_0", n_frames=5)
        if len(ball_positions_hist) >= 2:
            ball_vel = compute_velocity(ball_positions_hist, self.dt)[-1]
        else:
            ball_vel = np.array([0.0, 0.0])

        possession_team = 0.0
        if ball_carrier_id is not None:
            for p in all_players:
                if p.track_id == ball_carrier_id and p.team_id is not None:
                    possession_team = float(p.team_id)
                    break

        ball_features = np.array([
            ball_pos[0],                          # 0: ball x
            ball_pos[1],                          # 1: ball y
            ball_vel[0],                          # 2: ball vx
            ball_vel[1],                          # 3: ball vy
            compute_speed(ball_vel.reshape(1, 2))[0],  # 4: ball speed
            possession_team,                      # 5: possession team
        ], dtype=np.float32)

        # --- Normalize ---
        if self.normalize:
            player_features = self._normalize_features(player_features, player_mask)
            ball_features = self._normalize_ball_features(ball_features)

        # --- Context features ---
        pressing_intensity = self._compute_pressing(all_players, ball_pos)
        team_a_compact = compute_convex_hull_area(team_a_positions) if len(team_a_positions) >= 3 else 0.0
        team_b_compact = compute_convex_hull_area(team_b_positions) if len(team_b_positions) >= 3 else 0.0

        pitch_zone = self._get_pitch_zone(ball_pos)

        return GameState(
            frame_id=current.frame_id,
            player_features=player_features,
            ball_features=ball_features,
            player_mask=player_mask,
            ball_carrier_id=ball_carrier_id,
            possession_team=int(possession_team),
            pressing_intensity=pressing_intensity,
            team_a_compactness=team_a_compact,
            team_b_compactness=team_b_compact,
            pitch_zone=pitch_zone,
        )

    def _normalize_features(
        self,
        features: np.ndarray,
        mask: np.ndarray,
    ) -> np.ndarray:
        """Normalize player features to [0, 1] or [-1, 1] range."""
        normalized = features.copy()

        for i in range(len(mask)):
            if mask[i] == 0:
                continue
            # Position: normalize to pitch dimensions
            normalized[i, 0] /= PITCH_LENGTH   # x -> [0, 1]
            normalized[i, 1] /= PITCH_WIDTH    # y -> [0, 1]
            # Velocity: normalize by max expected speed (~10 m/s)
            normalized[i, 2] /= 10.0
            normalized[i, 3] /= 10.0
            # Acceleration: normalize by ~5 m/s²
            normalized[i, 4] /= 5.0
            normalized[i, 5] /= 5.0
            # Distances: normalize by pitch diagonal (~125m)
            normalized[i, 6] /= 125.0
            normalized[i, 7] /= 125.0
            # Angle: normalize by 180
            normalized[i, 8] /= 180.0
            # Nearest opponent: normalize by ~50m
            normalized[i, 9] /= 50.0

        return normalized

    def _normalize_ball_features(self, features: np.ndarray) -> np.ndarray:
        normalized = features.copy()
        normalized[0] /= PITCH_LENGTH
        normalized[1] /= PITCH_WIDTH
        normalized[2] /= 30.0  # Max ball speed ~30 m/s
        normalized[3] /= 30.0
        normalized[4] /= 30.0
        return normalized

    def _compute_pressing(
        self,
        players: List[TrackedObject],
        ball_pos: np.ndarray,
    ) -> float:
        """
        Compute pressing intensity: how many defenders are within
        PRESSING_DISTANCE_THRESHOLD of the ball.
        """
        count = 0
        for p in players:
            if p.pitch_position is not None:
                d = euclidean_distance(p.pitch_position, ball_pos)
                if d < PRESSING_DISTANCE_THRESHOLD:
                    count += 1
        # Normalize: 0-1 range (max ~6 players pressing)
        return min(count / 6.0, 1.0)

    def _get_pitch_zone(self, ball_pos: np.ndarray) -> str:
        x = ball_pos[0]
        if x < PITCH_LENGTH / 3:
            return "defensive"
        elif x < 2 * PITCH_LENGTH / 3:
            return "middle"
        else:
            return "attacking"


class SequenceBuilder:
    """
    Builds sequences of GameStates for the temporal prediction model.

    The model needs a sliding window of N frames to make predictions.
    """

    def __init__(self, config: dict):
        self.seq_length = config["features"]["sequence_length"]
        self.stride = config["features"]["stride"]
        self.max_players = config["features"]["max_players"]

        self.state_buffer: deque = deque(maxlen=self.seq_length + 10)

    def add_state(self, state: GameState):
        """Add a new game state to the buffer."""
        self.state_buffer.append(state)

    def get_sequence(self) -> Optional[Dict[str, np.ndarray]]:
        """
        Get the current sequence as tensors ready for the model.

        Returns:
            Dict with:
                "player_features": (seq_len, max_players, player_feat_dim)
                "ball_features": (seq_len, ball_feat_dim)
                "player_mask": (seq_len, max_players)
            Or None if not enough frames yet.
        """
        if len(self.state_buffer) < self.seq_length:
            return None

        # Take last seq_length states
        states = list(self.state_buffer)[-self.seq_length:]

        player_features = np.stack([s.player_features for s in states])  # (T, 22, 12)
        ball_features = np.stack([s.ball_features for s in states])      # (T, 6)
        player_mask = np.stack([s.player_mask for s in states])          # (T, 22)

        return {
            "player_features": player_features.astype(np.float32),
            "ball_features": ball_features.astype(np.float32),
            "player_mask": player_mask.astype(np.float32),
        }

    def is_ready(self) -> bool:
        return len(self.state_buffer) >= self.seq_length
