"""
STEP 2: Multi-Object Tracking
===============================
Assigns persistent IDs to detected players and ball across frames.
Uses ByteTrack via the `supervision` library.

Input:  DetectionResult per frame
Output: TrackedObject list with consistent track IDs
"""

import numpy as np
import supervision as sv
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from loguru import logger

from pipeline.step1_detection import DetectionResult, BBox


@dataclass
class TrackedObject:
    """A tracked entity with persistent ID."""
    track_id: int
    bbox: BBox
    class_name: str              # "player", "ball", "goalkeeper", "referee"
    foot_point_pixel: np.ndarray  # Bottom-center of bbox in pixel coords

    # These get filled in later pipeline steps
    pitch_position: Optional[np.ndarray] = None  # (x, y) in meters on pitch
    team_id: Optional[int] = None                 # 0 or 1 (filled in Step 4)
    velocity: Optional[np.ndarray] = None         # (vx, vy) in m/s
    acceleration: Optional[np.ndarray] = None     # (ax, ay) in m/s²


@dataclass
class TrackingResult:
    """All tracked objects for a single frame."""
    frame_id: int
    players: List[TrackedObject] = field(default_factory=list)
    ball: Optional[TrackedObject] = None
    referees: List[TrackedObject] = field(default_factory=list)
    goalkeepers: List[TrackedObject] = field(default_factory=list)

    @property
    def all_field_players(self) -> List[TrackedObject]:
        """All players + goalkeepers (the 22 on the pitch)."""
        return self.players + self.goalkeepers


class MultiObjectTracker:
    """
    Wraps ByteTrack via the supervision library for persistent tracking.

    Why ByteTrack?
    - Simple, fast, and reliable for sports tracking
    - Handles occlusions well (players overlapping)
    - supervision makes integration trivial
    """

    def __init__(self, config: dict):
        track_config = config["tracking"]

        # Initialize separate trackers for players and ball
        # (Ball has very different motion characteristics than players)
        self.player_tracker = sv.ByteTrack(
            track_activation_threshold=track_config["track_thresh"],
            lost_track_buffer=track_config["track_buffer"],
            minimum_matching_threshold=track_config["match_thresh"],
            minimum_consecutive_frames=track_config["min_hits"],
        )

        self.ball_tracker = sv.ByteTrack(
            track_activation_threshold=0.1,     # Lower threshold for ball (often low confidence)
            lost_track_buffer=60,               # Keep ball track longer (it goes off-screen more)
            minimum_matching_threshold=0.5,
            minimum_consecutive_frames=1,
        )

        logger.info("MultiObjectTracker initialized (ByteTrack)")

    def update(self, detection_result: DetectionResult) -> TrackingResult:
        """
        Update tracks with new detections.

        Args:
            detection_result: Detections from Step 1

        Returns:
            TrackingResult with persistent track IDs
        """
        result = TrackingResult(frame_id=detection_result.frame_id)

        # ---- Track Players ----
        if detection_result.players:
            player_sv_dets = self._bboxes_to_sv_detections(
                detection_result.players, class_id=0
            )
            tracked_players = self.player_tracker.update_with_detections(player_sv_dets)

            for i in range(len(tracked_players)):
                bbox_array = tracked_players.xyxy[i]
                track_id = int(tracked_players.tracker_id[i])

                bbox = BBox(
                    x1=bbox_array[0], y1=bbox_array[1],
                    x2=bbox_array[2], y2=bbox_array[3],
                    confidence=float(tracked_players.confidence[i]),
                    class_id=0, class_name="player",
                )

                result.players.append(TrackedObject(
                    track_id=track_id,
                    bbox=bbox,
                    class_name="player",
                    foot_point_pixel=bbox.foot_point,
                ))

        # ---- Track Ball ----
        if detection_result.ball:
            ball_sv_dets = self._bboxes_to_sv_detections(
                [detection_result.ball], class_id=1
            )
            tracked_ball = self.ball_tracker.update_with_detections(ball_sv_dets)

            if len(tracked_ball) > 0:
                bbox_array = tracked_ball.xyxy[0]
                bbox = BBox(
                    x1=bbox_array[0], y1=bbox_array[1],
                    x2=bbox_array[2], y2=bbox_array[3],
                    confidence=float(tracked_ball.confidence[0]),
                    class_id=1, class_name="ball",
                )
                result.ball = TrackedObject(
                    track_id=int(tracked_ball.tracker_id[0]),
                    bbox=bbox,
                    class_name="ball",
                    foot_point_pixel=bbox.center,  # Use center for ball
                )

        # ---- Track Goalkeepers (same tracker as players, different class) ----
        if detection_result.goalkeepers:
            for gk in detection_result.goalkeepers:
                bbox = gk
                result.goalkeepers.append(TrackedObject(
                    track_id=-1,  # Could use separate tracker if needed
                    bbox=bbox,
                    class_name="goalkeeper",
                    foot_point_pixel=bbox.foot_point,
                ))

        logger.debug(
            f"Frame {detection_result.frame_id}: "
            f"Tracking {len(result.players)} players, "
            f"ball={'tracked' if result.ball else 'lost'}"
        )

        return result

    def _bboxes_to_sv_detections(
        self, bboxes: List[BBox], class_id: int
    ) -> sv.Detections:
        """Convert our BBox list to supervision Detections format."""
        if not bboxes:
            return sv.Detections.empty()

        xyxy = np.array([[b.x1, b.y1, b.x2, b.y2] for b in bboxes])
        confidence = np.array([b.confidence for b in bboxes])
        class_ids = np.array([class_id] * len(bboxes))

        return sv.Detections(
            xyxy=xyxy,
            confidence=confidence,
            class_id=class_ids,
        )


class TrackHistory:
    """
    Maintains a rolling history of tracked positions for velocity computation.
    """

    def __init__(self, max_history: int = 60):
        self.max_history = max_history
        # track_id -> list of (frame_id, position)
        self.history: Dict[int, List[tuple]] = {}

    def update(self, tracking_result: TrackingResult):
        """Add new frame's positions to history."""
        frame_id = tracking_result.frame_id

        for player in tracking_result.all_field_players:
            if player.pitch_position is not None:
                tid = player.track_id
                if tid not in self.history:
                    self.history[tid] = []

                self.history[tid].append((frame_id, player.pitch_position.copy()))

                # Trim old entries
                if len(self.history[tid]) > self.max_history:
                    self.history[tid] = self.history[tid][-self.max_history:]

        # Ball
        if tracking_result.ball and tracking_result.ball.pitch_position is not None:
            tid = f"ball_{tracking_result.ball.track_id}"
            if tid not in self.history:
                self.history[tid] = []
            self.history[tid].append((frame_id, tracking_result.ball.pitch_position.copy()))
            if len(self.history[tid]) > self.max_history:
                self.history[tid] = self.history[tid][-self.max_history:]

    def get_positions(self, track_id, n_frames: int = 10) -> np.ndarray:
        """Get last N positions for a track."""
        key = track_id
        if key not in self.history:
            return np.array([]).reshape(0, 2)
        entries = self.history[key][-n_frames:]
        return np.array([pos for _, pos in entries])
