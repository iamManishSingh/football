"""
STEP 3: Homography — Pixel to Pitch Coordinate Mapping
========================================================
Uses pitch keypoints from Step 1 to compute a homography matrix,
then projects all player/ball positions onto a normalized pitch.

Input:  TrackingResult with pixel positions + PitchKeypoints
Output: TrackingResult with pitch_position filled in (meters)
"""

import numpy as np
import cv2
from typing import Dict, List, Optional, Tuple
from loguru import logger

from pipeline.step1_detection import PitchKeypoint
from pipeline.step2_tracking import TrackingResult
from utils.geometry import compute_homography, pixel_to_pitch


class HomographyEstimator:
    """
    Computes and maintains the homography matrix from pixel to pitch coordinates.

    Strategy:
    - Compute homography each frame from detected pitch keypoints
    - If too few keypoints in current frame, use the last valid homography
    - Smooth homography over time to reduce jitter (optional)
    """

    def __init__(self, config: dict):
        homo_config = config["homography"]
        self.pitch_length = homo_config["pitch_length"]
        self.pitch_width = homo_config["pitch_width"]

        # Build the mapping: keypoint_name -> real-world (x, y) in meters
        self.real_world_map: Dict[str, np.ndarray] = {}
        for name, coords in homo_config["real_world_points"].items():
            self.real_world_map[name] = np.array(coords, dtype=np.float32)

        self.current_homography: Optional[np.ndarray] = None
        self.homography_history: List[np.ndarray] = []  # For smoothing
        self.smoothing_window = 5

        logger.info(
            f"HomographyEstimator initialized: "
            f"pitch={self.pitch_length}x{self.pitch_width}m, "
            f"{len(self.real_world_map)} reference points"
        )

    def update(
        self,
        pitch_keypoints: List[PitchKeypoint],
        min_keypoints: int = 4,
    ) -> Optional[np.ndarray]:
        """
        Update homography from detected pitch keypoints.

        Args:
            pitch_keypoints: Detected keypoints from YOLO pitch model
            min_keypoints: Minimum keypoints needed to compute homography

        Returns:
            3x3 homography matrix, or None if failed
        """
        # Match detected keypoints to real-world coordinates
        src_points = []  # Pixel coordinates
        dst_points = []  # Real-world coordinates

        for kp in pitch_keypoints:
            if kp.name in self.real_world_map:
                src_points.append([kp.x, kp.y])
                dst_points.append(self.real_world_map[kp.name])

        if len(src_points) < min_keypoints:
            logger.debug(
                f"Only {len(src_points)} keypoints matched (need {min_keypoints}), "
                f"reusing last homography"
            )
            return self.current_homography

        src = np.array(src_points, dtype=np.float32)
        dst = np.array(dst_points, dtype=np.float32)

        H = compute_homography(src, dst)

        if H is not None:
            self.current_homography = H
            self.homography_history.append(H)

            # Keep only recent history
            if len(self.homography_history) > self.smoothing_window:
                self.homography_history = self.homography_history[-self.smoothing_window:]

        return self.current_homography

    def get_smoothed_homography(self) -> Optional[np.ndarray]:
        """
        Get a temporally smoothed homography to reduce frame-to-frame jitter.
        Simple averaging of recent homography matrices.
        """
        if not self.homography_history:
            return None

        # Average recent homographies
        H_avg = np.mean(self.homography_history, axis=0)

        # Re-normalize (homography matrices should have H[2,2] ≈ 1)
        if abs(H_avg[2, 2]) > 1e-6:
            H_avg /= H_avg[2, 2]

        return H_avg

    def transform_tracking_result(
        self,
        tracking_result: TrackingResult,
        pitch_keypoints: List[PitchKeypoint],
    ) -> TrackingResult:
        """
        Project all tracked objects from pixel to pitch coordinates.

        Args:
            tracking_result: From Step 2 (pixel positions)
            pitch_keypoints: From Step 1 (for homography update)

        Returns:
            Same TrackingResult with pitch_position filled in
        """
        # Update homography with this frame's keypoints
        self.update(pitch_keypoints)

        H = self.current_homography
        if H is None:
            logger.warning("No valid homography — cannot project to pitch coordinates")
            return tracking_result

        # ---- Project Players ----
        for player in tracking_result.players:
            pixel_pt = player.foot_point_pixel.reshape(1, 2)
            pitch_pt = pixel_to_pitch(pixel_pt, H)
            player.pitch_position = self._clamp_to_pitch(pitch_pt[0])

        # ---- Project Goalkeepers ----
        for gk in tracking_result.goalkeepers:
            pixel_pt = gk.foot_point_pixel.reshape(1, 2)
            pitch_pt = pixel_to_pitch(pixel_pt, H)
            gk.pitch_position = self._clamp_to_pitch(pitch_pt[0])

        # ---- Project Ball ----
        if tracking_result.ball:
            pixel_pt = tracking_result.ball.foot_point_pixel.reshape(1, 2)
            pitch_pt = pixel_to_pitch(pixel_pt, H)
            tracking_result.ball.pitch_position = self._clamp_to_pitch(pitch_pt[0])

        return tracking_result

    def _clamp_to_pitch(self, pos: np.ndarray) -> np.ndarray:
        """Clamp position to valid pitch boundaries."""
        x = np.clip(pos[0], 0, self.pitch_length)
        y = np.clip(pos[1], 0, self.pitch_width)
        return np.array([x, y])
