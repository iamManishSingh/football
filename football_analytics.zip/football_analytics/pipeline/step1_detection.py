"""
STEP 1: Detection Layer
========================
Uses RF-DETR for player/ball detection and YOLO for pitch keypoint detection.

Input:  Raw video frame (BGR image)
Output: DetectionResult containing player boxes, ball box, and pitch keypoints
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from loguru import logger


@dataclass
class BBox:
    """Single bounding box detection."""
    x1: float
    y1: float
    x2: float
    y2: float
    confidence: float
    class_id: int
    class_name: str

    @property
    def center(self) -> np.ndarray:
        return np.array([(self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2])

    @property
    def foot_point(self) -> np.ndarray:
        """Bottom-center of bbox (better for pitch projection)."""
        return np.array([(self.x1 + self.x2) / 2, self.y2])

    @property
    def width(self) -> float:
        return self.x2 - self.x1

    @property
    def height(self) -> float:
        return self.y2 - self.y1

    def to_xyxy(self) -> np.ndarray:
        return np.array([self.x1, self.y1, self.x2, self.y2])


@dataclass
class PitchKeypoint:
    """A detected pitch keypoint."""
    name: str
    x: float
    y: float
    confidence: float


@dataclass
class DetectionResult:
    """All detections for a single frame."""
    frame_id: int
    players: List[BBox] = field(default_factory=list)
    ball: Optional[BBox] = None
    referees: List[BBox] = field(default_factory=list)
    goalkeepers: List[BBox] = field(default_factory=list)
    pitch_keypoints: List[PitchKeypoint] = field(default_factory=list)


class PlayerBallDetector:
    """
    RF-DETR based detector for players, ball, referees, goalkeepers.

    NOTE: Adapt this to match YOUR RF-DETR model's API.
    The example below shows the general pattern.
    """

    def __init__(self, config: dict):
        self.config = config
        self.conf_threshold = config["confidence_threshold"]
        self.device = config["device"]
        self.class_map = config["classes"]  # {player: 0, ball: 1, ...}

        # --- Load your RF-DETR model ---
        # Option A: If using the rfdetr package
        # from rfdetr import RFDETRBase
        # self.model = RFDETRBase()
        # self.model.load(config["model_path"])

        # Option B: If using a custom export (ONNX, TorchScript, etc.)
        # import torch
        # self.model = torch.jit.load(config["model_path"])
        # self.model.to(self.device)
        # self.model.eval()

        logger.info(f"PlayerBallDetector initialized (device={self.device})")

    def detect(self, frame: np.ndarray) -> List[BBox]:
        """
        Run RF-DETR inference on a single frame.

        Args:
            frame: BGR image (H, W, 3)

        Returns:
            List of BBox detections
        """
        # ============================================================
        # REPLACE THIS WITH YOUR ACTUAL RF-DETR INFERENCE CODE
        # ============================================================
        #
        # Example with rfdetr package:
        #   detections = self.model.predict(frame, threshold=self.conf_threshold)
        #   # detections will have .xyxy, .confidence, .class_id attributes
        #
        # Example with supervision:
        #   import supervision as sv
        #   results = self.model(frame)
        #   detections = sv.Detections.from_... (depends on your setup)
        #
        # For now, here's the pattern you need to implement:
        # ============================================================

        results = []

        # --- Pseudocode: replace with your model call ---
        # raw_detections = self.model.predict(frame)
        # for det in raw_detections:
        #     if det.confidence < self.conf_threshold:
        #         continue
        #     bbox = BBox(
        #         x1=det.xyxy[0], y1=det.xyxy[1],
        #         x2=det.xyxy[2], y2=det.xyxy[3],
        #         confidence=det.confidence,
        #         class_id=det.class_id,
        #         class_name=self._get_class_name(det.class_id),
        #     )
        #     results.append(bbox)
        # ------------------------------------------------

        return results

    def _get_class_name(self, class_id: int) -> str:
        inv_map = {v: k for k, v in self.class_map.items()}
        return inv_map.get(class_id, "unknown")


class PitchDetector:
    """
    YOLO-based pitch keypoint detector.

    Your fine-tuned YOLO model should detect keypoints/intersections on the pitch
    (corners, penalty spots, center circle intersections, etc.)
    """

    def __init__(self, config: dict):
        self.config = config
        self.conf_threshold = config["confidence_threshold"]
        self.device = config["device"]
        self.keypoint_names = config["keypoint_names"]

        # --- Load your YOLO model ---
        # from ultralytics import YOLO
        # self.model = YOLO(config["model_path"])
        # self.model.to(self.device)

        logger.info(f"PitchDetector initialized with {len(self.keypoint_names)} keypoints")

    def detect(self, frame: np.ndarray) -> List[PitchKeypoint]:
        """
        Detect pitch keypoints in a frame.

        Args:
            frame: BGR image (H, W, 3)

        Returns:
            List of PitchKeypoint detections
        """
        # ============================================================
        # REPLACE WITH YOUR YOLO PITCH MODEL INFERENCE
        # ============================================================
        #
        # If your model detects keypoints (YOLO-Pose style):
        #   results = self.model(frame, conf=self.conf_threshold)
        #   keypoints = results[0].keypoints  # shape: (1, N_keypoints, 3) [x, y, conf]
        #   pitch_kps = []
        #   for i, name in enumerate(self.keypoint_names):
        #       if i < len(keypoints[0]):
        #           kp = keypoints[0][i]
        #           if kp[2] > self.conf_threshold:  # confidence check
        #               pitch_kps.append(PitchKeypoint(name, float(kp[0]), float(kp[1]), float(kp[2])))
        #
        # If your model detects keypoints as object bounding boxes:
        #   results = self.model(frame, conf=self.conf_threshold)
        #   for box in results[0].boxes:
        #       class_id = int(box.cls)
        #       name = self.keypoint_names[class_id]
        #       cx, cy = box.xywh[0][:2]  # center of bbox = keypoint location
        #       pitch_kps.append(PitchKeypoint(name, float(cx), float(cy), float(box.conf)))
        # ============================================================

        pitch_kps = []
        return pitch_kps


class DetectionPipeline:
    """
    Combined detection pipeline: runs both detectors and packages results.
    """

    def __init__(self, config: dict):
        det_config = config["detection"]
        self.player_detector = PlayerBallDetector(det_config["rfdetr"])
        self.pitch_detector = PitchDetector(det_config["yolo_pitch"])
        self.class_map = det_config["rfdetr"]["classes"]

    def process_frame(self, frame: np.ndarray, frame_id: int) -> DetectionResult:
        """
        Run all detections on a single frame.

        Args:
            frame: BGR image
            frame_id: Frame index in the video

        Returns:
            DetectionResult with all detections
        """
        result = DetectionResult(frame_id=frame_id)

        # --- Player/Ball Detection ---
        all_detections = self.player_detector.detect(frame)

        for det in all_detections:
            if det.class_name == "player":
                result.players.append(det)
            elif det.class_name == "ball":
                # Keep only highest confidence ball detection
                if result.ball is None or det.confidence > result.ball.confidence:
                    result.ball = det
            elif det.class_name == "referee":
                result.referees.append(det)
            elif det.class_name == "goalkeeper":
                result.goalkeepers.append(det)

        # --- Pitch Keypoint Detection ---
        result.pitch_keypoints = self.pitch_detector.detect(frame)

        logger.debug(
            f"Frame {frame_id}: {len(result.players)} players, "
            f"ball={'yes' if result.ball else 'no'}, "
            f"{len(result.pitch_keypoints)} keypoints"
        )

        return result
