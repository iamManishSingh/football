# Live Inference Implementation - Testing Checklist

## Pre-flight Checks

### Python Server Setup
- [ ] Python 3.8+ installed
- [ ] Dependencies installed: `pip install -r python-bridge/requirements.txt`
- [ ] RF-DETR package available: `python -c "from rfdetr import RFDETRBase"`
- [ ] Server starts without errors: `python live_server.py`
- [ ] Health endpoint responds: `curl http://localhost:8000/health`
- [ ] Model loads successfully (check terminal output)

### Backend Server
- [ ] Node.js 18+ installed
- [ ] Dependencies installed: `npm install` in backend/
- [ ] Server starts: `npm run dev`
- [ ] Port 3001 (REST) accessible
- [ ] Port 3002 (WebSocket) accessible
- [ ] No errors in terminal

### Frontend
- [ ] Dependencies installed: `npm install` in frontend/
- [ ] Server starts: `npm run dev`
- [ ] Browser opens at http://localhost:5173
- [ ] No console errors
- [ ] UI renders correctly

## Feature Tests

### 1. Server Availability Check
- [ ] "RF-DETR Ready" badge appears when Python server is running
- [ ] Badge disappears when Python server is stopped
- [ ] Frontend handles missing Python server gracefully

### 2. Video Upload (Live Mode)
- [ ] Click "Upload Video (Live)" button
- [ ] File selector opens
- [ ] Select a video file (.mp4, .avi, etc.)
- [ ] Upload progress shows (if large file)
- [ ] Success toast: "Video loaded: filename.mp4. Ready for live inference!"
- [ ] Video info shown: resolution badge (e.g., "1920x1080")
- [ ] "Live Mode" badge appears
- [ ] Total frames calculated correctly

### 3. Range Selection Dialog
- [ ] Prompt shows: "Enter start time in seconds..."
- [ ] Can enter custom start time
- [ ] Can press Enter for default (0)
- [ ] Prompt shows: "Enter end time in seconds..."
- [ ] Can enter custom end time
- [ ] Can enter -1 for full video
- [ ] Range calculated correctly (frames = seconds * fps)
- [ ] Toast shows: "Will process frames X to Y"

### 4. Live Inference Processing
- [ ] Click "Start/Resume Inference" button
- [ ] Processing indicator appears
- [ ] Progress percentage shows and updates
- [ ] Spinner animation works
- [ ] Video canvas shows frames as they're processed
- [ ] Green boxes show detected ball
- [ ] Red boxes show rejected detections
- [ ] Cache size badge updates: "X cached"
- [ ] Progress reaches 100%
- [ ] Success toast: "Live inference complete!"

### 5. Pause/Resume
- [ ] Click "Stop" button during processing
- [ ] Processing stops immediately
- [ ] Cache preserves processed frames
- [ ] Can scrub to any cached frame
- [ ] Click "Start/Resume Inference" again
- [ ] Processing continues from where it stopped
- [ ] Cache grows progressively

### 6. Instant Replay from Cache
- [ ] After caching frames, pause
- [ ] Scrub timeline to any cached frame
- [ ] Frame loads instantly (< 100ms)
- [ ] Canvas updates immediately
- [ ] Frame image loads
- [ ] Detection boxes render correctly
- [ ] No Python server calls (check network tab)

### 7. Filter Tuning with Cache
- [ ] With frames cached, go to Filters tab
- [ ] Adjust confidence threshold slider
- [ ] Click "Apply" button
- [ ] Current frame re-processes instantly
- [ ] Detection results change based on new filters
- [ ] Can scrub timeline and see updated results
- [ ] All cached frames use new filters
- [ ] Still instant (no Python re-run)

### 8. Playback from Cache
- [ ] With frames cached, click Play
- [ ] Video plays at ~25 FPS from cache
- [ ] Smooth playback
- [ ] Can change speed (1x, 2x, 4x)
- [ ] Faster speeds work correctly
- [ ] Can pause/resume anytime

### 9. Mode Switching
- [ ] Start in live mode (upload video)
- [ ] Process some frames
- [ ] Click "Load Detections" to load pre-compute JSON
- [ ] Mode switches to pre-compute
- [ ] "Live Mode" badge disappears
- [ ] Can still tune filters
- [ ] Can go back to live mode (upload new video)

### 10. Export Config
- [ ] After tuning filters, go to Config tab
- [ ] Click "Save" button
- [ ] Enter config name
- [ ] Config saves successfully
- [ ] Can load saved config later
- [ ] Can export as JSON
- [ ] Can export legacy format
- [ ] Exported config works in production pipeline

## Edge Cases

### Large Video
- [ ] Upload video > 100MB
- [ ] Upload completes (may take time)
- [ ] Can process in segments
- [ ] Cache doesn't overflow memory
- [ ] Can clear cache by refreshing

### Long Processing
- [ ] Start processing long clip (1000+ frames)
- [ ] Can pause midway
- [ ] Cache preserves all processed frames
- [ ] Can resume and continue
- [ ] Progress accurately reflects completion

### Network Issues
- [ ] Stop Python server mid-processing
- [ ] Frontend shows error toast
- [ ] Can still replay cached frames
- [ ] Restart Python server
- [ ] Can resume (if frame not in cache)

### Invalid Video
- [ ] Upload corrupted video
- [ ] Error handled gracefully
- [ ] Clear error message shown
- [ ] Can try uploading different video

### Zero Results
- [ ] Process video with no ball visible
- [ ] No detections shown (expected)
- [ ] No errors in console
- [ ] Canvas shows empty frame
- [ ] Stats show 0 detected frames

### Filter Extremes
- [ ] Set confidence threshold to 1.0 (rejects all)
- [ ] Apply → No detections shown
- [ ] Set threshold to 0.0 (accepts all)
- [ ] Apply → All detections shown (including FPs)
- [ ] Reset to defaults works

## Performance Tests

### Processing Speed
- [ ] CPU mode: ~0.5-1 FPS (expected)
- [ ] GPU mode: ~5-10 FPS (expected)
- [ ] Cache replay: > 30 FPS (instant)
- [ ] Filter apply: < 100ms

### Memory Usage
- [ ] Monitor browser memory
- [ ] 1000 cached frames: ~5-10 MB (acceptable)
- [ ] No memory leaks during long sessions
- [ ] Refreshing page clears cache

### Responsiveness
- [ ] UI remains responsive during processing
- [ ] Can interact with filters while processing
- [ ] Stop button works immediately
- [ ] No UI freezing

## Browser Compatibility

### Chrome/Edge
- [ ] All features work
- [ ] No console errors
- [ ] Performance good

### Firefox
- [ ] All features work
- [ ] No console errors
- [ ] Performance acceptable

### Safari
- [ ] All features work
- [ ] Video upload works
- [ ] Canvas rendering correct

## Integration Tests

### With Backend Proxy (Optional)
- [ ] Backend proxy endpoints work
- [ ] `/api/inference/health` responds
- [ ] `/api/inference/upload-video` proxies correctly
- [ ] `/api/inference/video/:id/detect/:frame` works
- [ ] Logs show proxy activity

### With WebSocket (Optional)
- [ ] WebSocket connects successfully
- [ ] Real-time updates work
- [ ] Config sync works
- [ ] Disconnection handled gracefully

### With Pre-compute Mode
- [ ] Can load pre-computed JSON
- [ ] Can switch to live mode
- [ ] Can switch back to JSON mode
- [ ] No conflicts between modes

## Documentation Verification

### User Guides
- [ ] README.md updated with live mode
- [ ] LIVE_INFERENCE_GUIDE.md complete
- [ ] IMPLEMENTATION_SUMMARY.md accurate
- [ ] ARCHITECTURE_DIAGRAMS.md clear

### Code Documentation
- [ ] .github/copilot-instructions.md updated
- [ ] Inline comments explain key functions
- [ ] Function signatures clear
- [ ] No TODO comments left

## Production Readiness

### Error Handling
- [ ] All fetch() calls have try/catch
- [ ] User-friendly error messages
- [ ] No unhandled promise rejections
- [ ] Console errors are actionable

### User Experience
- [ ] Loading states clear
- [ ] Progress indicators accurate
- [ ] Success/error toasts helpful
- [ ] No blocking operations

### Code Quality
- [ ] No TypeScript/ESLint errors
- [ ] Consistent code style
- [ ] No console.log() in production code
- [ ] No commented-out code

### Security
- [ ] No XSS vulnerabilities
- [ ] File upload size limited
- [ ] No sensitive data exposed
- [ ] CORS configured correctly

## Sign-off

- [ ] All critical tests passed
- [ ] No blocking issues found
- [ ] Documentation complete
- [ ] Ready for user testing

---

## Test Results

**Date**: _______________
**Tester**: _______________
**Environment**: _______________

**Summary**:
- Tests passed: ____ / 80
- Issues found: ____
- Blockers: ____

**Notes**:
_______________________________________________________________
_______________________________________________________________
_______________________________________________________________
