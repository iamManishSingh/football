# Ball Detection Workbench - Complete Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                     BALL DETECTION WORKBENCH                        │
│                    Complete System Architecture                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌──────────────────┐
│  Python Server  │    │   Node Backend  │    │  Svelte Frontend │
│   (Port 8000)   │◄───┤   (Port 3001)   │◄───┤   (Port 5173)    │
│                 │    │  WebSocket 3002 │    │                  │
│  - RF-DETR      │    │  - Frame Proc   │    │  - UI            │
│  - FastAPI      │    │  - Config CRUD  │    │  - Filter Panel  │
│  - Video Store  │    │  - Proxy (opt)  │    │  - Canvas        │
└─────────────────┘    └─────────────────┘    └──────────────────┘
        │                       │                       │
        │                       │                       │
        └───────────────────────┴───────────────────────┘
                               │
                    ┌──────────┴──────────┐
                    │   shared/ modules   │
                    │  (Single Source of  │
                    │      Truth)         │
                    │                     │
                    │  - ball-filter-     │
                    │    rfdetr.js        │
                    │  - ball-filter-     │
                    │    config.js        │
                    │  - ball-filter-     │
                    │    utils.js         │
                    └─────────────────────┘
```

## Two Operating Modes

### MODE 1: Pre-computed Detections (Offline)

```
┌─────────────────────────────────────────────────────────────┐
│                    OFFLINE WORKFLOW                         │
└─────────────────────────────────────────────────────────────┘

Step 1: Generate Detections (One-time)
────────────────────────────────────────
┌──────────┐
│  Video   │
│  File    │
└────┬─────┘
     │
     ▼
┌─────────────────────┐
│ Python Script       │
│ precompute.py       │
│                     │
│ - Loads video       │
│ - Runs RF-DETR      │
│ - Saves to JSON     │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ detections.json     │
│                     │
│ {                   │
│   video_info: {...} │
│   frames: [         │
│     { frame_idx,    │
│       bboxes,       │
│       confidences,  │
│       classIds }    │
│   ]                 │
│ }                   │
└─────────┬───────────┘
          │
          │ User clicks "Load Detections"
          │
          ▼

Step 2: Workbench (Instant Replay)
───────────────────────────────────
┌─────────────────────────────────────────┐
│           Workbench Frontend            │
│                                         │
│  ┌─────────────────────────────┐       │
│  │   Load JSON into memory     │       │
│  └─────────────┬───────────────┘       │
│                │                        │
│                ▼                        │
│  ┌─────────────────────────────┐       │
│  │  For each frame:            │       │
│  │                             │       │
│  │  JSON → Filter Pipeline →  │       │
│  │         Display             │       │
│  │                             │       │
│  │  INSTANT (no Python call)   │       │
│  └─────────────────────────────┘       │
│                                         │
│  User actions:                          │
│  - Scrub timeline → INSTANT             │
│  - Change filters → INSTANT             │
│  - Play at any speed → INSTANT          │
└─────────────────────────────────────────┘

Pros: ✅ Instant replay, ✅ Full video, ✅ No server needed
Cons: ❌ Requires pre-processing, ❌ Large JSON files
```

### MODE 2: Live Inference (Real-time)

```
┌─────────────────────────────────────────────────────────────┐
│                  LIVE INFERENCE WORKFLOW                    │
└─────────────────────────────────────────────────────────────┘

Step 1: Upload & Setup
──────────────────────
┌──────────┐
│  User    │
│  Uploads │
│  Video   │
└────┬─────┘
     │
     ▼
┌─────────────────────┐
│ Python Server       │
│ /upload-video       │
│                     │
│ - Stores video      │
│ - Extracts info     │
│ - Returns video_id  │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ Frontend            │
│                     │
│ Prompts user:       │
│ "Start time?"       │
│ "End time?"         │
│                     │
│ Sets processingRange│
└─────────────────────┘

Step 2: Live Processing (First Play)
─────────────────────────────────────
┌─────────────────────────────────────────────────────┐
│  FOR each frame in range:                           │
│                                                     │
│  1. Frontend → Python /video/{id}/detect/{frame}   │
│     ├─ Python runs RF-DETR on frame                │
│     └─ Returns { bboxes, confidences, classIds }   │
│                                                     │
│  2. Frontend caches raw detection:                 │
│     detectionCache[frameIdx] = rawDetection        │
│                                                     │
│  3. Frontend applies filters:                      │
│     rawDetection → BallFilterPipeline → result     │
│                                                     │
│  4. Display on canvas                              │
│     - Green box: detected ball                     │
│     - Red boxes: rejected detections               │
│                                                     │
│  5. Update progress: "Processing 45%"              │
│                                                     │
│  ⏸️  User can PAUSE at any time                    │
└─────────────────────────────────────────────────────┘
       │
       │ Cache fills as frames process
       │
       ▼
┌─────────────────────────────────────────────────────┐
│  detectionCache = {                                 │
│    0: { bboxes: [...], confidences: [...] },       │
│    1: { ... },                                      │
│    2: { ... },                                      │
│    ...                                              │
│    150: { ... }  ← 150 frames cached                │
│  }                                                  │
└─────────────────────────────────────────────────────┘

Step 3: Pause & Tune (Instant Replay)
──────────────────────────────────────
User clicks STOP or processing completes

┌─────────────────────────────────────────────────────┐
│  NOW: All cached frames can be replayed instantly  │
│                                                     │
│  User actions:                                      │
│                                                     │
│  1. Adjust filter slider                           │
│     └─ Confidence: 0.25 → 0.35                     │
│                                                     │
│  2. Click "Apply"                                  │
│     └─ Re-process ALL cached frames                │
│        (takes milliseconds, not seconds!)          │
│                                                     │
│  3. Scrub timeline                                 │
│     └─ Jump to frame 75 → INSTANT                  │
│                                                     │
│  4. Play/pause                                     │
│     └─ Smooth 25fps playback from cache            │
│                                                     │
│  Flow:                                              │
│  Cache → Filters → Display                         │
│  (NO Python server call!)                          │
└─────────────────────────────────────────────────────┘

Step 4: Resume Processing (Optional)
─────────────────────────────────────
User clicks "Start/Resume Inference"

┌─────────────────────────────────────────────────────┐
│  Continue from last frame:                          │
│                                                     │
│  FOR frame 151 to 300:                             │
│    - Fetch from Python                             │
│    - Cache                                          │
│    - Filter & display                              │
│                                                     │
│  Cache grows: 150 → 300 frames                     │
└─────────────────────────────────────────────────────┘

Pros: ✅ No pre-processing, ✅ Flexible ranges, ✅ Real-time feedback
Cons: ❌ Slower first play, ❌ Requires Python server
```

## Hybrid Workflow (Best of Both Worlds)

```
┌─────────────────────────────────────────────────────────────┐
│              RECOMMENDED WORKFLOW                           │
└─────────────────────────────────────────────────────────────┘

Phase 1: Initial Testing (Live Mode)
─────────────────────────────────────
Use live inference for quick iteration:
- Upload video
- Process 10-20 seconds only
- Tune filters rapidly
- Export config when satisfied

Phase 2: Validation (Pre-compute Mode)
───────────────────────────────────────
Generate full video detections:
- Run precompute.py on full video
- Load JSON in workbench
- Verify config works across entire video
- Adjust if needed

Phase 3: Production (Exported Config)
──────────────────────────────────────
Use tuned config in pipeline:
- Import config.json
- Use same shared/ filter code
- Guaranteed same behavior

┌─────────────────────────────────────┐
│  Time Savings:                      │
│  - Live: 5 min (30s clip)           │
│  - Pre-compute: 30 min (full video) │
│  - Total: 35 min                    │
│                                     │
│  vs. Full pre-compute only:         │
│  - Multiple iterations: 2+ hours   │
└─────────────────────────────────────┘
```

## Cache Behavior

```
┌─────────────────────────────────────────────────────────────┐
│                   DETECTION CACHE                           │
└─────────────────────────────────────────────────────────────┘

Structure:
──────────
detectionCache = {
  [frameIdx]: {
    frame_idx: number,
    time: number,
    bboxes: [[x, y, w, h], ...],
    confidences: [0.85, 0.72, ...],
    classIds: [32, 32, ...]
  }
}

Operations:
───────────
✅ ADD: When frame processed from Python
   detectionCache[frameIdx] = rawDetection

✅ READ: When replaying or scrubbing
   if (detectionCache[frameIdx]) {
     processFromCache(frameIdx)  // INSTANT
   }

✅ PERSIST: Cache survives filter changes
   User changes filters → Re-process cache → No Python call!

❌ CLEAR: Only when:
   - User uploads new video
   - User refreshes page
   - User switches to pre-compute mode

Size Tracking:
──────────────
Badge shows: "{cacheSize} cached"
Example: "150 cached" = 150 frames ready for instant replay

Memory Usage:
─────────────
Typical: ~5-10 KB per frame
1000 frames ≈ 5-10 MB (minimal!)
```

## Filter Pipeline (Single Source of Truth)

```
┌─────────────────────────────────────────────────────────────┐
│          shared/ball-filter-rfdetr.js                       │
│          (Used by BOTH modes)                               │
└─────────────────────────────────────────────────────────────┘

Input: { ball: { bboxes, confidences, classIds }, image, time }

Stage 1: Preprocessing (optional)
  └─ CLAHE, sharpening, gamma

Stage 2: SAHI (optional)
  └─ Tiled inference for small balls

Stage 3: Basic Filters
  └─ Confidence threshold
  └─ Size (min/max area)
  └─ Aspect ratio (circular check)

Stage 3E: ROI Mask (optional)
  └─ Exclude top/bottom
  └─ Custom polygon

Stage 4: Appearance (optional)
  └─ Circularity score
  └─ Color validation
  └─ Player overlap

Stage 4.5: Static Object Rejection
  └─ Track stationary objects
  └─ Reject if stuck in same spot

Stage 5: Single Ball Selection
  └─ Pick best candidate
  └─ Weighted: proximity + confidence + shape

Stage 6: Kalman Tracking (optional)
  └─ Predict position
  └─ Handle occlusions
  └─ Gravity model for aerial balls

Stage 7: Trajectory Smoothing (optional)
  └─ EMA smoothing
  └─ Physics validation

Output: { ball, meta, debug }
  └─ ball: Final detected ball
  └─ meta: { source: "detected" | "predicted" | "lost" }
  └─ debug: { rejected: [...], stage_counts: {...} }
```

## WebSocket Communication (Optional)

```
┌─────────────────────────────────────────────────────────────┐
│          Backend ↔ Frontend (Real-time Sync)                │
└─────────────────────────────────────────────────────────────┘

Frontend → Backend:
───────────────────
{ type: "update_config", config: {...} }
{ type: "seek_frame", frame: 42 }
{ type: "play", startFrame: 0, speed: 1 }
{ type: "pause" }
{ type: "step", direction: 1 }
{ type: "reset" }

Backend → Frontend:
───────────────────
{ type: "connected", config: {...}, detectionsLoaded: true }
{ type: "frame_result", ball: {...}, meta: {...}, debug: {...} }
{ type: "config_updated", config: {...} }
{ type: "playback_end" }
{ type: "reset_complete" }

Note: WebSocket is optional in live mode
      Frontend can work standalone with Python server
```

## File Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    FILE ORGANIZATION                        │
└─────────────────────────────────────────────────────────────┘

shared/  ← Single Source of Truth
├── ball-filter-rfdetr.js    (filter pipeline)
├── ball-filter-config.js    (config schema)
└── ball-filter-utils.js     (utility classes)
     │
     ├─ Imported by Backend (Node.js)
     └─ Imported by Frontend (Browser)

Python only generates JSON:
───────────────────────────
Video → RF-DETR → JSON → JavaScript filters → Display

No Python in filter logic!
─────────────────────────
✅ Consistent behavior
✅ Fast filter tuning
✅ Easy to debug
```
