# Live Inference Workflow Guide

This guide explains how to use the **Live Inference Mode** in the Ball Detection Filter Tuning Workbench.

## Overview

The workbench supports two modes of operation:

1. **Pre-computed Mode**: Load a pre-generated `detections.json` file (fast, offline)
2. **Live Inference Mode**: Upload video → RF-DETR processes frames live → Cache & display results in real-time

## Live Inference Architecture

```
┌────────────────────────────────────────────────────────────┐
│                                                            │
│   User uploads video                                       │
│       │                                                    │
│       ▼                                                    │
│   ┌─────────────────────────────────┐                      │
│   │ OPTION: Process full / Select   │                      │
│   │ clip range (start - end time)   │                      │
│   └─────────────────────────────────┘                      │
│       │                                                    │
│       ▼                                                    │
│   LIVE MODE (first play)                                   │
│   ┌─────────────────────────────────┐                      │
│   │ Each frame:                     │                      │
│   │  Video ──► Python RF-DETR ──►──┬──► Filters ──► Canvas│
│   │                                │                       │
│   │                        Cache store                     │
│   │                     (in-memory array)                  │
│   │                                                        │
│   │ User sees results AS inference runs.                   │
│   │ Can pause anytime and start tuning.                    │
│   └─────────────────────────────────┘                      │
│       │                                                    │
│       │ (cache fills up as video plays)                    │
│       ▼                                                    │
│   REPLAY MODE (after caching, or on any cached section)    │
│   ┌─────────────────────────────────┐                      │
│   │ Each frame:                     │                      │
│   │  Cache ──────────────►──► Filters ──► Canvas           │
│   │  (no Python!)                                          │
│   │                                                        │
│   │ Change slider + Apply → INSTANT re-render              │
│   │ Scrub forward/backward → INSTANT                       │
│   │ Play at 2x/4x → INSTANT                               │
│   └─────────────────────────────────┘                      │
│       │                                                    │
│       ▼                                                    │
│   SAVE CONFIG                                              │
│   ┌─────────────────────────────────┐                      │
│   │ Export config.json              │                      │
│   │ Import into production pipeline │                      │
│   │ Same ball-filter-rfdetr.js      │                      │
│   └─────────────────────────────────┘                      │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

## Setup

### 1. Install Python Dependencies

```bash
cd ball-workbench/python-bridge
pip install -r requirements.txt
```

Required packages:
- `rfdetr>=1.1.0` - RF-DETR model
- `opencv-python>=4.8.0` - Video processing
- `fastapi` - REST API server
- `uvicorn` - ASGI server
- `python-multipart` - File upload support

### 2. Start the Python Inference Server

```bash
cd ball-workbench/python-bridge
python live_server.py
```

Server starts on `http://localhost:8000` and loads the RF-DETR model.

### 3. Start Backend & Frontend (as usual)

```bash
# Terminal 2: Backend
cd ball-workbench/backend
npm run dev

# Terminal 3: Frontend
cd ball-workbench/frontend
npm run dev
```

## Using Live Inference

### Step 1: Upload Video

1. Open workbench at `http://localhost:5173`
2. Check that "RF-DETR Ready" badge appears (Python server is running)
3. Click **"Upload Video (Live)"** button
4. Select your video file

### Step 2: Select Processing Range (Optional)

After upload, you'll be prompted to select a time range:

```
Enter start time in seconds (0 to 180): 30
Enter end time in seconds (-1 for full video): 90
```

This will process frames 30s-90s only (saves time for testing).

**Tip**: For initial testing, process just 10-20 seconds to quickly iterate on filter settings.

### Step 3: Start Live Inference

Click **"Start/Resume Inference"** button or confirm the prompt.

You'll see:
- Progress indicator: "Processing: 45%"
- Status badge: "Live Mode" + "X cached"
- Video canvas showing detections in real-time
- Filter results applied instantly

### Step 4: Pause & Tune Filters

**At any time**, click **Stop** to pause processing.

Now you can:
- Adjust filter sliders (confidence, size, static rejection, etc.)
- Click **Apply** → Cached frames re-process instantly (no Python re-run!)
- Scrub timeline to any cached frame
- Play/pause at normal speed or 2x/4x

### Step 5: Resume or Process More

- Click **"Start/Resume Inference"** to continue from where you stopped
- Cache persists - already-processed frames load instantly
- Process additional ranges as needed

### Step 6: Export Config

Once satisfied with filter tuning:
1. Go to **Config** tab
2. Click **Save** to save locally
3. Or **Export Legacy** to generate code for production pipeline

## Key Features

### Progressive Caching

- Frames cached as they're processed
- Cache badge shows count: "150 cached"
- Cached frames load instantly when scrubbing/replaying
- Cache persists across filter changes (no re-inference!)

### Instant Filter Tuning

When you adjust filters and click Apply:
- Cached frames re-process in milliseconds
- No Python server involved
- See immediate effect on detection quality

### Two-Mode Operation

**Live Mode** (first pass):
```
Video → Python RF-DETR → Cache → Filters → Display
        (slow, ~1 sec/frame)
```

**Replay Mode** (after caching):
```
Cache → Filters → Display
(instant, ~60 FPS)
```

## Python Server Endpoints

The frontend calls these endpoints directly (backend optionally proxies):

### Health Check
```
GET http://localhost:8000/health
→ { "status": "ok", "model": "rfdetr-base" }
```

### Upload Video
```
POST http://localhost:8000/upload-video
Body: FormData { video: File }
→ { "video_id": "abc123", "video_info": {...} }
```

### Detect Frame
```
GET http://localhost:8000/video/{video_id}/detect/{frame_idx}?threshold=0.1&class_id=32
→ { 
    "frame_idx": 42,
    "time": 1.68,
    "bboxes": [[x, y, w, h], ...],
    "confidences": [0.85, ...],
    "classIds": [32, ...]
  }
```

### Get Frame Image
```
GET http://localhost:8000/video/{video_id}/frame/{frame_idx}
→ JPEG image bytes
```

## Troubleshooting

### "Python inference server not available"

**Problem**: Frontend can't reach Python server

**Solutions**:
1. Check Python server is running: `ps aux | grep live_server`
2. Verify port 8000 is not blocked: `curl http://localhost:8000/health`
3. Check firewall/network settings
4. Look for errors in Python server terminal

### "Model loading failed"

**Problem**: RF-DETR model can't load

**Solutions**:
1. Ensure `rfdetr` package is installed: `pip install rfdetr>=1.1.0`
2. Check model file exists (auto-downloads on first run)
3. Try loading model manually:
   ```python
   from rfdetr import RFDETRBase
   model = RFDETRBase()
   ```

### Slow inference (>2 sec/frame)

**Problem**: Processing is too slow

**Solutions**:
1. **Use GPU**: Ensure PyTorch with CUDA is installed
2. **Lower resolution**: Process smaller video or downscale
3. **Reduce threshold**: Higher threshold = fewer detections = faster
4. **Process shorter clips**: Start with 10-20 second clips
5. **Use pre-compute mode**: Generate JSON offline with `precompute.py`

### Out of memory during long videos

**Problem**: Cache grows too large

**Solutions**:
1. Process in smaller segments (e.g., 30s at a time)
2. Clear cache and reload: Refresh page
3. Use pre-compute mode for full videos
4. Increase system RAM or reduce video resolution

## Performance Tips

### For Fast Iteration

1. **Process 10-20 seconds only** during tuning
2. Select interesting sections (ball visible, fast movement)
3. Use cached replay extensively - it's instant!
4. Only re-process with Python when changing RF-DETR threshold

### For Full Video Processing

1. **Use pre-compute mode**:
   ```bash
   python precompute.py --video match.mp4 --output det.json --start 0 --end -1
   ```
2. Load `det.json` in workbench
3. Full instant replay from frame 0

### Hybrid Approach

1. Pre-compute full video offline
2. Load JSON for overview
3. If needed, upload video for live mode to test specific clips
4. Switch between modes as needed

## Comparison: Live vs Pre-compute

| Feature | Live Inference | Pre-compute |
|---------|---------------|-------------|
| **Setup** | Upload video | Run script first |
| **First play** | Slow (processes live) | Instant (pre-cached) |
| **Filter tuning** | Instant (from cache) | Instant |
| **Flexibility** | Process any range | Fixed range |
| **Use case** | Quick testing, small clips | Full videos, production |

**Recommendation**: Use live inference for development/testing, pre-compute for production analysis.

## Example Session

```bash
# Terminal 1: Start Python server
cd ball-workbench/python-bridge
python live_server.py
# → Server running on http://localhost:8000

# Terminal 2: Start backend
cd ball-workbench/backend
npm run dev
# → Backend on :3001, WebSocket on :3002

# Terminal 3: Start frontend
cd ball-workbench/frontend
npm run dev
# → Frontend on http://localhost:5173
```

In browser:
1. ✅ See "RF-DETR Ready" badge
2. Click "Upload Video (Live)"
3. Select `test_match.mp4`
4. Enter range: 30s to 60s
5. Click "Start/Resume Inference"
6. Watch live processing (30 seconds = ~750 frames)
7. Pause at frame 500
8. Adjust filters → Apply
9. Scrub timeline (instant replay!)
10. Resume processing to frame 1500
11. Export config.json

Total time: ~2-3 minutes for 30s video processing + instant tuning
