# ⚽ Ball Detection Filter Tuning Workbench — Complete Requirements

> **Purpose:** This document captures ALL finalized decisions for building the Ball Detection Filter Tuning Workbench. Hand this to Claude Code for end-to-end development.

---

## 1. PROJECT OVERVIEW

### 1.1 Problem Statement

We have a pre-trained RF-DETR model (COCO weights) running ball detection on football videos. The model works but has 5 key challenges:

| # | Challenge | Description |
|---|-----------|-------------|
| 1 | False Positives | Shoes, socks, bald heads detected as football |
| 2 | Aerial Ball Lost | When ball goes aerial, detection lost; not recovered when ball returns to ground |
| 3 | Outside Pitch FPs | Objects outside the pitch (crowd, scoreboard, ads) detected as ball |
| 4 | Fast Ball Desync | When ball moves fast, detection jitters or lags |
| 5 | Cross-Video Inconsistency | Config works on one video but fails on another (different angle/light/shadow/ball size) |

### 1.2 Solution

Build a **Filter Tuning Workbench** — a visual tool where the user:
1. Uploads a football video and pre-computed detection JSON
2. Sees RF-DETR detections live on a canvas
3. Toggles between **Base Model** (raw RF-DETR) and **Filter-Tuned** mode
4. Enables/disables filter groups and adjusts individual parameters with sliders
5. Sees the effect in real-time on the canvas (detected ball, rejected boxes, reasons)
6. Saves the tuned config as JSON
7. Loads that JSON in their production pipeline — **same filter code, same behavior**

### 1.3 Key Design Principle

**`ball-filter-rfdetr.js` is the single source of truth.** The workbench does NOT have its own filter logic. It imports and calls the same `BallFilterPipeline` class. The production pipeline uses the same file. Only the **JSON config** moves between them.

### 1.4 Hybrid Cache Approach (FINALIZED)

We use a **Hybrid approach** — NOT pre-compute-only, NOT fully-live-only:

- **First Play (Live Mode):** Each frame goes through RF-DETR inference → filters → canvas. As frames are processed, raw detections are cached in memory.
- **Pause & Tune (Instant Mode):** User pauses, adjusts filter sliders, clicks Apply. The current frame is instantly re-processed from cache — no Python/model re-run needed.
- **Replay Mode:** Once a section is cached, user can scrub to any cached frame, change any filter, and see results instantly. Play at 2x/4x speed.
- **For Phase 1 MVP:** We use pre-computed `detections.json` (from a Python script) loaded into the workbench. This gives instant replay from the start. Live Python inference is Phase 4.

---

## 2. TECH STACK (FINALIZED)

| Layer | Technology | Why |
|-------|-----------|-----|
| **Frontend** | SvelteKit (Svelte 5) | Reactive sliders, compiled to vanilla JS, fast canvas |
| **Backend** | Node.js (Express) | Same language as shared filter code (JavaScript) |
| **WebSocket** | `ws` (Node.js) | Real-time frame streaming + filter hot-reload |
| **Filter Engine** | JavaScript (shared/) | Single source of truth, runs in both backend AND browser |
| **RF-DETR Inference** | Python (`rfdetr` package) | Pre-compute script; live bridge in Phase 4 |
| **Video Processing** | ffmpeg (CLI) | Frame extraction from video files |
| **Styling** | Custom CSS (dark theme) | Professional, polished, no Tailwind dependency |

> **Important:** The filter engine is pure JavaScript (no Python dependency at filter-time). Python is only used for RF-DETR inference (precompute.py). This means the workbench can run filter tuning 100% in the browser if the backend is unavailable.

---

## 3. FILE STRUCTURE

```
ball-workbench/
├── shared/                              ← SINGLE SOURCE OF TRUTH
│   ├── ball-filter-rfdetr.js            ← All filter logic (BallFilterPipeline class)
│   ├── ball-filter-config.js            ← Config schema, defaults, presets, save/load utils
│   └── ball-filter-utils.js             ← Stateful classes: StaticRejecter, KalmanTracker,
│                                           ROIMask, CircularityChecker, ColorValidator,
│                                           TrajectoryValidator
│
├── frontend/                            ← SvelteKit app
│   ├── src/
│   │   ├── routes/
│   │   │   └── +page.svelte             ← Main workbench page
│   │   ├── lib/
│   │   │   ├── components/
│   │   │   │   ├── VideoCanvas.svelte   ← Canvas with detection overlays
│   │   │   │   ├── FilterPanel.svelte   ← All filter groups with sliders
│   │   │   │   ├── FilterGroup.svelte   ← Reusable: parent toggle + child params
│   │   │   │   ├── StatsPanel.svelte    ← Live detection statistics
│   │   │   │   ├── ConfigManager.svelte ← Presets, save/load/export/import
│   │   │   │   ├── TransportBar.svelte  ← Play/pause/step/seek/speed controls
│   │   │   │   └── DebugOverlay.svelte  ← Toggle chips for overlay layers
│   │   │   └── stores/
│   │   │       ├── config.js            ← Svelte store wrapping filter config state
│   │   │       ├── pipeline.js          ← Processing state, current frame, stats
│   │   │       └── websocket.js         ← WebSocket connection management
│   │   ├── app.html
│   │   └── app.css                      ← Global styles, CSS variables, dark theme
│   ├── static/
│   ├── svelte.config.js
│   ├── vite.config.js
│   └── package.json
│
├── backend/
│   ├── server.js                        ← Express + WebSocket server
│   ├── frame-processor.js               ← Imports shared/ pipeline, processes frames
│   ├── config-store.js                  ← Config CRUD (save/load/delete JSON files)
│   ├── video-handler.js                 ← Video upload, ffmpeg frame extraction
│   └── package.json
│
├── python-bridge/
│   ├── precompute.py                    ← RF-DETR inference → detections.json
│   ├── live_server.py                   ← (Phase 4) FastAPI live inference sidecar
│   └── requirements.txt
│
├── models/                              ← User places RF-DETR model files here
│   └── README.md
├── configs/                             ← Saved filter config JSON files
├── uploads/                             ← Uploaded video files
├── sample_detections.json               ← 100-frame test data (works immediately)
└── README.md
```

---

## 4. FILTER PIPELINE ARCHITECTURE (8 STAGES)

Each video frame is processed through these stages sequentially. Each stage checks its `enabled` flag and is skipped if disabled.

### Stage 0: Video Initialization (one-time per video)
- Runs on first 50–100 frames before main loop
- Auto-detects: pitch mask (HSV green segmentation), average brightness, expected ball size range
- Auto-calibrates: adaptive confidence threshold, SAHI slice dimensions
- Classifies camera type: STATIC / PAN-TILT / HANDHELD
- Output: calibration parameters used by subsequent stages

### Stage 1: Frame Preprocessing (every frame, if enabled)
- **CLAHE:** Contrast enhancement for shadows/floodlights (clip_limit: 1.0–6.0)
- **Sharpening:** Unsharp mask for motion blur recovery (strength: 0.0–1.0)
- **Gamma correction:** Brightness normalization (gamma: 0.5–2.5)
- **Multi-frame blend:** Average 2–3 frames for fast-ball visibility (optional)

### Stage 2: RF-DETR Inference
- Run model with LOW threshold (0.10–0.25) to catch faint detections
- SAHI tiled inference (optional): slice image, run on each tile, merge with NMS
- Multi-scale inference (optional): run at 2–3 resolutions, merge
- Output: raw detections (bboxes, confidences, classIds)

### Stage 3: Basic Filters (CRITICAL — fixes ~70% of issues)
- **3A. Class ID filter:** Keep only class_id == 32 or 37 ("sports ball")
- **3B. Confidence threshold:** Reject if score < threshold (0.25–0.75). EXCEPTION: if detection is near Kalman-predicted position, use lower rescue_threshold (0.10–0.35)
- **3C. Size filter:** Reject if bbox area outside [min_ball_area_ratio, max_ball_area_ratio] × frame_area
- **3D. Aspect ratio filter:** Reject if width/height outside [0.5, 2.0] — ball is ~square, shoes are elongated
- **3E. ROI / Pitch mask:** Reject if detection center is outside pitch polygon. Also: exclude_top_ratio, exclude_bottom_ratio for scoreboard/ad areas

### Stage 4: Appearance Filters (eliminates shoes, socks, bald heads)
- **4A. Circularity score:** Based on aspect ratio heuristic (0–1 scale). Reject if < circularity_min (0.4)
- **4B. Color validation:** Check if detection region is light-colored (ball is typically white). Reject if whiteness < threshold
- **4C. Player overlap:** If detection overlaps >70% with a person bounding box → likely shoe → reject
- **4D. Texture analysis:** (optional) Gradient magnitude check for ball panel texture

### Stage 4.5: Static Object Rejection
- Rolling window of recent detection positions
- If a candidate appears in ≥ max_hit_ratio of recent frames at nearly the same spot → static object (corner flag, logo, pitch marking) → reject
- Parameters: history_frames (14), cluster_radius_px (28), max_hit_ratio (0.72), warmup_frames (4)

### Stage 5: Single Ball Selection
- Only ONE ball on the pitch at a time
- If 0 candidates → pass to Kalman predictor
- If 1 candidate → use it
- If multiple → pick best using weighted scoring: proximity_weight (to Kalman prediction) + confidence_weight + shape_weight
- **Max-jump safety:** If selected detection is > max_jump_distance (200px) from last known position → reject, use Kalman prediction instead

### Stage 6: Kalman Filter Tracking
- State vector: [x, y, vx, vy] (position + velocity)
- When detection IS available: Kalman predict + update with measurement
- When detection is MISSING: Kalman predict only (no update), with gravity model for aerial balls (parabolic arc)
- Track lifecycle: max_lost_frames (60), confidence decays linearly, search radius grows per lost frame
- Occlusion handler: detect when ball was near player → disappeared → predict through player

### Stage 7: Trajectory Smoothing & Validation
- **EMA smoothing:** smoothed_pos = α × detected + (1-α) × previous (α = 0.6–0.8)
- **Gap interpolation:** linear for 1–5 frame gaps, cubic spline for 6–20 frames
- **Physics validation:** reject positions implying impossible velocity (>80 px/frame) or acceleration (>40 px/frame²)
- **Velocity estimation:** compute vx, vy, speed, direction per frame

### Stage 8: Output
Per-frame output structure:
```json
{
  "ball": { "bboxes": [[x,y,w,h]], "confidences": [0.82], "classIds": [37] },
  "meta": {
    "source": "detected|predicted|interpolated",
    "frame_index": 847,
    "track_age": 234,
    "ball_position": { "x": 623.4, "y": 341.2 }
  },
  "debug": {
    "raw_count": 7,
    "rejected": [{ "bbox": [...], "reason": "conf:0.23", "conf": 0.23 }],
    "stage_counts": { "after_basic": 3, "after_roi": 2, "after_appearance": 1, "final": 1 },
    "kalman_predicted": { "x": 620.1, "y": 342.8 },
    "velocity": { "vx": 12.3, "vy": -5.1 }
  }
}
```

---

## 5. ALL TUNABLE PARAMETERS

### 5.1 Filter Group: Basic Filters
| Parameter | Default | Range | Step | Type | Solves |
|-----------|---------|-------|------|------|--------|
| confidence_threshold | 0.35 | 0.05–0.95 | 0.01 | range | #1 FPs |
| rescue_threshold | 0.15 | 0.05–0.50 | 0.01 | range | #2 Aerial |
| rescue_radius_px | 80 | 20–300 | 5 | range | #2 Aerial |
| min_ball_area_ratio | 0.000015 | 0.000005–0.001 | 0.000005 | range | #1 FPs |
| max_ball_area_ratio | 0.0048 | 0.001–0.02 | 0.0001 | range | #1 FPs |
| min_aspect_ratio | 0.50 | 0.2–0.9 | 0.01 | range | #1 Shoes |
| max_aspect_ratio | 1.90 | 1.1–3.0 | 0.01 | range | #1 Shoes |

### 5.2 Filter Group: ROI / Pitch Mask
| Parameter | Default | Range | Step | Type | Solves |
|-----------|---------|-------|------|------|--------|
| exclude_top_ratio | 0.08 | 0–0.3 | 0.01 | range | #3 Outside pitch |
| exclude_bottom_ratio | 0.05 | 0–0.3 | 0.01 | range | #3 Outside pitch |
| pitch_margin_pct | 5 | 0–20 | 1 | range | #3 Outside pitch |

### 5.3 Filter Group: Appearance
| Parameter | Default | Range | Step | Type | Solves |
|-----------|---------|-------|------|------|--------|
| circularity_enabled | true | — | — | toggle | #1 Shoes |
| circularity_min | 0.4 | 0.1–0.9 | 0.01 | range | #1 Shoes |
| color_validation_enabled | false | — | — | toggle | #1 FPs |
| color_whiteness_threshold | 0.3 | 0.1–0.8 | 0.01 | range | #1 FPs |
| player_overlap_enabled | false | — | — | toggle | #1 Shoes |
| player_overlap_iou | 0.7 | 0.3–0.95 | 0.01 | range | #1 Shoes |

### 5.4 Filter Group: Static Object Rejection
| Parameter | Default | Range | Step | Type | Solves |
|-----------|---------|-------|------|------|--------|
| history_frames | 14 | 5–60 | 1 | range | #1 Flags/logos |
| cluster_radius_px | 28 | 5–80 | 1 | range | #1 Flags/logos |
| max_hit_ratio | 0.72 | 0.3–0.95 | 0.01 | range | #1 Flags/logos |
| warmup_frames | 4 | 1–20 | 1 | range | #1 Flags/logos |

### 5.5 Filter Group: Kalman Tracking
| Parameter | Default | Range | Step | Type | Solves |
|-----------|---------|-------|------|------|--------|
| max_lost_frames | 60 | 10–120 | 5 | range | #2 Aerial |
| gravity_enabled | true | — | — | toggle | #2 Aerial |
| gravity_strength | 0.5 | 0.1–3.0 | 0.1 | range | #2 Aerial |
| search_radius_base | 50 | 10–200 | 5 | range | #2 Aerial |
| search_radius_growth | 5 | 1–20 | 1 | range | #2 Aerial |
| confidence_decay_rate | 0.02 | 0.005–0.1 | 0.005 | range | #2 Aerial |
| process_noise | 0.03 | 0.005–0.2 | 0.005 | range | Tracking |
| measurement_noise | 0.1 | 0.01–1.0 | 0.01 | range | Tracking |

### 5.6 Filter Group: Trajectory Smoothing
| Parameter | Default | Range | Step | Type | Solves |
|-----------|---------|-------|------|------|--------|
| ema_alpha | 0.7 | 0.2–0.98 | 0.01 | range | #4 Jitter |
| interpolation_max_gap | 20 | 3–60 | 1 | range | #2 Gaps |
| max_valid_speed_px | 80 | 20–200 | 5 | range | #4 Teleport |
| max_valid_accel_px | 40 | 5–100 | 5 | range | #4 Teleport |

### 5.7 Filter Group: Preprocessing
| Parameter | Default | Range | Step | Type | Solves |
|-----------|---------|-------|------|------|--------|
| clahe_enabled | true | — | — | toggle | #5 Lighting |
| clahe_clip_limit | 2.0 | 1.0–6.0 | 0.1 | range | #5 Lighting |
| sharpen_enabled | false | — | — | toggle | #4 Blur |
| sharpen_strength | 0.3 | 0.1–2.0 | 0.1 | range | #4 Blur |
| gamma_enabled | false | — | — | toggle | #5 Brightness |
| gamma_value | 1.0 | 0.3–3.0 | 0.1 | range | #5 Brightness |

### 5.8 Filter Group: SAHI (Tiled Inference)
| Parameter | Default | Range | Step | Type | Solves |
|-----------|---------|-------|------|------|--------|
| slice_width | 640 | 200–1200 | 20 | range | #2 Small ball |
| slice_height | 640 | 200–1200 | 20 | range | #2 Small ball |
| overlap_px | 100 | 20–300 | 10 | range | #2 Small ball |
| iou_threshold | 0.3 | 0.1–0.7 | 0.05 | range | #2 Small ball |

---

## 6. FRONTEND SPECIFICATION

### 6.1 Layout
```
┌─────────────────────────────────────────────────────────────────┐
│ HEADER BAR                                                       │
│ Logo | Mode Toggle (Base/Filtered) | Upload Btns | Stats Summary │
├───────────────────────────────────────────┬─────────────────────┤
│                                           │                     │
│  VIDEO CANVAS                             │  SIDE PANEL         │
│  (with detection overlays)                │  ┌─ Tabs ─────────┐│
│                                           │  │Filters│Stats│Cfg││
│  Canvas badges:                           │  ├─────────────────┤│
│  ● DETECTED (green)                       │  │                 ││
│  ○ PREDICTED (blue)                       │  │ Filter groups   ││
│  ✕ LOST (red)                             │  │ with parent     ││
│  Raw: N | Rejected: M                     │  │ toggle + child  ││
│                                           │  │ sliders         ││
│                                           │  │                 ││
├───────────────────────────────────────────┤  ├─────────────────┤│
│ TRANSPORT BAR                             │  │ Debug toggles   ││
│ ⏮ ▶ ⏭ | Timeline (scrub) | Speed select │  │ [Apply] [Reset] ││
└───────────────────────────────────────────┴─────────────────────┘
```

### 6.2 Mode Toggle

- **Base Model:** All filter groups force-disabled. Only model threshold + class_id active. Filter panel grayed out. This shows raw RF-DETR output.
- **Filter-Tuned:** Filter groups become individually toggleable. Each parent controls its children.
- Switching modes preserves last known filter state.
- All parents OFF in Filter-Tuned mode = identical to Base Model.

### 6.3 Filter Panel — Parent/Child Hierarchy

Each filter group has:
- **Parent toggle (ON/OFF):** Controls the entire group. When OFF, all children are grayed out and not applied. Their values are PRESERVED but not used.
- **Group header:** Clickable to expand/collapse. Shows icon + label + chevron.
- **Child parameters:** Sliders (type: range) and toggles (type: toggle). Only active when parent is ON.
- **Child toggles:** Some parameters like `circularity_enabled` have their own ON/OFF within the group.

UI behavior:
- Parent OFF → all children disabled/grayed, values preserved
- Parent ON → children become interactive
- Changes do NOT auto-apply. User adjusts multiple params, then clicks **Apply** button.
- In paused mode, Apply re-processes current frame instantly.
- Each slider shows current value in monospace font.

### 6.4 Video Canvas

- HTML5 Canvas rendering
- Overlays (individually toggleable via debug chips):
  - **● Detected ball:** Green circle + bounding box + confidence label
  - **○ Predicted position:** Blue dashed circle (Kalman prediction)
  - **✕ Rejected detections:** Red dashed boxes with X marks + reason labels (e.g., "conf:0.23", "area:42", "aspect:3.2", "static", "outside_roi")
  - **▬ ROI mask:** Semi-transparent red overlay on excluded regions
- Status badges in top-left corner: DETECTED/PREDICTED/LOST + raw count + rejected count

### 6.5 Transport Bar

- Buttons: ⏮ (prev frame), ▶/⏸ (play/pause), ⏭ (next frame)
- Timeline bar: clickable to seek. Shows progress (white) + cached extent (blue)
- Time display: current time / total time (formatted M:SS.mm)
- Speed selector: 0.25×, 0.5×, 1×, 2×, 4×
- Keyboard shortcuts: Space (play/pause), ← (prev frame), → (next frame)

### 6.6 Stats Panel (tab)

Live cumulative statistics:
- Detection rate (% of frames with detected ball)
- Predicted count (frames using Kalman prediction)
- Lost frames (no ball at all)
- Total rejected detections
- Frames processed
- Current frame pipeline stages breakdown (after_basic: N, after_roi: N, etc.)
- Current frame rejected list (reason + confidence for each)

### 6.7 Config Panel (tab)

- **Presets:** 5 built-in presets (buttons to load):
  - Raw Model (No Filters)
  - Light Filtering
  - Broadcast Daytime
  - Broadcast Night
  - Wide Angle / Amateur
- **Actions:**
  - Save Config (prompt for name → POST to backend → saves JSON)
  - Export JSON (downloads .json file)
  - Import JSON (upload .json file → loads config)
  - Export Legacy (generates flat `FILTER_CONFIG = {...}` for copy-paste into original ball-filter-rfdetr.js)
  - Reset All (restores DEFAULT_CONFIG)
- **Saved Configs:** List of saved configs with Load and Delete buttons

### 6.8 Styling

- Dark theme (background: #0a0c10 → #1f2433 gradient)
- Font: DM Sans (body) + JetBrains Mono (values, code)
- Accent color: #3b82f6 (blue)
- Status colors: green (#22c55e), red (#ef4444), orange (#f59e0b), purple (#a78bfa)
- All CSS via custom properties (--bg-0, --bg-1, --border, --accent, etc.)
- Responsive: side panel collapses on narrow screens
- Smooth transitions (150ms cubic-bezier)
- Toast notifications for actions (success/error/info)

---

## 7. BACKEND SPECIFICATION

### 7.1 REST API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/upload-video | Upload video file (multipart form) |
| POST | /api/upload-detections | Upload detection JSON file (multipart form) |
| POST | /api/upload-detections-json | Upload detection JSON as raw body |
| GET | /api/frame/:frameIdx | Extract and return a single frame as JPEG |
| POST | /api/process-frame | Process single frame with current/specified config |
| POST | /api/process-range | Process frame range, return all results + stats |
| GET | /api/configs | List all saved configs |
| POST | /api/configs | Save a new config (body: { name, config }) |
| GET | /api/configs/:filename | Load a saved config |
| DELETE | /api/configs/:filename | Delete a saved config |
| GET | /api/presets | List preset names |
| GET | /api/presets/:name | Get a preset config |
| GET | /api/default-config | Get DEFAULT_CONFIG |

### 7.2 WebSocket Protocol

Connection: `ws://localhost:3001`

**Client → Server messages:**
```json
{ "type": "update_config", "config": {...} }
{ "type": "play", "startFrame": 0, "speed": 1 }
{ "type": "pause" }
{ "type": "seek", "frame": 847 }
{ "type": "step", "direction": 1 }   // 1 = forward, -1 = backward
{ "type": "process_current" }
```

**Server → Client messages:**
```json
{
  "type": "frame_result",
  "frameIdx": 847,
  "totalFrames": 45000,
  "time": 33.88,
  "raw": { "count": 7, "bboxes": [...], "confidences": [...] },
  "filtered": { "bboxes": [...], "confidences": [...], "classIds": [...] },
  "meta": { "source": "detected", "frame_index": 847, "track_age": 234 },
  "debug": { "raw_count": 7, "rejected": [...], "stage_counts": {...} }
}
{ "type": "config_updated" }
{ "type": "playback_end" }
```

### 7.3 Frame Processing Flow

```
Client sends "play" or "seek"
    │
    ▼
Server reads frame from detectionCache[frameIdx]
    │
    ▼
pipeline.processFrame({
  ball: { bboxes, confidences },
  image: { width, height },
  time
})
    │  ← Uses shared/ball-filter-rfdetr.js (SAME code as production)
    ▼
Returns { ball, meta, debug }
    │
    ▼
Server sends frame_result via WebSocket
    │
    ▼
Frontend draws on canvas + updates stats
```

### 7.4 Offline Mode

The frontend also has a local processing path. If WebSocket is not connected, it processes frames locally using the same filter algorithm inlined in the HTML. This ensures the workbench works even without the backend running.

---

## 8. SHARED MODULE SPECIFICATION (ball-filter-rfdetr.js)

### 8.1 Public API

```javascript
// For production pipeline (TransformStream):
export function ballFilterStream(config = null) → TransformStream
// config = null uses DEFAULT_CONFIG
// config = saved JSON from workbench

// For workbench (per-frame processing):
export function createPipeline(config = null) → BallFilterPipeline

// BallFilterPipeline methods:
pipeline.processFrame(data) → { ball, meta, debug }
pipeline.updateConfig(newConfig)   // hot-reload config
pipeline.reset()                   // clear tracking state
pipeline.getConfig()               // get current config copy
```

### 8.2 Backward Compatibility

The file must be backward-compatible with the user's existing pipeline. Calling `ballFilterStream()` with no arguments must work identically to the current behavior with hardcoded FILTER_CONFIG.

### 8.3 Config Format

Full JSON config structure (see DEFAULT_CONFIG in ball-filter-config.js):
- `mode`: "base_model" | "filter_tuned"
- `model`: { threshold, class_id }
- `filter_groups`: 8 groups, each with `enabled` (bool) + `params` (object)
- `selection`: { method, weights, max_jump_distance }
- `scene_cut_time_gap`: seconds
- `debug`: bool

### 8.4 Legacy Export

The `toLegacyConfig(config)` function generates a flat `FILTER_CONFIG` object matching the user's original `ball-filter-rfdetr.js` format. This allows zero-change integration for users who only need basic + static filters.

---

## 9. PYTHON PRECOMPUTE SCRIPT (precompute.py)

### 9.1 Usage
```bash
python precompute.py --video match.mp4 --output detections.json
python precompute.py --video match.mp4 --output det.json --start 120 --end 210
python precompute.py --video match.mp4 --output det.json --model large --threshold 0.10
```

### 9.2 Arguments
| Arg | Default | Description |
|-----|---------|-------------|
| --video | (required) | Path to input video |
| --output | (required) | Output JSON path |
| --model | base | RF-DETR variant: base/large/nano/small/medium |
| --threshold | 0.10 | Detection threshold (keep LOW, filter later) |
| --start | 0 | Start time in seconds |
| --end | -1 | End time (-1 = full video) |
| --max-frames | -1 | Max frames to process |
| --class-id | 32 | COCO class ID for sports ball |

### 9.3 Output JSON Format
```json
{
  "video_path": "match.mp4",
  "model": "base",
  "threshold": 0.10,
  "video_info": { "width": 1920, "height": 1080, "fps": 25.0, "total_frames": 45000 },
  "processed_range": { "start_frame": 0, "end_frame": 45000, "frames_processed": 45000 },
  "processing_time_sec": 1234.5,
  "frames": [
    {
      "frame_idx": 0,
      "time": 0.0,
      "bboxes": [[x, y, w, h], ...],
      "confidences": [0.82, ...],
      "classIds": [32, ...]
    },
    ...
  ]
}
```

---

## 10. PRESETS

| Preset Name | Mode | Enabled Groups | Key Param Overrides |
|-------------|------|---------------|-------------------|
| Raw Model (No Filters) | base_model | none | — |
| Light Filtering | filter_tuned | basic, static | defaults |
| Broadcast Daytime | filter_tuned | basic, roi, appearance, static, tracking | confidence: 0.45 |
| Broadcast Night | filter_tuned | basic, roi, appearance, static, tracking, preprocessing | confidence: 0.30, clahe_clip: 3.5 |
| Wide Angle / Amateur | filter_tuned | basic, roi, static, tracking, sahi | confidence: 0.25, slice: 480, max_lost: 90 |

---

## 11. PIPELINE INTEGRATION (How user deploys to production)

### Step 1: Tune in workbench → Save config as JSON
### Step 2: Copy JSON to pipeline/configs/ folder
### Step 3: In pipeline code, add 2 lines:

```javascript
// BEFORE (existing):
import { ballFilterStream } from './ball-filter-rfdetr.js'
const stream = ballFilterStream()

// AFTER (with workbench config):
import { ballFilterStream } from './ball-filter-rfdetr.js'
import { importConfig } from './ball-filter-config.js'
import fs from 'fs'

const config = importConfig(fs.readFileSync('./configs/broadcast-day.json', 'utf-8'))
const stream = ballFilterStream(config)
```

### Alternative: Legacy copy-paste
Use "Export Legacy" in workbench → generates flat `FILTER_CONFIG = {...}` → paste into existing file. Zero code changes needed.

---

## 12. IMPLEMENTATION PHASES

### Phase 1 — MVP (Get filter tuning working)
**Priority: Build this FIRST. Everything else depends on it.**

| Task | File(s) |
|------|---------|
| Enhanced BallFilterPipeline class | shared/ball-filter-rfdetr.js |
| Config schema + defaults + presets | shared/ball-filter-config.js |
| StaticRejecter (migrated from existing) | shared/ball-filter-utils.js |
| Express + WebSocket server | backend/server.js |
| Frame processor (imports shared/) | backend/frame-processor.js |
| Detection JSON upload + cache | backend/server.js |
| Video upload + ffmpeg frame extraction | backend/video-handler.js |
| Config save/load/delete REST endpoints | backend/config-store.js |
| Main page layout | frontend: +page.svelte |
| Video canvas with overlays | frontend: VideoCanvas.svelte |
| Filter panel with Basic + Static groups | frontend: FilterPanel.svelte, FilterGroup.svelte |
| Transport bar (play/pause/step/seek) | frontend: TransportBar.svelte |
| Mode toggle (Base/Filtered) | frontend: +page.svelte |
| Apply button + config hot-reload | frontend: stores/config.js |
| Sample detections.json for testing | sample_detections.json |
| Python precompute script | python-bridge/precompute.py |

### Phase 2 — All Filter Groups + Stats
| Task | File(s) |
|------|---------|
| ROI / Pitch mask filter | shared/ball-filter-utils.js (ROIMask class) |
| Appearance filters (circularity, color) | shared/ball-filter-utils.js |
| All 8 filter groups in UI | frontend: FilterGroup.svelte (reusable) |
| Stats panel (detection rate, rejected count) | frontend: StatsPanel.svelte |
| Config panel (presets, save/load, export) | frontend: ConfigManager.svelte |
| Debug overlay toggles | frontend: DebugOverlay.svelte |
| Export Legacy format | shared/ball-filter-config.js (toLegacyConfig) |

### Phase 3 — Tracking + Smoothing
| Task | File(s) |
|------|---------|
| KalmanTracker class | shared/ball-filter-utils.js |
| Gravity model for aerial prediction | shared/ball-filter-utils.js |
| TrajectoryValidator (EMA + physics) | shared/ball-filter-utils.js |
| Predicted position shown on canvas (blue circle) | frontend: VideoCanvas.svelte |
| Gap interpolation | shared/ball-filter-utils.js |
| Rescue threshold (lower conf near prediction) | shared/ball-filter-rfdetr.js |

### Phase 4 — Advanced + Polish
| Task | File(s) |
|------|---------|
| Live Python inference bridge (FastAPI sidecar) | python-bridge/live_server.py |
| SAHI tiled inference | python-bridge (Python side) |
| Preprocessing (CLAHE, sharpen, gamma) | python-bridge (Python side) |
| Multi-video comparison | frontend: new component |
| Clip selector (process only a time range) | frontend: TransportBar.svelte |
| Performance optimization | All |
| Metrics export (CSV) | backend endpoint |

---

## 13. RECOMMENDED TUNING WORKFLOW (for end users)

1. Select **Base Model** mode → Play video → observe problems
2. Switch to **Filter-Tuned** → Enable **Basic Filters** only → Adjust confidence until FPs drop but real ball isn't lost
3. Enable **ROI / Pitch** → Outside-pitch detections should vanish
4. Enable **Appearance** → Circularity first, then color if shoes still appear
5. Enable **Static Rejection** → Corner flags/logos should disappear
6. Enable **Tracking** → Aerial balls should be predicted during gaps
7. Enable **Smoothing** (optional) → Reduces jitter, adds slight lag
8. **Save config** → Test on 2–3 similar videos → If works, this is the preset for this video type

---

## 14. CODING GUIDELINES

### JavaScript (shared/ + backend/ + frontend/)
- ES Modules (`import`/`export`), not CommonJS
- No TypeScript (keep it simple, portable)
- `structuredClone()` for deep config copies
- All filter logic in shared/ — no duplication
- `console.log` debug output only when `config.debug === true`

### Svelte (frontend/)
- Svelte 5 runes: `$state`, `$derived`, `$effect`
- Reactive stores for config, pipeline state, WebSocket connection
- Canvas rendering in `$effect` or `requestAnimationFrame`
- Components: small, focused, one responsibility each
- No Tailwind — custom CSS with CSS variables

### Python (python-bridge/)
- Python 3.9+
- Use `argparse` for CLI
- Use `rfdetr` Python package for model inference
- Output clean JSON to stdout or file

---

## 15. DEPENDENCIES

### Backend (Node.js)
```json
{
  "express": "^4.21.0",
  "multer": "^1.4.5-lts.1",
  "ws": "^8.18.0"
}
```

### Frontend (SvelteKit)
```json
{
  "@sveltejs/kit": "^2.0.0",
  "svelte": "^5.0.0",
  "vite": "^6.0.0",
  "@sveltejs/adapter-static": "^3.0.0"
}
```

### Python (precompute)
```
rfdetr>=1.1.0
opencv-python>=4.8.0
Pillow>=10.0.0
numpy>=1.24.0
```

### System
- Node.js 18+
- Python 3.9+
- ffmpeg (for video frame extraction)

---

## 16. EXISTING CODE CONTEXT

The user has an existing pipeline with `ball-filter-rfdetr.js` that uses:
- A `TransformStream` interface (`ballFilterStream()`)
- Input format: `data.ball = { bboxes: [[x,y,w,h], ...], confidences: [0.82, ...] }`
- Output format: same structure, at most 1 detection (highest confidence survivor)
- COCO class ID 37 for classIds output
- Three existing filters: confidence threshold, size + aspect ratio, static-object rejection
- A `StaticRejecter` class with rolling window history

**The enhanced `ball-filter-rfdetr.js` MUST preserve this exact interface.** Calling `ballFilterStream()` with no arguments must produce identical behavior to the current file. The new `createPipeline(config)` and `updateConfig()` APIs are additions, not replacements.

---

## 17. SAMPLE DATA

A `sample_detections.json` file with 100 frames of synthetic detection data is provided. This includes:
- A ball moving in a parabolic arc (simulating an aerial kick)
- A static false positive at (200, 150) appearing in ~50% of frames (tests static rejection)
- Random false positives with elongated aspect ratios (tests aspect ratio filter)
- A gap of 5 frames with no detections (frames 13–17, tests tracking prediction)
- Outside-ROI detections (tests ROI filter)

This allows testing the entire workbench without needing a real video or running RF-DETR.

---

## 18. SUCCESS CRITERIA

The workbench is complete when:
1. User can upload video + detections JSON and see live annotated playback on canvas
2. Base Model / Filter-Tuned toggle works — Base shows raw detections, Filter-Tuned applies active filters
3. All 8 filter groups have parent toggle + child parameter sliders
4. Apply button re-processes with new config instantly (no re-inference)
5. Canvas shows detected ball (green), rejected boxes (red with reason), predicted position (blue)
6. Config can be saved as JSON and loaded back
7. Same JSON config can be loaded in production pipeline via `ballFilterStream(config)`
8. Export Legacy generates flat FILTER_CONFIG for copy-paste into original file
9. Frame-by-frame stepping with ← → keyboard shortcuts works
10. Stats panel shows detection rate, prediction rate, rejection counts

---

*End of requirements document. This should be provided to Claude Code for full implementation.*
