#!/usr/bin/env python3
"""
RF-DETR Detection Precompute Script

Runs RF-DETR inference on a video and outputs detection JSON for the workbench.

Usage:
    python precompute.py --video match.mp4 --output detections.json
    python precompute.py --video match.mp4 --output det.json --start 120 --end 210
    python precompute.py --video match.mp4 --output det.json --model large --threshold 0.10
    python precompute.py --video match.mp4 --output det.json --all-classes  # Keep all detections
"""

import argparse
import json
import sys
import time
from pathlib import Path

try:
    import cv2
    import numpy as np
except ImportError as e:
    print(f"Error: Missing required package: {e}")
    print("Install with: pip install opencv-python numpy")
    sys.exit(1)

# Try different rfdetr import patterns
MODEL_CLASS = None
try:
    from rfdetr import RFDETRBase, RFDETRLarge
    MODEL_CLASS = "rfdetr"
    print("Using rfdetr package")
except ImportError:
    try:
        # Alternative: rfdetr might be installed differently
        import rfdetr
        if hasattr(rfdetr, 'RFDETRBase'):
            from rfdetr import RFDETRBase, RFDETRLarge
            MODEL_CLASS = "rfdetr"
        print(f"rfdetr module found: {dir(rfdetr)}")
    except ImportError:
        pass

if MODEL_CLASS is None:
    print("Warning: rfdetr package not found.")
    print("Install with: pip install rfdetr")
    print("\nAlternatively, you can use a different object detection model.")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run RF-DETR inference on video and output detection JSON"
    )
    parser.add_argument(
        "--video", "-v",
        required=True,
        help="Path to input video file"
    )
    parser.add_argument(
        "--output", "-o",
        required=True,
        help="Output JSON path"
    )
    parser.add_argument(
        "--model", "-m",
        default="base",
        choices=["base", "large"],
        help="RF-DETR model variant (default: base)"
    )
    parser.add_argument(
        "--threshold", "-t",
        type=float,
        default=0.10,
        help="Detection confidence threshold (default: 0.10, keep low)"
    )
    parser.add_argument(
        "--start", "-s",
        type=float,
        default=0,
        help="Start time in seconds (default: 0)"
    )
    parser.add_argument(
        "--end", "-e",
        type=float,
        default=-1,
        help="End time in seconds (-1 = full video)"
    )
    parser.add_argument(
        "--max-frames",
        type=int,
        default=-1,
        help="Maximum frames to process (-1 = no limit)"
    )
    parser.add_argument(
        "--class-id",
        type=int,
        default=32,
        help="COCO class ID for sports ball (default: 32)"
    )
    parser.add_argument(
        "--all-classes",
        action="store_true",
        help="Keep all detected classes (not just sports ball)"
    )
    parser.add_argument(
        "--skip-frames",
        type=int,
        default=1,
        help="Process every Nth frame (default: 1 = all frames)"
    )
    parser.add_argument(
        "--verbose", "-V",
        action="store_true",
        help="Print progress for every frame"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Print detection details for debugging"
    )
    return parser.parse_args()


def load_model(model_name):
    """Load the RF-DETR model."""
    if MODEL_CLASS is None:
        raise RuntimeError("No detection model available. Install rfdetr package.")

    print(f"Loading RF-DETR {model_name} model...")
    if model_name == "large":
        model = RFDETRLarge()
    else:
        model = RFDETRBase()
    print("Model loaded successfully")
    return model


def get_video_info(video_path):
    """Get video metadata."""
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")

    info = {
        "width": int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
        "height": int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
        "fps": cap.get(cv2.CAP_PROP_FPS),
        "total_frames": int(cap.get(cv2.CAP_PROP_FRAME_COUNT)),
    }
    info["duration"] = info["total_frames"] / info["fps"] if info["fps"] > 0 else 0

    cap.release()
    return info


def parse_detection(det, debug=False):
    """Parse a detection object and return (bbox, confidence, class_id) or None."""
    cid = None
    conf = None
    bbox = None

    # Pattern 1: Object with attributes (supervision-style)
    if hasattr(det, 'xyxy') and hasattr(det, 'confidence') and hasattr(det, 'class_id'):
        # This is a supervision Detections object
        xyxy = det.xyxy
        confs = det.confidence
        cids = det.class_id

        if debug:
            print(f"  Supervision Detections: {len(xyxy)} boxes")
            for i in range(min(5, len(xyxy))):
                print(f"    [{i}] class={cids[i]}, conf={confs[i]:.3f}, box={xyxy[i]}")

        # Return as list of detections
        results = []
        for i in range(len(xyxy)):
            x1, y1, x2, y2 = xyxy[i]
            results.append({
                'bbox': [float(x1), float(y1), float(x2 - x1), float(y2 - y1)],
                'conf': float(confs[i]) if confs is not None else 1.0,
                'class_id': int(cids[i]) if cids is not None else 0
            })
        return results

    # Pattern 2: Single detection object with attributes
    if hasattr(det, 'class_id'):
        cid = det.class_id
        conf = det.confidence if hasattr(det, 'confidence') else 1.0
        bbox = det.xyxy if hasattr(det, 'xyxy') else det.bbox if hasattr(det, 'bbox') else None

    # Pattern 3: Dictionary
    elif isinstance(det, dict):
        cid = det.get('class_id', det.get('category_id', det.get('label', 0)))
        conf = det.get('confidence', det.get('score', 1.0))
        bbox = det.get('bbox', det.get('xyxy', det.get('box', None)))

    # Pattern 4: Tuple/list
    elif isinstance(det, (tuple, list)):
        if len(det) >= 6:
            # [x1, y1, x2, y2, conf, class_id]
            bbox = det[:4]
            conf = det[4]
            cid = det[5]
        elif len(det) >= 5:
            bbox = det[:4]
            conf = det[4]
            cid = 0

    # Pattern 5: numpy array
    elif hasattr(det, 'shape') and hasattr(det, '__getitem__'):
        arr = np.array(det)
        if arr.ndim == 1 and len(arr) >= 5:
            bbox = arr[:4].tolist()
            conf = float(arr[4])
            cid = int(arr[5]) if len(arr) > 5 else 0
        elif arr.ndim == 2:
            # Multiple detections in array
            results = []
            for row in arr:
                if len(row) >= 5:
                    x1, y1, x2, y2 = row[:4]
                    results.append({
                        'bbox': [float(x1), float(y1), float(x2 - x1), float(y2 - y1)],
                        'conf': float(row[4]),
                        'class_id': int(row[5]) if len(row) > 5 else 0
                    })
            return results if results else None

    if bbox is None:
        if debug:
            print(f"  Unknown format: type={type(det)}")
            if hasattr(det, '__dict__'):
                print(f"    attributes: {det.__dict__}")
            else:
                print(f"    value: {det}")
        return None

    # Convert xyxy to xywh if needed
    if len(bbox) == 4:
        x1, y1, x2, y2 = bbox
        if x2 > x1 and y2 > y1:  # Already xyxy format
            return [{
                'bbox': [float(x1), float(y1), float(x2 - x1), float(y2 - y1)],
                'conf': float(conf) if conf is not None else 1.0,
                'class_id': int(cid) if cid is not None else 0
            }]
        else:  # Assume xywh
            return [{
                'bbox': [float(x1), float(y1), float(x2), float(y2)],
                'conf': float(conf) if conf is not None else 1.0,
                'class_id': int(cid) if cid is not None else 0
            }]

    return None


def process_video(args, model, video_info):
    """Process video and run inference."""
    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {args.video}")

    fps = video_info["fps"]
    total_frames = video_info["total_frames"]

    # Calculate frame range
    start_frame = int(args.start * fps) if args.start > 0 else 0
    end_frame = int(args.end * fps) if args.end > 0 else total_frames

    if args.max_frames > 0:
        end_frame = min(end_frame, start_frame + args.max_frames)

    # Seek to start frame
    if start_frame > 0:
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)

    frames = []
    frame_idx = start_frame
    processed_count = 0
    start_time = time.time()
    debug_printed = False

    # Ball class IDs in COCO
    ball_classes = {32, 37}  # sports ball

    print(f"Processing frames {start_frame} to {end_frame}...")
    print(f"Video: {video_info['width']}x{video_info['height']} @ {fps:.2f} fps")
    if args.all_classes:
        print("Keeping ALL detected classes")
    else:
        print(f"Filtering for class IDs: {ball_classes}")

    while frame_idx < end_frame:
        ret, frame = cap.read()
        if not ret:
            break

        # Skip frames if specified
        if args.skip_frames > 1 and (frame_idx - start_frame) % args.skip_frames != 0:
            frame_idx += 1
            continue

        # Convert BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Run inference
        detections = model.predict(rgb_frame, threshold=args.threshold)

        # Debug: print detection format on first frame
        if args.debug and not debug_printed:
            print(f"\n=== Detection Debug (frame {frame_idx}) ===")
            print(f"Raw result type: {type(detections)}")
            if hasattr(detections, '__len__'):
                print(f"Raw result length: {len(detections)}")
            if hasattr(detections, '__dict__'):
                print(f"Attributes: {list(detections.__dict__.keys())}")
            debug_printed = True

        # Parse detections
        bboxes = []
        confidences = []
        class_ids = []
        all_detected_classes = set()

        # Handle different return types
        parsed = parse_detection(detections, debug=args.debug and frame_idx == start_frame)

        if parsed is None and hasattr(detections, '__iter__'):
            # Try iterating
            parsed = []
            for det in detections:
                p = parse_detection(det, debug=args.debug and frame_idx == start_frame)
                if p:
                    parsed.extend(p)

        if parsed:
            for det in parsed:
                cid = det['class_id']
                all_detected_classes.add(cid)

                # Filter by class or keep all
                if args.all_classes or cid in ball_classes or cid == args.class_id:
                    bboxes.append(det['bbox'])
                    confidences.append(det['conf'])
                    class_ids.append(cid)

        # Store frame result
        frame_time = frame_idx / fps
        frames.append({
            "frame_idx": frame_idx,
            "time": round(frame_time, 4),
            "bboxes": bboxes,
            "confidences": confidences,
            "classIds": class_ids,
        })

        processed_count += 1
        frame_idx += 1

        # Progress reporting
        if args.verbose or processed_count % 100 == 0:
            elapsed = time.time() - start_time
            fps_proc = processed_count / elapsed if elapsed > 0 else 0
            progress = (frame_idx - start_frame) / (end_frame - start_frame) * 100
            classes_str = f" (classes: {all_detected_classes})" if all_detected_classes else ""
            print(f"  Frame {frame_idx}/{end_frame} ({progress:.1f}%) - "
                  f"{len(bboxes)} kept / {len(all_detected_classes)} classes{classes_str} - {fps_proc:.1f} fps")

    cap.release()

    return frames, {
        "start_frame": start_frame,
        "end_frame": frame_idx,
        "frames_processed": processed_count,
    }


def main():
    args = parse_args()

    # Validate input
    video_path = Path(args.video)
    if not video_path.exists():
        print(f"Error: Video file not found: {args.video}")
        sys.exit(1)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Get video info
    print(f"Analyzing video: {args.video}")
    video_info = get_video_info(args.video)
    print(f"  Resolution: {video_info['width']}x{video_info['height']}")
    print(f"  FPS: {video_info['fps']:.2f}")
    print(f"  Total frames: {video_info['total_frames']}")
    print(f"  Duration: {video_info['duration']:.2f}s")

    # Load model
    model = load_model(args.model)

    # Process video
    start_time = time.time()
    frames, processed_range = process_video(args, model, video_info)
    processing_time = time.time() - start_time

    # Build output JSON
    output_data = {
        "video_path": str(video_path.name),
        "model": args.model,
        "threshold": args.threshold,
        "class_id": args.class_id,
        "all_classes": args.all_classes,
        "video_info": video_info,
        "processed_range": processed_range,
        "processing_time_sec": round(processing_time, 2),
        "frames": frames,
    }

    # Write output
    print(f"\nWriting output to: {args.output}")
    with open(output_path, 'w') as f:
        json.dump(output_data, f, indent=2)

    # Summary
    total_detections = sum(len(f["bboxes"]) for f in frames)
    frames_with_detection = sum(1 for f in frames if len(f["bboxes"]) > 0)

    print(f"\nProcessing complete!")
    print(f"  Frames processed: {processed_range['frames_processed']}")
    print(f"  Total detections: {total_detections}")
    print(f"  Frames with detections: {frames_with_detection} "
          f"({frames_with_detection/len(frames)*100:.1f}%)" if frames else "0")
    print(f"  Processing time: {processing_time:.2f}s "
          f"({processed_range['frames_processed']/processing_time:.1f} fps)" if processing_time > 0 else "")
    print(f"  Output file: {output_path} ({output_path.stat().st_size / 1024:.1f} KB)")

    if total_detections == 0:
        print("\n⚠️  No detections found!")
        print("   Try running with --all-classes to see what the model detects")
        print("   Or use --debug flag to see detection format")


if __name__ == "__main__":
    main()
