#!/usr/bin/env python3
"""
RF-DETR Live Inference Server

FastAPI server that provides real-time ball detection for the workbench.
Runs RF-DETR inference on video frames on demand.

Usage:
    python live_server.py
    # Server runs on http://localhost:8000
"""

import os
import sys
import json
import time
import tempfile
from pathlib import Path
from typing import Optional, List
import asyncio

try:
    import cv2
    import numpy as np
    from fastapi import FastAPI, File, UploadFile, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse, StreamingResponse
    from pydantic import BaseModel
    import uvicorn
except ImportError as e:
    print(f"Missing package: {e}")
    print("Install with: pip install fastapi uvicorn opencv-python numpy python-multipart")
    sys.exit(1)

# Try to import RF-DETR
MODEL = None
MODEL_NAME = "base"

def load_model():
    global MODEL, MODEL_NAME
    if MODEL is not None:
        return MODEL

    try:
        from rfdetr import RFDETRBase
        print("Loading RF-DETR base model...")
        MODEL = RFDETRBase()
        MODEL_NAME = "base"
        print("Model loaded successfully!")
        return MODEL
    except ImportError:
        print("Warning: rfdetr not installed. Using mock detections.")
        return None

# FastAPI app
app = FastAPI(title="Ball Detection Inference Server")

# CORS for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Video storage
VIDEOS = {}  # video_id -> { path, cap, info }
UPLOAD_DIR = tempfile.mkdtemp(prefix="ball_workbench_")

class VideoInfo(BaseModel):
    video_id: str
    width: int
    height: int
    fps: float
    total_frames: int
    duration: float

class Detection(BaseModel):
    bbox: List[float]  # [x, y, w, h]
    confidence: float
    class_id: int

class FrameResult(BaseModel):
    frame_idx: int
    time: float
    bboxes: List[List[float]]
    confidences: List[float]
    classIds: List[int]

@app.on_event("startup")
async def startup():
    """Load model on startup."""
    load_model()

@app.get("/health")
async def health():
    """Health check."""
    return {
        "status": "ok",
        "model_loaded": MODEL is not None,
        "model_name": MODEL_NAME,
    }

@app.post("/upload-video")
async def upload_video(video: UploadFile = File(...)):
    """Upload a video file for processing."""
    try:
        # Save video to temp file
        video_id = f"video_{int(time.time() * 1000)}"
        video_path = os.path.join(UPLOAD_DIR, f"{video_id}{Path(video.filename).suffix}")

        with open(video_path, "wb") as f:
            content = await video.read()
            f.write(content)

        # Open video and get info
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise HTTPException(status_code=400, detail="Could not open video file")

        info = {
            "width": int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
            "height": int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
            "fps": cap.get(cv2.CAP_PROP_FPS),
            "total_frames": int(cap.get(cv2.CAP_PROP_FRAME_COUNT)),
        }
        info["duration"] = info["total_frames"] / info["fps"] if info["fps"] > 0 else 0

        # Store video reference
        VIDEOS[video_id] = {
            "path": video_path,
            "cap": cap,
            "info": info,
            "filename": video.filename,
        }

        print(f"Video uploaded: {video.filename} ({info['width']}x{info['height']}, {info['total_frames']} frames)")

        return {
            "video_id": video_id,
            "filename": video.filename,
            "video_info": info,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/video/{video_id}/info")
async def get_video_info(video_id: str):
    """Get video information."""
    if video_id not in VIDEOS:
        raise HTTPException(status_code=404, detail="Video not found")

    v = VIDEOS[video_id]
    return {
        "video_id": video_id,
        "filename": v["filename"],
        "video_info": v["info"],
    }

@app.get("/video/{video_id}/frame/{frame_idx}")
async def get_frame_image(video_id: str, frame_idx: int):
    """Get a frame as JPEG image."""
    if video_id not in VIDEOS:
        raise HTTPException(status_code=404, detail="Video not found")

    v = VIDEOS[video_id]
    cap = v["cap"]

    # Seek to frame
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
    ret, frame = cap.read()

    if not ret:
        raise HTTPException(status_code=404, detail="Frame not found")

    # Encode as JPEG
    _, jpeg = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])

    return StreamingResponse(
        iter([jpeg.tobytes()]),
        media_type="image/jpeg"
    )

@app.get("/video/{video_id}/detect/{frame_idx}")
async def detect_frame(
    video_id: str,
    frame_idx: int,
    threshold: float = 0.1,
    class_id: Optional[int] = None,
    nms_iou: float = 0.5,
    image_size: int = 560,
):
    """Run detection on a single frame."""
    if video_id not in VIDEOS:
        raise HTTPException(status_code=404, detail="Video not found")

    v = VIDEOS[video_id]
    cap = v["cap"]
    info = v["info"]

    # Seek to frame
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
    ret, frame = cap.read()

    if not ret:
        raise HTTPException(status_code=404, detail="Frame not found")

    # Convert BGR to RGB
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Run detection
    bboxes, confidences, class_ids = run_detection(
        rgb_frame, threshold, class_id,
        nms_iou=nms_iou, image_size=image_size
    )

    return {
        "frame_idx": frame_idx,
        "time": frame_idx / info["fps"] if info["fps"] > 0 else 0,
        "bboxes": bboxes,
        "confidences": confidences,
        "classIds": class_ids,
        "video_info": info,
    }

@app.get("/video/{video_id}/detect-range")
async def detect_range(
    video_id: str,
    start_frame: int = 0,
    end_frame: int = -1,
    threshold: float = 0.1,
    class_id: Optional[int] = None,
    skip_frames: int = 1,
):
    """Run detection on a range of frames."""
    if video_id not in VIDEOS:
        raise HTTPException(status_code=404, detail="Video not found")

    v = VIDEOS[video_id]
    cap = v["cap"]
    info = v["info"]

    if end_frame < 0:
        end_frame = info["total_frames"]

    results = []
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)

    for frame_idx in range(start_frame, end_frame, skip_frames):
        ret, frame = cap.read()
        if not ret:
            break

        # Skip frames
        for _ in range(skip_frames - 1):
            cap.read()

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        bboxes, confidences, class_ids = run_detection(rgb_frame, threshold, class_id)

        results.append({
            "frame_idx": frame_idx,
            "time": frame_idx / info["fps"] if info["fps"] > 0 else 0,
            "bboxes": bboxes,
            "confidences": confidences,
            "classIds": class_ids,
        })

    return {
        "video_id": video_id,
        "video_info": info,
        "frames": results,
    }

def run_detection(rgb_frame, threshold=0.1, filter_class_id=None, nms_iou=0.5, image_size=560):
    """Run RF-DETR detection on a frame."""
    global MODEL

    bboxes = []
    confidences = []
    class_ids = []

    if MODEL is None:
        # Mock detection for testing without model
        # Return a random detection
        h, w = rgb_frame.shape[:2]
        if np.random.random() > 0.3:  # 70% chance of detection
            cx = np.random.randint(w // 4, 3 * w // 4)
            cy = np.random.randint(h // 4, 3 * h // 4)
            size = np.random.randint(15, 40)
            bboxes.append([float(cx - size//2), float(cy - size//2), float(size), float(size)])
            confidences.append(float(np.random.uniform(0.3, 0.9)))
            class_ids.append(37)
        return bboxes, confidences, class_ids

    try:
        # Resize frame if image_size is specified and differs from default
        input_frame = rgb_frame
        original_h, original_w = rgb_frame.shape[:2]
        scale_x, scale_y = 1.0, 1.0

        if image_size and image_size != 560:
            # Resize maintaining aspect ratio to a square of image_size
            input_frame = cv2.resize(rgb_frame, (image_size, image_size))
            scale_x = original_w / image_size
            scale_y = original_h / image_size

        # Run inference with threshold
        detections = MODEL.predict(input_frame, threshold=threshold)

        # Parse detections (supervision format)
        if hasattr(detections, 'xyxy') and hasattr(detections, 'confidence'):
            xyxy = detections.xyxy
            confs = detections.confidence
            cids = detections.class_id

            # Apply NMS with custom IoU threshold
            if len(xyxy) > 1 and nms_iou < 1.0:
                try:
                    from torchvision.ops import nms as torch_nms
                    import torch
                    boxes_tensor = torch.tensor(xyxy, dtype=torch.float32)
                    scores_tensor = torch.tensor(confs, dtype=torch.float32)
                    keep = torch_nms(boxes_tensor, scores_tensor, nms_iou)
                    keep = keep.numpy()
                    xyxy = xyxy[keep]
                    confs = confs[keep]
                    cids = cids[keep] if cids is not None else None
                except ImportError:
                    # Fallback: skip custom NMS if torchvision not available
                    pass

            for i in range(len(xyxy)):
                cid = int(cids[i]) if cids is not None else 0

                # Filter by class if specified
                if filter_class_id is not None and cid != filter_class_id and cid != 37:
                    continue

                # Keep only ball class (37) by default
                if filter_class_id is None and cid not in [32, 37]:
                    continue

                x1, y1, x2, y2 = xyxy[i]
                # Scale back to original coordinates if resized
                if scale_x != 1.0 or scale_y != 1.0:
                    x1, x2 = x1 * scale_x, x2 * scale_x
                    y1, y2 = y1 * scale_y, y2 * scale_y
                bboxes.append([float(x1), float(y1), float(x2 - x1), float(y2 - y1)])
                confidences.append(float(confs[i]) if confs is not None else 1.0)
                class_ids.append(cid)

    except Exception as e:
        print(f"Detection error: {e}")

    return bboxes, confidences, class_ids

@app.delete("/video/{video_id}")
async def delete_video(video_id: str):
    """Delete a video and free resources."""
    if video_id not in VIDEOS:
        raise HTTPException(status_code=404, detail="Video not found")

    v = VIDEOS[video_id]
    v["cap"].release()

    try:
        os.remove(v["path"])
    except:
        pass

    del VIDEOS[video_id]
    return {"status": "deleted"}

@app.on_event("shutdown")
async def shutdown():
    """Clean up on shutdown."""
    for video_id in list(VIDEOS.keys()):
        try:
            VIDEOS[video_id]["cap"].release()
            os.remove(VIDEOS[video_id]["path"])
        except:
            pass
    VIDEOS.clear()

if __name__ == "__main__":
    print("Starting Ball Detection Inference Server...")
    print(f"Upload directory: {UPLOAD_DIR}")
    uvicorn.run(app, host="0.0.0.0", port=8000)
