#!/usr/bin/env python3
"""
Debug script to check RF-DETR detection output format
"""

import sys

try:
    import cv2
    import numpy as np
    from PIL import Image
except ImportError as e:
    print(f"Error: Missing required package: {e}")
    sys.exit(1)

# Try to import rfdetr
try:
    from rfdetr import RFDETRBase
    print("rfdetr package imported successfully")
except ImportError:
    print("rfdetr package not found. Trying alternative import...")
    try:
        import rfdetr
        print(f"rfdetr module contents: {dir(rfdetr)}")
    except ImportError as e:
        print(f"Cannot import rfdetr: {e}")
        print("\nTrying supervision-based approach...")

# Check if supervision is available (common for object detection)
try:
    import supervision as sv
    print("supervision package available")
except ImportError:
    print("supervision package not installed")

# Try loading a test image
print("\n--- Testing with a simple image ---")

# Create a test image (white ball on green background)
test_img = np.zeros((720, 1280, 3), dtype=np.uint8)
test_img[:, :] = [0, 128, 0]  # Green background (BGR)
cv2.circle(test_img, (640, 360), 30, (255, 255, 255), -1)  # White ball

# Convert to RGB
rgb_img = cv2.cvtColor(test_img, cv2.COLOR_BGR2RGB)

try:
    from rfdetr import RFDETRBase
    model = RFDETRBase()
    print("Model loaded")

    # Run inference
    result = model.predict(rgb_img, threshold=0.01)  # Very low threshold

    print(f"\nResult type: {type(result)}")
    print(f"Result: {result}")

    if hasattr(result, '__iter__'):
        print(f"Result length: {len(list(result)) if hasattr(result, '__len__') else 'iterable'}")

        # Try to iterate
        for i, det in enumerate(result):
            print(f"\nDetection {i}:")
            print(f"  Type: {type(det)}")
            print(f"  Dir: {dir(det)}")
            if hasattr(det, 'xyxy'):
                print(f"  xyxy: {det.xyxy}")
            if hasattr(det, 'class_id'):
                print(f"  class_id: {det.class_id}")
            if hasattr(det, 'confidence'):
                print(f"  confidence: {det.confidence}")
            if isinstance(det, dict):
                print(f"  Dict keys: {det.keys()}")
            if i >= 5:
                print("  ... (showing first 5 only)")
                break

except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()

print("\n--- Checking COCO class IDs ---")
print("Sports ball class IDs in COCO:")
print("  - Class 32: 'sports ball' (0-indexed)")
print("  - Class 37: sometimes used for ball")
print("\nNote: RF-DETR may use different class mappings or return all classes")
