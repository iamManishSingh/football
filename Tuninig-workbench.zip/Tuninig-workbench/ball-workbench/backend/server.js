/**
 * Ball Detection Filter Tuning Workbench - Backend Server
 *
 * Express + WebSocket server for:
 * - REST API endpoints (video/detection upload, config CRUD, presets)
 * - WebSocket real-time frame streaming and config updates
 */

import express from 'express'
import cors from 'cors'
import multer from 'multer'
import { WebSocketServer } from 'ws'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

import { createFrameProcessor, DEFAULT_CONFIG, PRESETS } from './frame-processor.js'
import { listConfigs, saveConfig, loadConfig, deleteConfig } from './config-store.js'
import { getVideoInfo, extractFrame, UPLOADS_DIR } from './video-handler.js'
import { toLegacyConfig, toLegacyConfigString, PARAM_METADATA } from '../shared/ball-filter-config.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// ============================================================================
// SERVER SETUP
// ============================================================================

const app = express()
const PORT = process.env.PORT || 3001
const WS_PORT = process.env.WS_PORT || 3002

app.use(cors())
app.use(express.json({ limit: '100mb' }))

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR)
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${file.originalname}`
    cb(null, uniqueName)
  }
})

const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB max
})

// ============================================================================
// STATE
// ============================================================================

let frameProcessor = createFrameProcessor()
let currentVideoPath = null
let currentVideoInfo = null
let detectionsLoaded = false

// Python inference server configuration
const PYTHON_INFERENCE_URL = process.env.PYTHON_INFERENCE_URL || 'http://localhost:8000'

// ============================================================================
// HELPER: Proxy to Python inference server
// ============================================================================

async function proxyToPython(path, options = {}) {
  const url = `${PYTHON_INFERENCE_URL}${path}`
  try {
    const response = await fetch(url, options)
    return response
  } catch (error) {
    console.error(`Failed to proxy to Python server: ${error.message}`)
    throw error
  }
}

// ============================================================================
// REST API ENDPOINTS
// ============================================================================

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// Upload video file
app.post('/api/upload-video', upload.single('video'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No video file provided' })
    }

    currentVideoPath = req.file.path

    // Get video info
    try {
      currentVideoInfo = await getVideoInfo(currentVideoPath)
    } catch (e) {
      currentVideoInfo = { width: 1920, height: 1080, fps: 25, duration: 0, totalFrames: 0 }
      console.warn('Could not get video info:', e.message)
    }

    res.json({
      success: true,
      filename: req.file.filename,
      path: currentVideoPath,
      videoInfo: currentVideoInfo,
    })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Upload detection JSON file
app.post('/api/upload-detections', upload.single('detections'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No detection file provided' })
    }

    const content = fs.readFileSync(req.file.path, 'utf-8')
    const detections = JSON.parse(content)

    frameProcessor.loadDetections(detections)
    detectionsLoaded = true

    // Update video info if present in detections
    if (detections.video_info) {
      currentVideoInfo = detections.video_info
    }

    res.json({
      success: true,
      filename: req.file.filename,
      totalFrames: frameProcessor.getTotalFrames(),
      videoInfo: frameProcessor.getVideoInfo(),
    })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Upload detection JSON as raw body
app.post('/api/upload-detections-json', async (req, res) => {
  try {
    const detections = req.body

    if (!detections || !detections.frames) {
      return res.status(400).json({ error: 'Invalid detection JSON format' })
    }

    frameProcessor.loadDetections(detections)
    detectionsLoaded = true

    // Update video info if present
    if (detections.video_info) {
      currentVideoInfo = detections.video_info
    }

    res.json({
      success: true,
      totalFrames: frameProcessor.getTotalFrames(),
      videoInfo: frameProcessor.getVideoInfo(),
    })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Get a single frame image
app.get('/api/frame/:frameIdx', async (req, res) => {
  try {
    const frameIdx = parseInt(req.params.frameIdx)

    if (!currentVideoPath) {
      return res.status(400).json({ error: 'No video loaded' })
    }

    const fps = currentVideoInfo?.fps || 25
    const buffer = await extractFrame(currentVideoPath, frameIdx, fps)

    res.set('Content-Type', 'image/jpeg')
    res.send(buffer)
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Process a single frame
app.post('/api/process-frame', (req, res) => {
  try {
    const { frameIdx, config } = req.body

    if (!detectionsLoaded) {
      return res.status(400).json({ error: 'No detections loaded' })
    }

    // Update config if provided
    if (config) {
      frameProcessor.updateConfig(config)
    }

    const result = frameProcessor.processFrame(frameIdx)

    res.json({
      success: true,
      frameIdx,
      ...result,
    })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Process a range of frames
app.post('/api/process-range', (req, res) => {
  try {
    const { startFrame, endFrame, config } = req.body

    if (!detectionsLoaded) {
      return res.status(400).json({ error: 'No detections loaded' })
    }

    // Update config if provided
    if (config) {
      frameProcessor.updateConfig(config)
    }

    const results = frameProcessor.processRange(startFrame, endFrame)

    res.json({
      success: true,
      startFrame,
      endFrame,
      results,
      stats: frameProcessor.getStats(),
    })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Update config
app.post('/api/update-config', (req, res) => {
  try {
    const { config } = req.body
    frameProcessor.updateConfig(config)

    res.json({
      success: true,
      config: frameProcessor.getConfig(),
    })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Reset pipeline
app.post('/api/reset', (req, res) => {
  try {
    frameProcessor.reset()
    res.json({ success: true })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Get current stats
app.get('/api/stats', (req, res) => {
  res.json({
    stats: frameProcessor.getStats(),
    totalFrames: frameProcessor.getTotalFrames(),
    videoInfo: currentVideoInfo,
    detectionsLoaded,
  })
})

// ── Config CRUD ────────────────────────────────────────────────────────────

// List saved configs
app.get('/api/configs', (req, res) => {
  const configs = listConfigs()
  res.json({ configs })
})

// Save a config
app.post('/api/configs', (req, res) => {
  try {
    const { name, config } = req.body

    if (!name || !config) {
      return res.status(400).json({ error: 'Name and config required' })
    }

    const result = saveConfig(name, config)
    res.json(result)
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Load a config
app.get('/api/configs/:filename', (req, res) => {
  const result = loadConfig(req.params.filename)

  if (result.success) {
    res.json(result)
  } else {
    res.status(404).json(result)
  }
})

// Delete a config
app.delete('/api/configs/:filename', (req, res) => {
  const result = deleteConfig(req.params.filename)

  if (result.success) {
    res.json(result)
  } else {
    res.status(404).json(result)
  }
})

// ── Presets ────────────────────────────────────────────────────────────────

// List preset names
app.get('/api/presets', (req, res) => {
  const presetList = Object.entries(PRESETS).map(([key, preset]) => ({
    key,
    name: preset.name,
    description: preset.description,
  }))
  res.json({ presets: presetList })
})

// Get a preset config
app.get('/api/presets/:name', (req, res) => {
  const preset = PRESETS[req.params.name]

  if (preset) {
    res.json({
      success: true,
      name: preset.name,
      description: preset.description,
      config: preset.config,
    })
  } else {
    res.status(404).json({ error: 'Preset not found' })
  }
})

// Get default config
app.get('/api/default-config', (req, res) => {
  res.json({ config: DEFAULT_CONFIG })
})

// Get parameter metadata (for UI rendering)
app.get('/api/param-metadata', (req, res) => {
  res.json({ metadata: PARAM_METADATA })
})

// Export to legacy format
app.post('/api/export-legacy', (req, res) => {
  try {
    const { config } = req.body
    const legacy = toLegacyConfig(config || frameProcessor.getConfig())
    const legacyString = toLegacyConfigString(config || frameProcessor.getConfig())

    res.json({
      success: true,
      legacy,
      legacyString,
    })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// ============================================================================
// LIVE INFERENCE PROXY ENDPOINTS
// ============================================================================

// Check if Python inference server is available
app.get('/api/inference/health', async (req, res) => {
  try {
    const response = await proxyToPython('/health')
    const data = await response.json()
    res.json(data)
  } catch (e) {
    res.status(503).json({ status: 'unavailable', error: e.message })
  }
})

// Proxy video upload to Python server
app.post('/api/inference/upload-video', upload.single('video'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No video file provided' })
    }

    // Forward the video file to Python server using native fetch with FormData
    const FormData = (await import('formdata-node')).FormData
    const { Blob } = await import('buffer')
    const { fileFromPath } = await import('formdata-node/file-from-path')
    
    const formData = new FormData()
    const file = await fileFromPath(req.file.path, req.file.originalname)
    formData.append('video', file)

    const response = await proxyToPython('/upload-video', {
      method: 'POST',
      body: formData,
    })

    if (response.ok) {
      const data = await response.json()
      
      // Store video info locally
      currentVideoInfo = data.video_info
      detectionsLoaded = true

      res.json(data)
    } else {
      const error = await response.json()
      res.status(response.status).json(error)
    }
  } catch (e) {
    console.error('Proxy upload error:', e)
    res.status(500).json({ error: e.message })
  }
})

// Proxy frame detection request
app.get('/api/inference/video/:videoId/detect/:frameIdx', async (req, res) => {
  try {
    const { videoId, frameIdx } = req.params
    const { threshold = 0.1, class_id } = req.query

    let url = `/video/${videoId}/detect/${frameIdx}?threshold=${threshold}`
    if (class_id) {
      url += `&class_id=${class_id}`
    }

    const response = await proxyToPython(url)

    if (response.ok) {
      const data = await response.json()
      res.json(data)
    } else {
      const error = await response.json()
      res.status(response.status).json(error)
    }
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// Proxy frame image request
app.get('/api/inference/video/:videoId/frame/:frameIdx', async (req, res) => {
  try {
    const { videoId, frameIdx } = req.params

    const response = await proxyToPython(`/video/${videoId}/frame/${frameIdx}`)

    if (response.ok) {
      res.setHeader('Content-Type', 'image/jpeg')
      // Stream the image back
      const buffer = await response.arrayBuffer()
      res.send(Buffer.from(buffer))
    } else {
      res.status(response.status).json({ error: 'Frame not found' })
    }
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

// ============================================================================
// WEBSOCKET SERVER
// ============================================================================

const wss = new WebSocketServer({ port: WS_PORT })

// Track connected clients
const clients = new Set()

// Playback state
let playbackState = {
  playing: false,
  currentFrame: 0,
  speed: 1,
  interval: null,
}

function broadcast(message) {
  const data = JSON.stringify(message)
  for (const client of clients) {
    if (client.readyState === 1) { // OPEN
      client.send(data)
    }
  }
}

function stopPlayback() {
  if (playbackState.interval) {
    clearInterval(playbackState.interval)
    playbackState.interval = null
  }
  playbackState.playing = false
}

function startPlayback(startFrame = 0, speed = 1) {
  stopPlayback()

  playbackState.currentFrame = startFrame
  playbackState.speed = speed
  playbackState.playing = true

  const fps = currentVideoInfo?.fps || 25
  const intervalMs = 1000 / (fps * speed)

  playbackState.interval = setInterval(() => {
    if (!detectionsLoaded) {
      stopPlayback()
      return
    }

    const totalFrames = frameProcessor.getTotalFrames()

    if (playbackState.currentFrame >= totalFrames) {
      stopPlayback()
      broadcast({ type: 'playback_end' })
      return
    }

    const result = frameProcessor.processFrame(playbackState.currentFrame)

    broadcast({
      type: 'frame_result',
      frameIdx: playbackState.currentFrame,
      totalFrames,
      time: playbackState.currentFrame / fps,
      ...result,
    })

    playbackState.currentFrame++
  }, intervalMs)
}

wss.on('connection', (ws) => {
  clients.add(ws)
  console.log('WebSocket client connected')

  // Send initial state
  ws.send(JSON.stringify({
    type: 'connected',
    config: frameProcessor.getConfig(),
    detectionsLoaded,
    totalFrames: frameProcessor.getTotalFrames(),
    videoInfo: currentVideoInfo,
  }))

  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data.toString())

      switch (message.type) {
        case 'update_config':
          frameProcessor.updateConfig(message.config)
          broadcast({ type: 'config_updated', config: frameProcessor.getConfig() })
          break

        case 'play':
          startPlayback(message.startFrame || 0, message.speed || 1)
          break

        case 'pause':
          stopPlayback()
          break

        case 'seek':
          stopPlayback()
          playbackState.currentFrame = message.frame || 0
          frameProcessor.reset()

          if (detectionsLoaded) {
            const result = frameProcessor.processFrame(playbackState.currentFrame)
            ws.send(JSON.stringify({
              type: 'frame_result',
              frameIdx: playbackState.currentFrame,
              totalFrames: frameProcessor.getTotalFrames(),
              time: playbackState.currentFrame / (currentVideoInfo?.fps || 25),
              ...result,
            }))
          }
          break

        case 'step':
          stopPlayback()
          playbackState.currentFrame += message.direction || 1
          playbackState.currentFrame = Math.max(0, playbackState.currentFrame)

          if (detectionsLoaded) {
            const totalFrames = frameProcessor.getTotalFrames()
            playbackState.currentFrame = Math.min(playbackState.currentFrame, totalFrames - 1)

            const result = frameProcessor.processFrame(playbackState.currentFrame)
            ws.send(JSON.stringify({
              type: 'frame_result',
              frameIdx: playbackState.currentFrame,
              totalFrames,
              time: playbackState.currentFrame / (currentVideoInfo?.fps || 25),
              ...result,
            }))
          }
          break

        case 'process_current':
          if (detectionsLoaded) {
            const result = frameProcessor.processFrame(playbackState.currentFrame)
            ws.send(JSON.stringify({
              type: 'frame_result',
              frameIdx: playbackState.currentFrame,
              totalFrames: frameProcessor.getTotalFrames(),
              time: playbackState.currentFrame / (currentVideoInfo?.fps || 25),
              ...result,
            }))
          }
          break

        case 'reset':
          frameProcessor.reset()
          playbackState.currentFrame = 0
          ws.send(JSON.stringify({ type: 'reset_complete' }))
          break

        default:
          console.log('Unknown message type:', message.type)
      }
    } catch (e) {
      console.error('WebSocket message error:', e)
    }
  })

  ws.on('close', () => {
    clients.delete(ws)
    console.log('WebSocket client disconnected')
  })
})

// ============================================================================
// START SERVER
// ============================================================================

app.listen(PORT, () => {
  console.log(`🎯 Ball Workbench Backend running on http://localhost:${PORT}`)
  console.log(`📡 WebSocket server running on ws://localhost:${WS_PORT}`)
  console.log(`🐍 Python inference server: ${PYTHON_INFERENCE_URL}`)
  console.log('')
  console.log('Available endpoints:')
  console.log('  POST /api/upload-video       - Upload video file')
  console.log('  POST /api/upload-detections  - Upload detection JSON file')
  console.log('  GET  /api/frame/:idx         - Get video frame as JPEG')
  console.log('  POST /api/process-frame      - Process single frame')
  console.log('  POST /api/process-range      - Process frame range')
  console.log('  GET  /api/configs            - List saved configs')
  console.log('  POST /api/configs            - Save config')
  console.log('  GET  /api/presets            - List presets')
  console.log('  GET  /api/default-config     - Get default config')
  console.log('')
  console.log('Live Inference Proxy:')
  console.log('  GET  /api/inference/health                         - Check Python server status')
  console.log('  POST /api/inference/upload-video                   - Upload video for live inference')
  console.log('  GET  /api/inference/video/:id/detect/:frame        - Get frame detection')
  console.log('  GET  /api/inference/video/:id/frame/:frame         - Get frame image')
})
