/**
 * Video Handler - Video upload and frame extraction
 *
 * Handles video file uploads and extracts frames using ffmpeg.
 */

import { spawn } from 'child_process'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const UPLOADS_DIR = path.join(__dirname, '..', 'uploads')
const FRAMES_DIR = path.join(__dirname, '..', 'uploads', 'frames')

// Ensure directories exist
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true })
}
if (!fs.existsSync(FRAMES_DIR)) {
  fs.mkdirSync(FRAMES_DIR, { recursive: true })
}

/**
 * Get video metadata using ffprobe
 * @param {string} videoPath - Path to video file
 * @returns {Promise<{width: number, height: number, fps: number, duration: number, totalFrames: number}>}
 */
export async function getVideoInfo(videoPath) {
  return new Promise((resolve, reject) => {
    const ffprobe = spawn('ffprobe', [
      '-v', 'quiet',
      '-print_format', 'json',
      '-show_format',
      '-show_streams',
      videoPath
    ])

    let output = ''
    ffprobe.stdout.on('data', (data) => {
      output += data.toString()
    })

    ffprobe.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`ffprobe exited with code ${code}`))
        return
      }

      try {
        const info = JSON.parse(output)
        const videoStream = info.streams.find(s => s.codec_type === 'video')

        if (!videoStream) {
          reject(new Error('No video stream found'))
          return
        }

        // Parse frame rate (can be "30/1" or "29.97")
        let fps = 25
        if (videoStream.r_frame_rate) {
          const parts = videoStream.r_frame_rate.split('/')
          fps = parts.length === 2 ? parseFloat(parts[0]) / parseFloat(parts[1]) : parseFloat(parts[0])
        }

        const duration = parseFloat(info.format.duration || 0)
        const totalFrames = Math.floor(duration * fps)

        resolve({
          width: videoStream.width,
          height: videoStream.height,
          fps,
          duration,
          totalFrames,
        })
      } catch (e) {
        reject(e)
      }
    })

    ffprobe.on('error', reject)
  })
}

/**
 * Extract a single frame from video as JPEG
 * @param {string} videoPath - Path to video file
 * @param {number} frameIdx - Frame index to extract
 * @param {number} fps - Video FPS
 * @returns {Promise<Buffer>}
 */
export async function extractFrame(videoPath, frameIdx, fps = 25) {
  return new Promise((resolve, reject) => {
    const timestamp = frameIdx / fps

    const ffmpeg = spawn('ffmpeg', [
      '-ss', timestamp.toFixed(4),
      '-i', videoPath,
      '-vframes', '1',
      '-f', 'image2pipe',
      '-vcodec', 'mjpeg',
      '-q:v', '2',
      '-'
    ])

    const chunks = []
    ffmpeg.stdout.on('data', (chunk) => {
      chunks.push(chunk)
    })

    ffmpeg.stderr.on('data', () => {
      // Ignore ffmpeg stderr output
    })

    ffmpeg.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`ffmpeg exited with code ${code}`))
        return
      }
      resolve(Buffer.concat(chunks))
    })

    ffmpeg.on('error', reject)
  })
}

/**
 * Extract multiple frames and cache them
 * @param {string} videoPath - Path to video file
 * @param {number} startFrame - Start frame index
 * @param {number} endFrame - End frame index
 * @param {number} fps - Video FPS
 * @param {string} cacheDir - Directory to cache frames
 * @returns {Promise<string[]>} - Array of frame file paths
 */
export async function extractFrameRange(videoPath, startFrame, endFrame, fps = 25, cacheDir = FRAMES_DIR) {
  const frames = []
  const videoName = path.basename(videoPath, path.extname(videoPath))
  const videoFrameDir = path.join(cacheDir, videoName)

  if (!fs.existsSync(videoFrameDir)) {
    fs.mkdirSync(videoFrameDir, { recursive: true })
  }

  for (let i = startFrame; i <= endFrame; i++) {
    const framePath = path.join(videoFrameDir, `frame_${i.toString().padStart(6, '0')}.jpg`)

    if (!fs.existsSync(framePath)) {
      const buffer = await extractFrame(videoPath, i, fps)
      fs.writeFileSync(framePath, buffer)
    }

    frames.push(framePath)
  }

  return frames
}

/**
 * Get the path to a cached frame, or extract it
 * @param {string} videoPath - Path to video file
 * @param {number} frameIdx - Frame index
 * @param {number} fps - Video FPS
 * @returns {Promise<string>} - Path to frame file
 */
export async function getFramePath(videoPath, frameIdx, fps = 25) {
  const videoName = path.basename(videoPath, path.extname(videoPath))
  const frameDir = path.join(FRAMES_DIR, videoName)
  const framePath = path.join(frameDir, `frame_${frameIdx.toString().padStart(6, '0')}.jpg`)

  if (fs.existsSync(framePath)) {
    return framePath
  }

  if (!fs.existsSync(frameDir)) {
    fs.mkdirSync(frameDir, { recursive: true })
  }

  const buffer = await extractFrame(videoPath, frameIdx, fps)
  fs.writeFileSync(framePath, buffer)

  return framePath
}

export { UPLOADS_DIR, FRAMES_DIR }

export default {
  getVideoInfo,
  extractFrame,
  extractFrameRange,
  getFramePath,
  UPLOADS_DIR,
  FRAMES_DIR,
}
