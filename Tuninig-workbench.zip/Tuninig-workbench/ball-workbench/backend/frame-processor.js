/**
 * Frame Processor - Process frames through the filter pipeline
 *
 * Imports the shared filter pipeline and processes detection data.
 */

import { createPipeline } from '../shared/ball-filter-rfdetr.js'
import { DEFAULT_CONFIG, PRESETS, cloneConfig } from '../shared/ball-filter-config.js'

/**
 * Frame Processor class
 * Manages a filter pipeline instance and processes frames
 */
export class FrameProcessor {
  constructor(config = null) {
    this.config = config ? cloneConfig(config) : cloneConfig(DEFAULT_CONFIG)
    this.pipeline = createPipeline(this.config)
    this.detectionsCache = null
    this.videoInfo = null
  }

  /**
   * Load detection data from JSON
   * @param {object} detections - Detection JSON data
   */
  loadDetections(detections) {
    this.detectionsCache = detections

    // Extract video info if available
    if (detections.video_info) {
      this.videoInfo = detections.video_info
    }

    // Reset pipeline for new video
    this.pipeline.reset()
  }

  /**
   * Get detection data for a specific frame
   * @param {number} frameIdx - Frame index
   * @returns {object|null}
   */
  getFrameDetections(frameIdx) {
    if (!this.detectionsCache?.frames) return null

    // Frames array might be indexed or might need searching
    const frame = this.detectionsCache.frames.find(f => f.frame_idx === frameIdx)
      || this.detectionsCache.frames[frameIdx]

    return frame || null
  }

  /**
   * Process a single frame
   * @param {number} frameIdx - Frame index
   * @returns {object} - { ball, meta, debug, raw }
   */
  processFrame(frameIdx) {
    const frameData = this.getFrameDetections(frameIdx)

    if (!frameData) {
      return {
        ball: { bboxes: [], confidences: [], classIds: [] },
        meta: { source: 'no_data', frame_index: frameIdx },
        debug: { raw_count: 0, rejected: [], stage_counts: {} },
        raw: { bboxes: [], confidences: [] },
      }
    }

    const imageInfo = this.videoInfo || { width: 1920, height: 1080 }

    const input = {
      ball: {
        bboxes: frameData.bboxes || [],
        confidences: frameData.confidences || [],
        classIds: frameData.classIds || [],
      },
      image: imageInfo,
      time: frameData.time || frameIdx / 25,
    }

    const result = this.pipeline.processFrame(input)

    return {
      ...result,
      raw: {
        bboxes: frameData.bboxes || [],
        confidences: frameData.confidences || [],
      },
    }
  }

  /**
   * Process a range of frames
   * @param {number} startFrame - Start frame index
   * @param {number} endFrame - End frame index
   * @returns {object[]} - Array of processed results
   */
  processRange(startFrame, endFrame) {
    const results = []

    for (let i = startFrame; i <= endFrame; i++) {
      results.push(this.processFrame(i))
    }

    return results
  }

  /**
   * Update filter configuration
   * @param {object} newConfig - New configuration
   */
  updateConfig(newConfig) {
    this.config = cloneConfig(newConfig)
    this.pipeline.updateConfig(newConfig)
  }

  /**
   * Reset pipeline state (for seeking/scene cuts)
   */
  reset() {
    this.pipeline.reset()
  }

  /**
   * Get current configuration
   * @returns {object}
   */
  getConfig() {
    return cloneConfig(this.config)
  }

  /**
   * Get pipeline statistics
   * @returns {object}
   */
  getStats() {
    return this.pipeline.getStats()
  }

  /**
   * Get total frames available
   * @returns {number}
   */
  getTotalFrames() {
    if (this.detectionsCache?.frames) {
      return this.detectionsCache.frames.length
    }
    if (this.videoInfo?.total_frames) {
      return this.videoInfo.total_frames
    }
    return 0
  }

  /**
   * Get video info
   * @returns {object|null}
   */
  getVideoInfo() {
    return this.videoInfo
  }
}

/**
 * Create a new frame processor
 * @param {object} config - Optional configuration
 * @returns {FrameProcessor}
 */
export function createFrameProcessor(config = null) {
  return new FrameProcessor(config)
}

export { DEFAULT_CONFIG, PRESETS }

export default {
  FrameProcessor,
  createFrameProcessor,
  DEFAULT_CONFIG,
  PRESETS,
}
