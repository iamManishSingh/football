/**
 * Config Store - CRUD operations for filter configurations
 *
 * Handles saving, loading, listing, and deleting configuration JSON files.
 */

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const CONFIGS_DIR = path.join(__dirname, '..', 'configs')

// Ensure configs directory exists
if (!fs.existsSync(CONFIGS_DIR)) {
  fs.mkdirSync(CONFIGS_DIR, { recursive: true })
}

/**
 * List all saved configurations
 * @returns {Array<{filename: string, name: string, created: string}>}
 */
export function listConfigs() {
  const files = fs.readdirSync(CONFIGS_DIR)
    .filter(f => f.endsWith('.json'))

  return files.map(filename => {
    try {
      const content = fs.readFileSync(path.join(CONFIGS_DIR, filename), 'utf-8')
      const parsed = JSON.parse(content)
      return {
        filename,
        name: parsed.name || filename.replace('.json', ''),
        created: parsed.created || null,
        version: parsed.version || null,
      }
    } catch (e) {
      return {
        filename,
        name: filename.replace('.json', ''),
        created: null,
        version: null,
        error: e.message,
      }
    }
  })
}

/**
 * Save a configuration
 * @param {string} name - Config name (will be sanitized for filename)
 * @param {object} config - Configuration object
 * @returns {{success: boolean, filename: string, error?: string}}
 */
export function saveConfig(name, config) {
  // Sanitize filename
  const safeName = name.replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase()
  const filename = `${safeName}.json`
  const filepath = path.join(CONFIGS_DIR, filename)

  const data = {
    name,
    version: '1.0',
    created: new Date().toISOString(),
    config,
  }

  try {
    fs.writeFileSync(filepath, JSON.stringify(data, null, 2))
    return { success: true, filename }
  } catch (e) {
    return { success: false, filename, error: e.message }
  }
}

/**
 * Load a configuration by filename
 * @param {string} filename - Config filename
 * @returns {{success: boolean, config?: object, name?: string, error?: string}}
 */
export function loadConfig(filename) {
  const filepath = path.join(CONFIGS_DIR, filename)

  if (!fs.existsSync(filepath)) {
    return { success: false, error: 'Config not found' }
  }

  try {
    const content = fs.readFileSync(filepath, 'utf-8')
    const parsed = JSON.parse(content)
    return {
      success: true,
      name: parsed.name,
      config: parsed.config,
      created: parsed.created,
      version: parsed.version,
    }
  } catch (e) {
    return { success: false, error: e.message }
  }
}

/**
 * Delete a configuration
 * @param {string} filename - Config filename
 * @returns {{success: boolean, error?: string}}
 */
export function deleteConfig(filename) {
  const filepath = path.join(CONFIGS_DIR, filename)

  if (!fs.existsSync(filepath)) {
    return { success: false, error: 'Config not found' }
  }

  try {
    fs.unlinkSync(filepath)
    return { success: true }
  } catch (e) {
    return { success: false, error: e.message }
  }
}

export default {
  listConfigs,
  saveConfig,
  loadConfig,
  deleteConfig,
}
