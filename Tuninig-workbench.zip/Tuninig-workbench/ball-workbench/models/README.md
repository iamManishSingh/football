# Models Directory

Place your RF-DETR model weights here.

## Supported Models

The Python precompute script supports:
- `base` - RF-DETR Base (default)
- `large` - RF-DETR Large (more accurate, slower)

## Usage

Models are automatically downloaded by the `rfdetr` package when first used.

If you have custom weights, place them here and modify `precompute.py` to load them.
