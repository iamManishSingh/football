

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.ORE-GaEB.js","_app/immutable/chunks/D5CXPMaf.js","_app/immutable/chunks/BozxfvMh.js","_app/immutable/chunks/D6v0vpci.js","_app/immutable/chunks/B1bZW2ul.js","_app/immutable/chunks/mpRJvuPN.js","_app/immutable/chunks/DQk-li30.js"];
export const stylesheets = ["_app/immutable/assets/2.BLzaaY6d.css"];
export const fonts = [];
