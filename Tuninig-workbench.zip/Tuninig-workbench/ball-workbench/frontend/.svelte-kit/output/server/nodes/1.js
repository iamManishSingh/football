

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.BjGOSKMA.js","_app/immutable/chunks/D5CXPMaf.js","_app/immutable/chunks/BozxfvMh.js","_app/immutable/chunks/B1bZW2ul.js","_app/immutable/chunks/CYK0FZCP.js","_app/immutable/chunks/D6v0vpci.js"];
export const stylesheets = [];
export const fonts = [];
