import { $ as attr_class, a0 as attr, _ as derived, e as escape_html, a1 as attr_style, a2 as ensure_array_like, a3 as stringify, a4 as bind_props } from "../../chunks/index.js";
function html(value) {
  var html2 = String(value ?? "");
  var open = "<!---->";
  return open + html2 + "<!---->";
}
function VideoCanvas($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      videoInfo = null
    } = $$props;
    let containerWidth = 800;
    let containerHeight = 450;
    let showClipControls = false;
    let canvasWidth = derived(() => () => {
      if (!videoInfo) return 800;
      const aspectRatio = videoInfo.width / videoInfo.height;
      return Math.min(containerWidth, containerHeight * aspectRatio);
    });
    let canvasHeight = derived(() => () => {
      if (!videoInfo) return 450;
      const aspectRatio = videoInfo.width / videoInfo.height;
      return Math.min(containerHeight, containerWidth / aspectRatio);
    });
    $$renderer2.push(`<div class="vc-wrap svelte-1c4v0vj"><div${attr_class("vc-video-preview svelte-1c4v0vj", void 0, { "vc-video-hidden": !showClipControls })}><video preload="metadata" muted="" class="svelte-1c4v0vj"></video></div> <div${attr_class("canvas-container svelte-1c4v0vj", void 0, { "vc-behind": showClipControls })}><canvas${attr("width", canvasWidth()())}${attr("height", canvasHeight()())} class="svelte-1c4v0vj"></canvas></div> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function FilterGroup($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      groupName = "",
      label = "",
      icon = "filter",
      description = "",
      group = { enabled: false, params: {} },
      paramMeta = {},
      globalDisabled = false,
      onchange = () => {
      }
    } = $$props;
    let expanded = group.enabled;
    let childrenDisabled = derived(() => !group.enabled || globalDisabled);
    let bodyHeight = 0;
    function formatValue(val, meta) {
      if (val === void 0 || val === null) return "—";
      if (typeof val === "boolean") return val ? "ON" : "OFF";
      if (typeof val !== "number") return String(val);
      if (meta.step == null) return val.toString();
      if (meta.step < 1e-4) return val.toFixed(6);
      if (meta.step < 0.01) return val.toFixed(4);
      if (meta.step < 1) return val.toFixed(2);
      return val.toFixed(0);
    }
    let paramCount = derived(() => Object.keys(paramMeta).length);
    const icons = {
      filter: '<path d="M3 4h18v2H3V4zm3 5h12v2H6V9zm4 5h4v2h-4v-2z"/>',
      crop: '<path d="M17 15h2V7c0-1.1-.9-2-2-2H9v2h8v8zM7 17V1H5v4H1v2h4v10c0 1.1.9 2 2 2h10v4h2v-4h4v-2H7z"/>',
      eye: '<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>',
      ban: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM4 12c0-4.42 3.58-8 8-8 1.85 0 3.55.63 4.9 1.69L5.69 16.9C4.63 15.55 4 13.85 4 12zm8 8c-1.85 0-3.55-.63-4.9-1.69L18.31 7.1C19.37 8.45 20 10.15 20 12c0 4.42-3.58 8-8 8z"/>',
      crosshair: '<path d="M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm8.94 3c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/>',
      "trending-up": '<path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"/>',
      sliders: '<path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"/>',
      grid: '<path d="M4 4h4v4H4V4zm6 0h4v4h-4V4zm6 0h4v4h-4V4zM4 10h4v4H4v-4zm6 0h4v4h-4v-4zm6 0h4v4h-4v-4zM4 16h4v4H4v-4zm6 0h4v4h-4v-4zm6 0h4v4h-4v-4z"/>'
    };
    $$renderer2.push(`<div${attr_class("fg svelte-1ak6s9t", void 0, {
      "fg-on": group.enabled && !globalDisabled,
      "fg-off": !group.enabled,
      "fg-global-off": globalDisabled
    })}><button class="fg-head svelte-1ak6s9t"${attr("aria-expanded", expanded)}><span class="fg-sw svelte-1ak6s9t"><span${attr_class("fg-sw-track svelte-1ak6s9t", void 0, { "fg-sw-track-on": group.enabled })}></span> <span${attr_class("fg-sw-dot svelte-1ak6s9t", void 0, { "fg-sw-dot-on": group.enabled })}></span></span> <svg class="fg-ico svelte-1ak6s9t" viewBox="0 0 24 24">${html(icons[icon] || icons.filter)}</svg> <div class="fg-title svelte-1ak6s9t"><span class="fg-name svelte-1ak6s9t">${escape_html(label)}</span> <span class="fg-sub svelte-1ak6s9t">${escape_html(description)} · ${escape_html(paramCount())} params</span></div> <span${attr_class("fg-pill svelte-1ak6s9t", void 0, { "fg-pill-on": group.enabled })}>${escape_html(group.enabled ? "ON" : "OFF")}</span> <svg${attr_class("fg-chev svelte-1ak6s9t", void 0, { "fg-chev-open": expanded })} viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"></path></svg></button> <div class="fg-body-wrap svelte-1ak6s9t"${attr_style(`max-height: ${stringify(expanded ? bodyHeight + "px" : "0px")}`)}><div${attr_class("fg-body svelte-1ak6s9t", void 0, { "fg-body-off": childrenDisabled() })}>`);
    if (childrenDisabled() && !globalDisabled) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<p class="fg-hint svelte-1ak6s9t"><svg viewBox="0 0 24 24" class="fg-hint-ico svelte-1ak6s9t"><path d="M13 9h-2v2h2V9zm0 4h-2v6h2v-6zM12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2z"></path></svg> Enable this group to adjust its filters</p>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <!--[-->`);
    const each_array = ensure_array_like(Object.entries(paramMeta));
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let [paramName, meta] = each_array[$$index];
      $$renderer2.push(`<div${attr_class("fg-row svelte-1ak6s9t", void 0, { "fg-row-toggle": meta.type === "toggle" })}><div class="fg-row-top svelte-1ak6s9t"><span class="fg-lbl svelte-1ak6s9t">${escape_html(meta.label)}</span> <span class="fg-val mono svelte-1ak6s9t">`);
      if (meta.type === "toggle") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span${attr_class("fg-val-bool svelte-1ak6s9t", void 0, { "fg-val-bool-on": group.params[paramName] })}>${escape_html(group.params[paramName] ? "ON" : "OFF")}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`${escape_html(formatValue(group.params[paramName], meta))}`);
      }
      $$renderer2.push(`<!--]--></span></div> `);
      if (meta.type === "toggle") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="fg-mini-sw svelte-1ak6s9t"><span${attr_class("fg-mini-track svelte-1ak6s9t", void 0, { "fg-mini-track-on": group.params[paramName] })}></span> <span${attr_class("fg-mini-dot svelte-1ak6s9t", void 0, { "fg-mini-dot-on": group.params[paramName] })}></span></span>`);
      } else if (meta.type === "range") {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<div class="fg-slider svelte-1ak6s9t"><input type="range"${attr("min", meta.min)}${attr("max", meta.max)}${attr("step", meta.step)}${attr("value", group.params[paramName])}${attr("disabled", childrenDisabled(), true)}${attr_style(`--pct: ${stringify((group.params[paramName] - meta.min) / (meta.max - meta.min) * 100)}%`)} class="svelte-1ak6s9t"/> <div class="fg-slider-bounds svelte-1ak6s9t"><span class="mono">${escape_html(meta.min)}</span> <span class="mono">${escape_html(meta.max)}</span></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]--></div></div></div>`);
    bind_props($$props, { group });
  });
}
function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}
const DEFAULT_CONFIG = {
  // Mode: "base_model" shows raw RF-DETR output, "filter_tuned" applies filters
  mode: "filter_tuned",
  // Model-level settings (always applied)
  model: {
    threshold: 0.1,
    // Low threshold for RF-DETR, filter later
    class_id: 32,
    // COCO class ID for sports ball (also 37 in some models)
    nms_iou: 0.5,
    // NMS IoU threshold — lower = more aggressive suppression
    image_size: 560
    // Inference resolution (RF-DETR supports 560, 640, 800, etc.)
  },
  // Filter groups - each has enabled flag and params
  filter_groups: {
    // Basic Filters (Stage 3)
    basic: {
      enabled: true,
      params: {
        confidence_threshold: 0.35,
        rescue_threshold: 0.15,
        rescue_radius_px: 80,
        min_ball_area_ratio: 15e-6,
        max_ball_area_ratio: 48e-4,
        min_aspect_ratio: 0.5,
        max_aspect_ratio: 1.9
      }
    },
    // ROI / Pitch Mask (Stage 3E)
    roi: {
      enabled: false,
      params: {
        exclude_top_ratio: 0.08,
        exclude_bottom_ratio: 0.05,
        pitch_margin_pct: 5,
        // Custom polygon points (optional) - array of [x, y] normalized 0-1
        custom_polygon: null
      }
    },
    // Appearance Filters (Stage 4)
    appearance: {
      enabled: false,
      params: {
        circularity_enabled: true,
        circularity_min: 0.4,
        color_validation_enabled: false,
        color_whiteness_threshold: 0.3,
        player_overlap_enabled: false,
        player_overlap_iou: 0.7
      }
    },
    // Static Object Rejection (Stage 4.5)
    static: {
      enabled: true,
      params: {
        history_frames: 14,
        cluster_radius_px: 28,
        max_hit_ratio: 0.72,
        warmup_frames: 4
      }
    },
    // Kalman Tracking (Stage 6)
    tracking: {
      enabled: false,
      params: {
        max_lost_frames: 60,
        gravity_enabled: true,
        gravity_strength: 0.5,
        search_radius_base: 50,
        search_radius_growth: 5,
        confidence_decay_rate: 0.02,
        process_noise: 0.03,
        measurement_noise: 0.1
      }
    },
    // Trajectory Smoothing (Stage 7)
    smoothing: {
      enabled: false,
      params: {
        ema_alpha: 0.7,
        interpolation_max_gap: 20,
        max_valid_speed_px: 80,
        max_valid_accel_px: 40
      }
    },
    // Preprocessing (Stage 1)
    preprocessing: {
      enabled: false,
      params: {
        clahe_enabled: true,
        clahe_clip_limit: 2,
        sharpen_enabled: false,
        sharpen_strength: 0.3,
        gamma_enabled: false,
        gamma_value: 1
      }
    },
    // SAHI Tiled Inference (Stage 2)
    sahi: {
      enabled: false,
      params: {
        slice_width: 640,
        slice_height: 640,
        overlap_px: 100,
        iou_threshold: 0.3
      }
    }
  },
  // Single ball selection settings
  selection: {
    method: "weighted",
    // "highest_conf" | "weighted" | "nearest_prediction"
    weights: {
      proximity: 0.4,
      confidence: 0.4,
      shape: 0.2
    },
    max_jump_distance: 200
  },
  // Scene cut detection
  scene_cut_time_gap: 1.5,
  // Debug output
  debug: false
};
function createPresets() {
  deepClone(DEFAULT_CONFIG);
  return {
    "raw_model": {
      name: "Raw Model (No Filters)",
      description: "Shows raw RF-DETR output with only class ID filtering",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "base_model",
        filter_groups: Object.fromEntries(
          Object.entries(DEFAULT_CONFIG.filter_groups).map(([key, group]) => [
            key,
            { ...deepClone(group), enabled: false }
          ])
        )
      }
    },
    "light_filtering": {
      name: "Light Filtering",
      description: "Basic confidence and static rejection only",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          ...deepClone(DEFAULT_CONFIG.filter_groups),
          basic: { ...deepClone(DEFAULT_CONFIG.filter_groups.basic), enabled: true },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: false },
          appearance: { ...deepClone(DEFAULT_CONFIG.filter_groups.appearance), enabled: false },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: false },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: { ...deepClone(DEFAULT_CONFIG.filter_groups.preprocessing), enabled: false },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false }
        }
      }
    },
    "broadcast_daytime": {
      name: "Broadcast Daytime",
      description: "Optimized for professional broadcast footage in daylight",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.45
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: { ...deepClone(DEFAULT_CONFIG.filter_groups.appearance), enabled: true },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: true },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: { ...deepClone(DEFAULT_CONFIG.filter_groups.preprocessing), enabled: false },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false }
        }
      }
    },
    "broadcast_night": {
      name: "Broadcast Night",
      description: "Optimized for professional broadcast footage under floodlights",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.3
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: { ...deepClone(DEFAULT_CONFIG.filter_groups.appearance), enabled: true },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: true },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: true,
              clahe_clip_limit: 3.5
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false }
        }
      }
    },
    "wide_angle_amateur": {
      name: "Wide Angle / Amateur",
      description: "For amateur footage with distant/small ball",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.25
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: { ...deepClone(DEFAULT_CONFIG.filter_groups.appearance), enabled: false },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          tracking: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.tracking.params,
              max_lost_frames: 90
            }
          },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: { ...deepClone(DEFAULT_CONFIG.filter_groups.preprocessing), enabled: false },
          sahi: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.sahi.params,
              slice_width: 480,
              slice_height: 480
            }
          }
        }
      }
    },
    "harsh_shadows": {
      name: "Harsh Shadows",
      description: "Daytime with strong ground shadows causing false positives",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.4,
              min_aspect_ratio: 0.55,
              max_aspect_ratio: 1.8
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.appearance.params,
              circularity_enabled: true,
              circularity_min: 0.5,
              color_validation_enabled: true,
              color_whiteness_threshold: 0.25
            }
          },
          static: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.static.params,
              history_frames: 18,
              max_hit_ratio: 0.65,
              cluster_radius_px: 32
            }
          },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: true },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: true,
              clahe_clip_limit: 2.5,
              gamma_enabled: true,
              gamma_value: 0.85
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false }
        }
      }
    },
    "fog_haze": {
      name: "Fog / Haze",
      description: "Low visibility, washed-out colours from fog or mist",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        model: {
          ...DEFAULT_CONFIG.model,
          threshold: 0.08,
          image_size: 640
        },
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.22,
              rescue_threshold: 0.1,
              rescue_radius_px: 100,
              min_ball_area_ratio: 12e-6
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.appearance.params,
              circularity_enabled: true,
              circularity_min: 0.35,
              color_validation_enabled: false
            }
          },
          static: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.static.params,
              history_frames: 20,
              max_hit_ratio: 0.78,
              warmup_frames: 6
            }
          },
          tracking: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.tracking.params,
              max_lost_frames: 90,
              search_radius_base: 70,
              search_radius_growth: 8,
              process_noise: 0.05,
              measurement_noise: 0.15
            }
          },
          smoothing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.smoothing.params,
              ema_alpha: 0.6,
              interpolation_max_gap: 30
            }
          },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: true,
              clahe_clip_limit: 4,
              sharpen_enabled: true,
              sharpen_strength: 0.5,
              gamma_enabled: true,
              gamma_value: 0.75
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false }
        }
      }
    },
    "bright_daylight": {
      name: "Bright Daylight",
      description: "Overexposed / high-glare conditions under strong sun",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.4,
              max_ball_area_ratio: 6e-3
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.appearance.params,
              circularity_enabled: true,
              circularity_min: 0.45,
              color_validation_enabled: true,
              color_whiteness_threshold: 0.4
            }
          },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: true },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: false,
              gamma_enabled: true,
              gamma_value: 1.25
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false }
        }
      }
    },
    "mixed_conditions": {
      name: "Mixed / Varying Light",
      description: "Changing light, partial clouds, varying shadows throughout match",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        model: {
          ...DEFAULT_CONFIG.model,
          threshold: 0.08
        },
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.28,
              rescue_threshold: 0.12,
              rescue_radius_px: 90,
              min_aspect_ratio: 0.5,
              max_aspect_ratio: 1.95
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.appearance.params,
              circularity_enabled: true,
              circularity_min: 0.38,
              color_validation_enabled: false
            }
          },
          static: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.static.params,
              history_frames: 16,
              max_hit_ratio: 0.7
            }
          },
          tracking: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.tracking.params,
              max_lost_frames: 75,
              search_radius_base: 60,
              process_noise: 0.04,
              measurement_noise: 0.12
            }
          },
          smoothing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.smoothing.params,
              ema_alpha: 0.65,
              interpolation_max_gap: 25
            }
          },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: true,
              clahe_clip_limit: 3,
              gamma_enabled: true,
              gamma_value: 0.9
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false }
        }
      }
    }
  };
}
let _presets = null;
const PRESETS = new Proxy({}, {
  get(target, prop) {
    if (_presets === null) {
      _presets = createPresets();
    }
    return _presets[prop];
  },
  ownKeys() {
    if (_presets === null) {
      _presets = createPresets();
    }
    return Object.keys(_presets);
  },
  getOwnPropertyDescriptor(target, prop) {
    if (_presets === null) {
      _presets = createPresets();
    }
    return Object.getOwnPropertyDescriptor(_presets, prop);
  }
});
const PARAM_METADATA = {
  basic: {
    label: "Basic Filters",
    icon: "filter",
    description: "Confidence, size, and aspect ratio filtering",
    params: {
      confidence_threshold: { label: "Confidence Threshold", min: 0.05, max: 0.95, step: 0.01, type: "range" },
      rescue_threshold: { label: "Rescue Threshold", min: 0.05, max: 0.5, step: 0.01, type: "range" },
      rescue_radius_px: { label: "Rescue Radius (px)", min: 20, max: 300, step: 5, type: "range" },
      min_ball_area_ratio: { label: "Min Ball Area Ratio", min: 5e-6, max: 1e-3, step: 5e-6, type: "range" },
      max_ball_area_ratio: { label: "Max Ball Area Ratio", min: 1e-3, max: 0.02, step: 1e-4, type: "range" },
      min_aspect_ratio: { label: "Min Aspect Ratio", min: 0.2, max: 0.9, step: 0.01, type: "range" },
      max_aspect_ratio: { label: "Max Aspect Ratio", min: 1.1, max: 3, step: 0.01, type: "range" }
    }
  },
  roi: {
    label: "ROI / Pitch Mask",
    icon: "crop",
    description: "Region of interest filtering",
    params: {
      exclude_top_ratio: { label: "Exclude Top Ratio", min: 0, max: 0.3, step: 0.01, type: "range" },
      exclude_bottom_ratio: { label: "Exclude Bottom Ratio", min: 0, max: 0.3, step: 0.01, type: "range" },
      pitch_margin_pct: { label: "Pitch Margin %", min: 0, max: 20, step: 1, type: "range" }
    }
  },
  appearance: {
    label: "Appearance Filters",
    icon: "eye",
    description: "Shape and color validation",
    params: {
      circularity_enabled: { label: "Circularity Check", type: "toggle" },
      circularity_min: { label: "Min Circularity", min: 0.1, max: 0.9, step: 0.01, type: "range" },
      color_validation_enabled: { label: "Color Validation", type: "toggle" },
      color_whiteness_threshold: { label: "Whiteness Threshold", min: 0.1, max: 0.8, step: 0.01, type: "range" },
      player_overlap_enabled: { label: "Player Overlap Check", type: "toggle" },
      player_overlap_iou: { label: "Player Overlap IoU", min: 0.3, max: 0.95, step: 0.01, type: "range" }
    }
  },
  static: {
    label: "Static Object Rejection",
    icon: "ban",
    description: "Reject stationary false positives",
    params: {
      history_frames: { label: "History Frames", min: 5, max: 60, step: 1, type: "range" },
      cluster_radius_px: { label: "Cluster Radius (px)", min: 5, max: 80, step: 1, type: "range" },
      max_hit_ratio: { label: "Max Hit Ratio", min: 0.3, max: 0.95, step: 0.01, type: "range" },
      warmup_frames: { label: "Warmup Frames", min: 1, max: 20, step: 1, type: "range" }
    }
  },
  tracking: {
    label: "Kalman Tracking",
    icon: "crosshair",
    description: "Prediction and tracking through occlusions",
    params: {
      max_lost_frames: { label: "Max Lost Frames", min: 10, max: 120, step: 5, type: "range" },
      gravity_enabled: { label: "Gravity Model", type: "toggle" },
      gravity_strength: { label: "Gravity Strength", min: 0.1, max: 3, step: 0.1, type: "range" },
      search_radius_base: { label: "Search Radius Base (px)", min: 10, max: 200, step: 5, type: "range" },
      search_radius_growth: { label: "Search Radius Growth", min: 1, max: 20, step: 1, type: "range" },
      confidence_decay_rate: { label: "Confidence Decay Rate", min: 5e-3, max: 0.1, step: 5e-3, type: "range" },
      process_noise: { label: "Process Noise", min: 5e-3, max: 0.2, step: 5e-3, type: "range" },
      measurement_noise: { label: "Measurement Noise", min: 0.01, max: 1, step: 0.01, type: "range" }
    }
  },
  smoothing: {
    label: "Trajectory Smoothing",
    icon: "trending-up",
    description: "Position smoothing and physics validation",
    params: {
      ema_alpha: { label: "EMA Alpha", min: 0.2, max: 0.98, step: 0.01, type: "range" },
      interpolation_max_gap: { label: "Max Interpolation Gap", min: 3, max: 60, step: 1, type: "range" },
      max_valid_speed_px: { label: "Max Valid Speed (px/frame)", min: 20, max: 200, step: 5, type: "range" },
      max_valid_accel_px: { label: "Max Valid Accel (px/frame²)", min: 5, max: 100, step: 5, type: "range" }
    }
  },
  preprocessing: {
    label: "Preprocessing",
    icon: "sliders",
    description: "Image enhancement for difficult conditions",
    params: {
      clahe_enabled: { label: "CLAHE Enhancement", type: "toggle" },
      clahe_clip_limit: { label: "CLAHE Clip Limit", min: 1, max: 6, step: 0.1, type: "range" },
      sharpen_enabled: { label: "Sharpening", type: "toggle" },
      sharpen_strength: { label: "Sharpen Strength", min: 0.1, max: 2, step: 0.1, type: "range" },
      gamma_enabled: { label: "Gamma Correction", type: "toggle" },
      gamma_value: { label: "Gamma Value", min: 0.3, max: 3, step: 0.1, type: "range" }
    }
  },
  sahi: {
    label: "SAHI (Tiled Inference)",
    icon: "grid",
    description: "Tiled inference for small ball detection",
    params: {
      slice_width: { label: "Slice Width", min: 200, max: 1200, step: 20, type: "range" },
      slice_height: { label: "Slice Height", min: 200, max: 1200, step: 20, type: "range" },
      overlap_px: { label: "Overlap (px)", min: 20, max: 300, step: 10, type: "range" },
      iou_threshold: { label: "IoU Threshold", min: 0.1, max: 0.7, step: 0.05, type: "range" }
    }
  }
};
function cloneConfig(config) {
  return deepClone(config);
}
function FilterPanel($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      config = {},
      mode = "filter_tuned",
      disabled = false,
      onchange = () => {
      },
      onapply = () => {
      },
      onreset = () => {
      },
      onloadpreset = (key) => {
      }
    } = $$props;
    let hasChanges = false;
    let presetDrawerOpen = false;
    function markChanged() {
      hasChanges = true;
      onchange();
    }
    const groupOrder = [
      "basic",
      "roi",
      "appearance",
      "static",
      "tracking",
      "smoothing",
      "preprocessing",
      "sahi"
    ];
    let enabledCount = derived(() => groupOrder.filter((g) => config.filter_groups?.[g]?.enabled).length);
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="fp svelte-85s9jg"><div class="fp-header svelte-85s9jg"><h3 class="svelte-85s9jg">Filter Configuration</h3> <div class="fp-mode svelte-85s9jg"><button${attr_class("fp-mode-btn svelte-85s9jg", void 0, { "active": mode === "base_model" })}${attr("disabled", disabled, true)}>Base Model</button> <button${attr_class("fp-mode-btn svelte-85s9jg", void 0, { "active": mode === "filter_tuned" })}${attr("disabled", disabled, true)}>Filter-Tuned</button></div> `);
      if (mode === "filter_tuned") {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="fp-summary svelte-85s9jg"><span class="fp-summary-count svelte-85s9jg">${escape_html(enabledCount())}/${escape_html(groupOrder.length)} groups active</span> <div class="fp-quick-actions svelte-85s9jg"><button class="fp-quick-btn svelte-85s9jg"${attr("disabled", disabled, true)}>All On</button> <button class="fp-quick-btn svelte-85s9jg"${attr("disabled", disabled, true)}>All Off</button></div></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div> `);
      if (mode === "filter_tuned") {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div${attr_class("fp-preset-drawer svelte-85s9jg", void 0, { "fp-drawer-open": presetDrawerOpen })}><button class="fp-drawer-trigger svelte-85s9jg"${attr("disabled", disabled, true)}><span class="fp-drawer-label svelte-85s9jg"><svg viewBox="0 0 24 24" class="fp-drawer-ico svelte-85s9jg"><path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z" class="svelte-85s9jg"></path></svg> Presets</span> `);
        {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<span class="fp-drawer-none svelte-85s9jg">Select a preset…</span>`);
        }
        $$renderer3.push(`<!--]--> <svg${attr_class("fp-drawer-chev svelte-85s9jg", void 0, { "fp-drawer-chev-open": presetDrawerOpen })} viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z" class="svelte-85s9jg"></path></svg></button> `);
        {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> <div class="fp-body svelte-85s9jg">`);
      if (mode === "base_model") {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="fp-base-params svelte-85s9jg"><div class="fp-base-param svelte-85s9jg"><div class="fp-inline-param svelte-85s9jg"><span class="fp-inline-label svelte-85s9jg">Confidence Threshold</span> <span class="fp-inline-val mono svelte-85s9jg">${escape_html(config.model?.threshold?.toFixed(2) ?? "0.10")}</span></div> <input type="range" min="0.01" max="0.90" step="0.01"${attr("value", config.model?.threshold ?? 0.1)}${attr("disabled", disabled, true)} class="svelte-85s9jg"/> <span class="fp-param-hint svelte-85s9jg">Lower = more detections, higher = stricter</span></div> <div class="fp-base-param svelte-85s9jg"><div class="fp-inline-param svelte-85s9jg"><span class="fp-inline-label svelte-85s9jg">NMS / IoU Threshold</span> <span class="fp-inline-val mono svelte-85s9jg">${escape_html(config.model?.nms_iou?.toFixed(2) ?? "0.50")}</span></div> <input type="range" min="0.10" max="0.95" step="0.01"${attr("value", config.model?.nms_iou ?? 0.5)}${attr("disabled", disabled, true)} class="svelte-85s9jg"/> <span class="fp-param-hint svelte-85s9jg">Lower = suppress more overlapping boxes</span></div> <div class="fp-base-param svelte-85s9jg"><div class="fp-inline-param svelte-85s9jg"><span class="fp-inline-label svelte-85s9jg">Image Size</span> <span class="fp-inline-val mono svelte-85s9jg">${escape_html(config.model?.image_size ?? 560)}px</span></div> <input type="range" min="320" max="1280" step="32"${attr("value", config.model?.image_size ?? 560)}${attr("disabled", disabled, true)} class="svelte-85s9jg"/> <span class="fp-param-hint svelte-85s9jg">Higher = better accuracy, slower inference</span></div></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<details class="fp-section svelte-85s9jg" open=""><summary class="fp-section-title svelte-85s9jg"><svg viewBox="0 0 24 24" class="fp-section-icon svelte-85s9jg"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z" class="svelte-85s9jg"></path></svg> Model Settings</summary> <div class="fp-section-body svelte-85s9jg"><div class="fp-inline-param svelte-85s9jg"><span class="fp-inline-label svelte-85s9jg">Detection Threshold</span> <span class="fp-inline-val mono svelte-85s9jg">${escape_html(config.model?.threshold?.toFixed(2) ?? "0.10")}</span></div> <input type="range" min="0.01" max="0.50" step="0.01"${attr("value", config.model?.threshold ?? 0.1)}${attr("disabled", disabled, true)} class="svelte-85s9jg"/> <div class="fp-inline-param svelte-85s9jg"><span class="fp-inline-label svelte-85s9jg">COCO Class ID</span> <span class="fp-inline-val mono svelte-85s9jg">${escape_html(config.model?.class_id ?? 32)}</span></div> <input type="range" min="0" max="80" step="1"${attr("value", config.model?.class_id ?? 32)}${attr("disabled", disabled, true)} class="svelte-85s9jg"/></div></details>`);
      }
      $$renderer3.push(`<!--]--> `);
      if (mode === "filter_tuned") {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<!--[-->`);
        const each_array_1 = ensure_array_like(groupOrder);
        for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
          let groupName = each_array_1[$$index_1];
          const meta = PARAM_METADATA[groupName];
          if (meta && config.filter_groups?.[groupName]) {
            $$renderer3.push("<!--[-->");
            FilterGroup($$renderer3, {
              groupName,
              label: meta.label,
              icon: meta.icon,
              description: meta.description,
              paramMeta: meta.params,
              globalDisabled: disabled,
              onchange: markChanged,
              get group() {
                return config.filter_groups[groupName];
              },
              set group($$value) {
                config.filter_groups[groupName] = $$value;
                $$settled = false;
              }
            });
          } else {
            $$renderer3.push("<!--[!-->");
          }
          $$renderer3.push(`<!--]-->`);
        }
        $$renderer3.push(`<!--]-->`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      if (mode === "filter_tuned") {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<details class="fp-section svelte-85s9jg"><summary class="fp-section-title svelte-85s9jg"><svg viewBox="0 0 24 24" class="fp-section-icon svelte-85s9jg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" class="svelte-85s9jg"></path></svg> Ball Selection</summary> <div class="fp-section-body svelte-85s9jg"><div class="fp-inline-param svelte-85s9jg"><span class="fp-inline-label svelte-85s9jg">Selection Method</span> `);
        $$renderer3.select(
          {
            value: config.selection?.method ?? "weighted",
            onchange: (e) => {
              config.selection.method = e.target.value;
              markChanged();
            },
            disabled,
            class: ""
          },
          ($$renderer4) => {
            $$renderer4.option(
              { value: "highest_conf", class: "" },
              ($$renderer5) => {
                $$renderer5.push(`Highest Confidence`);
              },
              "svelte-85s9jg"
            );
            $$renderer4.option(
              { value: "weighted", class: "" },
              ($$renderer5) => {
                $$renderer5.push(`Weighted (proximity + conf + shape)`);
              },
              "svelte-85s9jg"
            );
            $$renderer4.option(
              { value: "nearest_prediction", class: "" },
              ($$renderer5) => {
                $$renderer5.push(`Nearest to Prediction`);
              },
              "svelte-85s9jg"
            );
          },
          "svelte-85s9jg"
        );
        $$renderer3.push(`</div> <div class="fp-inline-param svelte-85s9jg"><span class="fp-inline-label svelte-85s9jg">Max Jump Distance (px)</span> <span class="fp-inline-val mono svelte-85s9jg">${escape_html(config.selection?.max_jump_distance ?? 200)}</span></div> <input type="range" min="50" max="600" step="10"${attr("value", config.selection?.max_jump_distance ?? 200)}${attr("disabled", disabled, true)} class="svelte-85s9jg"/></div></details>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> <div class="fp-debug-row svelte-85s9jg"><span class="svelte-85s9jg">Debug output</span> <label class="fp-debug-toggle svelte-85s9jg"><input type="checkbox"${attr("checked", config.debug ?? false, true)}${attr("disabled", disabled, true)} class="svelte-85s9jg"/> <span class="fp-toggle-track svelte-85s9jg"></span> <span class="fp-toggle-thumb svelte-85s9jg"></span></label></div></div> <div class="fp-actions svelte-85s9jg"><button class="btn btn-secondary svelte-85s9jg"${attr("disabled", !hasChanges, true)}>Discard</button> <button${attr_class("btn btn-primary svelte-85s9jg", void 0, { "fp-pulse": hasChanges })}>${escape_html(hasChanges ? "● Apply Changes" : "Applied ✓")}</button></div></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { config, mode });
  });
}
function DebugOverlay($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      settings = {
        showDetected: true,
        showRejected: true,
        showPredicted: true,
        showRoiMask: false,
        showTrajectory: false,
        showVelocity: false
      },
      onchange = () => {
      }
    } = $$props;
    const overlayOptions = [
      { key: "showDetected", label: "Detected", color: "success" },
      { key: "showRejected", label: "Rejected", color: "error" },
      { key: "showPredicted", label: "Predicted", color: "info" },
      { key: "showRoiMask", label: "ROI Mask", color: "warning" },
      { key: "showVelocity", label: "Velocity", color: "purple" }
    ];
    $$renderer2.push(`<div class="debug-overlay svelte-9j9c2r"><span class="label svelte-9j9c2r">Overlays:</span> <div class="chips svelte-9j9c2r"><!--[-->`);
    const each_array = ensure_array_like(overlayOptions);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let option = each_array[$$index];
      $$renderer2.push(`<button${attr_class(`chip ${stringify(option.color)}`, "svelte-9j9c2r", { "active": settings[option.key] })}><span class="chip-dot svelte-9j9c2r"></span> ${escape_html(option.label)}</button>`);
    }
    $$renderer2.push(`<!--]--></div></div>`);
    bind_props($$props, { settings });
  });
}
function StatsHUD($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      frameResult = null,
      frameIndex = 0,
      cacheSize = 0,
      isProcessing = false,
      mode = "filter_tuned"
    } = $$props;
    let expanded = false;
    let pulse = false;
    let confidence = derived(() => frameResult?.ball?.confidences?.[0] || 0);
    let source = derived(() => frameResult?.meta?.source || "none");
    let rawCount = derived(() => frameResult?.raw?.bboxes?.length || 0);
    let filteredCount = derived(() => frameResult?.ball?.bboxes?.length || 0);
    let rejectedCount = derived(() => frameResult?.debug?.rejected?.length || 0);
    let detectionRate = derived(() => "—");
    function confColor(c) {
      if (c >= 0.7) return "var(--success)";
      if (c >= 0.4) return "var(--warning)";
      if (c > 0) return "var(--error)";
      return "var(--text-muted)";
    }
    function sourceLabel(s) {
      if (s === "detected") return "DET";
      if (s === "predicted") return "PRED";
      if (s === "lost" || s === "no_data") return "LOST";
      return "—";
    }
    function sourceColor(s) {
      if (s === "detected") return "var(--success)";
      if (s === "predicted") return "var(--warning)";
      return "var(--error)";
    }
    if (frameResult) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div${attr_class("stats-hud svelte-ao3y14", void 0, { "expanded": expanded, "pulse": pulse })}><button class="hud-bar svelte-ao3y14"><span class="hud-cell hud-frame svelte-ao3y14"><span class="hud-label svelte-ao3y14">FRM</span> <span class="hud-val mono svelte-ao3y14">${escape_html(frameIndex)}</span></span> <span class="hud-cell hud-conf svelte-ao3y14"><span class="hud-dot svelte-ao3y14"${attr_style("", { background: confColor(confidence()) })}></span> <span class="hud-val mono svelte-ao3y14">${escape_html(confidence() > 0 ? confidence().toFixed(2) : "—")}</span></span> <span class="hud-cell hud-source svelte-ao3y14"><span class="hud-source-badge svelte-ao3y14"${attr_style("", { background: sourceColor(source()) })}>${escape_html(sourceLabel(source()))}</span></span> <span class="hud-cell svelte-ao3y14"><span class="hud-label svelte-ao3y14">RATE</span> <span class="hud-val mono svelte-ao3y14">${escape_html(detectionRate())}%</span></span> <span class="hud-cell hud-pipeline svelte-ao3y14"><span class="hud-val mono svelte-ao3y14">${escape_html(rawCount())}</span> <span class="hud-arrow svelte-ao3y14">→</span> <span class="hud-val mono svelte-ao3y14">${escape_html(filteredCount())}</span> `);
      if (rejectedCount() > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="hud-rejected-badge svelte-ao3y14">-${escape_html(rejectedCount())}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></span> `);
      if (cacheSize > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="hud-cell svelte-ao3y14"><span class="hud-label svelte-ao3y14">CACHE</span> <span class="hud-val mono svelte-ao3y14">${escape_html(cacheSize)}</span></span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (isProcessing) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="hud-cell hud-live svelte-ao3y14"><span class="hud-live-dot svelte-ao3y14"></span> LIVE</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <span class="hud-cell hud-mode svelte-ao3y14">${escape_html(mode === "base_model" ? "BASE" : "TUNED")}</span> <span${attr_class("hud-chevron svelte-ao3y14", void 0, { "rotated": expanded })}>▾</span></button> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let config = cloneConfig(DEFAULT_CONFIG);
    let pipeline = null;
    let videoInfo = { width: 1920, height: 1080, fps: 25, totalFrames: 0 };
    let currentFrame = 0;
    let frameResult = null;
    let overlaySettings = {
      showDetected: true,
      showRejected: true,
      showPredicted: true,
      showRoiMask: false,
      showVelocity: false
    };
    let activeTab = "filters";
    let wsConnected = false;
    let ws = null;
    let toast = null;
    let isProcessing = false;
    let cacheSize = 0;
    function showToast(message, type = "info") {
      toast = { message, type };
      setTimeout(() => toast = null, 3e3);
    }
    function processFrame(frameIdx) {
      {
        console.warn("No detection frames available");
        return;
      }
    }
    function handleConfigChange() {
    }
    function handleApply() {
      pipeline.updateConfig(config);
      processFrame();
      showToast("Config applied", "success");
      if (ws?.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: "update_config", config }));
      }
    }
    function handleReset() {
      config = cloneConfig(DEFAULT_CONFIG);
      pipeline.updateConfig(config);
      processFrame();
      showToast("Config reset to defaults", "info");
    }
    function handleLoadPreset(key) {
      const preset = PRESETS[key];
      if (preset) {
        config = cloneConfig(preset.config);
        pipeline.updateConfig(config);
        processFrame();
        showToast(`Loaded preset: ${preset.name}`, "success");
      }
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="workbench svelte-1uha8ag"><header class="header svelte-1uha8ag"><div class="header-shimmer svelte-1uha8ag"></div> <div class="header-left svelte-1uha8ag"><div class="logo-mark svelte-1uha8ag"><svg viewBox="0 0 40 40" class="logo-icon svelte-1uha8ag" xmlns="http://www.w3.org/2000/svg"><defs class="svelte-1uha8ag"><linearGradient id="logoGrad" x1="0" y1="0" x2="40" y2="40" class="svelte-1uha8ag"><stop offset="0%" stop-color="var(--accent-light)" class="svelte-1uha8ag"></stop><stop offset="100%" stop-color="var(--teal)" class="svelte-1uha8ag"></stop></linearGradient><radialGradient id="ballShine" cx="35%" cy="30%" r="65%" class="svelte-1uha8ag"><stop offset="0%" stop-color="#ffffff" stop-opacity="0.35" class="svelte-1uha8ag"></stop><stop offset="100%" stop-color="#ffffff" stop-opacity="0" class="svelte-1uha8ag"></stop></radialGradient></defs><circle cx="20" cy="20" r="17" fill="#f0f0f0" stroke="url(#logoGrad)" stroke-width="1.8" class="fb-body svelte-1uha8ag"></circle><polygon points="20,8 23.5,11.5 22,16 18,16 16.5,11.5" fill="#1a1a2e" class="fb-patch svelte-1uha8ag"></polygon><polygon points="28,15 32,18 31,23 27,23 26,18" fill="#1a1a2e" class="fb-patch svelte-1uha8ag"></polygon><polygon points="12,15 14,18 13,23 9,23 8,18" fill="#1a1a2e" class="fb-patch svelte-1uha8ag"></polygon><polygon points="15,27 18,24 22,24 25,27 22,31 18,31" fill="#1a1a2e" class="fb-patch svelte-1uha8ag"></polygon><line x1="16.5" y1="11.5" x2="14" y2="18" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" class="svelte-1uha8ag"></line><line x1="23.5" y1="11.5" x2="26" y2="18" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" class="svelte-1uha8ag"></line><line x1="22" y1="16" x2="22" y2="24" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" class="svelte-1uha8ag"></line><line x1="18" y1="16" x2="18" y2="24" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" class="svelte-1uha8ag"></line><line x1="27" y1="23" x2="25" y2="27" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" class="svelte-1uha8ag"></line><line x1="13" y1="23" x2="15" y2="27" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" class="svelte-1uha8ag"></line><circle cx="20" cy="20" r="17" fill="url(#ballShine)" class="svelte-1uha8ag"></circle><circle cx="20" cy="20" r="19" fill="none" stroke="url(#logoGrad)" stroke-width="1.5" stroke-dasharray="12 108" stroke-linecap="round" class="logo-scan svelte-1uha8ag" opacity="0.6"></circle></svg></div> <div class="title-group svelte-1uha8ag"><h1 class="app-title svelte-1uha8ag"><span class="title-text svelte-1uha8ag">Ball Detection</span> <span class="title-separator svelte-1uha8ag">·</span> <span class="title-accent svelte-1uha8ag">Filter Tuning</span></h1> <span class="app-subtitle svelte-1uha8ag">RF-DETR Workbench</span></div> <div class="status-badges svelte-1uha8ag"><span${attr_class("hdr-badge svelte-1uha8ag", void 0, {
        "hdr-badge-online": wsConnected,
        "hdr-badge-offline": !wsConnected
      })}><span${attr_class("hdr-badge-dot svelte-1uha8ag", void 0, { "dot-pulse": wsConnected })}></span> ${escape_html("Offline")}</span> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div></div> <div class="header-right svelte-1uha8ag"><label class="hdr-btn hdr-btn-video svelte-1uha8ag"><span class="hdr-btn-icon svelte-1uha8ag"><svg viewBox="0 0 24 24" class="svelte-1uha8ag"><path d="M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4h-4z" fill="currentColor" class="svelte-1uha8ag"></path></svg></span> <span class="hdr-btn-label svelte-1uha8ag">${escape_html("Upload Video")}</span> <input type="file" accept="video/*" style="display: none" class="svelte-1uha8ag"/></label> <label class="hdr-btn hdr-btn-detect svelte-1uha8ag"><span class="hdr-btn-icon svelte-1uha8ag"><svg viewBox="0 0 24 24" class="svelte-1uha8ag"><path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z" fill="currentColor" class="svelte-1uha8ag"></path></svg></span> <span class="hdr-btn-label svelte-1uha8ag">Load Detections</span> <input type="file" accept=".json" style="display: none" class="svelte-1uha8ag"/></label></div></header> <div class="main-content svelte-1uha8ag"><div class="video-area svelte-1uha8ag"><div class="video-canvas-wrapper svelte-1uha8ag">`);
      VideoCanvas($$renderer3, {
        videoInfo
      });
      $$renderer3.push(`<!----> `);
      StatsHUD($$renderer3, {
        frameResult,
        frameIndex: currentFrame,
        cacheSize,
        isProcessing,
        mode: config.mode
      });
      $$renderer3.push(`<!----></div> `);
      DebugOverlay($$renderer3, {
        get settings() {
          return overlaySettings;
        },
        set settings($$value) {
          overlaySettings = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div> <div class="side-panel svelte-1uha8ag"><div class="tabs svelte-1uha8ag"><button${attr_class("tab svelte-1uha8ag", void 0, { "active": activeTab === "filters" })}>Filters</button> <button${attr_class("tab svelte-1uha8ag", void 0, { "active": activeTab === "config" })}>Config</button></div> <div class="tab-content svelte-1uha8ag">`);
      {
        $$renderer3.push("<!--[-->");
        FilterPanel($$renderer3, {
          disabled: false,
          onchange: handleConfigChange,
          onapply: handleApply,
          onreset: handleReset,
          onloadpreset: handleLoadPreset,
          get config() {
            return config;
          },
          set config($$value) {
            config = $$value;
            $$settled = false;
          },
          get mode() {
            return config.mode;
          },
          set mode($$value) {
            config.mode = $$value;
            $$settled = false;
          }
        });
      }
      $$renderer3.push(`<!--]--></div></div></div> `);
      if (toast) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="toast-container svelte-1uha8ag"><div${attr_class(`toast toast-${stringify(toast.type)}`, "svelte-1uha8ag")}>${escape_html(toast.message)}</div></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
