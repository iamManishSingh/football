export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set([]),
	mimeTypes: {},
	_: {
		client: {start:"_app/immutable/entry/start.DLGHXzgf.js",app:"_app/immutable/entry/app.BEA9OtHh.js",imports:["_app/immutable/entry/start.DLGHXzgf.js","_app/immutable/chunks/CYK0FZCP.js","_app/immutable/chunks/BozxfvMh.js","_app/immutable/chunks/D6v0vpci.js","_app/immutable/entry/app.BEA9OtHh.js","_app/immutable/chunks/BozxfvMh.js","_app/immutable/chunks/B1bZW2ul.js","_app/immutable/chunks/D5CXPMaf.js","_app/immutable/chunks/D6v0vpci.js","_app/immutable/chunks/mpRJvuPN.js","_app/immutable/chunks/DQk-li30.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
