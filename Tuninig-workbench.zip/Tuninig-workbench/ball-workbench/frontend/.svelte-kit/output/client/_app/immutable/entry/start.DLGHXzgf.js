import{l as o,a as r}from"../chunks/CYK0FZCP.js";export{o as load_css,r as start};
