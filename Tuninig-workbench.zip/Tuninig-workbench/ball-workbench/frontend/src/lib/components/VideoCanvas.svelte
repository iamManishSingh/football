<script>
  /**
   * VideoCanvas Component
   *
   * Canvas for video playback with detection overlays.
   * Also hosts the uploaded <video> element for preview and clip-time selection.
   */

  import { onMount } from 'svelte'

  let {
    frameResult = null,
    videoInfo = null,
    frameImage = null,
    overlaySettings = {
      showDetected: true,
      showRejected: true,
      showPredicted: true,
      showRoiMask: false,
    },
    // Video file for preview / clip selection
    videoFile = null,
    videoReady = false,       // True once video is uploaded & ready
    isProcessing = false,     // True while inference is running
    processingProgress = 0,
    inferenceAvailable = false, // True when Python inference server is available
    cacheSize = 0,            // Number of frames cached
    currentFrame = 0,         // Current displayed frame index
    totalFrames = 0,          // Total frames in video
    onStartDetection = (startSec, endSec) => {},
    onStopDetection = () => {},
    onRestartDetection = () => {},
    onSeekFrame = (frameIdx) => {},
  } = $props()

  let canvas
  let ctx
  let videoEl = $state(null)  // The <video> element reference
  let containerWidth = $state(800)
  let containerHeight = $state(450)

  // Clip-time controls
  let clipStart = $state(0)
  let clipEnd = $state(0)
  let videoDuration = $state(0)
  let showClipControls = $state(false)

  // Canvas dimensions based on video aspect ratio
  let canvasWidth = $derived(() => {
    if (!videoInfo) return 800
    const aspectRatio = videoInfo.width / videoInfo.height
    return Math.min(containerWidth, containerHeight * aspectRatio)
  })

  let canvasHeight = $derived(() => {
    if (!videoInfo) return 450
    const aspectRatio = videoInfo.width / videoInfo.height
    return Math.min(containerHeight, containerWidth / aspectRatio)
  })

  // Scale factor for drawing
  let scale = $derived(() => {
    if (!videoInfo) return 1
    return canvasWidth() / videoInfo.width
  })

  onMount(() => {
    ctx = canvas.getContext('2d')
    const resizeObserver = new ResizeObserver(entries => {
      for (const entry of entries) {
        containerWidth = entry.contentRect.width
        containerHeight = entry.contentRect.height
      }
    })
    resizeObserver.observe(canvas.parentElement)
    return () => resizeObserver.disconnect()
  })

  // When a new video file is provided, load it into the <video> element
  $effect(() => {
    if (videoFile) {
      showClipControls = true
      // videoEl is always rendered now (hidden when not needed),
      // so we can safely set src once it's bound
      if (videoEl) {
        const url = URL.createObjectURL(videoFile)
        videoEl.src = url
        videoEl.load()
      }
    } else {
      showClipControls = false
    }
  })

  // Once videoEl is bound after first render, re-trigger load if videoFile is already set
  $effect(() => {
    if (videoEl && videoFile && !videoEl.src) {
      const url = URL.createObjectURL(videoFile)
      videoEl.src = url
      videoEl.load()
    }
  })

  function handleVideoLoaded() {
    videoDuration = videoEl.duration || 0
    clipEnd = Math.floor(videoDuration)
    // Seek to first frame for preview
    videoEl.currentTime = 0
  }

  function formatTimecode(sec) {
    const m = Math.floor(sec / 60)
    const s = Math.floor(sec % 60)
    return `${m}:${s.toString().padStart(2, '0')}`
  }

  function handleStartDetection() {
    onStartDetection(clipStart, clipEnd)
  }

  // Redraw when frame result or settings change
  $effect(() => {
    if (ctx) {
      draw()
    }
  })

  function draw() {
    const w = canvasWidth()
    const h = canvasHeight()
    const s = scale()

    // Clear canvas
    ctx.fillStyle = '#0a0c10'
    ctx.fillRect(0, 0, w, h)

    // Draw frame image if available
    if (frameImage) {
      ctx.drawImage(frameImage, 0, 0, w, h)
    } else {
      // Draw placeholder grid
      ctx.strokeStyle = '#1a1f2a'
      ctx.lineWidth = 1
      const gridSize = 40
      for (let x = 0; x < w; x += gridSize) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, h)
        ctx.stroke()
      }
      for (let y = 0; y < h; y += gridSize) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(w, y)
        ctx.stroke()
      }
    }

    if (!frameResult) return

    const { ball, meta, debug, raw } = frameResult

    // Draw ROI mask (excluded areas)
    if (overlaySettings.showRoiMask && debug?.roi_exclusion) {
      ctx.fillStyle = 'rgba(239, 68, 68, 0.2)'
      if (debug.roi_exclusion.top) {
        ctx.fillRect(0, 0, w, debug.roi_exclusion.top.y2 * s)
      }
      if (debug.roi_exclusion.bottom) {
        ctx.fillRect(0, debug.roi_exclusion.bottom.y1 * s, w, h - debug.roi_exclusion.bottom.y1 * s)
      }
    }

    // Draw rejected detections (red dashed boxes)
    if (overlaySettings.showRejected && debug?.rejected) {
      ctx.setLineDash([4, 4])
      ctx.strokeStyle = '#ef4444'
      ctx.lineWidth = 2
      ctx.fillStyle = 'rgba(239, 68, 68, 0.1)'

      for (const rejected of debug.rejected) {
        const [x, y, bw, bh] = rejected.bbox
        const sx = x * s
        const sy = y * s
        const sw = bw * s
        const sh = bh * s

        ctx.fillRect(sx, sy, sw, sh)
        ctx.strokeRect(sx, sy, sw, sh)

        ctx.beginPath()
        ctx.moveTo(sx + 4, sy + 4)
        ctx.lineTo(sx + sw - 4, sy + sh - 4)
        ctx.moveTo(sx + sw - 4, sy + 4)
        ctx.lineTo(sx + 4, sy + sh - 4)
        ctx.stroke()

        ctx.setLineDash([])
        ctx.font = '10px JetBrains Mono, monospace'
        ctx.fillStyle = '#ef4444'
        ctx.fillText(rejected.reason, sx, sy - 4)
        ctx.setLineDash([4, 4])
      }
      ctx.setLineDash([])
    }

    // Draw predicted position (blue dashed circle)
    if (overlaySettings.showPredicted && debug?.kalman_predicted) {
      const pred = debug.kalman_predicted
      ctx.setLineDash([6, 4])
      ctx.strokeStyle = '#3b82f6'
      ctx.lineWidth = 2

      ctx.beginPath()
      ctx.arc(pred.x * s, pred.y * s, 15 * s, 0, Math.PI * 2)
      ctx.stroke()
      ctx.setLineDash([])

      ctx.font = '10px JetBrains Mono, monospace'
      ctx.fillStyle = '#3b82f6'
      ctx.fillText('PREDICTED', pred.x * s - 30, pred.y * s - 20)
    }

    // Draw velocity vector
    if (overlaySettings.showVelocity && debug?.velocity && meta?.ball_position) {
      const pos = meta.ball_position
      const vel = debug.velocity
      ctx.strokeStyle = '#a78bfa'
      ctx.lineWidth = 2

      ctx.beginPath()
      ctx.moveTo(pos.x * s, pos.y * s)
      ctx.lineTo((pos.x + vel.vx * 5) * s, (pos.y + vel.vy * 5) * s)
      ctx.stroke()

      const angle = Math.atan2(vel.vy, vel.vx)
      const headLen = 8
      ctx.beginPath()
      ctx.moveTo((pos.x + vel.vx * 5) * s, (pos.y + vel.vy * 5) * s)
      ctx.lineTo(
        (pos.x + vel.vx * 5) * s - headLen * Math.cos(angle - Math.PI / 6),
        (pos.y + vel.vy * 5) * s - headLen * Math.sin(angle - Math.PI / 6)
      )
      ctx.lineTo(
        (pos.x + vel.vx * 5) * s - headLen * Math.cos(angle + Math.PI / 6),
        (pos.y + vel.vy * 5) * s - headLen * Math.sin(angle + Math.PI / 6)
      )
      ctx.closePath()
      ctx.fillStyle = '#a78bfa'
      ctx.fill()
    }

    // Draw detected ball (green solid box and circle)
    if (overlaySettings.showDetected && ball?.bboxes?.length > 0) {
      const [x, y, bw, bh] = ball.bboxes[0]
      const conf = ball.confidences[0]
      const sx = x * s
      const sy = y * s
      const sw = bw * s
      const sh = bh * s
      const cx = sx + sw / 2
      const cy = sy + sh / 2

      ctx.strokeStyle = '#22c55e'
      ctx.lineWidth = 2
      ctx.strokeRect(sx, sy, sw, sh)

      ctx.beginPath()
      ctx.arc(cx, cy, Math.min(sw, sh) / 2, 0, Math.PI * 2)
      ctx.stroke()

      ctx.fillStyle = 'rgba(34, 197, 94, 0.2)'
      ctx.fill()

      ctx.font = 'bold 12px JetBrains Mono, monospace'
      ctx.fillStyle = '#22c55e'
      ctx.fillText(`${(conf * 100).toFixed(0)}%`, sx, sy - 6)
    }

    drawStatusBadges(w)
  }

  function drawStatusBadges(canvasW) {
    const meta = frameResult?.meta
    const debug = frameResult?.debug

    let badgeY = 20
    const badgeX = 12

    if (meta?.source) {
      const sourceColors = {
        detected: { bg: 'rgba(34, 197, 94, 0.9)', text: '#fff', label: 'DETECTED' },
        predicted: { bg: 'rgba(59, 130, 246, 0.9)', text: '#fff', label: 'PREDICTED' },
        lost: { bg: 'rgba(239, 68, 68, 0.9)', text: '#fff', label: 'LOST' },
        interpolated: { bg: 'rgba(167, 139, 250, 0.9)', text: '#fff', label: 'INTERPOLATED' },
      }
      const style = sourceColors[meta.source] || sourceColors.lost

      ctx.font = 'bold 11px DM Sans, sans-serif'
      const textWidth = ctx.measureText(style.label).width

      ctx.fillStyle = style.bg
      roundRect(ctx, badgeX, badgeY - 14, textWidth + 16, 20, 4)
      ctx.fill()

      ctx.fillStyle = style.text
      ctx.fillText(style.label, badgeX + 8, badgeY)
      badgeY += 28
    }

    if (debug) {
      ctx.font = '11px JetBrains Mono, monospace'

      ctx.fillStyle = 'rgba(30, 30, 40, 0.85)'
      roundRect(ctx, badgeX, badgeY - 14, 90, 20, 4)
      ctx.fill()
      ctx.fillStyle = '#a0aec0'
      ctx.fillText(`Raw: ${debug.raw_count || 0}`, badgeX + 8, badgeY)
      badgeY += 24

      ctx.fillStyle = 'rgba(30, 30, 40, 0.85)'
      roundRect(ctx, badgeX, badgeY - 14, 110, 20, 4)
      ctx.fill()
      ctx.fillStyle = '#ef4444'
      ctx.fillText(`Rejected: ${debug.rejected?.length || 0}`, badgeX + 8, badgeY)
    }
  }

  function roundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath()
    ctx.moveTo(x + radius, y)
    ctx.lineTo(x + width - radius, y)
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius)
    ctx.lineTo(x + width, y + height - radius)
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height)
    ctx.lineTo(x + radius, y + height)
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius)
    ctx.lineTo(x, y + radius)
    ctx.quadraticCurveTo(x, y, x + radius, y)
    ctx.closePath()
  }
</script>

<div class="vc-wrap">
  <!-- Video preview layer (always rendered so bind:this works; visible when video uploaded but before detection starts) -->
  <div class="vc-video-preview" class:vc-video-hidden={!showClipControls || frameImage}>
    <!-- svelte-ignore a11y_media_has_caption -->
    <video
      bind:this={videoEl}
      onloadedmetadata={handleVideoLoaded}
      preload="metadata"
      muted
    ></video>
  </div>

  <!-- Canvas layer (always present, hidden behind video preview when showing video) -->
  <div class="canvas-container" class:vc-behind={showClipControls && !frameImage}>
    <canvas
      bind:this={canvas}
      width={canvasWidth()}
      height={canvasHeight()}
    ></canvas>
  </div>

  <!-- Clip time controls overlay -->
  {#if showClipControls}
    <div class="clip-bar" class:clip-bar-processing={isProcessing}>
      {#if isProcessing}
        <!-- ── Processing progress ──────────────────────────────────────── -->
        <div class="clip-progress-row">
          <div class="clip-progress-track">
            <div class="clip-progress-fill" style="width: {processingProgress}%"></div>
          </div>
          <span class="clip-progress-pct mono">{processingProgress.toFixed(0)}%</span>
          <button class="clip-stop-btn" onclick={onStopDetection}>
            <svg viewBox="0 0 24 24" class="clip-stop-icon"><path d="M6 6h12v12H6z"/></svg>
            Stop
          </button>
        </div>
      {:else if cacheSize > 0}
        <!-- ── Post-detection: scrub cached frames + restart ────────────── -->
        <div class="clip-scrub-row">
          <button class="clip-restart-btn" onclick={onRestartDetection} title="Restart detection from beginning">
            <svg viewBox="0 0 24 24" class="clip-restart-icon"><path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/></svg>
          </button>

          <span class="clip-frame-label mono">{currentFrame}</span>

          <div class="clip-scrub-track">
            <input
              type="range"
              min="0"
              max={cacheSize > 0 ? cacheSize - 1 : 0}
              step="1"
              value={currentFrame}
              oninput={(e) => onSeekFrame(parseInt(e.target.value))}
              class="clip-scrub-range"
            />
            <div class="clip-scrub-fill"
              style="width: {cacheSize > 1 ? (currentFrame / (cacheSize - 1)) * 100 : 0}%"
            ></div>
          </div>

          <span class="clip-frame-label mono">{cacheSize - 1}</span>

          <span class="clip-cache-badge">{cacheSize} frames</span>

          <button class="clip-go-btn clip-go-sm" onclick={handleStartDetection} disabled={!inferenceAvailable}>
            <svg viewBox="0 0 24 24" class="clip-go-icon"><path d="M8 5v14l11-7z"/></svg>
            Continue
          </button>
        </div>
      {:else}
        <!-- ── Initial: clip time selection ─────────────────────────────── -->
        <div class="clip-row">
          <div class="clip-field">
            <span class="clip-field-label">Start</span>
            <div class="clip-input-wrap">
              <input
                type="number"
                min="0"
                max={videoDuration}
                step="1"
                bind:value={clipStart}
              />
              <span class="clip-unit">s</span>
            </div>
            <span class="clip-tc mono">{formatTimecode(clipStart)}</span>
          </div>

          <div class="clip-range-track">
            <input
              type="range"
              min="0"
              max={Math.floor(videoDuration)}
              step="1"
              bind:value={clipStart}
              class="clip-range clip-range-start"
            />
            <input
              type="range"
              min="0"
              max={Math.floor(videoDuration)}
              step="1"
              bind:value={clipEnd}
              class="clip-range clip-range-end"
            />
            <div class="clip-range-fill"
              style="left: {(clipStart / (videoDuration || 1)) * 100}%; right: {100 - (clipEnd / (videoDuration || 1)) * 100}%"
            ></div>
          </div>

          <div class="clip-field">
            <span class="clip-field-label">End</span>
            <div class="clip-input-wrap">
              <input
                type="number"
                min="0"
                max={videoDuration}
                step="1"
                bind:value={clipEnd}
              />
              <span class="clip-unit">s</span>
            </div>
            <span class="clip-tc mono">{formatTimecode(clipEnd)}</span>
          </div>

          <button class="clip-go-btn" onclick={handleStartDetection} disabled={!inferenceAvailable}>
            <svg viewBox="0 0 24 24" class="clip-go-icon"><path d="M8 5v14l11-7z"/></svg>
            {inferenceAvailable ? 'Start Detection' : 'Server Offline'}
          </button>
        </div>
      {/if}
    </div>
  {/if}
</div>

<style>
  /* ── Wrapper ─────────────────────────────────────────────────────────── */
  .vc-wrap {
    position: relative;
    width: 100%;
    height: 100%;
    flex: 1;
    display: flex;
    flex-direction: column;
    border-radius: var(--radius-md);
    overflow: hidden;
    background: var(--bg-0);
  }

  /* ── Video preview ───────────────────────────────────────────────────── */
  .vc-video-preview {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1;
    background: #000;
    transition: opacity 0.25s ease;
  }
  .vc-video-preview.vc-video-hidden {
    opacity: 0;
    pointer-events: none;
    z-index: -1;
  }
  .vc-video-preview video {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    border-radius: var(--radius-sm);
  }

  /* ── Canvas container ────────────────────────────────────────────────── */
  .canvas-container {
    width: 100%;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    z-index: 2;
  }
  .canvas-container.vc-behind {
    /* hide canvas when showing video preview */
    opacity: 0;
    pointer-events: none;
  }
  canvas {
    max-width: 100%;
    max-height: 100%;
    border-radius: var(--radius-sm);
  }

  /* ── Clip time bar ───────────────────────────────────────────────────── */
  .clip-bar {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 10;
    background: linear-gradient(transparent, rgba(10, 12, 16, 0.92) 30%);
    padding: 32px 20px 16px;
    animation: clipSlideUp 0.35s cubic-bezier(0.22, 1, 0.36, 1);
  }
  @keyframes clipSlideUp {
    from { transform: translateY(100%); opacity: 0; }
    to   { transform: translateY(0);    opacity: 1; }
  }

  .clip-row {
    display: flex;
    align-items: flex-end;
    gap: 14px;
  }

  .clip-field {
    display: flex;
    flex-direction: column;
    gap: 3px;
    min-width: 72px;
  }
  .clip-field .clip-field-label {
    font-size: 0.65rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--text-muted);
    font-weight: 600;
  }
  .clip-input-wrap {
    display: flex;
    align-items: center;
    gap: 2px;
    background: var(--bg-2);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 0 6px;
  }
  .clip-input-wrap input {
    width: 48px;
    padding: 5px 0;
    background: transparent;
    border: none;
    color: var(--text-primary);
    font-size: 0.85rem;
    font-family: var(--font-mono);
    outline: none;
    text-align: right;
  }
  .clip-input-wrap input::-webkit-inner-spin-button { opacity: 0.3; }
  .clip-unit {
    font-size: 0.7rem;
    color: var(--text-muted);
  }
  .clip-tc {
    font-size: 0.65rem;
    color: var(--text-muted);
  }

  /* ── Dual range slider ───────────────────────────────────────────────── */
  .clip-range-track {
    flex: 1;
    position: relative;
    height: 32px;
    display: flex;
    align-items: center;
  }
  .clip-range {
    position: absolute;
    width: 100%;
    -webkit-appearance: none;
    appearance: none;
    background: transparent;
    pointer-events: none;
    height: 6px;
    z-index: 2;
  }
  .clip-range::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: var(--accent);
    border: 2px solid #fff;
    cursor: pointer;
    pointer-events: all;
    box-shadow: 0 0 6px rgba(59, 130, 246, 0.5);
    transition: transform 0.12s ease;
  }
  .clip-range::-webkit-slider-thumb:hover {
    transform: scale(1.2);
  }
  .clip-range::-webkit-slider-runnable-track {
    height: 4px;
    background: transparent;
    border-radius: 2px;
  }
  .clip-range-fill {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    height: 4px;
    background: var(--accent);
    border-radius: 2px;
    pointer-events: none;
    z-index: 1;
  }
  /* Unfilled portion of track */
  .clip-range-track::before {
    content: '';
    position: absolute;
    width: 100%;
    height: 4px;
    top: 50%;
    transform: translateY(-50%);
    background: var(--bg-3);
    border-radius: 2px;
  }

  /* ── Start button ────────────────────────────────────────────────────── */
  .clip-go-btn {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 18px;
    background: var(--success);
    color: #fff;
    font-weight: 700;
    font-size: 0.85rem;
    border-radius: var(--radius-md);
    white-space: nowrap;
    transition: background 0.15s ease, transform 0.1s ease;
    border: none;
    cursor: pointer;
  }
  .clip-go-btn:hover {
    background: #16a34a;
    transform: translateY(-1px);
  }
  .clip-go-btn:disabled {
    background: var(--bg-3);
    color: var(--text-muted);
    cursor: not-allowed;
    transform: none;
  }
  .clip-go-icon {
    width: 16px;
    height: 16px;
    fill: currentColor;
  }

  /* ── Processing progress ─────────────────────────────────────────────── */
  .clip-progress-row {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .clip-progress-track {
    flex: 1;
    height: 6px;
    background: var(--bg-3);
    border-radius: 3px;
    overflow: hidden;
  }
  .clip-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--accent), var(--success));
    border-radius: 3px;
    transition: width 0.3s ease;
  }
  .clip-progress-pct {
    font-size: 0.8rem;
    color: var(--text-primary);
    min-width: 38px;
    text-align: right;
  }
  .clip-stop-btn {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 6px 14px;
    background: var(--error);
    color: #fff;
    font-weight: 600;
    font-size: 0.8rem;
    border-radius: var(--radius-md);
    border: none;
    cursor: pointer;
    transition: background 0.15s ease;
  }
  .clip-stop-btn:hover { background: #dc2626; }
  .clip-stop-icon {
    width: 14px;
    height: 14px;
    fill: currentColor;
  }

  /* ── Post-detection scrub row ────────────────────────────────────────── */
  .clip-scrub-row {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .clip-restart-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    background: var(--bg-3);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.15s ease;
    flex-shrink: 0;
  }
  .clip-restart-btn:hover {
    background: var(--accent);
    color: #fff;
    border-color: var(--accent);
  }
  .clip-restart-icon {
    width: 16px;
    height: 16px;
    fill: currentColor;
  }
  .clip-frame-label {
    font-size: 0.75rem;
    color: var(--text-muted);
    min-width: 32px;
    text-align: center;
    flex-shrink: 0;
  }
  .clip-scrub-track {
    flex: 1;
    position: relative;
    height: 28px;
    display: flex;
    align-items: center;
  }
  .clip-scrub-track::before {
    content: '';
    position: absolute;
    width: 100%;
    height: 4px;
    top: 50%;
    transform: translateY(-50%);
    background: var(--bg-3);
    border-radius: 2px;
  }
  .clip-scrub-fill {
    position: absolute;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
    height: 4px;
    background: var(--accent);
    border-radius: 2px;
    pointer-events: none;
    transition: width 0.1s ease;
  }
  .clip-scrub-range {
    width: 100%;
    -webkit-appearance: none;
    appearance: none;
    background: transparent;
    height: 4px;
    z-index: 2;
    position: relative;
  }
  .clip-scrub-range::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: var(--accent);
    border: 2px solid #fff;
    cursor: pointer;
    box-shadow: 0 0 4px rgba(59, 130, 246, 0.4);
    transition: transform 0.1s ease;
  }
  .clip-scrub-range::-webkit-slider-thumb:hover {
    transform: scale(1.25);
  }
  .clip-scrub-range::-webkit-slider-runnable-track {
    height: 4px;
    background: transparent;
  }
  .clip-cache-badge {
    font-size: 0.65rem;
    color: var(--accent-light);
    background: rgba(59, 130, 246, 0.12);
    padding: 2px 8px;
    border-radius: var(--radius-full);
    white-space: nowrap;
    flex-shrink: 0;
  }
  .clip-go-sm {
    padding: 6px 12px;
    font-size: 0.75rem;
  }
</style>
