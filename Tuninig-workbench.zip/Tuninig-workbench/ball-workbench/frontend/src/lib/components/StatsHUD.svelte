<script>
  /**
   * StatsHUD Component
   *
   * Compact, glassmorphic stats overlay that sits on top of the video canvas.
   * Shows real-time detection stats in a top bar with an expandable detail panel.
   *
   * Features:
   *   - Compact bar: frame#, confidence dot, detection rate, raw→filtered, cache, mode badge
   *   - Expandable detail panel with running stats grid
   *   - Animated counters, smooth transitions, pulse on new detection
   */

  let {
    frameResult = null,
    frameIndex = 0,
    totalFrames = 0,
    cacheSize = 0,
    isProcessing = false,
    mode = 'filter_tuned',
  } = $props()

  let expanded = $state(false)
  let pulse = $state(false)

  // Running stats accumulated across frames
  let runningStats = $state({
    framesProcessed: 0,
    detectedCount: 0,
    predictedCount: 0,
    lostCount: 0,
    totalRejected: 0,
    avgConfidence: 0,
    confidenceSum: 0,
    maxConfidence: 0,
    minConfidence: 1,
    avgRawCount: 0,
    rawCountSum: 0,
  })

  let lastFrameIndex = $state(-1)

  // Update running stats when frame changes
  $effect(() => {
    if (!frameResult || frameIndex === lastFrameIndex) return
    lastFrameIndex = frameIndex

    runningStats.framesProcessed++

    const source = frameResult.meta?.source
    if (source === 'detected') runningStats.detectedCount++
    else if (source === 'predicted') runningStats.predictedCount++
    else if (source === 'lost' || source === 'no_data') runningStats.lostCount++

    const rejCount = frameResult.debug?.rejected?.length || 0
    runningStats.totalRejected += rejCount

    const rawCount = frameResult.raw?.bboxes?.length || frameResult.debug?.raw_count || 0
    runningStats.rawCountSum += rawCount
    runningStats.avgRawCount = runningStats.rawCountSum / runningStats.framesProcessed

    const conf = frameResult.ball?.confidences?.[0] || 0
    if (conf > 0) {
      runningStats.confidenceSum += conf
      runningStats.avgConfidence = runningStats.confidenceSum / runningStats.detectedCount
      if (conf > runningStats.maxConfidence) runningStats.maxConfidence = conf
      if (conf < runningStats.minConfidence) runningStats.minConfidence = conf
    }

    // Trigger pulse animation
    if (source === 'detected') {
      pulse = true
      setTimeout(() => pulse = false, 400)
    }
  })

  // Derived display values
  let confidence = $derived(frameResult?.ball?.confidences?.[0] || 0)
  let source = $derived(frameResult?.meta?.source || 'none')
  let rawCount = $derived(frameResult?.raw?.bboxes?.length || 0)
  let filteredCount = $derived(frameResult?.ball?.bboxes?.length || 0)
  let rejectedCount = $derived(frameResult?.debug?.rejected?.length || 0)
  let detectionRate = $derived(
    runningStats.framesProcessed > 0
      ? ((runningStats.detectedCount / runningStats.framesProcessed) * 100).toFixed(0)
      : '—'
  )

  function confColor(c) {
    if (c >= 0.7) return 'var(--success)'
    if (c >= 0.4) return 'var(--warning)'
    if (c > 0) return 'var(--error)'
    return 'var(--text-muted)'
  }

  function sourceLabel(s) {
    if (s === 'detected') return 'DET'
    if (s === 'predicted') return 'PRED'
    if (s === 'lost' || s === 'no_data') return 'LOST'
    return '—'
  }

  function sourceColor(s) {
    if (s === 'detected') return 'var(--success)'
    if (s === 'predicted') return 'var(--warning)'
    return 'var(--error)'
  }
</script>

{#if frameResult}
  <div class="stats-hud" class:expanded class:pulse>
    <!-- Compact bar -->
    <button class="hud-bar" onclick={() => expanded = !expanded}>
      <!-- Frame number -->
      <span class="hud-cell hud-frame">
        <span class="hud-label">FRM</span>
        <span class="hud-val mono">{frameIndex}</span>
      </span>

      <!-- Confidence dot -->
      <span class="hud-cell hud-conf">
        <span class="hud-dot" style:background={confColor(confidence)}></span>
        <span class="hud-val mono">{confidence > 0 ? confidence.toFixed(2) : '—'}</span>
      </span>

      <!-- Source badge -->
      <span class="hud-cell hud-source">
        <span class="hud-source-badge" style:background={sourceColor(source)}>
          {sourceLabel(source)}
        </span>
      </span>

      <!-- Detection rate -->
      <span class="hud-cell">
        <span class="hud-label">RATE</span>
        <span class="hud-val mono">{detectionRate}%</span>
      </span>

      <!-- Raw → Filtered -->
      <span class="hud-cell hud-pipeline">
        <span class="hud-val mono">{rawCount}</span>
        <span class="hud-arrow">→</span>
        <span class="hud-val mono">{filteredCount}</span>
        {#if rejectedCount > 0}
          <span class="hud-rejected-badge">-{rejectedCount}</span>
        {/if}
      </span>

      <!-- Cache -->
      {#if cacheSize > 0}
        <span class="hud-cell">
          <span class="hud-label">CACHE</span>
          <span class="hud-val mono">{cacheSize}</span>
        </span>
      {/if}

      <!-- Processing indicator -->
      {#if isProcessing}
        <span class="hud-cell hud-live">
          <span class="hud-live-dot"></span>
          LIVE
        </span>
      {/if}

      <!-- Mode -->
      <span class="hud-cell hud-mode">
        {mode === 'base_model' ? 'BASE' : 'TUNED'}
      </span>

      <!-- Expand chevron -->
      <span class="hud-chevron" class:rotated={expanded}>▾</span>
    </button>

    <!-- Expanded detail panel -->
    {#if expanded}
      <div class="hud-detail">
        <div class="hud-grid">
          <div class="hud-stat">
            <span class="hud-stat-label">Frames Processed</span>
            <span class="hud-stat-val mono">{runningStats.framesProcessed}</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Detection Rate</span>
            <span class="hud-stat-val mono" style:color="var(--success)">{detectionRate}%</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Detected</span>
            <span class="hud-stat-val mono" style:color="var(--success)">{runningStats.detectedCount}</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Predicted</span>
            <span class="hud-stat-val mono" style:color="var(--warning)">{runningStats.predictedCount}</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Lost</span>
            <span class="hud-stat-val mono" style:color="var(--error)">{runningStats.lostCount}</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Total Rejected</span>
            <span class="hud-stat-val mono">{runningStats.totalRejected}</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Avg Confidence</span>
            <span class="hud-stat-val mono">{runningStats.avgConfidence > 0 ? runningStats.avgConfidence.toFixed(3) : '—'}</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Max Confidence</span>
            <span class="hud-stat-val mono">{runningStats.maxConfidence > 0 ? runningStats.maxConfidence.toFixed(3) : '—'}</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Avg Raw / Frame</span>
            <span class="hud-stat-val mono">{runningStats.avgRawCount.toFixed(1)}</span>
          </div>
          <div class="hud-stat">
            <span class="hud-stat-label">Current Frame</span>
            <span class="hud-stat-val mono">{frameIndex} / {totalFrames}</span>
          </div>
        </div>
      </div>
    {/if}
  </div>
{/if}

<style>
  .stats-hud {
    position: absolute;
    top: 10px;
    left: 10px;
    right: 10px;
    z-index: 20;
    border-radius: var(--radius-lg);
    background: rgba(10, 12, 16, 0.78);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border: 1px solid rgba(255, 255, 255, 0.10);
    overflow: hidden;
    transition: box-shadow 0.3s ease;
    pointer-events: auto;
  }

  .stats-hud.pulse {
    box-shadow: 0 0 20px rgba(34, 197, 94, 0.3);
  }

  /* ── Compact bar ─────────────────────────────────────────────────────── */
  .hud-bar {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 10px 16px;
    width: 100%;
    text-align: left;
    cursor: pointer;
    font-size: 0.82rem;
    color: var(--text-secondary);
    background: none;
    border: none;
    transition: background 0.15s ease;
  }
  .hud-bar:hover {
    background: rgba(255, 255, 255, 0.04);
  }

  .hud-cell {
    display: flex;
    align-items: center;
    gap: 5px;
    white-space: nowrap;
  }

  .hud-label {
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.06em;
    color: var(--text-muted);
    text-transform: uppercase;
  }

  .hud-val {
    font-size: 0.85rem;
    color: var(--text-primary);
  }

  /* Confidence dot */
  .hud-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    flex-shrink: 0;
    transition: background 0.2s ease;
  }

  /* Source badge */
  .hud-source-badge {
    font-size: 0.7rem;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: var(--radius-full);
    color: white;
    letter-spacing: 0.04em;
  }

  /* Pipeline arrow */
  .hud-arrow {
    color: var(--text-muted);
    font-size: 0.75rem;
  }
  .hud-rejected-badge {
    font-size: 0.7rem;
    font-weight: 700;
    color: var(--error);
    background: var(--error-bg);
    padding: 1px 6px;
    border-radius: var(--radius-sm);
  }

  /* Live indicator */
  .hud-live {
    color: var(--error);
    font-weight: 700;
    font-size: 0.75rem;
    letter-spacing: 0.08em;
    gap: 5px;
  }
  .hud-live-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--error);
    animation: livePulse 1.2s ease-in-out infinite;
  }
  @keyframes livePulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.3; transform: scale(0.7); }
  }

  /* Mode badge */
  .hud-mode {
    font-size: 0.7rem;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: var(--radius-full);
    background: var(--accent);
    color: white;
    letter-spacing: 0.06em;
    margin-left: auto;
  }

  /* Chevron */
  .hud-chevron {
    font-size: 0.85rem;
    color: var(--text-muted);
    transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  }
  .hud-chevron.rotated {
    transform: rotate(180deg);
  }

  /* ── Expanded detail panel ───────────────────────────────────────────── */
  .hud-detail {
    border-top: 1px solid rgba(255, 255, 255, 0.06);
    padding: 14px 16px;
    animation: slideDown 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  }

  @keyframes slideDown {
    from {
      opacity: 0;
      transform: translateY(-8px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .hud-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 10px;
  }

  .hud-stat {
    display: flex;
    flex-direction: column;
    gap: 3px;
    padding: 8px 10px;
    background: rgba(255, 255, 255, 0.03);
    border-radius: var(--radius-sm);
    border: 1px solid rgba(255, 255, 255, 0.04);
  }

  .hud-stat-label {
    font-size: 0.68rem;
    font-weight: 600;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }

  .hud-stat-val {
    font-size: 0.95rem;
    font-weight: 600;
    color: var(--text-primary);
  }
</style>
