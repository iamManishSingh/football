<script>
  /**
   * ConfigManager Component
   *
   * Handles save/load/export/import configurations.
   */

  let {
    config = {},
    onsave = (name) => {},
    onload = (configData) => {},
    onexport = () => {},
    onexportlegacy = () => {},
    onimport = (json) => {},
    onreset = () => {},
    savedConfigs = [],
    onrefreshconfigs = () => {},
    ondeleteconfig = (filename) => {},
  } = $props()

  let saveDialogOpen = $state(false)
  let saveName = $state('')
  let importInput

  function handleSave() {
    if (saveName.trim()) {
      onsave(saveName.trim())
      saveName = ''
      saveDialogOpen = false
    }
  }

  function handleImport() {
    importInput.click()
  }

  function handleImportFile(e) {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = () => {
        onimport(reader.result)
      }
      reader.readAsText(file)
    }
    e.target.value = '' // Reset input
  }

  function handleExport() {
    const json = JSON.stringify({
      name: 'exported_config',
      version: '1.0',
      created: new Date().toISOString(),
      config,
    }, null, 2)

    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `ball-filter-config-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
  }
</script>

<div class="config-manager">
  <h4>Configuration</h4>

  <!-- Actions -->
  <section class="section">
    <h5>Actions</h5>
    <div class="action-buttons">
      <button class="btn btn-secondary" onclick={() => saveDialogOpen = true}>
        <svg viewBox="0 0 24 24" class="icon icon-sm">
          <path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/>
        </svg>
        Save Config
      </button>

      <button class="btn btn-secondary" onclick={handleExport}>
        <svg viewBox="0 0 24 24" class="icon icon-sm">
          <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>
        </svg>
        Export JSON
      </button>

      <button class="btn btn-secondary" onclick={handleImport}>
        <svg viewBox="0 0 24 24" class="icon icon-sm">
          <path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z"/>
        </svg>
        Import JSON
      </button>
      <input
        type="file"
        accept=".json"
        bind:this={importInput}
        onchange={handleImportFile}
        style="display: none"
      />

      <button class="btn btn-secondary" onclick={onexportlegacy}>
        <svg viewBox="0 0 24 24" class="icon icon-sm">
          <path d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/>
        </svg>
        Export Legacy
      </button>

      <button class="btn btn-secondary danger" onclick={onreset}>
        <svg viewBox="0 0 24 24" class="icon icon-sm">
          <path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
        </svg>
        Reset All
      </button>
    </div>
  </section>

  <!-- Saved Configs -->
  <section class="section">
    <div class="section-header">
      <h5>Saved Configs</h5>
      <button class="btn btn-ghost btn-sm" onclick={onrefreshconfigs}>
        <svg viewBox="0 0 24 24" class="icon icon-sm">
          <path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
        </svg>
      </button>
    </div>

    <div class="saved-list">
      {#if savedConfigs.length === 0}
        <div class="empty-state">No saved configurations</div>
      {:else}
        {#each savedConfigs as saved}
          <div class="saved-item">
            <div class="saved-info">
              <span class="saved-name">{saved.name}</span>
              {#if saved.created}
                <span class="saved-date">{new Date(saved.created).toLocaleDateString()}</span>
              {/if}
            </div>
            <div class="saved-actions">
              <button
                class="btn btn-ghost btn-sm"
                onclick={() => onload(saved.filename)}
                title="Load"
              >
                Load
              </button>
              <button
                class="btn btn-ghost btn-sm danger"
                onclick={() => ondeleteconfig(saved.filename)}
                title="Delete"
              >
                <svg viewBox="0 0 24 24" class="icon icon-sm">
                  <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                </svg>
              </button>
            </div>
          </div>
        {/each}
      {/if}
    </div>
  </section>

  <!-- Save Dialog -->
  {#if saveDialogOpen}
    <div class="dialog-overlay" onclick={() => saveDialogOpen = false}>
      <div class="dialog" onclick={(e) => e.stopPropagation()}>
        <h5>Save Configuration</h5>
        <input
          type="text"
          placeholder="Configuration name"
          bind:value={saveName}
          onkeydown={(e) => e.key === 'Enter' && handleSave()}
        />
        <div class="dialog-actions">
          <button class="btn btn-secondary" onclick={() => saveDialogOpen = false}>
            Cancel
          </button>
          <button class="btn btn-primary" onclick={handleSave} disabled={!saveName.trim()}>
            Save
          </button>
        </div>
      </div>
    </div>
  {/if}
</div>

<style>
  .config-manager {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-lg);
    height: 100%;
    overflow-y: auto;
  }

  h4 {
    font-size: 1rem;
    color: var(--text-primary);
  }

  h5 {
    font-size: 0.875rem;
    color: var(--text-secondary);
    margin-bottom: var(--space-sm);
  }

  .section {
    display: flex;
    flex-direction: column;
  }

  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: var(--space-sm);
  }

  .section-header h5 {
    margin-bottom: 0;
  }

  .action-buttons {
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
  }

  .action-buttons .btn {
    justify-content: flex-start;
    gap: var(--space-sm);
  }

  .action-buttons .btn .icon {
    fill: currentColor;
  }

  .btn.danger {
    color: var(--error);
  }

  .btn.danger:hover {
    background: var(--error-bg);
  }

  .saved-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-xs);
    max-height: 200px;
    overflow-y: auto;
  }

  .saved-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--space-sm);
    background: var(--bg-2);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
  }

  .saved-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .saved-name {
    font-size: 0.875rem;
    color: var(--text-primary);
  }

  .saved-date {
    font-size: 0.7rem;
    color: var(--text-muted);
  }

  .saved-actions {
    display: flex;
    gap: var(--space-xs);
  }

  .empty-state {
    padding: var(--space-lg);
    text-align: center;
    color: var(--text-muted);
    font-size: 0.875rem;
  }

  .dialog-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 100;
  }

  .dialog {
    background: var(--bg-2);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: var(--space-lg);
    min-width: 300px;
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
  }

  .dialog input {
    width: 100%;
  }

  .dialog-actions {
    display: flex;
    justify-content: flex-end;
    gap: var(--space-sm);
  }

  .icon {
    fill: currentColor;
  }
</style>
