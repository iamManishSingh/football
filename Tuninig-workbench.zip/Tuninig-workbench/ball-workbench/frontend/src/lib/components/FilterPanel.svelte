<script>
  /**
   * FilterPanel Component
   *
   * Master panel that renders:
   *   1. Mode toggle (Base Model ↔ Filter-Tuned)
   *   2. Animated preset cards in filter_tuned mode
   *   3. Model-level settings (detection threshold, class ID)
   *   4. All 8 filter groups with parent enable/disable toggles
   *   5. Ball selection settings
   *   6. Debug toggle
   *   7. Apply / Discard action bar
   */

  import FilterGroup from './FilterGroup.svelte'
  import { PARAM_METADATA, PRESETS, cloneConfig } from '../../../../shared/ball-filter-config.js'

  let {
    config = $bindable({}),
    mode = $bindable('filter_tuned'),
    disabled = false,
    onchange = () => {},
    onapply = () => {},
    onreset = () => {},
    onloadpreset = (key) => {},
  } = $props()

  let hasChanges = $state(false)
  let activePreset = $state(null)
  let presetFlash = $state(null)
  let presetDrawerOpen = $state(false)

  function markChanged() {
    hasChanges = true
    onchange()
  }

  function handleApply() {
    hasChanges = false
    onapply()
  }

  function handleReset() {
    hasChanges = false
    onreset()
  }

  function setMode(newMode) {
    if (mode === newMode) return
    mode = newMode
    config.mode = newMode
    // Mode switch auto-applies immediately — user sees result in real-time
    hasChanges = false
    onapply()
  }

  // ── Preset definitions with icons and gradient colors ──
  const presetCards = [
    {
      key: 'light_filtering',
      icon: '🎯',
      name: 'Light Filtering',
      desc: 'Basic confidence + static rejection only',
      gradient: 'linear-gradient(135deg, #22c55e22, #22c55e08)',
      borderColor: '#22c55e44',
      accentColor: '#22c55e',
      tags: ['basic', 'static'],
    },
    {
      key: 'broadcast_daytime',
      icon: '☀️',
      name: 'Broadcast Daytime',
      desc: 'Professional broadcast in daylight',
      gradient: 'linear-gradient(135deg, #f59e0b22, #f59e0b08)',
      borderColor: '#f59e0b44',
      accentColor: '#f59e0b',
      tags: ['basic', 'roi', 'appearance', 'static', 'tracking'],
    },
    {
      key: 'broadcast_night',
      icon: '🌙',
      name: 'Broadcast Night',
      desc: 'Floodlit / evening broadcast footage',
      gradient: 'linear-gradient(135deg, #8b5cf622, #8b5cf608)',
      borderColor: '#8b5cf644',
      accentColor: '#8b5cf6',
      tags: ['basic', 'roi', 'appearance', 'static', 'tracking', 'preprocessing'],
    },
    {
      key: 'wide_angle_amateur',
      icon: '📷',
      name: 'Wide Angle / Amateur',
      desc: 'Distant ball, amateur footage with SAHI',
      gradient: 'linear-gradient(135deg, #3b82f622, #3b82f608)',
      borderColor: '#3b82f644',
      accentColor: '#3b82f6',
      tags: ['basic', 'roi', 'static', 'tracking', 'sahi'],
    },
    {
      key: 'harsh_shadows',
      icon: '🌗',
      name: 'Harsh Shadows',
      desc: 'Strong ground shadows causing false positives',
      gradient: 'linear-gradient(135deg, #64748b22, #0f172a18)',
      borderColor: '#64748b44',
      accentColor: '#94a3b8',
      tags: ['basic', 'appearance', 'static', 'tracking', 'preprocessing'],
    },
    {
      key: 'fog_haze',
      icon: '🌫️',
      name: 'Fog / Haze',
      desc: 'Low visibility, washed-out colours from mist',
      gradient: 'linear-gradient(135deg, #94a3b822, #cbd5e118)',
      borderColor: '#94a3b844',
      accentColor: '#cbd5e1',
      tags: ['basic', 'static', 'tracking', 'smoothing', 'preprocessing'],
    },
    {
      key: 'bright_daylight',
      icon: '🔆',
      name: 'Bright Daylight',
      desc: 'Overexposed / high-glare strong sunlight',
      gradient: 'linear-gradient(135deg, #facc1522, #fbbf2408)',
      borderColor: '#facc1544',
      accentColor: '#fbbf24',
      tags: ['basic', 'appearance', 'static', 'tracking', 'preprocessing'],
    },
    {
      key: 'mixed_conditions',
      icon: '🌤️',
      name: 'Mixed / Varying',
      desc: 'Changing light, partial clouds, varying shadows',
      gradient: 'linear-gradient(135deg, #14b8a622, #06b6d418)',
      borderColor: '#14b8a644',
      accentColor: '#14b8a6',
      tags: ['basic', 'appearance', 'static', 'tracking', 'smoothing', 'preprocessing'],
    },
  ]

  function applyPreset(key) {
    activePreset = key
    presetFlash = key
    setTimeout(() => presetFlash = null, 600)
    // Presets auto-apply immediately — updates detection in real-time
    onloadpreset(key)
    hasChanges = false
    presetDrawerOpen = false
  }

  // Ordered list of filter groups to display
  const groupOrder = ['basic', 'roi', 'appearance', 'static', 'tracking', 'smoothing', 'preprocessing', 'sahi']

  // Count how many groups are currently enabled
  let enabledCount = $derived(
    groupOrder.filter(g => config.filter_groups?.[g]?.enabled).length
  )

  // Quick helpers
  function enableAllGroups() {
    for (const g of groupOrder) {
      if (config.filter_groups?.[g]) {
        config.filter_groups[g].enabled = true
      }
    }
    markChanged()
  }
  function disableAllGroups() {
    for (const g of groupOrder) {
      if (config.filter_groups?.[g]) {
        config.filter_groups[g].enabled = false
      }
    }
    markChanged()
  }
</script>

<!-- ─── Markup ──────────────────────────────────────────────────────────── -->

<div class="fp">
  <!-- ── Header ─────────────────────────────────────────────────────────── -->
  <div class="fp-header">
    <h3>Filter Configuration</h3>

    <!-- Mode toggle -->
    <div class="fp-mode">
      <button
        class="fp-mode-btn"
        class:active={mode === 'base_model'}
        onclick={() => setMode('base_model')}
        {disabled}
      >
        Base Model
      </button>
      <button
        class="fp-mode-btn"
        class:active={mode === 'filter_tuned'}
        onclick={() => setMode('filter_tuned')}
        {disabled}
      >
        Filter-Tuned
      </button>
    </div>

    {#if mode === 'filter_tuned'}
      <div class="fp-summary">
        <span class="fp-summary-count">{enabledCount}/{groupOrder.length} groups active</span>
        <div class="fp-quick-actions">
          <button class="fp-quick-btn" onclick={enableAllGroups} {disabled}>All On</button>
          <button class="fp-quick-btn" onclick={disableAllGroups} {disabled}>All Off</button>
        </div>
      </div>
    {/if}
  </div>

  <!-- ── Preset Drawer (always visible below header in filter_tuned) ──── -->
  {#if mode === 'filter_tuned'}
    <div class="fp-preset-drawer" class:fp-drawer-open={presetDrawerOpen}>
      <button class="fp-drawer-trigger" onclick={() => presetDrawerOpen = !presetDrawerOpen} {disabled}>
        <span class="fp-drawer-label">
          <svg viewBox="0 0 24 24" class="fp-drawer-ico"><path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z"/></svg>
          Presets
        </span>
        {#if activePreset}
          {@const active = presetCards.find(p => p.key === activePreset)}
          {#if active}
            <span class="fp-drawer-active" style:--preset-accent={active.accentColor}>
              <span class="fp-drawer-active-icon">{active.icon}</span>
              {active.name}
            </span>
          {/if}
        {:else}
          <span class="fp-drawer-none">Select a preset…</span>
        {/if}
        <svg class="fp-drawer-chev" class:fp-drawer-chev-open={presetDrawerOpen} viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </button>

      {#if presetDrawerOpen}
        <div class="fp-drawer-panel">
          {#each presetCards as preset, i (preset.key)}
            <button
              class="fp-drawer-item"
              class:fp-drawer-item-active={activePreset === preset.key}
              class:flash={presetFlash === preset.key}
              style:--preset-accent={preset.accentColor}
              style:animation-delay="{i * 30}ms"
              onclick={() => applyPreset(preset.key)}
              {disabled}
            >
              <span class="fp-drawer-item-icon">{preset.icon}</span>
              <div class="fp-drawer-item-info">
                <span class="fp-drawer-item-name">{preset.name}</span>
                <span class="fp-drawer-item-desc">{preset.desc}</span>
              </div>
              {#if activePreset === preset.key}
                <span class="fp-drawer-item-check">✓</span>
              {/if}
            </button>
          {/each}
        </div>
      {/if}
    </div>
  {/if}

  <!-- ── Scrollable body ────────────────────────────────────────────────── -->
  <div class="fp-body">

    {#if mode === 'base_model'}
      <!-- ── Base Model: 3 core params ──────────────────────────────────── -->
      <div class="fp-base-params">
        <div class="fp-base-param">
          <div class="fp-inline-param">
            <span class="fp-inline-label">Confidence Threshold</span>
            <span class="fp-inline-val mono">{config.model?.threshold?.toFixed(2) ?? '0.10'}</span>
          </div>
          <input
            type="range"
            min="0.01" max="0.90" step="0.01"
            value={config.model?.threshold ?? 0.10}
            oninput={(e) => { config.model.threshold = parseFloat(e.target.value); markChanged() }}
            {disabled}
          />
          <span class="fp-param-hint">Lower = more detections, higher = stricter</span>
        </div>

        <div class="fp-base-param">
          <div class="fp-inline-param">
            <span class="fp-inline-label">NMS / IoU Threshold</span>
            <span class="fp-inline-val mono">{config.model?.nms_iou?.toFixed(2) ?? '0.50'}</span>
          </div>
          <input
            type="range"
            min="0.10" max="0.95" step="0.01"
            value={config.model?.nms_iou ?? 0.50}
            oninput={(e) => { config.model.nms_iou = parseFloat(e.target.value); markChanged() }}
            {disabled}
          />
          <span class="fp-param-hint">Lower = suppress more overlapping boxes</span>
        </div>

        <div class="fp-base-param">
          <div class="fp-inline-param">
            <span class="fp-inline-label">Image Size</span>
            <span class="fp-inline-val mono">{config.model?.image_size ?? 560}px</span>
          </div>
          <input
            type="range"
            min="320" max="1280" step="32"
            value={config.model?.image_size ?? 560}
            oninput={(e) => { config.model.image_size = parseInt(e.target.value); markChanged() }}
            {disabled}
          />
          <span class="fp-param-hint">Higher = better accuracy, slower inference</span>
        </div>
      </div>
    {:else}
      <!-- ── Model Settings (filter_tuned only) ────────────────────────── -->
      <details class="fp-section" open>
        <summary class="fp-section-title">
          <svg viewBox="0 0 24 24" class="fp-section-icon"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>
          Model Settings
        </summary>
        <div class="fp-section-body">
          <div class="fp-inline-param">
            <span class="fp-inline-label">Detection Threshold</span>
            <span class="fp-inline-val mono">{config.model?.threshold?.toFixed(2) ?? '0.10'}</span>
          </div>
          <input
            type="range"
            min="0.01" max="0.50" step="0.01"
            value={config.model?.threshold ?? 0.10}
            oninput={(e) => { config.model.threshold = parseFloat(e.target.value); markChanged() }}
            {disabled}
          />

          <div class="fp-inline-param">
            <span class="fp-inline-label">COCO Class ID</span>
            <span class="fp-inline-val mono">{config.model?.class_id ?? 32}</span>
          </div>
          <input
            type="range"
            min="0" max="80" step="1"
            value={config.model?.class_id ?? 32}
            oninput={(e) => { config.model.class_id = parseInt(e.target.value); markChanged() }}
            {disabled}
          />
        </div>
      </details>
    {/if}

    <!-- ── Filter Groups (filter_tuned only) ──────────────────────────── -->
    {#if mode === 'filter_tuned'}
      {#each groupOrder as groupName (groupName)}
        {@const meta = PARAM_METADATA[groupName]}
        {#if meta && config.filter_groups?.[groupName]}
          <FilterGroup
            {groupName}
            label={meta.label}
            icon={meta.icon}
            description={meta.description}
            bind:group={config.filter_groups[groupName]}
            paramMeta={meta.params}
            globalDisabled={disabled}
            onchange={markChanged}
          />
        {/if}
      {/each}
    {/if}

    {#if mode === 'filter_tuned'}
      <!-- ── Selection Settings (filter_tuned only) ────────────────────── -->
      <details class="fp-section">
        <summary class="fp-section-title">
          <svg viewBox="0 0 24 24" class="fp-section-icon"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
          Ball Selection
        </summary>
        <div class="fp-section-body">
          <div class="fp-inline-param">
            <span class="fp-inline-label">Selection Method</span>
            <select
              value={config.selection?.method ?? 'weighted'}
              onchange={(e) => { config.selection.method = e.target.value; markChanged() }}
              {disabled}
            >
              <option value="highest_conf">Highest Confidence</option>
              <option value="weighted">Weighted (proximity + conf + shape)</option>
              <option value="nearest_prediction">Nearest to Prediction</option>
            </select>
          </div>

          <div class="fp-inline-param">
            <span class="fp-inline-label">Max Jump Distance (px)</span>
            <span class="fp-inline-val mono">{config.selection?.max_jump_distance ?? 200}</span>
          </div>
          <input
            type="range"
            min="50" max="600" step="10"
            value={config.selection?.max_jump_distance ?? 200}
            oninput={(e) => { config.selection.max_jump_distance = parseInt(e.target.value); markChanged() }}
            {disabled}
          />
        </div>
      </details>
    {/if}

    <!-- ── Debug Toggle ────────────────────────────────────────────────── -->
    <div class="fp-debug-row">
      <span>Debug output</span>
      <label class="fp-debug-toggle">
        <input
          type="checkbox"
          checked={config.debug ?? false}
          onchange={() => { config.debug = !config.debug; markChanged() }}
          {disabled}
        />
        <span class="fp-toggle-track"></span>
        <span class="fp-toggle-thumb"></span>
      </label>
    </div>
  </div>

  <!-- ── Action bar ─────────────────────────────────────────────────────── -->
  <div class="fp-actions">
    <button class="btn btn-secondary" onclick={handleReset} disabled={!hasChanges}>
      Discard
    </button>
    <button class="btn btn-primary" class:fp-pulse={hasChanges} onclick={handleApply}>
      {hasChanges ? '● Apply Changes' : 'Applied ✓'}
    </button>
  </div>
</div>

<!-- ─── Styles ──────────────────────────────────────────────────────────── -->

<style>
  /* ── Panel shell ──────────────────────────────────────────────────────── */
  .fp {
    display: flex;
    flex-direction: column;
    height: 100%;
    background: linear-gradient(180deg, var(--panel-bg) 0%, var(--bg-1) 100%);
  }

  /* ── Header ───────────────────────────────────────────────────────────── */
  .fp-header {
    padding: var(--space-md);
    border-bottom: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    background: linear-gradient(135deg, rgba(59,130,246,0.06) 0%, rgba(20,184,166,0.04) 100%);
  }
  .fp-header h3 {
    font-size: 1rem;
    margin: 0;
    background: linear-gradient(135deg, var(--accent-light) 0%, var(--teal-light) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-weight: 700;
  }

  .fp-mode {
    display: flex;
    gap: 2px;
    background: var(--bg-0);
    border-radius: var(--radius-md);
    padding: 3px;
    border: 1px solid var(--border);
  }
  .fp-mode-btn {
    flex: 1;
    padding: var(--space-sm) var(--space-md);
    font-size: 0.82rem;
    font-weight: 600;
    border-radius: 6px;
    color: var(--text-muted);
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
  }
  .fp-mode-btn:hover {
    color: var(--text-secondary);
    background: var(--panel-card);
  }
  .fp-mode-btn.active {
    background: linear-gradient(135deg, var(--accent) 0%, #6366f1 100%);
    color: white;
    box-shadow: 0 2px 12px rgba(59, 130, 246, 0.35);
  }

  .fp-summary {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .fp-summary-count {
    font-size: 0.75rem;
    color: var(--accent-light);
    font-weight: 500;
  }
  .fp-quick-actions {
    display: flex;
    gap: 4px;
  }
  .fp-quick-btn {
    font-size: 0.7rem;
    padding: 3px 10px;
    border-radius: var(--radius-full);
    background: var(--panel-card);
    color: var(--text-secondary);
    cursor: pointer;
    border: 1px solid var(--border);
    transition: all 0.15s ease;
    font-weight: 500;
  }
  .fp-quick-btn:hover {
    background: var(--accent);
    color: white;
    border-color: var(--accent);
    box-shadow: 0 2px 8px rgba(59, 130, 246, 0.25);
  }

  /* ── Scrollable body ──────────────────────────────────────────────────── */
  .fp-body {
    flex: 1;
    overflow-y: auto;
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
  }

  /* ── Base model params ────────────────────────────────────────────────── */
  .fp-base-params {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
  }
  .fp-base-param {
    background: var(--panel-card);
    border: 1px solid var(--border);
    border-left: 3px solid var(--accent);
    border-radius: var(--radius-md);
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: 6px;
    transition: all 0.2s ease;
  }
  .fp-base-param:hover {
    background: var(--panel-card-hover);
    border-left-color: var(--accent-light);
    box-shadow: 0 2px 12px rgba(59, 130, 246, 0.08);
  }
  .fp-base-param:nth-child(2) {
    border-left-color: var(--teal);
  }
  .fp-base-param:nth-child(2):hover {
    border-left-color: var(--teal-light);
    box-shadow: 0 2px 12px rgba(20, 184, 166, 0.08);
  }
  .fp-base-param:nth-child(3) {
    border-left-color: var(--purple);
  }
  .fp-base-param:nth-child(3):hover {
    border-left-color: #c4b5fd;
    box-shadow: 0 2px 12px rgba(167, 139, 250, 0.08);
  }
  .fp-base-param input[type="range"] {
    width: 100%;
    accent-color: var(--accent);
  }
  .fp-param-hint {
    font-size: 0.65rem;
    color: var(--text-muted);
    font-style: italic;
  }

  /* ── Preset Drawer (pinned between header and body) ────────────────────── */
  .fp-preset-drawer {
    border-bottom: 1px solid var(--border);
    background: var(--panel-card);
    position: relative;
    z-index: 5;
    transition: all 0.2s ease;
  }
  .fp-drawer-open {
    background: var(--panel-card-hover);
    box-shadow: 0 4px 16px rgba(0,0,0,0.2);
  }

  .fp-drawer-trigger {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    padding: 8px 14px;
    background: linear-gradient(135deg, rgba(59,130,246,0.06) 0%, rgba(20,184,166,0.04) 100%);
    border: none;
    cursor: pointer;
    color: inherit;
    font: inherit;
    text-align: left;
    transition: background 0.15s ease;
  }
  .fp-drawer-trigger:hover {
    background: linear-gradient(135deg, rgba(59,130,246,0.10) 0%, rgba(20,184,166,0.06) 100%);
  }

  .fp-drawer-label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 0.78rem;
    font-weight: 700;
    color: var(--accent-light);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    white-space: nowrap;
  }
  .fp-drawer-ico {
    width: 14px;
    height: 14px;
    fill: var(--accent-light);
    flex-shrink: 0;
  }

  .fp-drawer-active {
    display: flex;
    align-items: center;
    gap: 4px;
    margin-left: auto;
    font-size: 0.7rem;
    font-weight: 600;
    color: var(--preset-accent, var(--accent-light));
    background: rgba(255,255,255,0.05);
    padding: 2px 8px;
    border-radius: var(--radius-full);
    border: 1px solid var(--preset-accent, var(--border));
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 140px;
  }
  .fp-drawer-active-icon {
    font-size: 0.75rem;
    line-height: 1;
  }
  .fp-drawer-none {
    margin-left: auto;
    font-size: 0.68rem;
    color: var(--text-muted);
    font-style: italic;
  }

  .fp-drawer-chev {
    width: 16px;
    height: 16px;
    fill: var(--text-muted);
    flex-shrink: 0;
    transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
  }
  .fp-drawer-chev-open {
    transform: rotate(180deg);
  }

  /* Dropdown panel */
  .fp-drawer-panel {
    display: flex;
    flex-direction: column;
    border-top: 1px solid var(--border);
    max-height: 280px;
    overflow-y: auto;
    animation: drawerSlideDown 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  }
  @keyframes drawerSlideDown {
    from {
      opacity: 0;
      max-height: 0;
    }
    to {
      opacity: 1;
      max-height: 280px;
    }
  }

  .fp-drawer-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 12px;
    background: transparent;
    border: none;
    border-bottom: 1px solid rgba(255,255,255,0.03);
    cursor: pointer;
    color: inherit;
    font: inherit;
    text-align: left;
    transition: all 0.15s ease;
    animation: drawerItemIn 0.25s ease both;
    position: relative;
  }
  @keyframes drawerItemIn {
    from {
      opacity: 0;
      transform: translateX(-6px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }
  .fp-drawer-item:hover {
    background: var(--panel-card-hover);
    padding-left: 16px;
  }
  .fp-drawer-item:last-child {
    border-bottom: none;
  }
  .fp-drawer-item-active {
    background: rgba(59, 130, 246, 0.06);
    border-left: 3px solid var(--preset-accent, var(--accent));
  }
  .fp-drawer-item-active:hover {
    background: rgba(59, 130, 246, 0.10);
  }
  .fp-drawer-item.flash {
    animation: drawerFlash 0.5s ease;
  }
  @keyframes drawerFlash {
    0% { background: transparent; }
    40% { background: rgba(59, 130, 246, 0.15); }
    100% { background: rgba(59, 130, 246, 0.06); }
  }

  .fp-drawer-item-icon {
    font-size: 1.1rem;
    line-height: 1;
    flex-shrink: 0;
    width: 24px;
    text-align: center;
  }
  .fp-drawer-item-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  }
  .fp-drawer-item-name {
    font-size: 0.76rem;
    font-weight: 700;
    color: var(--text-primary);
    line-height: 1.2;
  }
  .fp-drawer-item-desc {
    font-size: 0.62rem;
    color: var(--text-muted);
    line-height: 1.25;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fp-drawer-item-check {
    width: 18px;
    height: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: var(--preset-accent, var(--accent));
    color: white;
    font-size: 0.6rem;
    font-weight: 700;
    flex-shrink: 0;
    animation: checkPop 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  }
  @keyframes checkPop {
    from { transform: scale(0); }
    to { transform: scale(1); }
  }

  /* ── Collapsible sections (Model, Selection) ──────────────────────────── */
  .fp-section {
    background: var(--panel-card);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    overflow: hidden;
    transition: all 0.2s ease;
  }
  .fp-section:hover {
    border-color: var(--border-light);
  }
  .fp-section[open] {
    border-color: var(--border-accent);
    box-shadow: 0 2px 12px var(--accent-glow);
  }
  .fp-section-title {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: 10px var(--space-md);
    background: var(--panel-header-bg);
    cursor: pointer;
    user-select: none;
    font-weight: 600;
    font-size: 0.88rem;
    color: var(--text-primary);
    list-style: none;
    transition: background 0.15s ease;
  }
  .fp-section-title:hover {
    background: var(--panel-card-hover);
  }
  .fp-section-title::-webkit-details-marker { display: none; }
  .fp-section-title::after {
    content: '▸';
    margin-left: auto;
    color: var(--text-muted);
    transition: transform 0.15s ease, color 0.15s ease;
  }
  .fp-section[open] > .fp-section-title::after {
    transform: rotate(90deg);
    color: var(--accent-light);
  }
  .fp-section-icon {
    width: 16px;
    height: 16px;
    fill: var(--accent-light);
    opacity: 0.8;
  }
  .fp-section-body {
    padding: var(--space-sm) var(--space-md) var(--space-md);
    display: flex;
    flex-direction: column;
    gap: 8px;
    border-top: 1px solid var(--border);
    background: var(--panel-section-bg);
  }

  .fp-inline-param {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .fp-inline-label {
    font-size: 0.8rem;
    color: var(--text-secondary);
  }
  .fp-inline-val {
    font-size: 0.72rem;
    color: var(--accent-light);
    background: var(--bg-0);
    padding: 2px 8px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    font-weight: 600;
  }

  .fp-section-body select {
    padding: var(--space-xs) var(--space-sm);
    font-size: 0.8rem;
    background: var(--bg-0);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    transition: border-color 0.15s ease;
  }
  .fp-section-body select:focus {
    border-color: var(--accent);
    outline: none;
    box-shadow: 0 0 0 2px var(--accent-glow);
  }

  /* ── Debug row ────────────────────────────────────────────────────────── */
  .fp-debug-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: var(--panel-card);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    padding: 8px var(--space-md);
    font-size: 0.85rem;
    color: var(--text-secondary);
    transition: all 0.15s ease;
  }
  .fp-debug-row:hover {
    background: var(--panel-card-hover);
    border-color: var(--border-light);
  }

  .fp-debug-toggle {
    position: relative;
    display: inline-flex;
    align-items: center;
    cursor: pointer;
  }
  .fp-debug-toggle input {
    position: absolute; opacity: 0; width: 0; height: 0;
  }
  .fp-toggle-track {
    width: 34px;
    height: 18px;
    background: var(--bg-0);
    border: 1px solid var(--border);
    border-radius: var(--radius-full);
    transition: all 0.2s ease;
  }
  .fp-debug-toggle input:checked + .fp-toggle-track {
    background: var(--accent);
    border-color: var(--accent);
    box-shadow: 0 0 8px rgba(59, 130, 246, 0.3);
  }
  .fp-toggle-thumb {
    position: absolute;
    top: 2px; left: 2px;
    width: 14px; height: 14px;
    background: white;
    border-radius: 50%;
    transition: left 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
    box-shadow: 0 1px 3px rgba(0,0,0,0.2);
  }
  .fp-debug-toggle input:checked ~ .fp-toggle-thumb {
    left: 18px;
  }

  /* ── Action bar ───────────────────────────────────────────────────────── */
  .fp-actions {
    padding: var(--space-md);
    border-top: 1px solid var(--border);
    display: flex;
    gap: var(--space-sm);
    background: linear-gradient(180deg, var(--panel-bg) 0%, var(--bg-1) 100%);
  }
  .fp-actions .btn { flex: 1; }

  .fp-pulse {
    animation: fp-pulse-anim 2s infinite;
    background: linear-gradient(135deg, var(--accent) 0%, #6366f1 100%) !important;
    border: none !important;
  }
  @keyframes fp-pulse-anim {
    0%, 100% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.4); }
    50%      { box-shadow: 0 0 0 8px rgba(59, 130, 246, 0); }
  }
</style>
