<script>
  /**
   * TransportBar Component
   *
   * Video playback controls: play/pause, step, seek, speed selector.
   */

  let {
    currentFrame = 0,
    totalFrames = 0,
    isPlaying = false,
    playbackSpeed = 1,
    disabled = false,
    onplay = () => {},
    onpause = () => {},
    onstep = (direction) => {},
    onseek = (frame) => {},
    onspeedchange = (speed) => {},
  } = $props()

  const speedOptions = [0.25, 0.5, 1, 2, 4]

  // Format time from frame index (assuming 25 fps default)
  function formatTime(frame, fps = 25) {
    const seconds = frame / fps
    const mins = Math.floor(seconds / 60)
    const secs = (seconds % 60).toFixed(2)
    return `${mins}:${secs.padStart(5, '0')}`
  }

  function handleSeek(e) {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const ratio = x / rect.width
    const frame = Math.round(ratio * totalFrames)
    onseek(Math.max(0, Math.min(frame, totalFrames - 1)))
  }

  function handleKeydown(e) {
    if (disabled) return

    switch (e.key) {
      case ' ':
        e.preventDefault()
        isPlaying ? onpause() : onplay()
        break
      case 'ArrowLeft':
        e.preventDefault()
        onstep(-1)
        break
      case 'ArrowRight':
        e.preventDefault()
        onstep(1)
        break
    }
  }

  // Progress percentage
  let progress = $derived(totalFrames > 0 ? (currentFrame / totalFrames) * 100 : 0)
</script>

<svelte:window onkeydown={handleKeydown} />

<div class="transport-bar" class:disabled>
  <!-- Playback buttons -->
  <div class="controls">
    <button
      class="control-btn"
      onclick={() => onstep(-1)}
      {disabled}
      title="Previous frame (Left Arrow)"
    >
      <svg viewBox="0 0 24 24" class="icon">
        <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/>
      </svg>
    </button>

    <button
      class="control-btn play-btn"
      onclick={() => isPlaying ? onpause() : onplay()}
      {disabled}
      title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
    >
      {#if isPlaying}
        <svg viewBox="0 0 24 24" class="icon">
          <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
        </svg>
      {:else}
        <svg viewBox="0 0 24 24" class="icon">
          <path d="M8 5v14l11-7z"/>
        </svg>
      {/if}
    </button>

    <button
      class="control-btn"
      onclick={() => onstep(1)}
      {disabled}
      title="Next frame (Right Arrow)"
    >
      <svg viewBox="0 0 24 24" class="icon">
        <path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/>
      </svg>
    </button>
  </div>

  <!-- Timeline -->
  <div class="timeline-container">
    <div
      class="timeline"
      role="slider"
      tabindex="0"
      onclick={handleSeek}
    >
      <div class="timeline-progress" style="width: {progress}%"></div>
      <div class="timeline-thumb" style="left: {progress}%"></div>
    </div>
  </div>

  <!-- Time display -->
  <div class="time-display mono">
    <span class="current-time">{formatTime(currentFrame)}</span>
    <span class="separator">/</span>
    <span class="total-time">{formatTime(totalFrames)}</span>
  </div>

  <!-- Speed selector -->
  <div class="speed-selector">
    <select
      value={playbackSpeed}
      onchange={(e) => onspeedchange(parseFloat(e.target.value))}
      {disabled}
    >
      {#each speedOptions as speed}
        <option value={speed}>{speed}x</option>
      {/each}
    </select>
  </div>

  <!-- Frame counter -->
  <div class="frame-counter mono">
    Frame: {currentFrame} / {totalFrames}
  </div>
</div>

<style>
  .transport-bar {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    padding: var(--space-md);
    background: var(--bg-2);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
  }

  .transport-bar.disabled {
    opacity: 0.5;
    pointer-events: none;
  }

  .controls {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
  }

  .control-btn {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--bg-3);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    transition: var(--transition);
  }

  .control-btn:hover:not(:disabled) {
    background: var(--bg-hover);
    border-color: var(--border-light);
  }

  .control-btn .icon {
    width: 20px;
    height: 20px;
    fill: var(--text-primary);
  }

  .play-btn {
    width: 44px;
    height: 44px;
    background: var(--accent);
    border-color: var(--accent);
  }

  .play-btn:hover:not(:disabled) {
    background: var(--accent-hover);
    border-color: var(--accent-hover);
  }

  .play-btn .icon {
    fill: white;
  }

  .timeline-container {
    flex: 1;
    padding: 0 var(--space-sm);
  }

  .timeline {
    position: relative;
    height: 8px;
    background: var(--bg-3);
    border-radius: var(--radius-full);
    cursor: pointer;
  }

  .timeline-progress {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    background: var(--accent);
    border-radius: var(--radius-full);
    pointer-events: none;
  }

  .timeline-thumb {
    position: absolute;
    top: 50%;
    width: 16px;
    height: 16px;
    background: white;
    border: 2px solid var(--accent);
    border-radius: 50%;
    transform: translate(-50%, -50%);
    pointer-events: none;
    transition: transform var(--transition-fast);
  }

  .timeline:hover .timeline-thumb {
    transform: translate(-50%, -50%) scale(1.2);
  }

  .time-display {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.875rem;
    color: var(--text-secondary);
    min-width: 100px;
  }

  .current-time {
    color: var(--text-primary);
  }

  .separator {
    color: var(--text-muted);
  }

  .speed-selector select {
    padding: var(--space-xs) var(--space-sm);
    font-size: 0.875rem;
    background: var(--bg-3);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    cursor: pointer;
  }

  .speed-selector select:hover {
    border-color: var(--border-light);
  }

  .frame-counter {
    font-size: 0.75rem;
    color: var(--text-muted);
    min-width: 120px;
    text-align: right;
  }
</style>
