<script>
  /**
   * FilterGroup Component — Animated, interactive filter card
   *
   * - Parent enable toggle → auto-expands & shows params with slide animation
   * - Disable → collapses smoothly, siblings shift up
   * - Sliders are large, clearly visible with custom styling
   * - Toggle params use pill-style switches
   */

  let {
    groupName = '',
    label = '',
    icon = 'filter',
    description = '',
    group = $bindable({ enabled: false, params: {} }),
    paramMeta = {},
    globalDisabled = false,
    onchange = () => {},
  } = $props()

  // Auto-expand when enabled, collapse when disabled
  let expanded = $state(group.enabled)

  // Watch enable state and auto-expand/collapse
  $effect(() => {
    if (group.enabled && !globalDisabled) {
      expanded = true
    } else if (!group.enabled) {
      expanded = false
    }
  })

  let childrenDisabled = $derived(!group.enabled || globalDisabled)

  // Body ref for animated height
  let bodyRef = $state(null)
  let bodyHeight = $state(0)

  // Measure body when it mounts or params change
  $effect(() => {
    if (bodyRef && expanded) {
      // Use requestAnimationFrame to get height after render
      requestAnimationFrame(() => {
        bodyHeight = bodyRef.scrollHeight
      })
    }
  })

  function toggleEnabled(e) {
    e.stopPropagation()
    if (globalDisabled) return
    group.enabled = !group.enabled
    onchange()
  }

  function toggleExpand() {
    expanded = !expanded
  }

  function handleParamChange(paramName, value) {
    group.params[paramName] = value
    onchange()
  }

  function formatValue(val, meta) {
    if (val === undefined || val === null) return '—'
    if (typeof val === 'boolean') return val ? 'ON' : 'OFF'
    if (typeof val !== 'number') return String(val)
    if (meta.step == null) return val.toString()
    if (meta.step < 0.0001) return val.toFixed(6)
    if (meta.step < 0.01) return val.toFixed(4)
    if (meta.step < 1) return val.toFixed(2)
    return val.toFixed(0)
  }

  // Param count
  let paramCount = $derived(Object.keys(paramMeta).length)

  const icons = {
    filter: '<path d="M3 4h18v2H3V4zm3 5h12v2H6V9zm4 5h4v2h-4v-2z"/>',
    crop: '<path d="M17 15h2V7c0-1.1-.9-2-2-2H9v2h8v8zM7 17V1H5v4H1v2h4v10c0 1.1.9 2 2 2h10v4h2v-4h4v-2H7z"/>',
    eye: '<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>',
    ban: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM4 12c0-4.42 3.58-8 8-8 1.85 0 3.55.63 4.9 1.69L5.69 16.9C4.63 15.55 4 13.85 4 12zm8 8c-1.85 0-3.55-.63-4.9-1.69L18.31 7.1C19.37 8.45 20 10.15 20 12c0 4.42-3.58 8-8 8z"/>',
    crosshair: '<path d="M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm8.94 3c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/>',
    'trending-up': '<path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"/>',
    sliders: '<path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"/>',
    grid: '<path d="M4 4h4v4H4V4zm6 0h4v4h-4V4zm6 0h4v4h-4V4zM4 10h4v4H4v-4zm6 0h4v4h-4v-4zm6 0h4v4h-4v-4zM4 16h4v4H4v-4zm6 0h4v4h-4v-4zm6 0h4v4h-4v-4z"/>',
  }
</script>

<!-- ─── Markup ─────────────────────────────────────────────────────────── -->

<div
  class="fg"
  class:fg-on={group.enabled && !globalDisabled}
  class:fg-off={!group.enabled}
  class:fg-global-off={globalDisabled}
>
  <!-- Header -->
  <button class="fg-head" onclick={toggleExpand} aria-expanded={expanded}>
    <!-- Toggle switch -->
    <!-- svelte-ignore a11y_no_static_element_interactions -->
    <span class="fg-sw" onclick={toggleEnabled} onkeydown={(e) => { if (e.key === 'Enter') toggleEnabled(e) }}>
      <span class="fg-sw-track" class:fg-sw-track-on={group.enabled}></span>
      <span class="fg-sw-dot" class:fg-sw-dot-on={group.enabled}></span>
    </span>

    <!-- Icon -->
    <svg class="fg-ico" viewBox="0 0 24 24">{@html icons[icon] || icons.filter}</svg>

    <!-- Title -->
    <div class="fg-title">
      <span class="fg-name">{label}</span>
      <span class="fg-sub">{description} · {paramCount} params</span>
    </div>

    <!-- Status pill -->
    <span class="fg-pill" class:fg-pill-on={group.enabled}>
      {group.enabled ? 'ON' : 'OFF'}
    </span>

    <!-- Chevron -->
    <svg class="fg-chev" class:fg-chev-open={expanded} viewBox="0 0 24 24">
      <path d="M7 10l5 5 5-5z"/>
    </svg>
  </button>

  <!-- Animated body wrapper -->
  <div
    class="fg-body-wrap"
    style="max-height: {expanded ? bodyHeight + 'px' : '0px'}"
  >
    <div class="fg-body" bind:this={bodyRef} class:fg-body-off={childrenDisabled}>

      {#if childrenDisabled && !globalDisabled}
        <p class="fg-hint">
          <svg viewBox="0 0 24 24" class="fg-hint-ico"><path d="M13 9h-2v2h2V9zm0 4h-2v6h2v-6zM12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2z"/></svg>
          Enable this group to adjust its filters
        </p>
      {/if}

      {#each Object.entries(paramMeta) as [paramName, meta] (paramName)}
        <div class="fg-row" class:fg-row-toggle={meta.type === 'toggle'}>
          <!-- Label + live value -->
          <div class="fg-row-top">
            <span class="fg-lbl">{meta.label}</span>
            <span class="fg-val mono">
              {#if meta.type === 'toggle'}
                <span class="fg-val-bool" class:fg-val-bool-on={group.params[paramName]}>
                  {group.params[paramName] ? 'ON' : 'OFF'}
                </span>
              {:else}
                {formatValue(group.params[paramName], meta)}
              {/if}
            </span>
          </div>

          <!-- Slider / toggle control -->
          {#if meta.type === 'toggle'}
            <!-- svelte-ignore a11y_no_static_element_interactions -->
            <span
              class="fg-mini-sw"
              onclick={(e) => { e.stopPropagation(); if (!childrenDisabled) handleParamChange(paramName, !group.params[paramName]) }}
              onkeydown={(e) => { if (e.key === 'Enter' && !childrenDisabled) handleParamChange(paramName, !group.params[paramName]) }}
            >
              <span class="fg-mini-track" class:fg-mini-track-on={group.params[paramName]}></span>
              <span class="fg-mini-dot" class:fg-mini-dot-on={group.params[paramName]}></span>
            </span>
          {:else if meta.type === 'range'}
            <div class="fg-slider">
              <input
                type="range"
                min={meta.min}
                max={meta.max}
                step={meta.step}
                value={group.params[paramName]}
                oninput={(e) => handleParamChange(paramName, parseFloat(e.target.value))}
                disabled={childrenDisabled}
                style="--pct: {((group.params[paramName] - meta.min) / (meta.max - meta.min)) * 100}%"
              />
              <div class="fg-slider-bounds">
                <span class="mono">{meta.min}</span>
                <span class="mono">{meta.max}</span>
              </div>
            </div>
          {/if}
        </div>
      {/each}
    </div>
  </div>
</div>

<!-- ─── Styles ─────────────────────────────────────────────────────────── -->

<style>
  /* ═══════════════════════════════════════════════════════════════════════
     CARD
     ═══════════════════════════════════════════════════════════════════ */
  .fg {
    border-radius: var(--radius-lg);
    border: 1.5px solid var(--border);
    background: var(--panel-card);
    transition:
      border-color 0.25s ease,
      box-shadow 0.25s ease,
      opacity 0.2s ease,
      transform 0.2s ease,
      background 0.2s ease;
  }
  .fg:hover {
    background: var(--panel-card-hover);
    border-color: var(--border-light);
  }
  .fg-on {
    border-color: var(--accent);
    background: linear-gradient(135deg, var(--panel-card) 0%, rgba(59,130,246,0.05) 100%);
    box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.12), 0 4px 20px -4px rgba(59, 130, 246, 0.1);
  }
  .fg-on:hover {
    background: linear-gradient(135deg, var(--panel-card-hover) 0%, rgba(59,130,246,0.08) 100%);
  }
  .fg-off {
    opacity: 0.68;
  }
  .fg-global-off {
    opacity: 0.38;
    pointer-events: none;
  }

  /* ═══════════════════════════════════════════════════════════════════════
     HEADER
     ═══════════════════════════════════════════════════════════════════ */
  .fg-head {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    padding: 12px 14px;
    background: transparent;
    border: none;
    cursor: pointer;
    user-select: none;
    color: inherit;
    font: inherit;
    text-align: left;
    transition: background 0.15s ease;
  }
  .fg-head:hover {
    background: rgba(255, 255, 255, 0.03);
  }

  /* ── Switch (parent toggle) ──────────────────────────────────────────── */
  .fg-sw {
    position: relative;
    width: 40px;
    height: 22px;
    flex-shrink: 0;
    cursor: pointer;
  }
  .fg-sw-track {
    position: absolute;
    inset: 0;
    border-radius: 11px;
    background: var(--bg-0);
    border: 1.5px solid var(--border);
    transition: all 0.2s ease;
  }
  .fg-sw-track-on {
    background: linear-gradient(135deg, var(--accent) 0%, #6366f1 100%);
    border-color: var(--accent);
    box-shadow: 0 0 10px rgba(59, 130, 246, 0.3);
  }
  .fg-sw-dot {
    position: absolute;
    top: 3px;
    left: 3px;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.3);
    transition: left 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
  }
  .fg-sw-dot-on {
    left: 21px;
  }

  .fg-ico {
    width: 18px;
    height: 18px;
    fill: var(--text-muted);
    flex-shrink: 0;
    transition: fill 0.15s ease;
  }
  .fg-on .fg-ico {
    fill: var(--accent-light);
    filter: drop-shadow(0 0 3px rgba(96, 165, 250, 0.3));
  }

  .fg-title {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  }
  .fg-name {
    font-weight: 700;
    font-size: 0.88rem;
    color: var(--text-primary);
    line-height: 1.2;
  }
  .fg-sub {
    font-size: 0.68rem;
    color: var(--text-muted);
    line-height: 1.2;
  }

  /* ── Status pill ─────────────────────────────────────────────────────── */
  .fg-pill {
    font-size: 0.6rem;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    padding: 2px 8px;
    border-radius: 9999px;
    flex-shrink: 0;
    background: var(--bg-0);
    color: var(--text-muted);
    border: 1px solid var(--border);
    transition: all 0.2s ease;
  }
  .fg-pill-on {
    background: linear-gradient(135deg, rgba(34,197,94,0.15) 0%, rgba(34,197,94,0.08) 100%);
    color: var(--success);
    border-color: rgba(34, 197, 94, 0.3);
    box-shadow: 0 0 6px rgba(34, 197, 94, 0.15);
  }

  .fg-chev {
    width: 18px;
    height: 18px;
    fill: var(--text-muted);
    flex-shrink: 0;
    transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
  }
  .fg-chev-open {
    transform: rotate(180deg);
  }

  /* ═══════════════════════════════════════════════════════════════════════
     ANIMATED BODY WRAPPER
     ═══════════════════════════════════════════════════════════════════ */
  .fg-body-wrap {
    overflow: hidden;
    transition: max-height 0.35s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .fg-body {
    padding: 6px 14px 14px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    border-top: 1px solid var(--border);
    background: rgba(0, 0, 0, 0.08);
    transition: opacity 0.2s ease;
  }
  .fg-body-off {
    opacity: 0.3;
    pointer-events: none;
  }

  .fg-hint {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 0.72rem;
    color: var(--text-muted);
    font-style: italic;
    margin: 2px 0;
  }
  .fg-hint-ico {
    width: 14px;
    height: 14px;
    fill: var(--text-muted);
    flex-shrink: 0;
  }

  /* ═══════════════════════════════════════════════════════════════════════
     PARAM ROWS
     ═══════════════════════════════════════════════════════════════════ */
  .fg-row {
    display: flex;
    flex-direction: column;
    gap: 5px;
    animation: fgRowIn 0.3s ease both;
  }
  .fg-row-toggle {
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  @keyframes fgRowIn {
    from { opacity: 0; transform: translateY(6px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  /* Stagger the rows */
  .fg-row:nth-child(1)  { animation-delay: 0ms; }
  .fg-row:nth-child(2)  { animation-delay: 30ms; }
  .fg-row:nth-child(3)  { animation-delay: 60ms; }
  .fg-row:nth-child(4)  { animation-delay: 90ms; }
  .fg-row:nth-child(5)  { animation-delay: 120ms; }
  .fg-row:nth-child(6)  { animation-delay: 150ms; }
  .fg-row:nth-child(7)  { animation-delay: 180ms; }
  .fg-row:nth-child(8)  { animation-delay: 210ms; }
  .fg-row:nth-child(9)  { animation-delay: 240ms; }
  .fg-row:nth-child(10) { animation-delay: 270ms; }

  .fg-row-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .fg-lbl {
    font-size: 0.78rem;
    color: var(--text-secondary);
    font-weight: 500;
  }
  .fg-val {
    font-size: 0.72rem;
    padding: 2px 8px;
    border-radius: var(--radius-sm);
    background: var(--bg-0);
    color: var(--accent-light);
    border: 1px solid var(--border);
    font-weight: 600;
  }
  .fg-val-bool {
    color: var(--text-muted);
    transition: color 0.15s ease;
  }
  .fg-val-bool-on {
    color: var(--success);
    text-shadow: 0 0 6px rgba(34, 197, 94, 0.3);
  }

  /* ═══════════════════════════════════════════════════════════════════════
     SLIDER (custom styled – large, clearly visible)
     ═══════════════════════════════════════════════════════════════════ */
  .fg-slider {
    display: flex;
    flex-direction: column;
    gap: 3px;
  }
  .fg-slider input[type="range"] {
    -webkit-appearance: none;
    appearance: none;
    width: 100%;
    height: 8px;
    border-radius: 4px;
    outline: none;
    cursor: pointer;
    /* Filled track trick using background gradient */
    background: linear-gradient(
      to right,
      var(--accent) 0%,
      var(--accent) var(--pct, 50%),
      rgba(255,255,255,0.08) var(--pct, 50%),
      rgba(255,255,255,0.08) 100%
    );
    transition: opacity 0.15s ease;
  }
  .fg-slider input[type="range"]:disabled {
    opacity: 0.3;
    cursor: not-allowed;
  }
  /* Thumb */
  .fg-slider input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    background: #fff;
    border: 2.5px solid var(--accent);
    box-shadow: 0 1px 4px rgba(0,0,0,0.25), 0 0 0 2px rgba(59, 130, 246, 0.1);
    cursor: pointer;
    transition: transform 0.12s ease, box-shadow 0.12s ease;
  }
  .fg-slider input[type="range"]::-webkit-slider-thumb:hover {
    transform: scale(1.18);
    box-shadow: 0 0 0 5px rgba(59, 130, 246, 0.2), 0 2px 6px rgba(0,0,0,0.2);
  }
  .fg-slider input[type="range"]::-webkit-slider-thumb:active {
    transform: scale(1.25);
    box-shadow: 0 0 0 6px rgba(59, 130, 246, 0.25), 0 2px 8px rgba(0,0,0,0.25);
  }
  /* Firefox */
  .fg-slider input[type="range"]::-moz-range-thumb {
    width: 18px;
    height: 18px;
    border-radius: 50%;
    background: #fff;
    border: 2.5px solid var(--accent);
    cursor: pointer;
  }
  .fg-slider input[type="range"]::-moz-range-track {
    height: 8px;
    border-radius: 4px;
    background: rgba(255,255,255,0.08);
  }
  .fg-slider input[type="range"]::-moz-range-progress {
    height: 8px;
    border-radius: 4px;
    background: var(--accent);
  }

  .fg-slider-bounds {
    display: flex;
    justify-content: space-between;
    font-size: 0.6rem;
    color: var(--text-muted);
    padding: 0 2px;
  }

  /* ═══════════════════════════════════════════════════════════════════════
     MINI TOGGLE SWITCH (for boolean params)
     ═══════════════════════════════════════════════════════════════════ */
  .fg-mini-sw {
    position: relative;
    width: 34px;
    height: 18px;
    flex-shrink: 0;
    cursor: pointer;
  }
  .fg-mini-track {
    position: absolute;
    inset: 0;
    border-radius: 9px;
    background: var(--bg-0);
    border: 1.5px solid var(--border);
    transition: all 0.2s ease;
  }
  .fg-mini-track-on {
    background: linear-gradient(135deg, var(--accent) 0%, #6366f1 100%);
    border-color: var(--accent);
    box-shadow: 0 0 8px rgba(59, 130, 246, 0.25);
  }
  .fg-mini-dot {
    position: absolute;
    top: 2px;
    left: 2px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 1px 2px rgba(0,0,0,0.2);
    transition: left 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
  }
  .fg-mini-dot-on {
    left: 18px;
  }
</style>
