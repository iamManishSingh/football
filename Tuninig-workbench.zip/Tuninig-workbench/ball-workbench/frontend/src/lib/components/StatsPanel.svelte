<script>
  /**
   * StatsPanel Component
   *
   * Displays live detection statistics.
   */

  let {
    stats = {
      totalFrames: 0,
      detectedFrames: 0,
      predictedFrames: 0,
      lostFrames: 0,
      totalRejected: 0,
    },
    frameResult = null,
  } = $props()

  // Calculate percentages
  let detectionRate = $derived(
    stats.totalFrames > 0
      ? ((stats.detectedFrames / stats.totalFrames) * 100).toFixed(1)
      : '0.0'
  )

  let predictionRate = $derived(
    stats.totalFrames > 0
      ? ((stats.predictedFrames / stats.totalFrames) * 100).toFixed(1)
      : '0.0'
  )

  let lostRate = $derived(
    stats.totalFrames > 0
      ? ((stats.lostFrames / stats.totalFrames) * 100).toFixed(1)
      : '0.0'
  )
</script>

<div class="stats-panel">
  <h4>Statistics</h4>

  <!-- Summary stats -->
  <div class="stats-grid">
    <div class="stat-card detected">
      <div class="stat-value">{detectionRate}%</div>
      <div class="stat-label">Detection Rate</div>
      <div class="stat-count">{stats.detectedFrames} frames</div>
    </div>

    <div class="stat-card predicted">
      <div class="stat-value">{predictionRate}%</div>
      <div class="stat-label">Prediction Rate</div>
      <div class="stat-count">{stats.predictedFrames} frames</div>
    </div>

    <div class="stat-card lost">
      <div class="stat-value">{lostRate}%</div>
      <div class="stat-label">Lost Rate</div>
      <div class="stat-count">{stats.lostFrames} frames</div>
    </div>

    <div class="stat-card rejected">
      <div class="stat-value">{stats.totalRejected}</div>
      <div class="stat-label">Total Rejected</div>
      <div class="stat-count">detections</div>
    </div>
  </div>

  <!-- Current frame details -->
  {#if frameResult?.debug}
    <div class="frame-details">
      <h5>Current Frame</h5>

      <div class="detail-row">
        <span class="detail-label">Raw Detections:</span>
        <span class="detail-value mono">{frameResult.debug.raw_count || 0}</span>
      </div>

      {#if frameResult.debug.stage_counts}
        <div class="stage-counts">
          <div class="stage-item">
            <span class="stage-label">After Basic:</span>
            <span class="stage-value">{frameResult.debug.stage_counts.after_basic || 0}</span>
          </div>
          <div class="stage-item">
            <span class="stage-label">After ROI:</span>
            <span class="stage-value">{frameResult.debug.stage_counts.after_roi || 0}</span>
          </div>
          <div class="stage-item">
            <span class="stage-label">After Appearance:</span>
            <span class="stage-value">{frameResult.debug.stage_counts.after_appearance || 0}</span>
          </div>
          <div class="stage-item">
            <span class="stage-label">After Static:</span>
            <span class="stage-value">{frameResult.debug.stage_counts.after_static || 0}</span>
          </div>
          <div class="stage-item final">
            <span class="stage-label">Final:</span>
            <span class="stage-value">{frameResult.debug.stage_counts.final || 0}</span>
          </div>
        </div>
      {/if}

      <!-- Rejected list -->
      {#if frameResult.debug.rejected?.length > 0}
        <div class="rejected-list">
          <h6>Rejected ({frameResult.debug.rejected.length})</h6>
          <div class="rejected-items">
            {#each frameResult.debug.rejected.slice(0, 10) as item}
              <div class="rejected-item">
                <span class="rejected-reason">{item.reason}</span>
                <span class="rejected-conf mono">{(item.conf * 100).toFixed(0)}%</span>
              </div>
            {/each}
            {#if frameResult.debug.rejected.length > 10}
              <div class="more-items">
                +{frameResult.debug.rejected.length - 10} more...
              </div>
            {/if}
          </div>
        </div>
      {/if}

      <!-- Velocity info -->
      {#if frameResult.debug.velocity}
        <div class="velocity-info">
          <h6>Ball Velocity</h6>
          <div class="velocity-values mono">
            <span>vx: {frameResult.debug.velocity.vx?.toFixed(1) || 0}</span>
            <span>vy: {frameResult.debug.velocity.vy?.toFixed(1) || 0}</span>
            <span>speed: {Math.hypot(
              frameResult.debug.velocity.vx || 0,
              frameResult.debug.velocity.vy || 0
            ).toFixed(1)} px/f</span>
          </div>
        </div>
      {/if}
    </div>
  {/if}
</div>

<style>
  .stats-panel {
    padding: var(--space-md);
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
    height: 100%;
    overflow-y: auto;
  }

  h4 {
    font-size: 1rem;
    color: var(--text-primary);
    margin-bottom: var(--space-xs);
  }

  h5, h6 {
    font-size: 0.875rem;
    color: var(--text-secondary);
    margin-bottom: var(--space-sm);
  }

  .stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: var(--space-sm);
  }

  .stat-card {
    background: var(--bg-2);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    padding: var(--space-md);
    text-align: center;
  }

  .stat-card.detected {
    border-left: 3px solid var(--success);
  }

  .stat-card.predicted {
    border-left: 3px solid var(--info);
  }

  .stat-card.lost {
    border-left: 3px solid var(--error);
  }

  .stat-card.rejected {
    border-left: 3px solid var(--warning);
  }

  .stat-value {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--text-primary);
  }

  .stat-label {
    font-size: 0.75rem;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .stat-count {
    font-size: 0.75rem;
    color: var(--text-secondary);
    margin-top: var(--space-xs);
  }

  .frame-details {
    background: var(--bg-2);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    padding: var(--space-md);
  }

  .detail-row {
    display: flex;
    justify-content: space-between;
    padding: var(--space-xs) 0;
  }

  .detail-label {
    color: var(--text-muted);
  }

  .detail-value {
    color: var(--text-primary);
  }

  .stage-counts {
    margin-top: var(--space-sm);
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .stage-item {
    display: flex;
    justify-content: space-between;
    padding: var(--space-xs) var(--space-sm);
    background: var(--bg-1);
    border-radius: var(--radius-sm);
    font-size: 0.8rem;
  }

  .stage-item.final {
    background: var(--success-bg);
  }

  .stage-item.final .stage-value {
    color: var(--success);
    font-weight: 600;
  }

  .stage-label {
    color: var(--text-muted);
  }

  .stage-value {
    color: var(--text-secondary);
  }

  .rejected-list {
    margin-top: var(--space-md);
  }

  .rejected-items {
    display: flex;
    flex-direction: column;
    gap: 2px;
    max-height: 150px;
    overflow-y: auto;
  }

  .rejected-item {
    display: flex;
    justify-content: space-between;
    padding: var(--space-xs) var(--space-sm);
    background: var(--error-bg);
    border-radius: var(--radius-sm);
    font-size: 0.75rem;
  }

  .rejected-reason {
    color: var(--error);
  }

  .rejected-conf {
    color: var(--text-muted);
  }

  .more-items {
    text-align: center;
    padding: var(--space-xs);
    color: var(--text-muted);
    font-size: 0.75rem;
  }

  .velocity-info {
    margin-top: var(--space-md);
  }

  .velocity-values {
    display: flex;
    gap: var(--space-md);
    font-size: 0.8rem;
    color: var(--purple);
  }
</style>
