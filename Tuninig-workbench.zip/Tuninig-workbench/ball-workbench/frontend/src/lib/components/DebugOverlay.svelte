<script>
  /**
   * DebugOverlay Component
   *
   * Toggle chips for overlay layers on the video canvas.
   */

  let {
    settings = $bindable({
      showDetected: true,
      showRejected: true,
      showPredicted: true,
      showRoiMask: false,
      showTrajectory: false,
      showVelocity: false,
    }),
    onchange = () => {},
  } = $props()

  const overlayOptions = [
    { key: 'showDetected', label: 'Detected', color: 'success' },
    { key: 'showRejected', label: 'Rejected', color: 'error' },
    { key: 'showPredicted', label: 'Predicted', color: 'info' },
    { key: 'showRoiMask', label: 'ROI Mask', color: 'warning' },
    { key: 'showVelocity', label: 'Velocity', color: 'purple' },
  ]

  function toggle(key) {
    settings[key] = !settings[key]
    onchange()
  }
</script>

<div class="debug-overlay">
  <span class="label">Overlays:</span>
  <div class="chips">
    {#each overlayOptions as option}
      <button
        class="chip {option.color}"
        class:active={settings[option.key]}
        onclick={() => toggle(option.key)}
      >
        <span class="chip-dot"></span>
        {option.label}
      </button>
    {/each}
  </div>
</div>

<style>
  .debug-overlay {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    background: var(--bg-2);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
  }

  .label {
    font-size: 0.75rem;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .chips {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-xs);
  }

  .chip {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    font-size: 0.75rem;
    font-weight: 500;
    background: var(--bg-1);
    border: 1px solid var(--border);
    border-radius: var(--radius-full);
    color: var(--text-muted);
    transition: var(--transition);
  }

  .chip:hover {
    background: var(--bg-3);
  }

  .chip.active {
    border-color: currentColor;
  }

  .chip-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: currentColor;
    opacity: 0.3;
    transition: var(--transition);
  }

  .chip.active .chip-dot {
    opacity: 1;
  }

  .chip.success {
    color: var(--success);
  }

  .chip.success.active {
    background: var(--success-bg);
  }

  .chip.error {
    color: var(--error);
  }

  .chip.error.active {
    background: var(--error-bg);
  }

  .chip.info {
    color: var(--info);
  }

  .chip.info.active {
    background: var(--info-bg);
  }

  .chip.warning {
    color: var(--warning);
  }

  .chip.warning.active {
    background: var(--warning-bg);
  }

  .chip.purple {
    color: var(--purple);
  }

  .chip.purple.active {
    background: var(--purple-bg);
  }
</style>
