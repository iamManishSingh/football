<script>
  /**
   * Ball Detection Filter Tuning Workbench
   *
   * Main page that brings together all components.
   */

  import { onMount } from 'svelte'
  import '../app.css'

  import VideoCanvas from '$lib/components/VideoCanvas.svelte'
  import FilterPanel from '$lib/components/FilterPanel.svelte'
  import TransportBar from '$lib/components/TransportBar.svelte'
  import ConfigManager from '$lib/components/ConfigManager.svelte'
  import DebugOverlay from '$lib/components/DebugOverlay.svelte'
  import StatsHUD from '$lib/components/StatsHUD.svelte'

  import { DEFAULT_CONFIG, PRESETS, cloneConfig, toLegacyConfigString } from '../../../shared/ball-filter-config.js'
  import { createPipeline } from '../../../shared/ball-filter-rfdetr.js'

  // API URLs
  const API_BASE = 'http://localhost:3001'      // Node.js backend
  const INFERENCE_API = 'http://localhost:8000'  // Python inference server
  const WS_URL = 'ws://localhost:3002'

  // State
  let config = $state(cloneConfig(DEFAULT_CONFIG))
  let pipeline = $state(null)
  let detectionsData = $state(null)
  let videoInfo = $state({ width: 1920, height: 1080, fps: 25, totalFrames: 0 })

  let currentFrame = $state(0)
  let totalFrames = $state(0)
  let isPlaying = $state(false)
  let playbackSpeed = $state(1)
  let playInterval = $state(null)

  let frameResult = $state(null)

  let overlaySettings = $state({
    showDetected: true,
    showRejected: true,
    showPredicted: true,
    showRoiMask: false,
    showVelocity: false,
  })

  let savedConfigs = $state([])
  let activeTab = $state('filters')
  let detectionsLoaded = $state(false)
  let wsConnected = $state(false)
  let ws = $state(null)

  let toast = $state(null)
  let detectionsInput
  let videoInput
  let videoLoaded = $state(false)
  let videoFilename = $state('')
  let frameImage = $state(null)
  let videoFile = $state(null)  // Raw File object for video preview

  // Live inference state
  let liveMode = $state(false)
  let videoId = $state(null)
  let inferenceAvailable = $state(false)
  let isProcessing = $state(false)
  let processingProgress = $state(0)

  // Detection cache for live mode
  let detectionCache = $state({})
  let cacheSize = $state(0)
  let useLiveInference = $state(false)  // Toggle between precompute JSON and live inference
  let processingRange = $state({ start: 0, end: -1 })  // Frame range for processing

  // Initialize pipeline
  onMount(() => {
    pipeline = createPipeline(config)
    fetchSavedConfigs()
    connectWebSocket()
    checkInferenceServer()

    return () => {
      stopPlayback()
      if (ws) ws.close()
    }
  })

  // Check if Python inference server is available
  async function checkInferenceServer() {
    try {
      const res = await fetch(`${INFERENCE_API}/health`)
      if (res.ok) {
        inferenceAvailable = true
        console.log('Python inference server available')
      }
    } catch (e) {
      inferenceAvailable = false
      console.log('Python inference server not available')
    }
  }

  // WebSocket connection
  function connectWebSocket() {
    try {
      ws = new WebSocket(WS_URL)

      ws.onopen = () => {
        wsConnected = true
        showToast('Connected to server', 'success')
      }

      ws.onclose = () => {
        wsConnected = false
        // Auto-reconnect after 2 seconds
        setTimeout(connectWebSocket, 2000)
      }

      ws.onmessage = (event) => {
        const message = JSON.parse(event.data)
        handleWsMessage(message)
      }
    } catch (e) {
      console.error('WebSocket connection failed:', e)
    }
  }

  function handleWsMessage(message) {
    switch (message.type) {
      case 'connected':
        if (message.config) {
          config = cloneConfig(message.config)
        }
        if (message.totalFrames) {
          totalFrames = message.totalFrames
        }
        if (message.videoInfo) {
          videoInfo = message.videoInfo
        }
        detectionsLoaded = message.detectionsLoaded
        break

      case 'frame_result':
        frameResult = message
        currentFrame = message.frameIdx
        totalFrames = message.totalFrames
        break

      case 'config_updated':
        showToast('Config updated', 'info')
        break

      case 'playback_end':
        stopPlayback()
        showToast('Playback complete', 'info')
        break
    }
  }

  // Toast notifications
  function showToast(message, type = 'info') {
    toast = { message, type }
    setTimeout(() => toast = null, 3000)
  }

  // Fetch saved configs
  async function fetchSavedConfigs() {
    try {
      const res = await fetch(`${API_BASE}/api/configs`)
      const data = await res.json()
      savedConfigs = data.configs || []
    } catch (e) {
      console.error('Failed to fetch configs:', e)
    }
  }

  // Upload detections
  async function handleDetectionsUpload(e) {
    const file = e.target.files[0]
    if (!file) return

    console.log('Loading detection file:', file.name)

    try {
      const text = await file.text()
      console.log('File text length:', text.length)

      const data = JSON.parse(text)
      console.log('Parsed JSON, frames:', data.frames?.length)

      // Store locally for offline processing
      detectionsData = data
      detectionsLoaded = true

      if (data.video_info) {
        videoInfo = data.video_info
        console.log('Video info:', videoInfo)
      }

      if (data.frames) {
        totalFrames = data.frames.length
      }

      // Try to send to server (but don't fail if server is unavailable)
      try {
        const res = await fetch(`${API_BASE}/api/upload-detections-json`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: text,
        })
        if (res.ok) {
          console.log('Detections uploaded to server')
        }
      } catch (serverErr) {
        console.log('Server unavailable, using offline mode')
      }

      showToast(`Loaded ${totalFrames} frames`, 'success')
      console.log('About to process frame 0')
      // Process first frame
      processFrame(0)
    } catch (e) {
      showToast('Failed to load detections: ' + e.message, 'error')
      console.error('Detection load error:', e)
    }
  }

  // Upload video
  async function handleVideoUpload(e) {
    const file = e.target.files[0]
    if (!file) return

    // Always store file for video preview in canvas (even if inference server is down)
    videoFile = file
    videoLoaded = true
    videoFilename = file.name

    // Check if inference server is available
    if (!inferenceAvailable) {
      showToast('Video loaded for preview. Python inference server not available — start it to enable detection.', 'warning')
      return
    }

    try {
      showToast('Uploading video...', 'info')

      const formData = new FormData()
      formData.append('video', file)

      // Upload to Python inference server
      const res = await fetch(`${INFERENCE_API}/upload-video`, {
        method: 'POST',
        body: formData,
      })

      if (res.ok) {
        const data = await res.json()
        videoLoaded = true
        videoFilename = file.name
        videoId = data.video_id
        useLiveInference = true

        if (data.video_info) {
          videoInfo = data.video_info
          totalFrames = data.video_info.total_frames || 0
        }

        // Reset cache
        detectionCache = {}
        cacheSize = 0
        // Don't set detectionsLoaded here – it becomes true once inference actually produces frames

        showToast(`Video loaded: ${file.name}. Select clip range and start detection.`, 'success')
        // No popup — clip controls now appear in the VideoCanvas
      } else {
        const error = await res.json()
        showToast(`Failed to upload video: ${error.detail || 'Unknown error'}`, 'error')
      }
    } catch (e) {
      showToast('Failed to upload video: ' + e.message, 'error')
      console.error('Video upload error:', e)
    }
  }

  // Called from VideoCanvas clip controls when user clicks "Start Detection"
  function handleStartDetectionFromCanvas(startSec, endSec) {
    const fps = videoInfo.fps || 25
    const startFrame = Math.floor(startSec * fps)
    const endFrame = endSec < 0 ? totalFrames : Math.floor(endSec * fps)

    processingRange = { start: startFrame, end: endFrame }
    showToast(`Processing frames ${startFrame} to ${endFrame}`, 'info')
    startLiveInference()
  }

  // Start live inference and playback
  async function startLiveInference() {
    if (!videoId || isProcessing) return

    isProcessing = true
    processingProgress = 0
    const startFrame = processingRange.start
    const endFrame = processingRange.end > 0 ? processingRange.end : totalFrames

    showToast('Starting live inference...', 'info')

    try {
      // Process frames sequentially and play as they arrive
      for (let frameIdx = startFrame; frameIdx < endFrame && isProcessing; frameIdx++) {
        // Fetch detection for this frame from Python server
        const frameResult = await fetchFrameDetection(frameIdx)
        
        if (frameResult) {
          // Cache the raw detection
          detectionCache[frameIdx] = frameResult
          cacheSize++

          // Mark detections as available once first frame arrives
          if (!detectionsLoaded) detectionsLoaded = true

          // Apply filters and display
          await processFrameFromCache(frameIdx)

          // Update progress
          processingProgress = ((frameIdx - startFrame + 1) / (endFrame - startFrame)) * 100

          // Small delay to allow UI updates and maintain ~playback speed
          const fps = videoInfo.fps || 25
          await new Promise(resolve => setTimeout(resolve, 1000 / fps))
        }
      }

      showToast('Live inference complete!', 'success')
      isProcessing = false
      
    } catch (e) {
      showToast('Live inference failed: ' + e.message, 'error')
      console.error('Live inference error:', e)
      isProcessing = false
    }
  }

  // Stop live inference
  function stopLiveInference() {
    isProcessing = false
    showToast('Live inference stopped', 'info')
  }

  // Restart detection from the beginning (clear cache & re-run)
  function handleRestartDetection() {
    stopLiveInference()
    detectionCache = {}
    cacheSize = 0
    currentFrame = 0
    frameResult = null
    frameImage = null
    detectionsLoaded = false
    processingProgress = 0
    showToast('Cache cleared. Select clip range and start detection.', 'info')
  }

  // Seek to a cached frame for instant replay
  function handleSeekCachedFrame(frameIdx) {
    if (detectionCache[frameIdx]) {
      processFrameFromCache(frameIdx)
    }
  }

  // Fetch detection for a single frame from Python server
  async function fetchFrameDetection(frameIdx) {
    try {
      const threshold = config.model?.threshold || 0.10
      const classId = config.model?.class_id || 32
      const nmsIou = config.model?.nms_iou ?? 0.50
      const imageSize = config.model?.image_size ?? 560

      const res = await fetch(
        `${INFERENCE_API}/video/${videoId}/detect/${frameIdx}?threshold=${threshold}&class_id=${classId}&nms_iou=${nmsIou}&image_size=${imageSize}`
      )

      if (res.ok) {
        return await res.json()
      } else {
        console.error(`Failed to fetch frame ${frameIdx}`)
        return null
      }
    } catch (e) {
      console.error(`Error fetching frame ${frameIdx}:`, e)
      return null
    }
  }

  // Process frame from cache (instant replay)
  async function processFrameFromCache(frameIdx) {
    const cachedData = detectionCache[frameIdx]
    
    if (!cachedData) {
      // Try to fetch from server if not in cache and live mode is active
      if (useLiveInference && videoId) {
        const frameData = await fetchFrameDetection(frameIdx)
        if (frameData) {
          detectionCache[frameIdx] = frameData
          cacheSize++
          return processFrameFromCache(frameIdx)
        }
      }

      console.warn(`Frame ${frameIdx} not in cache`)
      frameResult = {
        ball: { bboxes: [], confidences: [], classIds: [] },
        meta: { source: 'no_data', frame_index: frameIdx },
        debug: { raw_count: 0, rejected: [], stage_counts: {} },
        raw: { bboxes: [], confidences: [] },
      }
      return
    }

    const input = {
      ball: {
        bboxes: cachedData.bboxes || [],
        confidences: cachedData.confidences || [],
        classIds: cachedData.classIds || [],
      },
      image: videoInfo,
      time: cachedData.time || frameIdx / (videoInfo.fps || 25),
    }

    try {
      const result = pipeline.processFrame(input)

      frameResult = {
        ...result,
        raw: {
          bboxes: cachedData.bboxes || [],
          confidences: cachedData.confidences || [],
        },
      }

      currentFrame = frameIdx

      // Load frame image
      if (videoId) {
        await loadFrameImageFromInference(frameIdx)
      }
    } catch (e) {
      console.error('Error processing cached frame:', e)
    }
  }

  // Load frame image from Python inference server
  async function loadFrameImageFromInference(frameIdx) {
    if (!videoId) return

    try {
      const res = await fetch(`${INFERENCE_API}/video/${videoId}/frame/${frameIdx}`)
      if (res.ok) {
        const blob = await res.blob()
        const url = URL.createObjectURL(blob)

        const img = new Image()
        img.onload = () => {
          frameImage = img
        }
        img.src = url
      }
    } catch (e) {
      console.error('Failed to load frame image:', e)
    }
  }

  // Load frame image from server
  async function loadFrameImage(frameIdx) {
    if (!videoLoaded) return

    try {
      const res = await fetch(`${API_BASE}/api/frame/${frameIdx}`)
      if (res.ok) {
        const blob = await res.blob()
        const url = URL.createObjectURL(blob)

        // Create image element
        const img = new Image()
        img.onload = () => {
          frameImage = img
        }
        img.src = url
      }
    } catch (e) {
      console.error('Failed to load frame image:', e)
    }
  }

  // Process frame locally
  function processFrame(frameIdx) {
    // If using live inference and frame is in cache, use cached version
    if (useLiveInference && detectionCache[frameIdx]) {
      processFrameFromCache(frameIdx)
      return
    }

    // Otherwise use pre-computed detections
    if (!detectionsData?.frames) {
      console.warn('No detection frames available')
      return
    }

    if (!pipeline) {
      console.warn('Pipeline not initialized')
      pipeline = createPipeline(config)
    }

    const frameData = detectionsData.frames.find(f => f.frame_idx === frameIdx)
      || detectionsData.frames[frameIdx]

    if (!frameData) {
      console.warn(`No frame data for frame ${frameIdx}`)
      frameResult = {
        ball: { bboxes: [], confidences: [], classIds: [] },
        meta: { source: 'no_data', frame_index: frameIdx },
        debug: { raw_count: 0, rejected: [], stage_counts: {} },
        raw: { bboxes: [], confidences: [] },
      }
      return
    }

    const input = {
      ball: {
        bboxes: frameData.bboxes || [],
        confidences: frameData.confidences || [],
        classIds: frameData.classIds || [],
      },
      image: videoInfo,
      time: frameData.time || frameIdx / (videoInfo.fps || 25),
    }

    try {
      const result = pipeline.processFrame(input)

      frameResult = {
        ...result,
        raw: {
          bboxes: frameData.bboxes || [],
          confidences: frameData.confidences || [],
        },
      }

      currentFrame = frameIdx

      // Load frame image if video is loaded
      if (videoLoaded) {
        if (useLiveInference && videoId) {
          loadFrameImageFromInference(frameIdx)
        } else {
          loadFrameImage(frameIdx)
        }
      }
    } catch (e) {
      console.error('Error processing frame:', e)
      showToast('Error processing frame: ' + e.message, 'error')
    }
  }

  // Playback controls
  function play() {
    if (!detectionsLoaded || isPlaying) return

    isPlaying = true
    const fps = videoInfo?.fps || 25
    const intervalMs = 1000 / (fps * playbackSpeed)

    playInterval = setInterval(() => {
      if (currentFrame >= totalFrames - 1) {
        stopPlayback()
        return
      }
      processFrame(currentFrame + 1)
    }, intervalMs)

    // Also tell server
    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'play', startFrame: currentFrame, speed: playbackSpeed }))
    }
  }

  function pause() {
    stopPlayback()
    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'pause' }))
    }
  }

  function stopPlayback() {
    isPlaying = false
    if (playInterval) {
      clearInterval(playInterval)
      playInterval = null
    }
  }

  function step(direction) {
    stopPlayback()
    const newFrame = Math.max(0, Math.min(currentFrame + direction, totalFrames - 1))
    processFrame(newFrame)
  }

  function seek(frame) {
    stopPlayback()
    pipeline.reset()
    processFrame(frame)
  }

  function setSpeed(speed) {
    playbackSpeed = speed
    if (isPlaying) {
      stopPlayback()
      play()
    }
  }

  // Config handling
  function handleConfigChange() {
    // Mark that config has changed
  }

  function handleApply() {
    pipeline.updateConfig(config)
    processFrame(currentFrame)
    showToast('Config applied', 'success')

    // Send to server
    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'update_config', config }))
    }
  }

  function handleReset() {
    config = cloneConfig(DEFAULT_CONFIG)
    pipeline.updateConfig(config)
    processFrame(currentFrame)
    showToast('Config reset to defaults', 'info')
  }

  function handleLoadPreset(key) {
    const preset = PRESETS[key]
    if (preset) {
      config = cloneConfig(preset.config)
      pipeline.updateConfig(config)
      processFrame(currentFrame)
      showToast(`Loaded preset: ${preset.name}`, 'success')
    }
  }

  async function handleSaveConfig(name) {
    try {
      const res = await fetch(`${API_BASE}/api/configs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, config }),
      })
      if (res.ok) {
        showToast('Config saved', 'success')
        fetchSavedConfigs()
      }
    } catch (e) {
      showToast('Failed to save: ' + e.message, 'error')
    }
  }

  async function handleLoadConfig(filename) {
    try {
      const res = await fetch(`${API_BASE}/api/configs/${filename}`)
      const data = await res.json()
      if (data.config) {
        config = cloneConfig(data.config)
        pipeline.updateConfig(config)
        processFrame(currentFrame)
        showToast(`Loaded: ${data.name}`, 'success')
      }
    } catch (e) {
      showToast('Failed to load: ' + e.message, 'error')
    }
  }

  async function handleDeleteConfig(filename) {
    try {
      await fetch(`${API_BASE}/api/configs/${filename}`, { method: 'DELETE' })
      showToast('Config deleted', 'info')
      fetchSavedConfigs()
    } catch (e) {
      showToast('Failed to delete: ' + e.message, 'error')
    }
  }

  function handleImportConfig(jsonString) {
    try {
      const parsed = JSON.parse(jsonString)
      const newConfig = parsed.config || parsed
      config = cloneConfig({ ...DEFAULT_CONFIG, ...newConfig })
      pipeline.updateConfig(config)
      processFrame(currentFrame)
      showToast('Config imported', 'success')
    } catch (e) {
      showToast('Invalid JSON: ' + e.message, 'error')
    }
  }

  function handleExportLegacy() {
    const legacyString = toLegacyConfigString(config)

    // Copy to clipboard
    navigator.clipboard.writeText(legacyString).then(() => {
      showToast('Legacy config copied to clipboard', 'success')
    }).catch(() => {
      // Fallback: download as file
      const blob = new Blob([legacyString], { type: 'text/javascript' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'FILTER_CONFIG.js'
      a.click()
      URL.revokeObjectURL(url)
      showToast('Legacy config downloaded', 'success')
    })
  }
</script>

<div class="workbench">
  <!-- Header -->
  <header class="header">
    <!-- Animated background shimmer -->
    <div class="header-shimmer"></div>

    <div class="header-left">
      <!-- Animated logo mark -->
      <div class="logo-mark">
        <svg viewBox="0 0 40 40" class="logo-icon" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="logoGrad" x1="0" y1="0" x2="40" y2="40">
              <stop offset="0%" stop-color="var(--accent-light)" />
              <stop offset="100%" stop-color="var(--teal)" />
            </linearGradient>
            <radialGradient id="ballShine" cx="35%" cy="30%" r="65%">
              <stop offset="0%" stop-color="#ffffff" stop-opacity="0.35" />
              <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
            </radialGradient>
          </defs>
          <!-- Football body -->
          <circle cx="20" cy="20" r="17" fill="#f0f0f0" stroke="url(#logoGrad)" stroke-width="1.8" class="fb-body" />
          <!-- Pentagon patches (black) -->
          <polygon points="20,8 23.5,11.5 22,16 18,16 16.5,11.5" fill="#1a1a2e" class="fb-patch" />
          <polygon points="28,15 32,18 31,23 27,23 26,18" fill="#1a1a2e" class="fb-patch" />
          <polygon points="12,15 14,18 13,23 9,23 8,18" fill="#1a1a2e" class="fb-patch" />
          <polygon points="15,27 18,24 22,24 25,27 22,31 18,31" fill="#1a1a2e" class="fb-patch" />
          <!-- Seam lines connecting patches -->
          <line x1="16.5" y1="11.5" x2="14" y2="18" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" />
          <line x1="23.5" y1="11.5" x2="26" y2="18" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" />
          <line x1="22" y1="16" x2="22" y2="24" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" />
          <line x1="18" y1="16" x2="18" y2="24" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" />
          <line x1="27" y1="23" x2="25" y2="27" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" />
          <line x1="13" y1="23" x2="15" y2="27" stroke="#1a1a2e" stroke-width="0.7" opacity="0.5" />
          <!-- Shine overlay -->
          <circle cx="20" cy="20" r="17" fill="url(#ballShine)" />
          <!-- Scanning arc (animated, orbiting the ball) -->
          <circle cx="20" cy="20" r="19" fill="none" stroke="url(#logoGrad)" stroke-width="1.5" stroke-dasharray="12 108" stroke-linecap="round" class="logo-scan" opacity="0.6" />
        </svg>
      </div>

      <!-- Title group -->
      <div class="title-group">
        <h1 class="app-title">
          <span class="title-text">Ball Detection</span>
          <span class="title-separator">·</span>
          <span class="title-accent">Filter Tuning</span>
        </h1>
        <span class="app-subtitle">RF-DETR Workbench</span>
      </div>

      <!-- Status badges row -->
      <div class="status-badges">
        <span class="hdr-badge" class:hdr-badge-online={wsConnected} class:hdr-badge-offline={!wsConnected}>
          <span class="hdr-badge-dot" class:dot-pulse={wsConnected}></span>
          {wsConnected ? 'Connected' : 'Offline'}
        </span>
        {#if inferenceAvailable}
          <span class="hdr-badge hdr-badge-rfdetr">
            <svg viewBox="0 0 16 16" class="badge-icon"><path d="M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1zm3.16 4.78l-3.5 5a.75.75 0 0 1-1.12.13l-2-1.75a.75.75 0 0 1 .98-1.14l1.36 1.19 2.98-4.25a.75.75 0 0 1 1.3.76z" fill="currentColor"/></svg>
            RF-DETR Ready
          </span>
        {/if}
        {#if videoLoaded}
          <span class="hdr-badge hdr-badge-res">
            <svg viewBox="0 0 16 16" class="badge-icon"><path d="M2 3.5A1.5 1.5 0 013.5 2h9A1.5 1.5 0 0114 3.5v9a1.5 1.5 0 01-1.5 1.5h-9A1.5 1.5 0 012 12.5v-9zM3.5 3a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5h-9z" fill="currentColor"/></svg>
            {videoInfo.width}×{videoInfo.height}
          </span>
        {/if}
        {#if useLiveInference}
          <span class="hdr-badge hdr-badge-live">
            <span class="live-dot"></span>
            Live
          </span>
          {#if cacheSize > 0}
            <span class="hdr-badge hdr-badge-cache">
              <svg viewBox="0 0 16 16" class="badge-icon"><path d="M2.5 4a.5.5 0 01.5-.5h10a.5.5 0 01.5.5v1a.5.5 0 01-.5.5H3a.5.5 0 01-.5-.5V4zm0 3.5a.5.5 0 01.5-.5h10a.5.5 0 01.5.5v1a.5.5 0 01-.5.5H3a.5.5 0 01-.5-.5v-1zm0 3.5a.5.5 0 01.5-.5h10a.5.5 0 01.5.5v1a.5.5 0 01-.5.5H3a.5.5 0 01-.5-.5v-1z" fill="currentColor"/></svg>
              {cacheSize} cached
            </span>
          {/if}
        {/if}
        {#if detectionsLoaded && !useLiveInference}
          <span class="hdr-badge hdr-badge-frames">
            <svg viewBox="0 0 16 16" class="badge-icon"><path d="M1 4.5A2.5 2.5 0 013.5 2h9A2.5 2.5 0 0115 4.5v7a2.5 2.5 0 01-2.5 2.5h-9A2.5 2.5 0 011 11.5v-7zM3.5 3A1.5 1.5 0 002 4.5v7A1.5 1.5 0 003.5 13h9a1.5 1.5 0 001.5-1.5v-7A1.5 1.5 0 0012.5 3h-9zM5 8l2.5-2 2.5 2 2.5-3v5H3V9l2-1z" fill="currentColor"/></svg>
            {totalFrames} frames
          </span>
        {/if}
      </div>
    </div>

    <div class="header-right">
      <label class="hdr-btn hdr-btn-video">
        <span class="hdr-btn-icon">
          <svg viewBox="0 0 24 24"><path d="M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4h-4z" fill="currentColor"/></svg>
        </span>
        <span class="hdr-btn-label">{videoLoaded ? videoFilename : 'Upload Video'}</span>
        <input
          type="file"
          accept="video/*"
          bind:this={videoInput}
          onchange={handleVideoUpload}
          style="display: none"
        />
      </label>

      <label class="hdr-btn hdr-btn-detect">
        <span class="hdr-btn-icon">
          <svg viewBox="0 0 24 24"><path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z" fill="currentColor"/></svg>
        </span>
        <span class="hdr-btn-label">Load Detections</span>
        <input
          type="file"
          accept=".json"
          bind:this={detectionsInput}
          onchange={handleDetectionsUpload}
          style="display: none"
        />
      </label>
    </div>
  </header>

  <!-- Main Content -->
  <div class="main-content">
    <!-- Left: Video Area -->
    <div class="video-area">
      <div class="video-canvas-wrapper">
        <VideoCanvas
          {frameResult}
          {videoInfo}
          {overlaySettings}
          {frameImage}
          {videoFile}
          videoReady={videoLoaded}
          {isProcessing}
          {processingProgress}
          {inferenceAvailable}
          {cacheSize}
          {currentFrame}
          {totalFrames}
          onStartDetection={handleStartDetectionFromCanvas}
          onStopDetection={stopLiveInference}
          onRestartDetection={handleRestartDetection}
          onSeekFrame={handleSeekCachedFrame}
        />
        <StatsHUD
          {frameResult}
          frameIndex={currentFrame}
          {totalFrames}
          {cacheSize}
          {isProcessing}
          mode={config.mode}
        />
      </div>

      <DebugOverlay
        bind:settings={overlaySettings}
      />

      {#if (detectionsLoaded || cacheSize > 0) && !isProcessing}
        <TransportBar
          {currentFrame}
          {totalFrames}
          {isPlaying}
          {playbackSpeed}
          disabled={!detectionsLoaded}
          onplay={play}
          onpause={pause}
          onstep={step}
          onseek={seek}
          onspeedchange={setSpeed}
        />
      {/if}
    </div>

    <!-- Right: Side Panel -->
    <div class="side-panel">
      <div class="tabs">
        <button
          class="tab"
          class:active={activeTab === 'filters'}
          onclick={() => activeTab = 'filters'}
        >
          Filters
        </button>
        <button
          class="tab"
          class:active={activeTab === 'config'}
          onclick={() => activeTab = 'config'}
        >
          Config
        </button>
      </div>

      <div class="tab-content">
        {#if activeTab === 'filters'}
          <FilterPanel
            bind:config={config}
            bind:mode={config.mode}
            disabled={false}
            onchange={handleConfigChange}
            onapply={handleApply}
            onreset={handleReset}
            onloadpreset={handleLoadPreset}
          />
        {:else if activeTab === 'config'}
          <ConfigManager
            {config}
            {savedConfigs}
            onsave={handleSaveConfig}
            onload={handleLoadConfig}
            onimport={handleImportConfig}
            onexportlegacy={handleExportLegacy}
            onreset={handleReset}
            onrefreshconfigs={fetchSavedConfigs}
            ondeleteconfig={handleDeleteConfig}
          />
        {/if}
      </div>
    </div>
  </div>

  <!-- Toast -->
  {#if toast}
    <div class="toast-container">
      <div class="toast toast-{toast.type}">
        {toast.message}
      </div>
    </div>
  {/if}
</div>

<style>
  .workbench {
    display: flex;
    flex-direction: column;
    height: 100vh;
    overflow: hidden;
  }

  .header {
    position: relative;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 19px var(--space-lg);
    background: linear-gradient(135deg, #0d1117 0%, #131922 40%, #0f1a2e 100%);
    border-bottom: 1px solid rgba(59, 130, 246, 0.15);
    overflow: hidden;
    z-index: 10;
  }

  /* Animated shimmer sweep across header */
  .header-shimmer {
    position: absolute;
    inset: 0;
    background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(59, 130, 246, 0.03) 25%,
      rgba(20, 184, 166, 0.04) 50%,
      rgba(59, 130, 246, 0.03) 75%,
      transparent 100%
    );
    background-size: 200% 100%;
    animation: headerShimmer 8s ease-in-out infinite;
    pointer-events: none;
  }

  @keyframes headerShimmer {
    0%, 100% { background-position: 200% 0; }
    50% { background-position: -200% 0; }
  }

  .header-left {
    display: flex;
    align-items: center;
    gap: 14px;
    z-index: 1;
  }

  /* ── Logo Mark ── */
  .logo-mark {
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    filter: drop-shadow(0 0 8px rgba(59, 130, 246, 0.35));
    transition: transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1), filter 0.3s ease;
  }
  .logo-mark:hover {
    transform: scale(1.15) rotate(15deg);
    filter: drop-shadow(0 0 14px rgba(59, 130, 246, 0.55));
  }
  .logo-icon { width: 100%; height: 100%; }

  .fb-body {
    transition: fill 0.3s ease;
  }
  .logo-mark:hover .fb-body {
    fill: #fafafa;
  }

  .fb-patch {
    transition: fill 0.3s ease;
  }
  .logo-mark:hover .fb-patch {
    fill: #0f1a2e;
  }

  .logo-scan {
    animation: logoScanSpin 3s linear infinite;
    transform-origin: 20px 20px;
  }
  @keyframes logoScanSpin {
    to { transform: rotate(360deg); }
  }

  /* ── Title ── */
  .title-group {
    display: flex;
    flex-direction: column;
    gap: 1px;
  }
  .app-title {
    font-size: 1.05rem;
    font-weight: 700;
    letter-spacing: -0.01em;
    line-height: 1.2;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .title-text {
    background: linear-gradient(135deg, var(--text-primary) 0%, var(--accent-light) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
  .title-separator {
    color: var(--text-muted);
    opacity: 0.4;
    font-weight: 300;
  }
  .title-accent {
    background: linear-gradient(135deg, var(--teal-light) 0%, var(--accent-light) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
  .app-subtitle {
    font-size: 0.65rem;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    color: var(--text-muted);
    opacity: 0.6;
  }

  /* ── Status Badges ── */
  .status-badges {
    display: flex;
    gap: 6px;
    align-items: center;
    margin-left: 6px;
  }

  .hdr-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px;
    font-size: 0.68rem;
    font-weight: 600;
    letter-spacing: 0.02em;
    border-radius: var(--radius-full);
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.06);
    color: var(--text-secondary);
    backdrop-filter: blur(8px);
    transition: all 0.25s ease;
    white-space: nowrap;
  }
  .hdr-badge:hover {
    background: rgba(255, 255, 255, 0.08);
    border-color: rgba(255, 255, 255, 0.12);
    transform: translateY(-1px);
  }

  .badge-icon {
    width: 12px;
    height: 12px;
    flex-shrink: 0;
  }

  .hdr-badge-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--error);
    transition: background 0.3s ease;
    flex-shrink: 0;
  }
  .hdr-badge-online .hdr-badge-dot { background: var(--success); }
  .dot-pulse {
    animation: dotPulse 2s ease-in-out infinite;
    box-shadow: 0 0 4px var(--success);
  }
  @keyframes dotPulse {
    0%, 100% { box-shadow: 0 0 2px var(--success); transform: scale(1); }
    50% { box-shadow: 0 0 8px var(--success), 0 0 16px rgba(34, 197, 94, 0.3); transform: scale(1.3); }
  }

  .hdr-badge-online {
    color: var(--success);
    border-color: rgba(34, 197, 94, 0.2);
    background: rgba(34, 197, 94, 0.08);
  }
  .hdr-badge-offline {
    color: var(--error);
    border-color: rgba(239, 68, 68, 0.2);
    background: rgba(239, 68, 68, 0.08);
  }

  .hdr-badge-rfdetr {
    color: var(--teal-light);
    border-color: rgba(20, 184, 166, 0.2);
    background: rgba(20, 184, 166, 0.08);
    animation: badgeFadeIn 0.4s ease-out;
  }

  .hdr-badge-res {
    color: var(--purple);
    border-color: rgba(167, 139, 250, 0.2);
    background: rgba(167, 139, 250, 0.08);
    animation: badgeFadeIn 0.4s ease-out;
  }

  .hdr-badge-live {
    color: var(--rose);
    border-color: rgba(244, 114, 182, 0.25);
    background: rgba(244, 114, 182, 0.1);
    animation: badgeFadeIn 0.4s ease-out;
  }
  .live-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--rose);
    animation: liveBlink 1s ease-in-out infinite;
  }
  @keyframes liveBlink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
  }

  .hdr-badge-cache {
    color: var(--accent-light);
    border-color: rgba(59, 130, 246, 0.2);
    background: rgba(59, 130, 246, 0.08);
    animation: badgeFadeIn 0.4s ease-out;
  }

  .hdr-badge-frames {
    color: var(--info);
    border-color: rgba(59, 130, 246, 0.2);
    background: rgba(59, 130, 246, 0.08);
    animation: badgeFadeIn 0.4s ease-out;
  }

  @keyframes badgeFadeIn {
    from { opacity: 0; transform: translateY(-4px) scale(0.92); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }

  /* ── Header Buttons ── */
  .header-right {
    display: flex;
    gap: 10px;
    z-index: 1;
  }

  .hdr-btn {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    padding: 10px 20px;
    font-size: 0.88rem;
    font-weight: 600;
    border-radius: var(--radius-md);
    cursor: pointer;
    transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    white-space: nowrap;
  }
  .hdr-btn::before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: inherit;
    opacity: 0;
    transition: opacity 0.3s ease;
    pointer-events: none;
  }
  .hdr-btn:hover::before { opacity: 1; }
  .hdr-btn:active { transform: scale(0.97); }

  .hdr-btn-icon {
    display: flex;
    align-items: center;
  }
  .hdr-btn-icon svg {
    width: 20px;
    height: 20px;
    transition: transform 0.3s ease;
  }
  .hdr-btn:hover .hdr-btn-icon svg { transform: scale(1.12); }

  .hdr-btn-video {
    background: linear-gradient(135deg, rgba(167, 139, 250, 0.12) 0%, rgba(139, 92, 246, 0.08) 100%);
    border: 1px solid rgba(167, 139, 250, 0.2);
    color: var(--purple);
  }
  .hdr-btn-video::before {
    background: linear-gradient(135deg, rgba(167, 139, 250, 0.2) 0%, rgba(139, 92, 246, 0.15) 100%);
  }
  .hdr-btn-video:hover {
    border-color: rgba(167, 139, 250, 0.4);
    box-shadow: 0 0 20px rgba(167, 139, 250, 0.12), inset 0 0 20px rgba(167, 139, 250, 0.04);
  }

  .hdr-btn-detect {
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(20, 184, 166, 0.1) 100%);
    border: 1px solid rgba(59, 130, 246, 0.25);
    color: var(--accent-light);
  }
  .hdr-btn-detect::before {
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.25) 0%, rgba(20, 184, 166, 0.18) 100%);
  }
  .hdr-btn-detect:hover {
    border-color: rgba(59, 130, 246, 0.45);
    box-shadow: 0 0 20px rgba(59, 130, 246, 0.12), inset 0 0 20px rgba(59, 130, 246, 0.04);
  }

  .processing-indicator {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    background: var(--bg-2);
    border-radius: var(--radius);
    font-size: 0.875rem;
  }

  .spinner {
    width: 16px;
    height: 16px;
    border: 2px solid var(--border);
    border-top-color: var(--primary);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }

  @keyframes spin {
    to { transform: rotate(360deg); }
  }

  .main-content {
    display: flex;
    flex: 1;
    overflow: hidden;
  }

  .video-area {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
    padding: var(--space-sm) var(--space-md);
    min-width: 0;
  }

  .video-canvas-wrapper {
    position: relative;
    flex: 1 1 auto;
    min-height: 580px;
    display: flex;
    flex-direction: column;
  }

  .side-panel {
    width: 320px;
    min-width: 320px;
    display: flex;
    flex-direction: column;
    background: var(--panel-bg);
    border-left: 1px solid var(--border);
  }

  .tabs {
    display: flex;
    border-bottom: 1px solid var(--border);
  }

  .tab {
    flex: 1;
    padding: var(--space-md);
    font-weight: 500;
    color: var(--text-muted);
    text-align: center;
    transition: all 0.15s ease;
    border-bottom: 2px solid transparent;
    font-size: 0.88rem;
  }

  .tab:hover {
    color: var(--text-secondary);
    background: rgba(59, 130, 246, 0.05);
  }

  .tab.active {
    color: var(--accent-light);
    border-bottom-color: var(--accent);
    background: rgba(59, 130, 246, 0.04);
  }

  .tab-content {
    flex: 1;
    overflow-y: auto;
  }

  .toast-container {
    position: fixed;
    bottom: var(--space-lg);
    right: var(--space-lg);
    z-index: 1000;
  }

  .toast {
    padding: var(--space-md) var(--space-lg);
    background: var(--bg-2);
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-lg);
    animation: slideIn 0.3s ease;
  }

  .toast-success {
    border-left: 3px solid var(--success);
    color: var(--success);
  }

  .toast-error {
    border-left: 3px solid var(--error);
    color: var(--error);
  }

  .toast-info {
    border-left: 3px solid var(--info);
    color: var(--info);
  }

  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  /* Responsive */
  @media (max-width: 1024px) {
    .side-panel {
      width: 280px;
      min-width: 280px;
    }
  }

  @media (max-width: 768px) {
    .main-content {
      flex-direction: column;
    }

    .side-panel {
      width: 100%;
      max-height: 50vh;
    }
  }
</style>
