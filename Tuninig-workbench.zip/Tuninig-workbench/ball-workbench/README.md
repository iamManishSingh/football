# Ball Detection Filter Tuning Workbench

A visual tool for tuning RF-DETR ball detection filters in football videos.

## ✨ Two Modes of Operation

### Mode 1: Pre-computed Detections (Offline)
Generate detections first, then tune filters with instant replay.

### Mode 2: Live Inference (Real-time) 🆕
Upload video → RF-DETR processes live → Cache & tune → Instant replay.

**See [LIVE_INFERENCE_GUIDE.md](../LIVE_INFERENCE_GUIDE.md) for complete live mode documentation.**

## Quick Start

### 1. Install Dependencies

```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install

# Python (optional, for precompute)
cd ../python-bridge
pip install -r requirements.txt
```

### 2. Start the Servers

```bash
# Terminal 1: Backend
cd backend
npm run dev

# Terminal 2: Frontend
cd frontend
npm run dev

# Terminal 3 (optional, for live inference): Python server
cd python-bridge
python live_server.py
```

### 3. Open the Workbench

Open http://localhost:5173 in your browser.

### 4. Load Detection Data

**Option A: Pre-computed (Offline)**
Click "Load Detections" and select either:
- `sample_detections.json` (included test data)
- Your own detection JSON from `precompute.py`

**Option B: Live Inference (Real-time)** 🆕
1. Ensure Python server is running (Terminal 3)
2. Click "Upload Video (Live)"
3. Select video file
4. Choose time range to process
5. Click "Start/Resume Inference"
6. Watch live as RF-DETR processes each frame
7. Pause anytime to tune filters
8. Resume from cache (instant replay!)

See [LIVE_INFERENCE_GUIDE.md](../LIVE_INFERENCE_GUIDE.md) for detailed instructions.

## Features

- **Base Model / Filter-Tuned Toggle**: Switch between raw RF-DETR output and filtered results
- **8 Filter Groups**: Basic, ROI, Appearance, Static, Tracking, Smoothing, Preprocessing, SAHI
- **Real-time Visualization**: See detected ball (green), rejected boxes (red), predictions (blue)
- **Playback Controls**: Play, pause, step frame-by-frame, seek, speed control
- **Config Management**: Save, load, export/import JSON configs
- **Presets**: 5 built-in presets for common scenarios
- **Legacy Export**: Generate `FILTER_CONFIG` for your existing pipeline

## Generating Detection Data

### Using RF-DETR (Python)

```bash
cd python-bridge
python precompute.py --video your_video.mp4 --output detections.json
```

Options:
- `--model base|large`: RF-DETR model variant
- `--threshold 0.10`: Detection threshold (keep low)
- `--start 120`: Start time in seconds
- `--end 210`: End time in seconds
- `--max-frames 1000`: Limit frames to process

### Detection JSON Format

```json
{
  "video_info": { "width": 1920, "height": 1080, "fps": 25.0, "total_frames": 1000 },
  "frames": [
    {
      "frame_idx": 0,
      "time": 0.0,
      "bboxes": [[x, y, width, height], ...],
      "confidences": [0.85, ...],
      "classIds": [32, ...]
    }
  ]
}
```

## Filter Groups

### Basic Filters
- **Confidence Threshold**: Reject weak detections
- **Rescue Threshold**: Lower threshold near predicted position
- **Size Filter**: Min/max ball area ratio
- **Aspect Ratio**: Ball is ~circular; shoes are elongated

### ROI / Pitch Mask
- **Exclude Top/Bottom**: Remove scoreboard/ad areas
- **Custom Polygon**: Define pitch boundaries

### Appearance
- **Circularity**: Reject elongated shapes
- **Color Validation**: Check whiteness
- **Player Overlap**: Reject detections overlapping players

### Static Object Rejection
- **History Window**: Frames to track
- **Cluster Radius**: Spatial grouping
- **Hit Ratio**: % threshold for rejection

### Kalman Tracking
- **Max Lost Frames**: Continue prediction duration
- **Gravity Model**: Parabolic arc for aerial balls
- **Search Radius**: Growing search area

### Trajectory Smoothing
- **EMA Alpha**: Position smoothing
- **Physics Validation**: Speed/acceleration limits

## Integration

### Using Config in Your Pipeline

```javascript
import { ballFilterStream } from './shared/ball-filter-rfdetr.js'
import { importConfig } from './shared/ball-filter-config.js'
import fs from 'fs'

// Load config exported from workbench
const configJson = fs.readFileSync('./my-config.json', 'utf-8')
const config = importConfig(configJson)

// Use in your pipeline
const stream = ballFilterStream(config)
```

### Legacy Export

For existing pipelines using `FILTER_CONFIG`:
1. Click "Export Legacy" in the Config tab
2. Copy the generated code
3. Paste into your `ball-filter-rfdetr.js`

## Architecture

```
ball-workbench/
├── shared/                 # Single source of truth
│   ├── ball-filter-rfdetr.js    # Filter pipeline
│   ├── ball-filter-config.js    # Config schema
│   └── ball-filter-utils.js     # Utility classes
├── backend/                # Node.js Express + WebSocket
├── frontend/               # SvelteKit app
└── python-bridge/          # RF-DETR inference
```

## Presets

| Preset | Use Case |
|--------|----------|
| Raw Model | Debug - shows all RF-DETR output |
| Light Filtering | Basic noise rejection |
| Broadcast Daytime | Professional footage, daylight |
| Broadcast Night | Professional footage, floodlights |
| Wide Angle / Amateur | Distant camera, small ball |

## License

MIT
