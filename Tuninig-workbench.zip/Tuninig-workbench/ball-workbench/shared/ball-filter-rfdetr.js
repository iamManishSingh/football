/**
 * ⚽ Ball Detection Post-Processing for RF-DETR — Enhanced Edition
 *
 * BACKWARD COMPATIBLE: Same interface as original
 *   ballFilterStream() → TransformStream
 *   data.ball = { bboxes, confidences, classIds }
 *
 * NEW APIs for Workbench:
 *   createPipeline(config) → BallFilterPipeline
 *   pipeline.processFrame(data) → { ball, meta, debug }
 *   pipeline.updateConfig(newConfig)
 *   pipeline.reset()
 *
 * Goal: reject obvious false positives (shoes, static white objects like corner
 * flags / pitch logos / ads) with configurable filter stages. Supports advanced
 * tracking and prediction for aerial ball recovery.
 *
 * Filter Stages:
 *  1. Confidence threshold  — drop weak detections
 *  2. Size + aspect ratio   — ball is small & ~circular; shoes are elongated
 *  3. ROI mask              — exclude scoreboard/ad areas
 *  4. Appearance            — circularity, color validation
 *  4.5. Static-object guard — objects stuck in the same spot
 *  5. Single ball selection — pick best candidate
 *  6. Kalman tracking       — predict through occlusions
 *  7. Trajectory smoothing  — EMA + physics validation
 */

import {
  DEFAULT_CONFIG,
  cloneConfig,
  mergeConfig,
  toLegacyConfig,
} from './ball-filter-config.js'

import {
  StaticRejecter,
  KalmanTracker,
  ROIMask,
  CircularityChecker,
  ColorValidator,
  TrajectoryValidator,
  bboxCenter,
  distance,
} from './ball-filter-utils.js'


// ============================================================================
// LEGACY CONFIG (for backward compatibility)
// ============================================================================

export const FILTER_CONFIG = {
  confidence_threshold: 0.25,
  min_ball_area_ratio: 0.000015,
  max_ball_area_ratio: 0.0048,
  min_aspect_ratio: 0.50,
  max_aspect_ratio: 1.9,
  enable_static_rejection: true,
  static_history_frames: 14,
  static_cluster_radius_px: 28,
  static_max_hit_ratio: 0.72,
  static_warmup_frames: 4,
  scene_cut_time_gap: 1.5,
  debug: false,
}


// ============================================================================
// BALL FILTER PIPELINE CLASS
// ============================================================================

/**
 * Main filter pipeline class for workbench and advanced use cases.
 * Provides per-frame processing with full debug output.
 */
export class BallFilterPipeline {
  constructor(config = null) {
    this.config = config ? cloneConfig(config) : cloneConfig(DEFAULT_CONFIG)
    this._initComponents()
    this.reset()
  }

  _initComponents() {
    const cfg = this.config.filter_groups

    // Initialize all filter components
    this.staticRejecter = new StaticRejecter(cfg.static?.params || {})
    this.kalmanTracker = new KalmanTracker(cfg.tracking?.params || {})
    this.roiMask = new ROIMask(cfg.roi?.params || {})
    this.circularityChecker = new CircularityChecker(cfg.appearance?.params || {})
    this.colorValidator = new ColorValidator(cfg.appearance?.params || {})
    this.trajectoryValidator = new TrajectoryValidator(cfg.smoothing?.params || {})

    // Set debug mode
    this._updateDebugMode()
  }

  _updateDebugMode() {
    const debug = this.config.debug
    this.staticRejecter.setDebug(debug)
    this.kalmanTracker.setDebug(debug)
    this.roiMask.setDebug(debug)
    this.circularityChecker.setDebug(debug)
    this.colorValidator.setDebug(debug)
    this.trajectoryValidator.setDebug(debug)
  }

  /**
   * Update configuration at runtime (hot-reload)
   */
  updateConfig(newConfig) {
    this.config = mergeConfig(this.config, newConfig)

    // Update component parameters
    const cfg = this.config.filter_groups
    this.staticRejecter.updateParams(cfg.static?.params || {})
    this.kalmanTracker.updateParams(cfg.tracking?.params || {})
    this.roiMask.updateParams(cfg.roi?.params || {})
    this.circularityChecker.updateParams(cfg.appearance?.params || {})
    this.colorValidator.updateParams(cfg.appearance?.params || {})
    this.trajectoryValidator.updateParams(cfg.smoothing?.params || {})

    this._updateDebugMode()
  }

  /**
   * Get current configuration copy
   */
  getConfig() {
    return cloneConfig(this.config)
  }

  /**
   * Reset all tracking state
   */
  reset() {
    this.frameIdx = 0
    this.lastTime = 0
    this.staticRejecter.reset()
    this.kalmanTracker.reset()
    this.trajectoryValidator.reset()
    this.stats = {
      totalFrames: 0,
      detectedFrames: 0,
      predictedFrames: 0,
      lostFrames: 0,
      totalRejected: 0,
    }
  }

  /**
   * Check if we're in base model mode (filters disabled)
   */
  isBaseMode() {
    return this.config.mode === "base_model"
  }

  /**
   * Process a single frame through the filter pipeline
   *
   * @param {object} data - Frame data
   * @param {object} data.ball - Raw detections { bboxes: [[x,y,w,h],...], confidences: [...] }
   * @param {object} data.image - Image info { width, height }
   * @param {number} data.time - Frame timestamp in seconds
   * @param {object} data.players - Optional player detections for overlap check
   * @returns {object} - { ball, meta, debug }
   */
  processFrame(data) {
    const image = data.image || { width: 1920, height: 1080 }
    const frameArea = image.width * image.height
    const time = data.time ?? 0

    // Scene cut detection - reset state on large time gap
    if (Math.abs(time - this.lastTime) > this.config.scene_cut_time_gap) {
      if (this.config.debug) {
        console.log(`[BALL] Scene cut (gap=${(time - this.lastTime).toFixed(2)}s) → reset`)
      }
      this.reset()
    }
    this.lastTime = time

    const rawBboxes = data.ball?.bboxes || []
    const rawConfs = data.ball?.confidences || []
    const rawClassIds = data.ball?.classIds || []

    const debug = {
      raw_count: rawBboxes.length,
      rejected: [],
      stage_counts: {
        raw: rawBboxes.length,
        after_basic: 0,
        after_roi: 0,
        after_appearance: 0,
        after_static: 0,
        final: 0,
      },
      kalman_predicted: null,
      velocity: null,
    }

    // In base model mode, return raw detections (model-level params are applied at inference time)
    if (this.isBaseMode()) {
      const result = this._selectBestDetection(rawBboxes, rawConfs, null)
      this.frameIdx++
      this.stats.totalFrames++
      if (result) this.stats.detectedFrames++
      else this.stats.lostFrames++

      debug.stage_counts.after_basic = rawBboxes.length

      return {
        ball: {
          bboxes: result ? [result.bbox] : [],
          confidences: result ? [result.conf] : [],
          classIds: result ? [37] : [],
        },
        meta: {
          source: result ? "detected" : "lost",
          frame_index: this.frameIdx - 1,
          track_age: 0,
          ball_position: result ? bboxCenter(result.bbox) : null,
        },
        debug,
      }
    }

    // ── Stage 3: Basic Filters ─────────────────────────────────────────────
    let candidates = []
    const basicCfg = this.config.filter_groups.basic
    const basicEnabled = basicCfg?.enabled !== false

    for (let i = 0; i < rawBboxes.length; i++) {
      const bbox = rawBboxes[i]
      const conf = rawConfs[i]
      const classId = rawClassIds[i] ?? 32
      const center = bboxCenter(bbox)
      const area = bbox[2] * bbox[3]
      const aspectRatio = bbox[2] / Math.max(bbox[3], 1)

      if (basicEnabled) {
        const params = basicCfg.params

        // Get prediction for rescue threshold
        const prediction = this.kalmanTracker.state
          ? { x: this.kalmanTracker.state[0], y: this.kalmanTracker.state[1] }
          : null
        const nearPrediction = prediction && this.config.filter_groups.tracking?.enabled &&
          distance(center, prediction) <= params.rescue_radius_px

        // Confidence check (with rescue)
        const threshold = nearPrediction ? params.rescue_threshold : params.confidence_threshold
        if (conf < threshold) {
          debug.rejected.push({
            bbox, conf, classId,
            reason: `conf:${conf.toFixed(2)}<${threshold.toFixed(2)}`,
            stage: "basic"
          })
          this.stats.totalRejected++
          continue
        }

        // Size filter
        const areaRatio = area / frameArea
        if (areaRatio < params.min_ball_area_ratio || areaRatio > params.max_ball_area_ratio) {
          debug.rejected.push({
            bbox, conf, classId,
            reason: `area:${areaRatio.toFixed(6)}`,
            stage: "basic"
          })
          this.stats.totalRejected++
          continue
        }

        // Aspect ratio filter
        if (aspectRatio < params.min_aspect_ratio || aspectRatio > params.max_aspect_ratio) {
          debug.rejected.push({
            bbox, conf, classId,
            reason: `aspect:${aspectRatio.toFixed(2)}`,
            stage: "basic"
          })
          this.stats.totalRejected++
          continue
        }
      }

      candidates.push({ bbox, conf, classId, center, area, aspectRatio })
    }

    debug.stage_counts.after_basic = candidates.length

    // ── Stage 3E: ROI Filter ───────────────────────────────────────────────
    if (this.config.filter_groups.roi?.enabled) {
      candidates = candidates.filter(c => {
        if (!this.roiMask.isInsideROI(c.center.x, c.center.y, image.width, image.height)) {
          debug.rejected.push({
            bbox: c.bbox, conf: c.conf, classId: c.classId,
            reason: "outside_roi",
            stage: "roi"
          })
          this.stats.totalRejected++
          return false
        }
        return true
      })
    }

    debug.stage_counts.after_roi = candidates.length

    // ── Stage 4: Appearance Filters ────────────────────────────────────────
    if (this.config.filter_groups.appearance?.enabled) {
      const appearParams = this.config.filter_groups.appearance.params

      candidates = candidates.filter(c => {
        // Circularity check
        if (appearParams.circularity_enabled) {
          if (!this.circularityChecker.isCircular(c.bbox[2], c.bbox[3])) {
            debug.rejected.push({
              bbox: c.bbox, conf: c.conf, classId: c.classId,
              reason: `circularity:${this.circularityChecker.getCircularityScore(c.bbox[2], c.bbox[3]).toFixed(2)}`,
              stage: "appearance"
            })
            this.stats.totalRejected++
            return false
          }
        }

        // Color validation (requires image data)
        if (appearParams.color_validation_enabled) {
          if (!this.colorValidator.isValidColor(data.imageData, c.bbox)) {
            debug.rejected.push({
              bbox: c.bbox, conf: c.conf, classId: c.classId,
              reason: "color",
              stage: "appearance"
            })
            this.stats.totalRejected++
            return false
          }
        }

        // Player overlap check (requires player detections)
        if (appearParams.player_overlap_enabled && data.players?.bboxes) {
          // Check IoU with player bboxes - skip for now, needs implementation
        }

        return true
      })
    }

    debug.stage_counts.after_appearance = candidates.length

    // ── Stage 4.5: Static Object Rejection ─────────────────────────────────
    if (this.config.filter_groups.static?.enabled) {
      candidates = candidates.filter(c => {
        if (this.staticRejecter.isStatic(c.center.x, c.center.y, this.frameIdx)) {
          debug.rejected.push({
            bbox: c.bbox, conf: c.conf, classId: c.classId,
            reason: "static",
            stage: "static"
          })
          this.stats.totalRejected++
          return false
        }
        return true
      })
    }

    debug.stage_counts.after_static = candidates.length

    // ── Stage 5: Single Ball Selection ─────────────────────────────────────
    const prediction = this.kalmanTracker.state
      ? { x: this.kalmanTracker.state[0], y: this.kalmanTracker.state[1] }
      : null

    debug.kalman_predicted = prediction

    const selected = this._selectBestDetection(
      candidates.map(c => c.bbox),
      candidates.map(c => c.conf),
      prediction
    )

    // Check max jump distance
    let validSelection = selected
    if (selected && prediction && this.config.selection.max_jump_distance) {
      const dist = distance(bboxCenter(selected.bbox), prediction)
      if (dist > this.config.selection.max_jump_distance) {
        if (this.config.debug) {
          console.log(`[BALL] max jump exceeded: ${dist.toFixed(0)} > ${this.config.selection.max_jump_distance}`)
        }
        validSelection = null
      }
    }

    debug.stage_counts.final = validSelection ? 1 : 0

    // ── Stage 6: Kalman Tracking ───────────────────────────────────────────
    let trackingResult = { source: "detected", position: null, velocity: null }

    if (this.config.filter_groups.tracking?.enabled) {
      const measurement = validSelection
        ? { ...bboxCenter(validSelection.bbox), confidence: validSelection.conf }
        : null
      trackingResult = this.kalmanTracker.processFrame(measurement)

      if (trackingResult.velocity) {
        debug.velocity = trackingResult.velocity
      }
    }

    // ── Stage 7: Trajectory Smoothing ──────────────────────────────────────
    let finalPosition = validSelection ? bboxCenter(validSelection.bbox) : null

    if (this.config.filter_groups.smoothing?.enabled && finalPosition) {
      // Validate physics
      const validation = this.trajectoryValidator.validatePhysics(
        finalPosition.x, finalPosition.y, this.frameIdx
      )

      if (!validation.valid) {
        if (this.config.debug) {
          console.log(`[BALL] physics validation failed: ${validation.reason}`)
        }
        // Use prediction instead if physics fails
        if (prediction) {
          finalPosition = prediction
        }
      }

      // Apply smoothing
      finalPosition = this.trajectoryValidator.smooth(finalPosition.x, finalPosition.y)
    }

    // ── Build Output ───────────────────────────────────────────────────────
    this.frameIdx++
    this.stats.totalFrames++

    let source = "lost"
    let outputBall = { bboxes: [], confidences: [], classIds: [] }

    if (validSelection) {
      source = "detected"
      this.stats.detectedFrames++
      outputBall = {
        bboxes: [validSelection.bbox],
        confidences: [validSelection.conf],
        classIds: [37],
      }
    } else if (trackingResult.source === "predicted" && trackingResult.position) {
      source = "predicted"
      this.stats.predictedFrames++
      // Create synthetic bbox from predicted position
      const predPos = trackingResult.position
      const syntheticBbox = [predPos.x - 10, predPos.y - 10, 20, 20]
      outputBall = {
        bboxes: [syntheticBbox],
        confidences: [trackingResult.confidence],
        classIds: [37],
      }
      finalPosition = predPos
    } else {
      this.stats.lostFrames++
    }

    return {
      ball: outputBall,
      meta: {
        source,
        frame_index: this.frameIdx - 1,
        track_age: this.kalmanTracker.trackAge,
        ball_position: finalPosition,
      },
      debug,
    }
  }

  /**
   * Select the best detection from candidates
   */
  _selectBestDetection(bboxes, confs, prediction) {
    if (bboxes.length === 0) return null
    if (bboxes.length === 1) return { bbox: bboxes[0], conf: confs[0] }

    const method = this.config.selection?.method || "highest_conf"

    if (method === "highest_conf" || !prediction) {
      // Simple: pick highest confidence
      let bestIdx = 0
      let bestConf = confs[0]
      for (let i = 1; i < confs.length; i++) {
        if (confs[i] > bestConf) {
          bestConf = confs[i]
          bestIdx = i
        }
      }
      return { bbox: bboxes[bestIdx], conf: confs[bestIdx] }
    }

    if (method === "weighted") {
      const weights = this.config.selection.weights || { proximity: 0.4, confidence: 0.4, shape: 0.2 }

      let bestIdx = 0
      let bestScore = -Infinity

      for (let i = 0; i < bboxes.length; i++) {
        const center = bboxCenter(bboxes[i])
        const dist = distance(center, prediction)

        // Normalize distance to 0-1 score (closer = higher)
        const proximityScore = Math.max(0, 1 - dist / 200)

        // Confidence is already 0-1
        const confScore = confs[i]

        // Shape score based on aspect ratio
        const ar = bboxes[i][2] / Math.max(bboxes[i][3], 1)
        const shapeScore = 1 - Math.abs(1 - ar)

        const totalScore =
          weights.proximity * proximityScore +
          weights.confidence * confScore +
          weights.shape * shapeScore

        if (totalScore > bestScore) {
          bestScore = totalScore
          bestIdx = i
        }
      }

      return { bbox: bboxes[bestIdx], conf: confs[bestIdx] }
    }

    // Default: highest confidence
    return { bbox: bboxes[0], conf: confs[0] }
  }

  /**
   * Get current statistics
   */
  getStats() {
    return { ...this.stats }
  }
}


// ============================================================================
// FACTORY FUNCTION
// ============================================================================

/**
 * Create a new filter pipeline instance
 * @param {object} config - Configuration object (uses DEFAULT_CONFIG if null)
 * @returns {BallFilterPipeline}
 */
export function createPipeline(config = null) {
  return new BallFilterPipeline(config)
}


// ============================================================================
// TRANSFORM STREAM — BACKWARD COMPATIBLE
// ============================================================================

/**
 * Creates a TransformStream that applies lightweight false-positive rejection.
 * BACKWARD COMPATIBLE: Same interface as original.
 *
 * Input:  data.ball.{ bboxes, confidences }, data.image
 * Output: data.ball replaced with filtered { bboxes, confidences, classIds }
 *         At most one detection per frame (highest-confidence survivor).
 *
 * @param {object} config - Optional configuration (uses legacy defaults if null)
 * @returns {TransformStream}
 */
export function ballFilterStream(config = null) {
  // If no config provided, use legacy behavior with FILTER_CONFIG
  const useLegacy = config === null

  // Convert legacy config or use provided config
  let pipelineConfig
  if (useLegacy) {
    // Create config from legacy FILTER_CONFIG for exact backward compatibility
    pipelineConfig = {
      ...DEFAULT_CONFIG,
      mode: "filter_tuned",
      filter_groups: {
        basic: {
          enabled: true,
          params: {
            confidence_threshold: FILTER_CONFIG.confidence_threshold,
            rescue_threshold: 0.15,
            rescue_radius_px: 80,
            min_ball_area_ratio: FILTER_CONFIG.min_ball_area_ratio,
            max_ball_area_ratio: FILTER_CONFIG.max_ball_area_ratio,
            min_aspect_ratio: FILTER_CONFIG.min_aspect_ratio,
            max_aspect_ratio: FILTER_CONFIG.max_aspect_ratio,
          }
        },
        roi: { enabled: false, params: {} },
        appearance: { enabled: false, params: {} },
        static: {
          enabled: FILTER_CONFIG.enable_static_rejection,
          params: {
            history_frames: FILTER_CONFIG.static_history_frames,
            cluster_radius_px: FILTER_CONFIG.static_cluster_radius_px,
            max_hit_ratio: FILTER_CONFIG.static_max_hit_ratio,
            warmup_frames: FILTER_CONFIG.static_warmup_frames,
          }
        },
        tracking: { enabled: false, params: {} },
        smoothing: { enabled: false, params: {} },
        preprocessing: { enabled: false, params: {} },
        sahi: { enabled: false, params: {} },
      },
      scene_cut_time_gap: FILTER_CONFIG.scene_cut_time_gap,
      debug: FILTER_CONFIG.debug,
    }
  } else {
    pipelineConfig = config
  }

  const pipeline = new BallFilterPipeline(pipelineConfig)

  return new TransformStream({
    transform(data, controller) {
      const result = pipeline.processFrame(data)

      // Replace ball data with filtered output
      data.ball = result.ball

      // Optionally attach debug info
      if (pipelineConfig.debug || data._includeDebug) {
        data._ballFilterDebug = result.debug
        data._ballFilterMeta = result.meta
      }

      controller.enqueue(data)
    },
  })
}


// ============================================================================
// EXPORTS
// ============================================================================

export default ballFilterStream
