/**
 * Ball Filter Configuration Schema, Defaults, Presets, and Utilities
 *
 * This module defines all tunable parameters for the ball detection filter pipeline.
 * The workbench and production pipeline both use this configuration format.
 */

// ============================================================================
// DEEP CLONE UTILITY (works in all environments)
// ============================================================================

/**
 * Deep clone an object using JSON serialization
 * Works in both Node.js and browser environments
 */
function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj))
}

// ============================================================================
// DEFAULT CONFIGURATION
// ============================================================================

export const DEFAULT_CONFIG = {
  // Mode: "base_model" shows raw RF-DETR output, "filter_tuned" applies filters
  mode: "filter_tuned",

  // Model-level settings (always applied)
  model: {
    threshold: 0.10,    // Low threshold for RF-DETR, filter later
    class_id: 32,       // COCO class ID for sports ball (also 37 in some models)
    nms_iou: 0.50,      // NMS IoU threshold — lower = more aggressive suppression
    image_size: 560,    // Inference resolution (RF-DETR supports 560, 640, 800, etc.)
  },

  // Filter groups - each has enabled flag and params
  filter_groups: {
    // Basic Filters (Stage 3)
    basic: {
      enabled: true,
      params: {
        confidence_threshold: 0.35,
        rescue_threshold: 0.15,
        rescue_radius_px: 80,
        min_ball_area_ratio: 0.000015,
        max_ball_area_ratio: 0.0048,
        min_aspect_ratio: 0.50,
        max_aspect_ratio: 1.90,
      }
    },

    // ROI / Pitch Mask (Stage 3E)
    roi: {
      enabled: false,
      params: {
        exclude_top_ratio: 0.08,
        exclude_bottom_ratio: 0.05,
        pitch_margin_pct: 5,
        // Custom polygon points (optional) - array of [x, y] normalized 0-1
        custom_polygon: null,
      }
    },

    // Appearance Filters (Stage 4)
    appearance: {
      enabled: false,
      params: {
        circularity_enabled: true,
        circularity_min: 0.4,
        color_validation_enabled: false,
        color_whiteness_threshold: 0.3,
        player_overlap_enabled: false,
        player_overlap_iou: 0.7,
      }
    },

    // Static Object Rejection (Stage 4.5)
    static: {
      enabled: true,
      params: {
        history_frames: 14,
        cluster_radius_px: 28,
        max_hit_ratio: 0.72,
        warmup_frames: 4,
      }
    },

    // Kalman Tracking (Stage 6)
    tracking: {
      enabled: false,
      params: {
        max_lost_frames: 60,
        gravity_enabled: true,
        gravity_strength: 0.5,
        search_radius_base: 50,
        search_radius_growth: 5,
        confidence_decay_rate: 0.02,
        process_noise: 0.03,
        measurement_noise: 0.1,
      }
    },

    // Trajectory Smoothing (Stage 7)
    smoothing: {
      enabled: false,
      params: {
        ema_alpha: 0.7,
        interpolation_max_gap: 20,
        max_valid_speed_px: 80,
        max_valid_accel_px: 40,
      }
    },

    // Preprocessing (Stage 1)
    preprocessing: {
      enabled: false,
      params: {
        clahe_enabled: true,
        clahe_clip_limit: 2.0,
        sharpen_enabled: false,
        sharpen_strength: 0.3,
        gamma_enabled: false,
        gamma_value: 1.0,
      }
    },

    // SAHI Tiled Inference (Stage 2)
    sahi: {
      enabled: false,
      params: {
        slice_width: 640,
        slice_height: 640,
        overlap_px: 100,
        iou_threshold: 0.3,
      }
    },
  },

  // Single ball selection settings
  selection: {
    method: "weighted",  // "highest_conf" | "weighted" | "nearest_prediction"
    weights: {
      proximity: 0.4,
      confidence: 0.4,
      shape: 0.2,
    },
    max_jump_distance: 200,
  },

  // Scene cut detection
  scene_cut_time_gap: 1.5,

  // Debug output
  debug: false,
}


// ============================================================================
// PRESETS (built lazily to avoid initialization issues)
// ============================================================================

function createPresets() {
  const base = deepClone(DEFAULT_CONFIG)

  return {
    "raw_model": {
      name: "Raw Model (No Filters)",
      description: "Shows raw RF-DETR output with only class ID filtering",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "base_model",
        filter_groups: Object.fromEntries(
          Object.entries(DEFAULT_CONFIG.filter_groups).map(([key, group]) => [
            key,
            { ...deepClone(group), enabled: false }
          ])
        ),
      }
    },

    "light_filtering": {
      name: "Light Filtering",
      description: "Basic confidence and static rejection only",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          ...deepClone(DEFAULT_CONFIG.filter_groups),
          basic: { ...deepClone(DEFAULT_CONFIG.filter_groups.basic), enabled: true },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: false },
          appearance: { ...deepClone(DEFAULT_CONFIG.filter_groups.appearance), enabled: false },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: false },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: { ...deepClone(DEFAULT_CONFIG.filter_groups.preprocessing), enabled: false },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false },
        }
      }
    },

    "broadcast_daytime": {
      name: "Broadcast Daytime",
      description: "Optimized for professional broadcast footage in daylight",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.45,
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: { ...deepClone(DEFAULT_CONFIG.filter_groups.appearance), enabled: true },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: true },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: { ...deepClone(DEFAULT_CONFIG.filter_groups.preprocessing), enabled: false },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false },
        }
      }
    },

    "broadcast_night": {
      name: "Broadcast Night",
      description: "Optimized for professional broadcast footage under floodlights",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.30,
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: { ...deepClone(DEFAULT_CONFIG.filter_groups.appearance), enabled: true },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: true },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: true,
              clahe_clip_limit: 3.5,
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false },
        }
      }
    },

    "wide_angle_amateur": {
      name: "Wide Angle / Amateur",
      description: "For amateur footage with distant/small ball",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.25,
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: { ...deepClone(DEFAULT_CONFIG.filter_groups.appearance), enabled: false },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          tracking: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.tracking.params,
              max_lost_frames: 90,
            }
          },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: { ...deepClone(DEFAULT_CONFIG.filter_groups.preprocessing), enabled: false },
          sahi: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.sahi.params,
              slice_width: 480,
              slice_height: 480,
            }
          },
        }
      }
    },

    "harsh_shadows": {
      name: "Harsh Shadows",
      description: "Daytime with strong ground shadows causing false positives",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.40,
              min_aspect_ratio: 0.55,
              max_aspect_ratio: 1.80,
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.appearance.params,
              circularity_enabled: true,
              circularity_min: 0.50,
              color_validation_enabled: true,
              color_whiteness_threshold: 0.25,
            }
          },
          static: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.static.params,
              history_frames: 18,
              max_hit_ratio: 0.65,
              cluster_radius_px: 32,
            }
          },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: true },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: true,
              clahe_clip_limit: 2.5,
              gamma_enabled: true,
              gamma_value: 0.85,
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false },
        }
      }
    },

    "fog_haze": {
      name: "Fog / Haze",
      description: "Low visibility, washed-out colours from fog or mist",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        model: {
          ...DEFAULT_CONFIG.model,
          threshold: 0.08,
          image_size: 640,
        },
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.22,
              rescue_threshold: 0.10,
              rescue_radius_px: 100,
              min_ball_area_ratio: 0.000012,
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.appearance.params,
              circularity_enabled: true,
              circularity_min: 0.35,
              color_validation_enabled: false,
            }
          },
          static: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.static.params,
              history_frames: 20,
              max_hit_ratio: 0.78,
              warmup_frames: 6,
            }
          },
          tracking: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.tracking.params,
              max_lost_frames: 90,
              search_radius_base: 70,
              search_radius_growth: 8,
              process_noise: 0.05,
              measurement_noise: 0.15,
            }
          },
          smoothing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.smoothing.params,
              ema_alpha: 0.6,
              interpolation_max_gap: 30,
            }
          },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: true,
              clahe_clip_limit: 4.0,
              sharpen_enabled: true,
              sharpen_strength: 0.5,
              gamma_enabled: true,
              gamma_value: 0.75,
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false },
        }
      }
    },

    "bright_daylight": {
      name: "Bright Daylight",
      description: "Overexposed / high-glare conditions under strong sun",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.40,
              max_ball_area_ratio: 0.006,
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.appearance.params,
              circularity_enabled: true,
              circularity_min: 0.45,
              color_validation_enabled: true,
              color_whiteness_threshold: 0.40,
            }
          },
          static: { ...deepClone(DEFAULT_CONFIG.filter_groups.static), enabled: true },
          tracking: { ...deepClone(DEFAULT_CONFIG.filter_groups.tracking), enabled: true },
          smoothing: { ...deepClone(DEFAULT_CONFIG.filter_groups.smoothing), enabled: false },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: false,
              gamma_enabled: true,
              gamma_value: 1.25,
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false },
        }
      }
    },

    "mixed_conditions": {
      name: "Mixed / Varying Light",
      description: "Changing light, partial clouds, varying shadows throughout match",
      config: {
        ...deepClone(DEFAULT_CONFIG),
        mode: "filter_tuned",
        model: {
          ...DEFAULT_CONFIG.model,
          threshold: 0.08,
        },
        filter_groups: {
          basic: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.basic.params,
              confidence_threshold: 0.28,
              rescue_threshold: 0.12,
              rescue_radius_px: 90,
              min_aspect_ratio: 0.50,
              max_aspect_ratio: 1.95,
            }
          },
          roi: { ...deepClone(DEFAULT_CONFIG.filter_groups.roi), enabled: true },
          appearance: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.appearance.params,
              circularity_enabled: true,
              circularity_min: 0.38,
              color_validation_enabled: false,
            }
          },
          static: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.static.params,
              history_frames: 16,
              max_hit_ratio: 0.70,
            }
          },
          tracking: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.tracking.params,
              max_lost_frames: 75,
              search_radius_base: 60,
              process_noise: 0.04,
              measurement_noise: 0.12,
            }
          },
          smoothing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.smoothing.params,
              ema_alpha: 0.65,
              interpolation_max_gap: 25,
            }
          },
          preprocessing: {
            enabled: true,
            params: {
              ...DEFAULT_CONFIG.filter_groups.preprocessing.params,
              clahe_enabled: true,
              clahe_clip_limit: 3.0,
              gamma_enabled: true,
              gamma_value: 0.90,
            }
          },
          sahi: { ...deepClone(DEFAULT_CONFIG.filter_groups.sahi), enabled: false },
        }
      }
    },
  }
}

// Lazy-initialized presets
let _presets = null
export const PRESETS = new Proxy({}, {
  get(target, prop) {
    if (_presets === null) {
      _presets = createPresets()
    }
    return _presets[prop]
  },
  ownKeys() {
    if (_presets === null) {
      _presets = createPresets()
    }
    return Object.keys(_presets)
  },
  getOwnPropertyDescriptor(target, prop) {
    if (_presets === null) {
      _presets = createPresets()
    }
    return Object.getOwnPropertyDescriptor(_presets, prop)
  }
})


// ============================================================================
// PARAMETER METADATA (for UI rendering)
// ============================================================================

export const PARAM_METADATA = {
  basic: {
    label: "Basic Filters",
    icon: "filter",
    description: "Confidence, size, and aspect ratio filtering",
    params: {
      confidence_threshold: { label: "Confidence Threshold", min: 0.05, max: 0.95, step: 0.01, type: "range" },
      rescue_threshold: { label: "Rescue Threshold", min: 0.05, max: 0.50, step: 0.01, type: "range" },
      rescue_radius_px: { label: "Rescue Radius (px)", min: 20, max: 300, step: 5, type: "range" },
      min_ball_area_ratio: { label: "Min Ball Area Ratio", min: 0.000005, max: 0.001, step: 0.000005, type: "range" },
      max_ball_area_ratio: { label: "Max Ball Area Ratio", min: 0.001, max: 0.02, step: 0.0001, type: "range" },
      min_aspect_ratio: { label: "Min Aspect Ratio", min: 0.2, max: 0.9, step: 0.01, type: "range" },
      max_aspect_ratio: { label: "Max Aspect Ratio", min: 1.1, max: 3.0, step: 0.01, type: "range" },
    }
  },
  roi: {
    label: "ROI / Pitch Mask",
    icon: "crop",
    description: "Region of interest filtering",
    params: {
      exclude_top_ratio: { label: "Exclude Top Ratio", min: 0, max: 0.3, step: 0.01, type: "range" },
      exclude_bottom_ratio: { label: "Exclude Bottom Ratio", min: 0, max: 0.3, step: 0.01, type: "range" },
      pitch_margin_pct: { label: "Pitch Margin %", min: 0, max: 20, step: 1, type: "range" },
    }
  },
  appearance: {
    label: "Appearance Filters",
    icon: "eye",
    description: "Shape and color validation",
    params: {
      circularity_enabled: { label: "Circularity Check", type: "toggle" },
      circularity_min: { label: "Min Circularity", min: 0.1, max: 0.9, step: 0.01, type: "range" },
      color_validation_enabled: { label: "Color Validation", type: "toggle" },
      color_whiteness_threshold: { label: "Whiteness Threshold", min: 0.1, max: 0.8, step: 0.01, type: "range" },
      player_overlap_enabled: { label: "Player Overlap Check", type: "toggle" },
      player_overlap_iou: { label: "Player Overlap IoU", min: 0.3, max: 0.95, step: 0.01, type: "range" },
    }
  },
  static: {
    label: "Static Object Rejection",
    icon: "ban",
    description: "Reject stationary false positives",
    params: {
      history_frames: { label: "History Frames", min: 5, max: 60, step: 1, type: "range" },
      cluster_radius_px: { label: "Cluster Radius (px)", min: 5, max: 80, step: 1, type: "range" },
      max_hit_ratio: { label: "Max Hit Ratio", min: 0.3, max: 0.95, step: 0.01, type: "range" },
      warmup_frames: { label: "Warmup Frames", min: 1, max: 20, step: 1, type: "range" },
    }
  },
  tracking: {
    label: "Kalman Tracking",
    icon: "crosshair",
    description: "Prediction and tracking through occlusions",
    params: {
      max_lost_frames: { label: "Max Lost Frames", min: 10, max: 120, step: 5, type: "range" },
      gravity_enabled: { label: "Gravity Model", type: "toggle" },
      gravity_strength: { label: "Gravity Strength", min: 0.1, max: 3.0, step: 0.1, type: "range" },
      search_radius_base: { label: "Search Radius Base (px)", min: 10, max: 200, step: 5, type: "range" },
      search_radius_growth: { label: "Search Radius Growth", min: 1, max: 20, step: 1, type: "range" },
      confidence_decay_rate: { label: "Confidence Decay Rate", min: 0.005, max: 0.1, step: 0.005, type: "range" },
      process_noise: { label: "Process Noise", min: 0.005, max: 0.2, step: 0.005, type: "range" },
      measurement_noise: { label: "Measurement Noise", min: 0.01, max: 1.0, step: 0.01, type: "range" },
    }
  },
  smoothing: {
    label: "Trajectory Smoothing",
    icon: "trending-up",
    description: "Position smoothing and physics validation",
    params: {
      ema_alpha: { label: "EMA Alpha", min: 0.2, max: 0.98, step: 0.01, type: "range" },
      interpolation_max_gap: { label: "Max Interpolation Gap", min: 3, max: 60, step: 1, type: "range" },
      max_valid_speed_px: { label: "Max Valid Speed (px/frame)", min: 20, max: 200, step: 5, type: "range" },
      max_valid_accel_px: { label: "Max Valid Accel (px/frame²)", min: 5, max: 100, step: 5, type: "range" },
    }
  },
  preprocessing: {
    label: "Preprocessing",
    icon: "sliders",
    description: "Image enhancement for difficult conditions",
    params: {
      clahe_enabled: { label: "CLAHE Enhancement", type: "toggle" },
      clahe_clip_limit: { label: "CLAHE Clip Limit", min: 1.0, max: 6.0, step: 0.1, type: "range" },
      sharpen_enabled: { label: "Sharpening", type: "toggle" },
      sharpen_strength: { label: "Sharpen Strength", min: 0.1, max: 2.0, step: 0.1, type: "range" },
      gamma_enabled: { label: "Gamma Correction", type: "toggle" },
      gamma_value: { label: "Gamma Value", min: 0.3, max: 3.0, step: 0.1, type: "range" },
    }
  },
  sahi: {
    label: "SAHI (Tiled Inference)",
    icon: "grid",
    description: "Tiled inference for small ball detection",
    params: {
      slice_width: { label: "Slice Width", min: 200, max: 1200, step: 20, type: "range" },
      slice_height: { label: "Slice Height", min: 200, max: 1200, step: 20, type: "range" },
      overlap_px: { label: "Overlap (px)", min: 20, max: 300, step: 10, type: "range" },
      iou_threshold: { label: "IoU Threshold", min: 0.1, max: 0.7, step: 0.05, type: "range" },
    }
  },
}


// ============================================================================
// CONFIG UTILITIES
// ============================================================================

/**
 * Deep clone a config object
 * @param {object} config
 * @returns {object}
 */
export function cloneConfig(config) {
  return deepClone(config)
}

/**
 * Validate a config object against the schema
 * @param {object} config
 * @returns {{ valid: boolean, errors: string[] }}
 */
export function validateConfig(config) {
  const errors = []

  if (!config) {
    return { valid: false, errors: ["Config is null or undefined"] }
  }

  if (!["base_model", "filter_tuned"].includes(config.mode)) {
    errors.push(`Invalid mode: ${config.mode}`)
  }

  if (!config.filter_groups) {
    errors.push("Missing filter_groups")
  } else {
    for (const [groupName, groupMeta] of Object.entries(PARAM_METADATA)) {
      if (!config.filter_groups[groupName]) {
        errors.push(`Missing filter group: ${groupName}`)
        continue
      }
      const group = config.filter_groups[groupName]
      if (typeof group.enabled !== "boolean") {
        errors.push(`${groupName}.enabled must be boolean`)
      }
      if (!group.params) {
        errors.push(`${groupName}.params is missing`)
      }
    }
  }

  return { valid: errors.length === 0, errors }
}

/**
 * Merge a partial config update into a base config
 * @param {object} base
 * @param {object} partial
 * @returns {object}
 */
export function mergeConfig(base, partial) {
  const result = cloneConfig(base)

  if (partial.mode !== undefined) result.mode = partial.mode
  if (partial.debug !== undefined) result.debug = partial.debug
  if (partial.scene_cut_time_gap !== undefined) result.scene_cut_time_gap = partial.scene_cut_time_gap

  if (partial.model) {
    result.model = { ...result.model, ...partial.model }
  }

  if (partial.selection) {
    result.selection = { ...result.selection, ...partial.selection }
    if (partial.selection.weights) {
      result.selection.weights = { ...result.selection.weights, ...partial.selection.weights }
    }
  }

  if (partial.filter_groups) {
    for (const [groupName, groupUpdate] of Object.entries(partial.filter_groups)) {
      if (result.filter_groups[groupName]) {
        if (groupUpdate.enabled !== undefined) {
          result.filter_groups[groupName].enabled = groupUpdate.enabled
        }
        if (groupUpdate.params) {
          result.filter_groups[groupName].params = {
            ...result.filter_groups[groupName].params,
            ...groupUpdate.params,
          }
        }
      }
    }
  }

  return result
}

/**
 * Import a config from JSON string
 * @param {string} jsonString
 * @returns {object}
 */
export function importConfig(jsonString) {
  const parsed = JSON.parse(jsonString)

  // If it's a workbench-saved config with metadata, extract the config
  if (parsed.config && parsed.name) {
    return parsed.config
  }

  return parsed
}

/**
 * Export a config to JSON string (with metadata)
 * @param {object} config
 * @param {string} name
 * @returns {string}
 */
export function exportConfig(config, name = "custom") {
  return JSON.stringify({
    name,
    version: "1.0",
    created: new Date().toISOString(),
    config: cloneConfig(config),
  }, null, 2)
}

/**
 * Convert workbench config to legacy FILTER_CONFIG format
 * For backward compatibility with existing ball-filter-rfdetr.js
 * @param {object} config
 * @returns {object}
 */
export function toLegacyConfig(config) {
  const basic = config.filter_groups.basic.params
  const staticParams = config.filter_groups.static.params

  return {
    // Confidence
    confidence_threshold: basic.confidence_threshold,

    // Size ratios
    min_ball_area_ratio: basic.min_ball_area_ratio,
    max_ball_area_ratio: basic.max_ball_area_ratio,

    // Aspect ratio
    min_aspect_ratio: basic.min_aspect_ratio,
    max_aspect_ratio: basic.max_aspect_ratio,

    // Static rejection
    enable_static_rejection: config.filter_groups.static.enabled,
    static_history_frames: staticParams.history_frames,
    static_cluster_radius_px: staticParams.cluster_radius_px,
    static_max_hit_ratio: staticParams.max_hit_ratio,
    static_warmup_frames: staticParams.warmup_frames,

    // Scene cut
    scene_cut_time_gap: config.scene_cut_time_gap,

    // Debug
    debug: config.debug,
  }
}

/**
 * Generate legacy config string for copy-paste
 * @param {object} config
 * @returns {string}
 */
export function toLegacyConfigString(config) {
  const legacy = toLegacyConfig(config)
  return `export const FILTER_CONFIG = ${JSON.stringify(legacy, null, 2)}`
}

export default {
  DEFAULT_CONFIG,
  PRESETS,
  PARAM_METADATA,
  cloneConfig,
  validateConfig,
  mergeConfig,
  importConfig,
  exportConfig,
  toLegacyConfig,
  toLegacyConfigString,
}
