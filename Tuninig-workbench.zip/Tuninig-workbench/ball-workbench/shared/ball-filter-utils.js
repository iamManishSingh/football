/**
 * Ball Filter Utility Classes
 *
 * Stateful components used by the BallFilterPipeline:
 * - StaticRejecter: Rejects static objects that appear in the same position
 * - KalmanTracker: Predicts ball position through occlusions
 * - ROIMask: Region of interest filtering
 * - CircularityChecker: Shape validation
 * - TrajectoryValidator: Physics-based validation and smoothing
 */

// ============================================================================
// STATIC OBJECT REJECTER
// ============================================================================

/**
 * Tracks recent detection positions and rejects objects that stay in the same
 * position for too long (corner flags, logos, pitch markings, etc.)
 */
export class StaticRejecter {
  constructor(params = {}) {
    this.historyFrames = params.history_frames ?? 14
    this.clusterRadius = params.cluster_radius_px ?? 28
    this.maxHitRatio = params.max_hit_ratio ?? 0.72
    this.warmupFrames = params.warmup_frames ?? 4
    this._history = []
    this._debug = false
  }

  updateParams(params) {
    if (params.history_frames !== undefined) this.historyFrames = params.history_frames
    if (params.cluster_radius_px !== undefined) this.clusterRadius = params.cluster_radius_px
    if (params.max_hit_ratio !== undefined) this.maxHitRatio = params.max_hit_ratio
    if (params.warmup_frames !== undefined) this.warmupFrames = params.warmup_frames
  }

  setDebug(debug) {
    this._debug = debug
  }

  reset() {
    this._history = []
  }

  /**
   * Check if a detection at (cx, cy) appears to be a static object.
   * Records the detection into history regardless of result.
   *
   * @param {number} cx - Center X coordinate
   * @param {number} cy - Center Y coordinate
   * @param {number} frameIdx - Current frame index
   * @returns {boolean} True if the detection is likely static
   */
  isStatic(cx, cy, frameIdx) {
    // Prune entries outside the rolling window
    const minFrame = frameIdx - this.historyFrames
    this._history = this._history.filter(h => h.frameIdx >= minFrame)

    // Count distinct frames that had a detection near this spot
    const nearbyFrames = new Set()
    for (const h of this._history) {
      if (Math.hypot(h.cx - cx, h.cy - cy) <= this.clusterRadius) {
        nearbyFrames.add(h.frameIdx)
      }
    }

    // Record current detection
    this._history.push({ cx, cy, frameIdx })

    // Not enough history yet
    const framesInWindow = frameIdx - minFrame
    if (framesInWindow < this.warmupFrames) return false

    const hitRatio = nearbyFrames.size / framesInWindow

    if (this._debug && hitRatio >= this.maxHitRatio) {
      console.log(
        `[STATIC] reject cx=${Math.round(cx)} cy=${Math.round(cy)} ` +
        `hitRatio=${hitRatio.toFixed(2)} (${nearbyFrames.size}/${framesInWindow} frames)`
      )
    }

    return hitRatio >= this.maxHitRatio
  }
}


// ============================================================================
// KALMAN TRACKER
// ============================================================================

/**
 * Kalman filter for ball tracking and prediction.
 * State vector: [x, y, vx, vy]
 * Supports gravity model for aerial ball prediction.
 */
export class KalmanTracker {
  constructor(params = {}) {
    this.maxLostFrames = params.max_lost_frames ?? 60
    this.gravityEnabled = params.gravity_enabled ?? true
    this.gravityStrength = params.gravity_strength ?? 0.5
    this.searchRadiusBase = params.search_radius_base ?? 50
    this.searchRadiusGrowth = params.search_radius_growth ?? 5
    this.confidenceDecayRate = params.confidence_decay_rate ?? 0.02
    this.processNoise = params.process_noise ?? 0.03
    this.measurementNoise = params.measurement_noise ?? 0.1

    this._debug = false
    this.reset()
  }

  updateParams(params) {
    if (params.max_lost_frames !== undefined) this.maxLostFrames = params.max_lost_frames
    if (params.gravity_enabled !== undefined) this.gravityEnabled = params.gravity_enabled
    if (params.gravity_strength !== undefined) this.gravityStrength = params.gravity_strength
    if (params.search_radius_base !== undefined) this.searchRadiusBase = params.search_radius_base
    if (params.search_radius_growth !== undefined) this.searchRadiusGrowth = params.search_radius_growth
    if (params.confidence_decay_rate !== undefined) this.confidenceDecayRate = params.confidence_decay_rate
    if (params.process_noise !== undefined) this.processNoise = params.process_noise
    if (params.measurement_noise !== undefined) this.measurementNoise = params.measurement_noise
  }

  setDebug(debug) {
    this._debug = debug
  }

  reset() {
    // State vector [x, y, vx, vy]
    this.state = null
    // State covariance matrix (4x4)
    this.P = null
    // Track state
    this.initialized = false
    this.lostFrames = 0
    this.trackAge = 0
    this.confidence = 0
    this.lastMeasurement = null
  }

  /**
   * Initialize the tracker with a first measurement
   */
  initialize(x, y, confidence = 1.0) {
    this.state = [x, y, 0, 0]  // Start with zero velocity
    // Initial covariance - high uncertainty for velocity
    this.P = [
      [100, 0, 0, 0],
      [0, 100, 0, 0],
      [0, 0, 1000, 0],
      [0, 0, 0, 1000]
    ]
    this.initialized = true
    this.lostFrames = 0
    this.trackAge = 1
    this.confidence = confidence
    this.lastMeasurement = { x, y }
  }

  /**
   * Predict the next state (without measurement)
   */
  predict() {
    if (!this.initialized) return null

    const [x, y, vx, vy] = this.state
    const dt = 1  // Assume 1 frame

    // State transition
    let newVy = vy
    if (this.gravityEnabled) {
      newVy += this.gravityStrength  // Gravity pulls down
    }

    // Predicted state
    const predictedX = x + vx * dt
    const predictedY = y + newVy * dt

    // Update state
    this.state = [predictedX, predictedY, vx, newVy]

    // Update covariance (simplified)
    const q = this.processNoise
    for (let i = 0; i < 4; i++) {
      this.P[i][i] += q * 100
    }

    return { x: predictedX, y: predictedY, vx, vy: newVy }
  }

  /**
   * Update with a measurement
   */
  update(x, y, confidence = 1.0) {
    if (!this.initialized) {
      this.initialize(x, y, confidence)
      return
    }

    const [px, py, pvx, pvy] = this.state
    const r = this.measurementNoise

    // Kalman gain (simplified scalar approximation)
    const K = this.P[0][0] / (this.P[0][0] + r * 100)

    // Update state
    const newX = px + K * (x - px)
    const newY = py + K * (y - py)

    // Estimate velocity from position change
    const dt = 1
    const newVx = (newX - px) / dt * 0.5 + pvx * 0.5
    const newVy = (newY - py) / dt * 0.5 + pvy * 0.5

    this.state = [newX, newY, newVx, newVy]

    // Update covariance
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 4; j++) {
        this.P[i][j] *= (1 - K)
      }
    }

    // Update track state
    this.lostFrames = 0
    this.trackAge++
    this.confidence = confidence
    this.lastMeasurement = { x, y }

    if (this._debug) {
      console.log(
        `[KALMAN] update pos=(${x.toFixed(1)}, ${y.toFixed(1)}) ` +
        `vel=(${newVx.toFixed(1)}, ${newVy.toFixed(1)}) age=${this.trackAge}`
      )
    }
  }

  /**
   * Process a frame with optional measurement
   */
  processFrame(measurement = null) {
    // Predict first
    const prediction = this.predict()

    if (measurement) {
      // Update with measurement
      this.update(measurement.x, measurement.y, measurement.confidence ?? 1.0)
      return {
        position: { x: this.state[0], y: this.state[1] },
        velocity: { vx: this.state[2], vy: this.state[3] },
        source: "detected",
        prediction,
        confidence: this.confidence,
        trackAge: this.trackAge,
      }
    } else if (this.initialized) {
      // No measurement - use prediction
      this.lostFrames++
      this.confidence = Math.max(0, this.confidence - this.confidenceDecayRate)

      if (this.lostFrames > this.maxLostFrames) {
        // Track lost
        if (this._debug) {
          console.log(`[KALMAN] track lost after ${this.maxLostFrames} frames`)
        }
        return {
          position: null,
          velocity: null,
          source: "lost",
          prediction,
          confidence: 0,
          trackAge: this.trackAge,
        }
      }

      return {
        position: prediction ? { x: prediction.x, y: prediction.y } : null,
        velocity: prediction ? { vx: prediction.vx, vy: prediction.vy } : null,
        source: "predicted",
        prediction,
        confidence: this.confidence,
        trackAge: this.trackAge,
      }
    }

    return {
      position: null,
      velocity: null,
      source: "uninitialized",
      prediction: null,
      confidence: 0,
      trackAge: 0,
    }
  }

  /**
   * Get current search radius (grows when ball is lost)
   */
  getSearchRadius() {
    return this.searchRadiusBase + this.lostFrames * this.searchRadiusGrowth
  }

  /**
   * Check if a detection is within rescue distance of prediction
   */
  isWithinRescueDistance(x, y) {
    if (!this.initialized || !this.state) return false
    const dist = Math.hypot(x - this.state[0], y - this.state[1])
    return dist <= this.getSearchRadius()
  }
}


// ============================================================================
// ROI MASK
// ============================================================================

/**
 * Region of Interest filter - rejects detections outside the defined area
 */
export class ROIMask {
  constructor(params = {}) {
    this.excludeTopRatio = params.exclude_top_ratio ?? 0.08
    this.excludeBottomRatio = params.exclude_bottom_ratio ?? 0.05
    this.pitchMarginPct = params.pitch_margin_pct ?? 5
    this.customPolygon = params.custom_polygon ?? null
    this._debug = false
  }

  updateParams(params) {
    if (params.exclude_top_ratio !== undefined) this.excludeTopRatio = params.exclude_top_ratio
    if (params.exclude_bottom_ratio !== undefined) this.excludeBottomRatio = params.exclude_bottom_ratio
    if (params.pitch_margin_pct !== undefined) this.pitchMarginPct = params.pitch_margin_pct
    if (params.custom_polygon !== undefined) this.customPolygon = params.custom_polygon
  }

  setDebug(debug) {
    this._debug = debug
  }

  /**
   * Check if a point is inside the ROI
   */
  isInsideROI(cx, cy, frameWidth, frameHeight) {
    // Check top/bottom exclusion zones
    const topExclude = frameHeight * this.excludeTopRatio
    const bottomExclude = frameHeight * (1 - this.excludeBottomRatio)

    if (cy < topExclude || cy > bottomExclude) {
      if (this._debug) {
        console.log(`[ROI] reject cy=${Math.round(cy)} outside [${Math.round(topExclude)}, ${Math.round(bottomExclude)}]`)
      }
      return false
    }

    // Check custom polygon if defined
    if (this.customPolygon && this.customPolygon.length >= 3) {
      // Convert normalized coords to pixel coords
      const polygon = this.customPolygon.map(([nx, ny]) => [
        nx * frameWidth,
        ny * frameHeight
      ])

      if (!this._pointInPolygon(cx, cy, polygon)) {
        if (this._debug) {
          console.log(`[ROI] reject point (${Math.round(cx)}, ${Math.round(cy)}) outside custom polygon`)
        }
        return false
      }
    }

    return true
  }

  /**
   * Point-in-polygon test using ray casting
   */
  _pointInPolygon(x, y, polygon) {
    let inside = false
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const [xi, yi] = polygon[i]
      const [xj, yj] = polygon[j]

      if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) {
        inside = !inside
      }
    }
    return inside
  }

  /**
   * Get exclusion zones for visualization
   */
  getExclusionZones(frameWidth, frameHeight) {
    return {
      top: { y1: 0, y2: frameHeight * this.excludeTopRatio },
      bottom: { y1: frameHeight * (1 - this.excludeBottomRatio), y2: frameHeight },
    }
  }
}


// ============================================================================
// CIRCULARITY CHECKER
// ============================================================================

/**
 * Validates detection shape based on aspect ratio and circularity score
 */
export class CircularityChecker {
  constructor(params = {}) {
    this.enabled = params.circularity_enabled ?? true
    this.minCircularity = params.circularity_min ?? 0.4
    this._debug = false
  }

  updateParams(params) {
    if (params.circularity_enabled !== undefined) this.enabled = params.circularity_enabled
    if (params.circularity_min !== undefined) this.minCircularity = params.circularity_min
  }

  setDebug(debug) {
    this._debug = debug
  }

  /**
   * Calculate circularity score from aspect ratio
   * Score of 1.0 = perfect circle (aspect ratio = 1)
   * Score of 0.0 = very elongated
   */
  getCircularityScore(width, height) {
    const ar = width / Math.max(height, 1)
    // Score: 1 when ar=1, decreases as ar deviates from 1
    const score = 1 - Math.abs(1 - ar)
    return Math.max(0, Math.min(1, score))
  }

  /**
   * Check if a detection passes circularity filter
   */
  isCircular(width, height) {
    if (!this.enabled) return true

    const score = this.getCircularityScore(width, height)
    const passes = score >= this.minCircularity

    if (this._debug && !passes) {
      console.log(
        `[CIRC] reject w=${Math.round(width)} h=${Math.round(height)} ` +
        `score=${score.toFixed(2)} < ${this.minCircularity}`
      )
    }

    return passes
  }
}


// ============================================================================
// COLOR VALIDATOR
// ============================================================================

/**
 * Validates detection based on color (whiteness for typical football)
 * Note: This requires image data, which is optional in the workbench
 */
export class ColorValidator {
  constructor(params = {}) {
    this.enabled = params.color_validation_enabled ?? false
    this.whitenessThreshold = params.color_whiteness_threshold ?? 0.3
    this._debug = false
  }

  updateParams(params) {
    if (params.color_validation_enabled !== undefined) this.enabled = params.color_validation_enabled
    if (params.color_whiteness_threshold !== undefined) this.whitenessThreshold = params.color_whiteness_threshold
  }

  setDebug(debug) {
    this._debug = debug
  }

  /**
   * Check if a region is sufficiently white
   * Returns true if color validation is disabled or no image data
   */
  isValidColor(imageData, bbox) {
    if (!this.enabled || !imageData) return true

    // This would require extracting pixel data from the bbox region
    // For now, return true (pass) - actual implementation needs image data
    return true
  }
}


// ============================================================================
// TRAJECTORY VALIDATOR
// ============================================================================

/**
 * Validates and smooths ball trajectory using EMA and physics constraints
 */
export class TrajectoryValidator {
  constructor(params = {}) {
    this.emaAlpha = params.ema_alpha ?? 0.7
    this.maxGap = params.interpolation_max_gap ?? 20
    this.maxSpeed = params.max_valid_speed_px ?? 80
    this.maxAccel = params.max_valid_accel_px ?? 40

    this._debug = false
    this._history = []
    this._smoothedPosition = null
    this._lastVelocity = null
  }

  updateParams(params) {
    if (params.ema_alpha !== undefined) this.emaAlpha = params.ema_alpha
    if (params.interpolation_max_gap !== undefined) this.maxGap = params.interpolation_max_gap
    if (params.max_valid_speed_px !== undefined) this.maxSpeed = params.max_valid_speed_px
    if (params.max_valid_accel_px !== undefined) this.maxAccel = params.max_valid_accel_px
  }

  setDebug(debug) {
    this._debug = debug
  }

  reset() {
    this._history = []
    this._smoothedPosition = null
    this._lastVelocity = null
  }

  /**
   * Apply EMA smoothing to a position
   */
  smooth(x, y) {
    if (!this._smoothedPosition) {
      this._smoothedPosition = { x, y }
    } else {
      this._smoothedPosition = {
        x: this.emaAlpha * x + (1 - this.emaAlpha) * this._smoothedPosition.x,
        y: this.emaAlpha * y + (1 - this.emaAlpha) * this._smoothedPosition.y,
      }
    }
    return { ...this._smoothedPosition }
  }

  /**
   * Validate position based on physics constraints
   */
  validatePhysics(x, y, frameIdx) {
    if (this._history.length === 0) {
      this._history.push({ x, y, frameIdx })
      return { valid: true, reason: null }
    }

    const last = this._history[this._history.length - 1]
    const dt = frameIdx - last.frameIdx

    if (dt <= 0) {
      return { valid: true, reason: null }
    }

    // Calculate speed
    const dx = x - last.x
    const dy = y - last.y
    const dist = Math.hypot(dx, dy)
    const speed = dist / dt

    if (speed > this.maxSpeed) {
      if (this._debug) {
        console.log(
          `[TRAJ] invalid speed=${speed.toFixed(1)} > ${this.maxSpeed} ` +
          `(moved ${dist.toFixed(0)}px in ${dt} frames)`
        )
      }
      return { valid: false, reason: `speed:${speed.toFixed(0)}` }
    }

    // Calculate acceleration if we have velocity history
    if (this._lastVelocity) {
      const vx = dx / dt
      const vy = dy / dt
      const ax = (vx - this._lastVelocity.vx) / dt
      const ay = (vy - this._lastVelocity.vy) / dt
      const accel = Math.hypot(ax, ay)

      if (accel > this.maxAccel) {
        if (this._debug) {
          console.log(`[TRAJ] invalid accel=${accel.toFixed(1)} > ${this.maxAccel}`)
        }
        return { valid: false, reason: `accel:${accel.toFixed(0)}` }
      }

      this._lastVelocity = { vx, vy }
    } else {
      this._lastVelocity = { vx: dx / dt, vy: dy / dt }
    }

    // Keep limited history
    this._history.push({ x, y, frameIdx })
    if (this._history.length > 30) {
      this._history.shift()
    }

    return { valid: true, reason: null }
  }

  /**
   * Interpolate missing positions between two points
   */
  interpolate(start, end, numFrames) {
    if (numFrames > this.maxGap) {
      return null  // Gap too large
    }

    const positions = []
    for (let i = 1; i <= numFrames; i++) {
      const t = i / (numFrames + 1)
      positions.push({
        x: start.x + (end.x - start.x) * t,
        y: start.y + (end.y - start.y) * t,
        interpolated: true,
      })
    }
    return positions
  }

  /**
   * Get current velocity estimate
   */
  getVelocity() {
    return this._lastVelocity
  }
}


// ============================================================================
// GEOMETRY UTILITIES
// ============================================================================

/**
 * Calculate IoU (Intersection over Union) between two bounding boxes
 */
export function calculateIoU(box1, box2) {
  const [x1, y1, w1, h1] = box1
  const [x2, y2, w2, h2] = box2

  const xA = Math.max(x1, x2)
  const yA = Math.max(y1, y2)
  const xB = Math.min(x1 + w1, x2 + w2)
  const yB = Math.min(y1 + h1, y2 + h2)

  const interArea = Math.max(0, xB - xA) * Math.max(0, yB - yA)
  const box1Area = w1 * h1
  const box2Area = w2 * h2
  const unionArea = box1Area + box2Area - interArea

  return unionArea > 0 ? interArea / unionArea : 0
}

/**
 * Get center point of a bounding box
 */
export function bboxCenter(bbox) {
  return {
    x: bbox[0] + bbox[2] / 2,
    y: bbox[1] + bbox[3] / 2,
  }
}

/**
 * Calculate distance between two points
 */
export function distance(p1, p2) {
  return Math.hypot(p1.x - p2.x, p1.y - p2.y)
}


export default {
  StaticRejecter,
  KalmanTracker,
  ROIMask,
  CircularityChecker,
  ColorValidator,
  TrajectoryValidator,
  calculateIoU,
  bboxCenter,
  distance,
}
