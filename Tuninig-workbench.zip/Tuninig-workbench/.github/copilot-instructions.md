# Ball Detection Filter Tuning Workbench - AI Agent Instructions

## Project Overview

This is a **visual tuning workbench** for RF-DETR ball detection in football videos. It addresses 5 core challenges: false positives (shoes/heads), aerial ball loss, out-of-pitch detections, fast ball desync, and cross-video inconsistency.

**Critical Architectural Principle**: `shared/ball-filter-rfdetr.js` is the **single source of truth** for all filter logic. The workbench, backend, and production pipelines all import and use this exact same file. Only JSON configs move between environments—never duplicate filter logic.

## Architecture & Data Flow

```
Python (RF-DETR) → JSON detections → Node.js Backend (applies shared filters) ⇄ WebSocket ⇄ SvelteKit Frontend
                                     ↓
                              shared/ filter pipeline (single source of truth)
```

### Three-Layer System

1. **Frontend** (`ball-workbench/frontend/`): SvelteKit app with Svelte 5 runes (`$state`, `$derived`), custom CSS (no Tailwind)
2. **Backend** (`ball-workbench/backend/`): Node.js Express + WebSocket server, imports `shared/` filter pipeline
3. **Python Bridge** (`ball-workbench/python-bridge/`): RF-DETR inference (precompute or live), outputs detection JSON only

### Shared Filter Pipeline (`shared/`)

- **`ball-filter-rfdetr.js`**: `BallFilterPipeline` class with 8 filter stages (basic, ROI, appearance, static rejection, tracking, smoothing, preprocessing, SAHI)
- **`ball-filter-config.js`**: Config schema, `DEFAULT_CONFIG`, presets, serialization utilities
- **`ball-filter-utils.js`**: Stateful filter classes (`StaticRejecter`, `KalmanTracker`, `ROIMask`, etc.)

All three files use ES modules (`export`/`import`) and run in both Node.js and browser.

## Developer Workflows

### Starting the Workbench

```bash
# Terminal 1: Backend (port 3001 REST, 3002 WebSocket)
cd ball-workbench/backend
npm run dev  # Uses node --watch for auto-reload

# Terminal 2: Frontend (port 5173)
cd ball-workbench/frontend
npm run dev

# Terminal 3 (optional but recommended): Python inference server (port 8000)
cd ball-workbench/python-bridge
python live_server.py
```

**No build step needed** for shared files—both frontend and backend import directly via relative paths.

### Two Modes of Operation

#### Mode 1: Pre-computed Detections (Offline)

1. Generate detections first:
   ```bash
   cd ball-workbench/python-bridge
   python precompute.py --video match.mp4 --output detections.json \
     --threshold 0.10 --start 120 --end 210
   ```
2. Load `detections.json` in workbench via "Load Detections" button
3. **Instant replay** from frame 0 - all detections pre-cached
4. Tune filters, see results immediately

#### Mode 2: Live Inference (Real-time)

1. Start Python inference server (`python live_server.py`)
2. Click "Upload Video (Live)" in workbench
3. Select time range (start/end) for processing
4. Click "Start/Resume Inference"
5. **Watch live** as RF-DETR processes each frame → filters applied → results shown
6. Detections cached progressively in memory
7. Pause anytime, tune filters, resume from cache (**instant replay**)

**Key difference**: Mode 1 requires pre-processing, Mode 2 processes on-demand with progressive caching.

### Detection JSON Format

```json
{
  "video_info": { "width": 1920, "height": 1080, "fps": 25.0, "total_frames": 1000 },
  "frames": [
    { "frame_idx": 0, "time": 0.0, "bboxes": [[x,y,w,h]], "confidences": [0.85], "classIds": [32] }
  ]
}
```

### Live Inference Data Flow

```
User uploads video → Python server (/upload-video)
                  ↓
         Returns video_id + video_info
                  ↓
Frontend requests frame detection: /video/{id}/detect/{frame}
                  ↓
Python runs RF-DETR → returns raw detections
                  ↓
Frontend caches in detectionCache[frameIdx]
                  ↓
Frontend applies filters via BallFilterPipeline
                  ↓
Displays on canvas (green=detected, red=rejected)
                  ↓
User can pause, tune filters, replay from cache (instant)
```

### Testing Filter Changes

1. Edit `shared/ball-filter-rfdetr.js` or `shared/ball-filter-config.js`
2. Backend auto-reloads via `node --watch`
3. Frontend hot-reloads via Vite HMR
4. **No restart needed** unless changing WebSocket message structure

## Critical Patterns & Conventions

### Detection Cache Management

The workbench uses an in-memory cache for live inference:

```javascript
// Cache structure
detectionCache = {
  0: { frame_idx: 0, time: 0.0, bboxes: [...], confidences: [...], classIds: [...] },
  1: { frame_idx: 1, time: 0.04, bboxes: [...], confidences: [...], classIds: [...] },
  // ...
}

// Check if frame is cached
if (detectionCache[frameIdx]) {
  processFrameFromCache(frameIdx)  // Instant replay
} else if (useLiveInference) {
  fetchFrameDetection(frameIdx)    // Fetch from Python server
}
```

**Important**: Cache persists across filter changes. When user tunes filter sliders and clicks Apply, the same raw detections are re-processed through updated filters—no Python re-inference needed.

### Svelte 5 Runes (Not Stores in Components)

Use `$state` for reactive variables, `$derived` for computed values:

```javascript
let config = $state(cloneConfig(DEFAULT_CONFIG))
let pipeline = $state(null)
let stats = $derived.by(() => calculateStats(frameResult))
```

**Exception**: `frontend/src/lib/stores/` uses module-level stores for cross-component state (`config.svelte.js`, `pipeline.svelte.js`, `websocket.svelte.js`).

### Filter Configuration Updates

When adding a new filter parameter:

1. Update `DEFAULT_CONFIG` in `shared/ball-filter-config.js`
2. Add metadata to `PARAM_METADATA` (min, max, step, label, unit)
3. Implement filter logic in `BallFilterPipeline.processFrame()` in `shared/ball-filter-rfdetr.js`
4. UI automatically generates sliders from metadata—no manual UI code needed

### Filter Pipeline Flow

Each frame goes through 8 stages in `BallFilterPipeline.processFrame()`:

1. **Preprocessing** → 2. **SAHI** → 3. **Basic** (confidence, size, aspect ratio) → 3E. **ROI** → 4. **Appearance** (circularity, color, player overlap) → 4.5. **Static Rejection** → 5. **Single Ball Selection** → 6. **Kalman Tracking** → 7. **Trajectory Smoothing**

Each stage populates `debug.rejected` array with `{ bbox, reason, stage }` for visualization.

### WebSocket Messages

Backend → Frontend message types:
- `connected`: Initial state sync
- `frame_result`: Processed frame with `{ ball, meta, debug, raw }`
- `config_updated`: Config applied
- `playback_end`: Video finished

Frontend → Backend:
- `set_config`: Update filter config
- `seek_frame`: Jump to frame
- `play` / `pause` / `step`: Transport controls

### Mode Toggle: Base Model vs Filter-Tuned

`config.mode` controls display:
- `"base_model"`: Show raw RF-DETR detections (bypasses all filters)
- `"filter_tuned"`: Apply full filter pipeline

Frontend renders both but shows only active mode on canvas.

## Integration Points

### Production Pipeline Integration

Export tuned config from workbench:

```javascript
import { ballFilterStream } from './shared/ball-filter-rfdetr.js'
import { importConfig } from './shared/ball-filter-config.js'
import fs from 'fs'

const config = JSON.parse(fs.readFileSync('./tuned-config.json'))
const stream = ballFilterStream(config)  // Returns TransformStream
```

### Legacy Config Export

For existing pipelines using hardcoded `FILTER_CONFIG`:
1. Click "Export Legacy" in Config Manager
2. Copy generated code
3. Replace `FILTER_CONFIG` object in your pipeline

Generates code like:
```javascript
export const FILTER_CONFIG = {
  confidence_threshold: 0.35,
  min_ball_area_ratio: 0.000015,
  // ... all flattened params
}
```

## Common Pitfalls

### Don't Create Duplicate Filter Logic

❌ **Wrong**: Implementing filters in frontend or backend separately  
✅ **Right**: Always import and call `BallFilterPipeline` from `shared/ball-filter-rfdetr.js`

### Scene Cut Detection

Pipeline auto-resets state on time gaps > `scene_cut_time_gap` (default 1.5s). This prevents filter state leaking between scenes. If adding timestamp-dependent features, check `timeDelta` in `processFrame()`.

### Live Inference State Management

When switching between live and pre-computed modes:
- Set `useLiveInference = true` when uploading video to Python server
- Set `useLiveInference = false` when loading JSON detections
- `processFrame()` checks this flag to route to cache or JSON data
- Cache size shown in UI badge: `{cacheSize} cached`

### Progressive Caching During Live Playback

Live inference fills cache sequentially:
```javascript
for (let frameIdx = startFrame; frameIdx < endFrame; frameIdx++) {
  const frameResult = await fetchFrameDetection(frameIdx)
  detectionCache[frameIdx] = frameResult  // Cache raw detection
  await processFrameFromCache(frameIdx)    // Apply filters & display
  await delay(1000 / fps)                  // Maintain playback speed
}
```

User can stop at any time—cached frames remain available for instant replay.

### Static Object Rejection Warmup

`StaticRejecter` needs `warmup_frames` before rejecting. First N frames always pass through. Don't expect immediate rejection at video start.

### Kalman Tracker State

`KalmanTracker` maintains prediction state across frames. Call `pipeline.reset()` when loading new video or jumping to non-sequential frames (e.g., user seeks backward).

## File Naming & Structure

- Components: `PascalCase.svelte` (e.g., `VideoCanvas.svelte`)
- Stores: `kebab-case.svelte.js` (e.g., `config.svelte.js`)
- Shared logic: `kebab-case.js` (e.g., `ball-filter-rfdetr.js`)
- Backend: `kebab-case.js` (e.g., `frame-processor.js`)

## Dependencies & Versions

- **Frontend**: SvelteKit 2.0, Svelte 5.0, Vite 6.0
- **Backend**: Express 4.21, ws 8.18 (WebSocket), formdata-node (for proxying uploads)
- **Python**: rfdetr ≥1.1.0, opencv-python ≥4.8.0, fastapi, uvicorn

**Python server is optional**:
- **Pre-computed mode**: Works entirely offline with JSON file
- **Live mode**: Requires `live_server.py` running on port 8000
- Frontend checks `/health` endpoint and shows "RF-DETR Ready" badge when available

## Debugging Workflows

### Enable Debug Mode

Set `config.debug = true` to populate detailed `debug` objects:
- `debug.rejected`: Array of rejected detections with reasons
- `debug.stage_counts`: Counts per filter stage
- `debug.kalman_state`: Tracker position/velocity

### Canvas Overlays

Toggle overlays in `DebugOverlay.svelte`:
- Green box: Final detected ball
- Red boxes: Rejected detections (hover for reason)
- Blue box: Kalman prediction
- Orange polygon: ROI mask
- Yellow arrow: Velocity vector

### Backend Logs

Backend logs each processed frame:
```
Frame 42 | Raw: 5 → Basic: 3 → Static: 2 → Final: 1 | Mode: filter_tuned
```

## Key Files to Reference

- **Architecture**: `ball-workbench-requirements.md` (complete spec)
- **Filter stages**: `shared/ball-filter-rfdetr.js` lines 1-100 (docstring)
- **Config schema**: `shared/ball-filter-config.js` `DEFAULT_CONFIG`
- **Component structure**: `frontend/src/routes/+page.svelte` (main layout)
- **WebSocket protocol**: `backend/server.js` lines 400-500

## Video Processing Notes

- Videos stored in `uploads/` (gitignored)
- Frames extracted via ffmpeg (backend optional feature)
- Detection JSON typically 5-20MB for 1000 frames
- No video streaming—canvas draws from frame images fetched on demand
